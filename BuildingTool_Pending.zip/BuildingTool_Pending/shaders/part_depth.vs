#version 330

in vec3 vertexPosition;
in vec3 vertexNormal;

uniform mat4 mvp;
uniform mat4 matModel;
uniform mat4 lightSpaceMatrix;

out vec3 fragNormal;
out vec4 fragLightSpace;
out vec3 fragWorldPosition;

void main()
{
    vec4 worldPosition =
        matModel *
        vec4(vertexPosition, 1.0);

    fragNormal =
        normalize(
            transpose(
                inverse(
                    mat3(matModel)
                )
            ) * vertexNormal
        );

    fragWorldPosition =
        worldPosition.xyz;

    fragLightSpace =
        lightSpaceMatrix *
        worldPosition;

    gl_Position =
        mvp *
        vec4(vertexPosition, 1.0);
}