#version 330

in vec2 fragTexCoord;

uniform sampler2D texture0;
uniform vec2 texelSize;
uniform float blurStrength;

out vec4 finalColor;

void main()
{
    vec4 center =
        texture(
            texture0,
            fragTexCoord
        );

    if (blurStrength <= 0.001)
    {
        finalColor =
            center;

        return;
    }

    float radius =
        blurStrength;

    vec4 result =
        center * 0.227027;

    result +=
        texture(
            texture0,
            fragTexCoord +
            vec2(
                texelSize.x * radius,
                0.0
            )
        ) * 0.1945946;

    result +=
        texture(
            texture0,
            fragTexCoord -
            vec2(
                texelSize.x * radius,
                0.0
            )
        ) * 0.1945946;

    result +=
        texture(
            texture0,
            fragTexCoord +
            vec2(
                0.0,
                texelSize.y * radius
            )
        ) * 0.1945946;

    result +=
        texture(
            texture0,
            fragTexCoord -
            vec2(
                0.0,
                texelSize.y * radius
            )
        ) * 0.1945946;

    result +=
        texture(
            texture0,
            fragTexCoord +
            vec2(
                texelSize.x * radius,
                texelSize.y * radius
            )
        ) * 0.0470547;

    result +=
        texture(
            texture0,
            fragTexCoord +
            vec2(
                -texelSize.x * radius,
                texelSize.y * radius
            )
        ) * 0.0470547;

    result +=
        texture(
            texture0,
            fragTexCoord +
            vec2(
                texelSize.x * radius,
                -texelSize.y * radius
            )
        ) * 0.0470547;

    result +=
        texture(
            texture0,
            fragTexCoord -
            vec2(
                texelSize.x * radius,
                texelSize.y * radius
            )
        ) * 0.0470547;

    finalColor =
        result;
}