#version 330

in vec3 fragNormal;
in vec4 fragLightSpace;
in vec3 fragWorldPosition;

uniform sampler2D shadowMap;
uniform vec2 shadowMapTexelSize;

uniform vec4 colDiffuse;

uniform vec3 sunDirection;
uniform vec3 sunColor;

uniform vec3 ambientColor;
uniform vec3 outdoorAmbient;

uniform float sunIntensity;
uniform float ambientStrength;
uniform float brightness;
uniform float exposureCompensation;

uniform vec3 colorShiftTop;
uniform vec3 colorShiftBottom;

uniform vec3 fogColor;
uniform float fogStart;
uniform float fogEnd;

uniform vec3 cameraPosition;

uniform int globalShadows;
uniform int shadowSoftness; // Lighting preference (kept for API)
uniform int shadowFilterSize; // 0..7 denser taps inside fixed kernel width

// Part.Reflectance (0..1) — controls specular highlight strength
uniform float reflectance;
uniform float environmentSpecularScale;

// Multi local lights (Point / Spot / Surface)
#define MAX_LIGHTS 8
uniform int lightCount;
uniform vec3 lightPos[MAX_LIGHTS];
uniform vec3 lightColor[MAX_LIGHTS];
uniform vec3 lightDir[MAX_LIGHTS];
uniform float lightBrightness[MAX_LIGHTS];
uniform float lightRange[MAX_LIGHTS];
uniform float lightAngle[MAX_LIGHTS]; // full cone angle degrees
uniform int lightKind[MAX_LIGHTS];    // 0=point 1=spot 2=surface

out vec4 finalColor;

float getShadow()
{
    if (globalShadows == 0)
        return 0.0;

    vec3 projected = fragLightSpace.xyz / fragLightSpace.w;
    projected = projected * 0.5 + 0.5;

    if (projected.x < 0.0 || projected.x > 1.0 ||
        projected.y < 0.0 || projected.y > 1.0 ||
        projected.z < 0.0 || projected.z > 1.0)
        return 0.0;

    float currentDepth = projected.z;
    projected.xy = clamp(projected.xy, vec2(0.0), vec2(1.0));

    vec3 N = normalize(fragNormal);
    vec3 L = normalize(-sunDirection);
    float ndotl = max(dot(N, L), 0.0);
    float bias = max(0.0008 * (1.0 - ndotl), 0.00015);
    bias += (1.0 - ndotl) * 0.0015;

    // shadowFilterSize (from Game Graphics 1–6): denser sample grid only.
    // Kernel WIDTH stays fixed — higher quality = more points, smaller spacing.
    // 0 → 1 tap, 2 → 5x5, 3 → 7x7, 5 → 11x11, 7 → 15x15 inside same area.
    int density = clamp(shadowFilterSize, 0, 7);

    // Fixed kernel half-size in texels (same for all qualities)
    float kernelHalf = 1.5;

    // --- Hard: crisp edge; at higher density still stay inside a tiny kernel ---
    if (shadowSoftness == 1)
    {
        if (density <= 0)
        {
            float closestDepth = texture(shadowMap, projected.xy).r;
            return (currentDepth - bias > closestDepth) ? 1.0 : 0.0;
        }
        // Micro-AA only (very small fixed radius, more points when quality rises)
        float hardHalf = 0.55;
        float shadow = 0.0;
        float totalWeight = 0.0;
        int steps = density; // 1..7
        for (int x = -8; x <= 8; x++)
        {
            if (x < -steps || x > steps) continue;
            for (int y = -8; y <= 8; y++)
            {
                if (y < -steps || y > steps) continue;
                // Map grid into fixed hardHalf — denser grid = smaller step
                vec2 offset = vec2(float(x), float(y)) / float(steps)
                    * shadowMapTexelSize * hardHalf;
                float weight = 1.0 / (1.0 + float(x * x + y * y) * 0.25);
                float closestDepth = texture(shadowMap, projected.xy + offset).r;
                shadow += (currentDepth - bias > closestDepth ? 1.0 : 0.0) * weight;
                totalWeight += weight;
            }
        }
        return shadow / max(totalWeight, 0.0001);
    }

    // --- Sharp: contact-hardening; denser poisson inside fixed penumbra scale ---
    if (shadowSoftness == 2)
    {
        float blocker = 0.0;
        float blockerCount = 0.0;
        for (int x = -1; x <= 1; x++)
        {
            for (int y = -1; y <= 1; y++)
            {
                float d = texture(shadowMap, projected.xy + vec2(float(x), float(y)) * shadowMapTexelSize).r;
                if (d < currentDepth - bias)
                {
                    blocker += d;
                    blockerCount += 1.0;
                }
            }
        }
        float avgBlocker = (blockerCount > 0.5) ? (blocker / blockerCount) : currentDepth;
        // Fixed penumbra range — quality does not widen it
        float penumbra = clamp((currentDepth - avgBlocker) * 14.0, 0.6, 2.2);

        vec2 poisson[16] = vec2[](
            vec2(-0.94201624, -0.39906216),
            vec2( 0.94558609, -0.76890725),
            vec2(-0.09418410, -0.92938870),
            vec2( 0.34495938,  0.29387760),
            vec2(-0.91588581,  0.45771432),
            vec2(-0.81544232, -0.87912464),
            vec2(-0.38277543,  0.27676845),
            vec2( 0.97484398,  0.75648379),
            vec2( 0.44323325, -0.97511554),
            vec2( 0.53742981, -0.47373420),
            vec2(-0.26496911, -0.41893023),
            vec2( 0.79197514,  0.19090188),
            vec2(-0.24188840,  0.99706507),
            vec2(-0.81409955,  0.91437590),
            vec2( 0.19984126,  0.78641367),
            vec2( 0.14383161, -0.14100790)
        );
        // Use more poisson taps at higher density (up to 16)
        int taps = 4 + density * 2;
        if (taps > 16) taps = 16;
        float shadow = 0.0;
        for (int i = 0; i < 16; i++)
        {
            if (i >= taps) break;
            vec2 offset = poisson[i] * shadowMapTexelSize * penumbra;
            float closestDepth = texture(shadowMap, projected.xy + offset).r;
            shadow += (currentDepth - bias > closestDepth) ? 1.0 : 0.0;
        }
        return shadow / float(taps);
    }

    // --- Soft (default): fixed-width PCF, denser grid at higher quality ---
    {
        if (density <= 0)
        {
            float closestDepth = texture(shadowMap, projected.xy).r;
            return (currentDepth - bias > closestDepth) ? 1.0 : 0.0;
        }
        float shadow = 0.0;
        float totalWeight = 0.0;
        int steps = density; // 1..7 → more points inside same kernelHalf
        for (int x = -8; x <= 8; x++)
        {
            if (x < -steps || x > steps) continue;
            for (int y = -8; y <= 8; y++)
            {
                if (y < -steps || y > steps) continue;
                // Fixed outer radius kernelHalf — denser = smaller spacing
                vec2 offset = vec2(float(x), float(y)) / float(steps)
                    * shadowMapTexelSize * kernelHalf;
                float weight = 1.0 / (1.0 + float(x * x + y * y) * 0.3);
                float closestDepth = texture(shadowMap, projected.xy + offset).r;
                shadow += (currentDepth - bias > closestDepth ? 1.0 : 0.0) * weight;
                totalWeight += weight;
            }
        }
        return shadow / max(totalWeight, 0.0001);
    }
}

// Quadratic falloff matching Roblox-ish range lights
float rangeAttenuation(float dist, float range)
{
    if (range <= 0.001)
        return 0.0;
    float x = clamp(1.0 - (dist / range), 0.0, 1.0);
    return x * x;
}

// Spot / Surface cone factor (angle is full cone in degrees)
float coneFactor(vec3 toLight, vec3 dir, float angleDeg)
{
    float halfRad = radians(max(angleDeg, 1.0)) * 0.5;
    float cosOuter = cos(halfRad);
    float cosInner = cos(halfRad * 0.65);
    float cd = dot(normalize(-toLight), normalize(dir));
    return smoothstep(cosOuter, cosInner, cd);
}

vec3 evaluateLocalLights(vec3 normal, vec3 viewDir)
{
    vec3 total = vec3(0.0);
    float shininess = mix(8.0, 96.0, clamp(reflectance, 0.0, 1.0));
    float specStrength = reflectance * environmentSpecularScale;

    for (int i = 0; i < MAX_LIGHTS; i++)
    {
        if (i >= lightCount)
            break;

        vec3 toFrag = fragWorldPosition - lightPos[i];
        float dist = length(toFrag);
        float atten = rangeAttenuation(dist, lightRange[i]);
        if (atten <= 0.0)
            continue;

        vec3 L = normalize(-toFrag); // direction from frag to light
        float ndotl = max(dot(normal, L), 0.0);

        float cone = 1.0;
        if (lightKind[i] == 1 || lightKind[i] == 2)
            cone = coneFactor(toFrag, lightDir[i], lightAngle[i]);

        vec3 radiance =
            lightColor[i] *
            lightBrightness[i] *
            atten *
            cone;

        // Diffuse
        vec3 diffuse = radiance * ndotl;

        // Specular (Blinn-Phong) — reflectance controls strength
        vec3 H = normalize(L + viewDir);
        float ndoth = max(dot(normal, H), 0.0);
        float spec = pow(ndoth, shininess) * specStrength;
        vec3 specular = radiance * spec;

        total += diffuse + specular;
    }
    return total;
}

void main()
{
    vec3 normal =
        normalize(fragNormal);

    vec3 lightDirection =
        normalize(-sunDirection);

    float diffuse =
        max(
            dot(normal, lightDirection),
            0.0
        );

    float shadow =
        getShadow();

    float upward =
        clamp(
            normal.y * 0.5 + 0.5,
            0.0,
            1.0
        );

    vec3 environment =
        mix(
            ambientColor,
            outdoorAmbient,
            upward
        ) *
        ambientStrength;

    vec3 direct =
        sunColor *
        diffuse *
        sunIntensity *
        (1.0 - shadow);

    // Sun specular (reflectance)
    vec3 viewDir = normalize(cameraPosition - fragWorldPosition);
    float shininess = mix(8.0, 96.0, clamp(reflectance, 0.0, 1.0));
    float specStrength = reflectance * environmentSpecularScale;
    vec3 H = normalize(lightDirection + viewDir);
    float ndoth = max(dot(normal, H), 0.0);
    vec3 sunSpec =
        sunColor *
        pow(ndoth, shininess) *
        specStrength *
        sunIntensity *
        (1.0 - shadow);

    // Local Point / Spot / Surface lights
    vec3 local = evaluateLocalLights(normal, viewDir);

    float lighting =
        brightness;

    vec3 litColor =
        colDiffuse.rgb *
        (environment + direct + local) *
        lighting;

    litColor +=
        sunSpec *
        mix(vec3(1.0), colDiffuse.rgb, 0.35) *
        lighting;

    float shiftAmount =
        clamp(
            normal.y * 0.5 + 0.5,
            0.0,
            1.0
        );

    vec3 colorShift =
        mix(
            colorShiftBottom,
            colorShiftTop,
            shiftAmount
        );

    litColor +=
        colorShift *
        diffuse *
        0.25;

    litColor *=
        pow(
            2.0,
            exposureCompensation
        );

    litColor =
        clamp(
            litColor,
            0.0,
            1.0
        );

    float distanceToCamera =
        distance(
            fragWorldPosition,
            cameraPosition
        );

    float fogFactor =
        smoothstep(
            fogStart,
            max(
                fogEnd,
                fogStart + 0.001
            ),
            distanceToCamera
        );

    // Sky / fog tinted by a soft sun disk (view-ray vs -sunDirection).
    vec3 viewAway = normalize(fragWorldPosition - cameraPosition);
    vec3 toSun = normalize(-sunDirection);
    float sunAmount = pow(max(dot(viewAway, toSun), 0.0), 128.0);
    float sunHalo = pow(max(dot(viewAway, toSun), 0.0), 8.0);
    vec3 skyWithSun = fogColor
        + sunColor * sunAmount * 1.6
        + sunColor * sunHalo * 0.25 * sunIntensity;

    litColor =
        mix(
            litColor,
            skyWithSun,
            fogFactor
        );

    // Support Part.Transparency via colDiffuse.a
    finalColor =
        vec4(
            litColor,
            colDiffuse.a
        );
}