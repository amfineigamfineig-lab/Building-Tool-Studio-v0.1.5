// BuildingTool — thin driver. Main branches live in headers/.
// Include order matches the original single-file layout (dependencies flow top→bottom).

#include "headers/bt_common.h"
#include "headers/bt_types.h"
#include "headers/bt_assets.h"
#include "headers/bt_core.h"
#include "headers/bt_math.h"
#include "headers/bt_engine.h"

bool readEmbeddedRuntimeProject(const string& executablePath, string& projectData)
{
    ifstream executable(executablePath, ios::binary);
    if (!executable)
        return false;
    executable.seekg(0, ios::end);
    streamoff fileSize = executable.tellg();
    const streamoff trailerSize = 16;
    if (fileSize < trailerSize)
        return false;
    executable.seekg(fileSize - trailerSize);
    uint64_t payloadSize = 0;
    char marker[8] = {};
    executable.read(reinterpret_cast<char*>(&payloadSize), sizeof(payloadSize));
    executable.read(marker, sizeof(marker));
    const char expected[8] = { 'B', 'T', 'G', 'A', 'M', 'E', '0', '1' };
    if (!executable || memcmp(marker, expected, sizeof(marker)) != 0 ||
        payloadSize == 0 || payloadSize > static_cast<uint64_t>(fileSize - trailerSize) ||
        payloadSize > static_cast<uint64_t>(numeric_limits<streamsize>::max()))
        return false;
    executable.seekg(fileSize - trailerSize - static_cast<streamoff>(payloadSize));
    projectData.resize(static_cast<size_t>(payloadSize));
    executable.read(projectData.data(), static_cast<streamsize>(payloadSize));
    return static_cast<bool>(executable);
}

filesystem::path runtimeShaderTempRoot;

bool prepareEmbeddedRuntimeBundle(string& bundle, string& projectData)
{
    size_t separator = bundle.find('\0');
    if (separator == string::npos || separator == 0)
        return false;
    projectData.assign(bundle.data(), separator);
    size_t position = separator + 1;
    const vector<string> requiredShaders = {
        "part_depth.vs", "part_depth.fs", "shadow_depth.vs",
        "shadow_depth.fs", "postprocess.vs", "postprocess.fs"
    };
    unordered_set<string> writtenShaders;
    try
    {
        runtimeShaderTempRoot = filesystem::temp_directory_path() /
            ("BuildingToolRuntime_" + to_string(GetCurrentProcessId()));
        filesystem::create_directories(runtimeShaderTempRoot / "shaders");
        while (position < bundle.size())
        {
            size_t nameEnd = bundle.find('\0', position);
            if (nameEnd == string::npos)
                return false;
            string name = bundle.substr(position, nameEnd - position);
            position = nameEnd + 1;
            if (find(requiredShaders.begin(), requiredShaders.end(), name) == requiredShaders.end() ||
                writtenShaders.count(name) != 0 ||
                bundle.size() - position < sizeof(uint64_t))
                return false;
            uint64_t dataSize = 0;
            memcpy(&dataSize, bundle.data() + position, sizeof(dataSize));
            position += sizeof(dataSize);
            if (dataSize > bundle.size() - position)
                return false;
            filesystem::path shaderPath = runtimeShaderTempRoot / "shaders" / name;
            ofstream shader(shaderPath, ios::binary | ios::trunc);
            if (!shader || !shader.write(bundle.data() + position,
                static_cast<streamsize>(dataSize)))
                return false;
            position += static_cast<size_t>(dataSize);
            writtenShaders.insert(name);
        }
        if (writtenShaders.size() != requiredShaders.size())
            return false;
        return SetCurrentDirectoryA(runtimeShaderTempRoot.string().c_str()) != 0;
    }
    catch (const filesystem::filesystem_error&)
    {
        return false;
    }
}

int main(int argc, char** argv)
{
    // Path passed via shell "Open with" / double-click association / CLI:
    //   BuildingTool.exe "C:\path\project.btjson"   (or .json / .hlx)
    string startupProjectPath;
    string embeddedRuntimeProject;
    string embeddedRuntimeBundle;
    bool embeddedRuntimeBundleValid = false;
    if (argc >= 2 && argv[1] != nullptr && argv[1][0] != '\0')
    {
        startupProjectPath = argv[1];
        if (startupProjectPath.size() >= 2 &&
            ((startupProjectPath.front() == '"' && startupProjectPath.back() == '"') ||
             (startupProjectPath.front() == '\'' && startupProjectPath.back() == '\'')))
            startupProjectPath = startupProjectPath.substr(1, startupProjectPath.size() - 2);
    }

    // CRITICAL: "Open with" sets cwd to the file's folder, not the exe folder.
    // Shaders / assets/icons would fail to load → unloaded texture/shader errors.
    {
        char modulePath[MAX_PATH] = {};
        if (GetModuleFileNameA(nullptr, modulePath, MAX_PATH) > 0)
        {
            string dir = modulePath;
            readEmbeddedRuntimeProject(dir, embeddedRuntimeBundle);
            runtimeOnlyBuild = !embeddedRuntimeBundle.empty();
            size_t slash = dir.find_last_of("\\/");
            if (slash != string::npos)
                SetCurrentDirectoryA(dir.substr(0, slash).c_str());
            if (runtimeOnlyBuild)
                embeddedRuntimeBundleValid =
                    prepareEmbeddedRuntimeBundle(embeddedRuntimeBundle, embeddedRuntimeProject);
        }
    }

    SetConfigFlags(
        FLAG_WINDOW_RESIZABLE |
        FLAG_MSAA_4X_HINT |
        FLAG_VSYNC_HINT
    );

    InitWindow(800, 600, "Building Tool");
    if (!runtimeOnlyBuild)
    {
        registerHlxFileAssociation();
        runHlxAssociationBatchFirstLaunch();
    }
    InitEngine();

    MaximizeWindow();

    // Setup camera
    Camera3D camera = { 0 };

    camera.position = { 8.0f, 6.0f, 8.0f };
    camera.target = { 0.0f, 0.0f, 0.0f };
    camera.up = { 0.0f, 1.0f, 0.0f };
    camera.fovy = 45.0f;
    camera.projection = CAMERA_PERSPECTIVE;

    shadowCamera = { 0 };

    shadowCamera.position = Vector3Scale(Vector3Normalize(sun.direction), -20.0f);

    shadowCamera.target = { 0, 0, 0 };

    shadowCamera.up = { 0, 1, 0 };

    shadowCamera.projection = CAMERA_ORTHOGRAPHIC;

    shadowCamera.fovy = 40.0f;

    // Start on the welcome page unless launched via a project or exported game.
    bool newProjectProcess = false;
    welcomeScreenOpen = !runtimeOnlyBuild;
    loadRecentProjects();

    projectName = "Untitled";
    lastSavedProjectJSON = serializeProjectJSON();
    lastObservedProjectJSON = lastSavedProjectJSON;
    projectDirty = false;
    lastAutoSaveTime = GetTime();
    activeWindow = runtimeOnlyBuild ? WindowType::Viewport : WindowType::Welcome;
    updateApplicationWindowTitle();

    if (runtimeOnlyBuild)
    {
        if (embeddedRuntimeBundleValid && applyProjectJSON(embeddedRuntimeProject))
        {
            welcomeScreenOpen = false;
            activeWindow = WindowType::Viewport;
            focusedZone = FocusZone::Viewport;
            projectDirty = false;
            lastSavedProjectJSON = serializeProjectJSON();
            lastObservedProjectJSON = lastSavedProjectJSON;
            SetWindowTitle(projectName.c_str());
            startRuntime(true);
        }
        else
        {
            addOutputLog("[Error] Could not load the embedded runtime project.");
            forceExit = true;
        }
    }
    else if (!startupProjectPath.empty())
    {
        if (loadProjectFromPath(startupProjectPath))
        {
            welcomeScreenOpen = false;
            activeWindow = WindowType::Viewport;
            addOutputLog("[Open] Loaded from command line / Open with: " + startupProjectPath);
        }
        else
        {
            addOutputLog("[Error] Could not open: " + startupProjectPath);
        }
    }

    // Create TopBarItems
    vector<TopBarItem*> topBarItems;

    TopBarItem fileMenu;
    fileMenu.label = "File";
    fileMenu.hoverText = "File operations";

    TopBarItem helpMenu;
    helpMenu.label = "Help";
    helpMenu.hoverText = "Show keybinds";

    TopBarItem viewMenu;
    viewMenu.label = "View";
    viewMenu.hoverText = "Show editor views";

    TopBarItem viewViewportItem;
    viewViewportItem.label = "Viewport";
    viewViewportItem.hoverText = "Show the 3D viewport";
    viewViewportItem.isButton = true;

    TopBarItem viewOutputItem;
    viewOutputItem.label = "Output";
    viewOutputItem.hoverText = "Show the Output log";
    viewOutputItem.isButton = true;

    TopBarItem viewLibraryItem;
    viewLibraryItem.label = "Asset Manager";
    viewLibraryItem.hoverText = "Show the Asset Manager (embedded images, sounds & meshes)";
    viewLibraryItem.isButton = true;

    TopBarItem showHiddenAssetsItem;
    showHiddenAssetsItem.label = "Show Hidden Assets";
    showHiddenAssetsItem.hoverText = "Show CoreStorage and other system-owned assets";
    showHiddenAssetsItem.isButton = true;

    TopBarItem viewActionBarItem;
    viewActionBarItem.label = "Action Bar";
    viewActionBarItem.hoverText = "Show or hide the action bar";
    viewActionBarItem.isButton = true;

    TopBarItem viewWindowBarItem;
    viewWindowBarItem.label = "Window Bar";
    viewWindowBarItem.hoverText = "Show or hide the window bar";
    viewWindowBarItem.isButton = true;

    TopBarItem viewRibbonBarItem;
    viewRibbonBarItem.label = "Ribbon Bar";
    viewRibbonBarItem.hoverText = "Show or hide the ribbon bar";
    viewRibbonBarItem.isButton = true;

    TopBarItem newItem;
    newItem.label = "New";
    newItem.hoverText = "Create a new project";
    newItem.isButton = true;

    TopBarItem openItem;
    openItem.label = "Open";
    openItem.hoverText = "Open a project file";
    openItem.isButton = true;

    TopBarItem saveItem;
    saveItem.label = "Save";
    saveItem.hoverText = "Save the current project";
    saveItem.isButton = true;

    TopBarItem saveAsItem;
    saveAsItem.label = "Save As";
    saveAsItem.hoverText = "Save the project to another file";
    saveAsItem.isButton = true;

    TopBarItem exportItem;
    exportItem.label = "Export";
    exportItem.hoverText = "Create a standalone runtime executable";
    exportItem.isButton = true;

    TopBarItem importItem;
    importItem.label = "Import Asset";
    importItem.hoverText = "Import images, sounds, or multiple mesh files as MeshParts";
    importItem.isButton = true;

    TopBarItem studioSettingsItem;
    studioSettingsItem.label = "Studio Settings";
    studioSettingsItem.hoverText = "Editor preferences";
    studioSettingsItem.isButton = true;

    TopBarItem gameSettingsItem;
    gameSettingsItem.label = "Game Settings";
    gameSettingsItem.hoverText = "Project graphics & game options";
    gameSettingsItem.isButton = true;

    TopBarItem playItem;
    playItem.label = "Play";
    playItem.hoverText = "Run the active script in Luau";
    playItem.isButton = true;

    TopBarItem stopItem;
    stopItem.label = "Stop";
    stopItem.hoverText = "Stop Luau and reset script state";
    stopItem.isButton = true;

    topBarItems.push_back(&fileMenu);
    topBarItems.push_back(&viewMenu);
    topBarItems.push_back(&helpMenu);
    fileMenu.children.push_back(&newItem);
    fileMenu.children.push_back(&openItem);
    fileMenu.children.push_back(&saveItem);
    fileMenu.children.push_back(&saveAsItem);
    fileMenu.children.push_back(&exportItem);
    fileMenu.children.push_back(&importItem);
    fileMenu.children.push_back(&studioSettingsItem);
    fileMenu.children.push_back(&gameSettingsItem);
    viewMenu.children.push_back(&viewViewportItem);
    viewMenu.children.push_back(&viewOutputItem);
    viewMenu.children.push_back(&viewLibraryItem);
    viewMenu.children.push_back(&showHiddenAssetsItem);
    viewMenu.children.push_back(&viewActionBarItem);
    viewMenu.children.push_back(&viewRibbonBarItem);
    viewMenu.children.push_back(&viewWindowBarItem);

    loadStudioSettings(); // applies FPS / VSync from temp/studio_settings.json
    loadLuauConfig();

    TraceLog(
        LOG_INFO,
        "SHADOW MAP: id=%u texture=%u depth=%u size=%dx%d",
        shadowMap.id,
        shadowMap.texture.id,
        shadowMap.depth.id,
        shadowMap.texture.width,
        shadowMap.texture.height
    );

    TraceLog(
        LOG_INFO,
        "SHADOW LOCATIONS: shadowMap=%d lightSpace=%d",
        shadowMapLoc,
        lightSpaceMatrixLoc
    );

    TraceLog(
        LOG_INFO,
        "DEPTH TEX: id=%u size=%dx%d format=%d",
        shadowMap.depth.id,
        shadowMap.depth.width,
        shadowMap.depth.height,
        shadowMap.depth.format
    );

    // Disable default ESC-to-close so we fully control exit + save prompt.
    SetExitKey(KEY_NULL);
    bool systemCursorHidden = false;

    while (!forceExit)
    {
        Vector2 cursorPosition = GetMousePosition();
        bool cursorInsideWindow = cursorPosition.x >= 0.0f &&
            cursorPosition.y >= 0.0f &&
            cursorPosition.x < static_cast<float>(GetScreenWidth()) &&
            cursorPosition.y < static_cast<float>(GetScreenHeight());
        bool shouldHideSystemCursor = !runtimeOnlyBuild && !welcomeScreenOpen &&
            IsWindowFocused() && cursorInsideWindow;
        if (!shouldHideSystemCursor && systemCursorHidden)
        {
            ShowCursor();
            systemCursorHidden = false;
        }
        else if (shouldHideSystemCursor && !systemCursorHidden)
        {
            HideCursor();
            systemCursorHidden = true;
        }

        // Rising-edge close handling. Never `continue` past the draw path —
        // that skipped rendering the save dialog every frame (looked like a crash).
        bool shouldClose = WindowShouldClose();
        bool closeRisingEdge = shouldClose && !windowClosePrev;
        windowClosePrev = shouldClose;

        if (closeRisingEdge)
            windowCloseConsumed = false;

        if (shouldClose && !windowCloseConsumed && !projectSaveDialogOpen)
        {
            if (projectDirty)
            {
                pendingProjectAction = PendingProjectAction::Exit;
                projectSaveDialogOpen = true;
                projectSaveDialogWasCloseRequest = true;
            }
            else
            {
                forceExit = true;
                break;
            }
        }
        if (!runtimeOnlyBuild)
            updateProjectSaveSystem();
        updateSunDirectionFromClockTime();

        // Large light frustum so shadows cover the whole scene (not ~200x200)
        const float shadowExtent = 500.0f;
        const float shadowDist = 600.0f;
        Vector3 shadowFocus = camera.target;
        const float shadowTexelWorldSize = (shadowExtent * 2.0f) /
            static_cast<float>(std::max(shadowMap.texture.width, 1));
        shadowFocus.x = roundf(shadowFocus.x / shadowTexelWorldSize) * shadowTexelWorldSize;
        shadowFocus.y = roundf(shadowFocus.y / shadowTexelWorldSize) * shadowTexelWorldSize;
        shadowFocus.z = roundf(shadowFocus.z / shadowTexelWorldSize) * shadowTexelWorldSize;
        shadowCamera.target = shadowFocus;
        shadowCamera.position =
            Vector3Add(
                shadowFocus,
                Vector3Scale(Vector3Normalize(sun.direction), -shadowDist)
            );

        // ============================================================
        // SHADOW MATRICES
        // ============================================================

        Matrix lightView =
            MatrixLookAt(
                shadowCamera.position,
                shadowCamera.target,
                shadowCamera.up
            );

        Matrix lightProjection =
            MatrixOrtho(
                -shadowExtent,
                shadowExtent,
                -shadowExtent,
                shadowExtent,
                1.0f,
                shadowDist * 2.0f
            );

        lightSpaceMatrix =
            MatrixMultiply(
                lightView,
                lightProjection
            );

        SetShaderValueMatrix(
            shadowShader,
            shadowLightSpaceLoc,
            lightSpaceMatrix
        );

        // ============================================================
        // SHADOW PASS
        // ============================================================

        if (lightingSettings.globalShadows && getGraphicsQualityCaps(gameSettings.graphicsQuality).shadowsEnabled)
        {
            static uint64_t lastRenderedShadowHash = 0;
            static bool shadowMapInitialized = false;
            uint64_t sceneHash = currentShadowSceneHash(shadowFocus);
            if (!shadowMapInitialized || sceneHash != lastRenderedShadowHash)
            {
                BeginTextureMode(shadowMap);
                ClearBackground(WHITE);
                BeginMode3D(shadowCamera);

                // Render both faces into the depth map so undersides / thin
                // geometry still cast (fixes missing bottom-of-part shadows).
                rlDisableBackfaceCulling();
                renderShadowCasters(&workspace);
                rlEnableBackfaceCulling();

                EndMode3D();
                EndTextureMode();
                lastRenderedShadowHash = sceneHash;
                shadowMapInitialized = true;
            }
        }

        resizeLightingSceneTargetIfNeeded();


        // ============================================================
        // NORMAL CAMERA / INPUT
        // ============================================================

        // Menu bar works on welcome and in editor (New/Open from File)
        if (!projectSaveDialogOpen && !newProjectTypeDialogOpen)

        if (welcomeScreenOpen && !newProjectTypeDialogOpen)
        {
            bool welcomeClick = IsMouseButtonPressed(MOUSE_BUTTON_LEFT);
            bool menuOwnsClick = openMenu != nullptr ||
                (welcomeClick && GetMousePosition().y < static_cast<float>(MENU_BAR_HEIGHT));
            handleTopBarClick(topBarItems);
            if (!projectSaveDialogOpen && welcomeClick && !menuOwnsClick && openMenu == nullptr)
            {
                Vector2 mouse = GetMousePosition();
                // Ignore clicks on the menu bar itself
                if (mouse.y >= (float)MENU_BAR_HEIGHT)
                {
                    for (const WelcomeHit& hit : welcomeHits)
                    {
                        if (!CheckCollisionPointRec(mouse, hit.rect))
                            continue;
                        if (hit.kind == 0)
                            beginNewProject();
                        else if (hit.kind == 1)
                            loadProject();
                        else if (hit.kind == 2 && hit.index >= 0 &&
                                 hit.index < (int)recentProjects.size())
                        {
                            string path = recentProjects[hit.index];
                            if (!loadProjectFromPath(path))
                            {
                                recentProjects.erase(
                                    remove(recentProjects.begin(), recentProjects.end(), path),
                                    recentProjects.end());
                                saveRecentProjects();
                            }
                        }
                        break;
                    }
                }
            }
        }
        else if (!projectSaveDialogOpen && !newProjectTypeDialogOpen)
        {
            updateFocusFromMouseWheel();
            updateRuntimeLuauScheduler();
            if (runtimePlaying)
            {
                float dt = GetFrameTime();
                fireRuntimeRunService(dt);
                updateBasicPhysics(dt);
            }
            if (runtimePlaying && runtimeClientMode)
            {
                updateRuntimePlayerCamera(camera, GetFrameTime());
                updateCharacterAnimation(GetFrameTime());
                // Re-pose after the humanoid ground correction without advancing motor speed twice.
                applyPhysicsJoints(0.0f);
            }
            if (!runtimeOnlyBuild)
            {
            // Clicking the center viewport focuses it so Enter won't rename explorer items
            if (activeWindow == WindowType::Viewport &&
                (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) ||
                 IsMouseButtonPressed(MOUSE_BUTTON_RIGHT) ||
                 IsMouseButtonPressed(MOUSE_BUTTON_MIDDLE)))
            {
                Vector2 m = GetMousePosition();
                int lx = leftSlotWidth();
                int rx = GetScreenWidth() - rightSlotWidth();
                if (m.x >= lx && m.x < rx && m.y >= EDITOR_CONTENT_TOP)
                    focusedZone = FocusZone::Viewport;
            }
            if (activeWindow == WindowType::Viewport && isZoneFocused(FocusZone::Viewport) &&
                renamingInstance == nullptr && !runtimeClientMode)
                setupMouseMovement(camera);
            if (!insertMenuOpen)
                handleTopBarClick(topBarItems);
            updateDockDrag();
            bool ctrl = IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL);
            bool alt = IsKeyDown(KEY_LEFT_ALT) || IsKeyDown(KEY_RIGHT_ALT);
            if (alt && IsKeyPressed(KEY_S))
            {
                studioSettingsOpen = true;
                gameSettingsOpen = false;
            }
            else if (alt && IsKeyPressed(KEY_G))
            {
                gameSettingsOpen = true;
                studioSettingsOpen = false;
            }
            else if (ctrl && IsKeyPressed(KEY_S)) saveProject(false);
            else if (ctrl && IsKeyPressed(KEY_O)) requestProjectAction(PendingProjectAction::Open);
            else if (ctrl && IsKeyPressed(KEY_N)) requestProjectAction(PendingProjectAction::New);
            else if (ctrl && IsKeyPressed(KEY_I))
            {
                insertMenuOpen = !insertMenuOpen;
                insertMenuHover = -1;
                helpOpen = false;
            }
            bool insertMenuOwnsInput = insertMenuOpen;
            handleInsertMenuInput();
            if (!insertMenuOwnsInput)
            {
                handleWindowBarClick();
                handleOutputResize();
                handlePropertyPanelInput();
                handleExplorerClick();
                handleDocumentScrollInput();
                handleScriptInput();
                handleLibraryInput();
                handleHelpInput();
                updateHover(camera);
                if (activeWindow == WindowType::Viewport && isZoneFocused(FocusZone::Viewport) &&
                    renamingInstance == nullptr && !studioSettingsOpen && !gameSettingsOpen &&
                    !propertyColorPickerOpen && !isPointerOverScreenGui())
                {
                    handleGizmoMode();
                    handleGizmoInteraction(camera);
                }
                WhenClicked(camera);
                handleContextMenuInput(camera);
                if (activeWindow != WindowType::Script || isZoneFocused(FocusZone::Explorer))
                    handleExplorerRename();
                handleExplorerShortcuts();
                handleExplorerKeyboard();
            }
            }
        }
        else
        {
            // Save-warning dialog blocks editor input but leaves the editor
            // itself rendered underneath it.
        }


        // ============================================================
        // NORMAL RENDER
        // ============================================================

        BeginDrawing();

        if (welcomeScreenOpen)
        {
            renderWelcomeScreen();
            renderTopBar(topBarItems);
            renderContextMenu();
            renderNewProjectTypeDialog();
            EndDrawing();
            continue;
        }

        // Day/night sky from ClockTime: day = fogColor blue, night = dark + moon
        float dayFactor = 0.0f;
        {
            // sun.direction.y is negative when sun is "up" in our convention (light comes from -dir)
            // Use clock elevation: 6–18 roughly day
            float ct = lightingSettings.clockTime;
            // Smooth day factor: 1 at noon, 0 at midnight
            float hourAngle = (ct / 24.0f) * 2.0f * PI;
            dayFactor = Clamp(sinf(hourAngle) * 0.5f + 0.5f, 0.0f, 1.0f);
            // Boost daytime plateau
            dayFactor = Clamp(powf(dayFactor, 0.65f), 0.0f, 1.0f);
        }
        Color nightSky = { 8, 12, 28, 255 };
        Color daySky = lightingSettings.fogColor; // user FogColor = daytime sky
        Color viewportBackground = {
            (unsigned char)(nightSky.r + (daySky.r - nightSky.r) * dayFactor),
            (unsigned char)(nightSky.g + (daySky.g - nightSky.g) * dayFactor),
            (unsigned char)(nightSky.b + (daySky.b - nightSky.b) * dayFactor),
            255
        };

        if (activeWindow == WindowType::Viewport)
        {
            BeginTextureMode(lightingSceneTarget);

            ClearBackground(viewportBackground);

            BeginMode3D(camera);

            // Temporarily feed blended sky into shader fog, then restore
            Color savedFog = lightingSettings.fogColor;
            lightingSettings.fogColor = viewportBackground;
            updateSunShader(camera);
            lightingSettings.fogColor = savedFog;

            // Sun / moon disks in the sky
            {
                Vector3 toSun = Vector3Normalize(Vector3Scale(sun.direction, -1.0f));
                Vector3 sunPos = Vector3Add(camera.position, Vector3Scale(toSun, 520.0f));
                Vector3 moonPos = Vector3Add(camera.position, Vector3Scale(toSun, -520.0f));

                if (dayFactor > 0.12f)
                {
                    // Bright sun
                    float bright = 0.55f + 0.45f * dayFactor;
                    Color core = {
                        (unsigned char)min(255, (int)(sun.color.r * bright + 40)),
                        (unsigned char)min(255, (int)(sun.color.g * bright + 30)),
                        (unsigned char)min(255, (int)(sun.color.b * bright)),
                        255
                    };
                    DrawSphere(sunPos, 22.0f, (Color){ core.r, core.g, core.b, (unsigned char)(70 + 80 * dayFactor) });
                    DrawSphere(sunPos, 11.0f, core);
                    DrawSphere(sunPos, 5.0f, WHITE);
                }
                if (dayFactor < 0.55f)
                {
                    // Moon when evening/night
                    float moonA = 1.0f - dayFactor;
                    Color moon = { 220, 225, 240, (unsigned char)(180 * moonA + 40) };
                    DrawSphere(moonPos, 10.0f, (Color){ 180, 190, 220, (unsigned char)(60 * moonA) });
                    DrawSphere(moonPos, 6.0f, moon);
                    DrawSphere(moonPos, 2.5f, WHITE);
                }
            }

            // Ground grid (Studio Settings → Show grid)
            if (!runtimeOnlyBuild && studioSettings.showGrid)
            {
                DrawGrid(80, 4.0f);
            }

            rlEnableBackfaceCulling();
            if (runtimePlaying && runtimeClientMode)
                renderInstance(&Players, {}, &camera);
            renderInstance(&workspace, {}, &camera);
            if (runtimePlaying && runtimeClientMode)
                renderTransparentParts({ &Players, &workspace }, camera);
            else
                renderTransparentParts({ &workspace }, camera);

            if (!runtimeOnlyBuild) for (Part* selectedPart : getSelectedParts())
            {
                if (selectedPart == nullptr || selectedPart->hidden)
                    continue;
                Vector3 outlineSize = {
                    selectedPart->size.x + 0.025f,
                    selectedPart->size.y + 0.025f,
                    selectedPart->size.z + 0.025f
                };
                Color outlineColor = { 48, 145, 255, 255 };
                if (!selectedPart->isMeshPart && selectedPart->type == PartType::Sphere)
                    DrawSphereWiresCFrame(selectedPart->cframe,
                        selectedPart->size.x * 0.5f + 0.025f, outlineColor);
                else if (!selectedPart->isMeshPart && selectedPart->type == PartType::Cylinder)
                    DrawCylinderWiresCFrame(selectedPart->cframe, outlineSize, outlineColor);
                else
                    DrawCubeWiresCFrame(selectedPart->cframe, outlineSize, outlineColor);
            }

            EndMode3D();

            EndTextureMode();

            // Blur is a real screen-space post-process, not a part-lighting
            // operation. The editor UI is drawn afterward so it stays sharp.
            renderLightingPostProcess();

            // Gizmo pass (after lighting blit). Reset shader/texture state so
            // DrawMesh uses the same clean path as the rotation torus.
            BeginMode3D(camera);

            EndShaderMode();
            // Redraw face textures after post-process so side faces stay visible
            // (immediate-mode quads can be lost or depth-killed inside the lighting RT).
            drawAllPartFaceTextures(&workspace);
            rlActiveTextureSlot(0);
            rlDisableTexture();
            rlActiveTextureSlot(1);
            rlDisableTexture();
            rlActiveTextureSlot(0);
            rlDisableShader();
            rlSetShader(rlGetShaderIdDefault(), rlGetShaderLocsDefault());

            rlDisableDepthTest();

            if (!runtimeOnlyBuild && !selectToolActive && !selectedInstances.empty() && !getSelectedParts().empty())
            {
                static Part gizmoDrawProxy;
                gizmoDrawProxy.cframe.position = getSelectionGizmoPivot();
                gizmoDrawProxy.cframe.rotation = getSelectedParts().front()->cframe.rotation;
                gizmoDrawProxy.size = getSelectedParts().front()->size;
                gizmoDrawProxy.pivotOffset = { 0, 0, 0 };
                renderGizmo(currentGizmo, gizmoDrawProxy, camera);
                renderPartOrientationGuides();
            }

            rlEnableDepthTest();

            EndMode3D();
        }
        else
        {
            ClearBackground(viewportBackground);
        }

        // Keep a copy for BillboardGui / SurfaceGui world→screen projection.
        viewportCamera = camera;
        viewportCameraValid = true;
        if (runtimeOnlyBuild)
        {
            renderScreenGuisOverlay();
            if (runtimePlaying)
                updateRuntimeSounds();
            EndDrawing();
            continue;
        }
        updateApplicationWindowTitle();
        
        renderScreenGuisOverlay();
        renderViewportBorder();
        renderExplorer(game.children);
        renderWindowBar();
        render2D();
        renderViewportSelectionBox();
        renderPropertyPanel();
        renderHelpBoard();

        // Top bar is the highest editor UI layer.
        renderTopBar(topBarItems);
        renderContextMenu();

        // Insert menu above editor UI, below save dialog.
        renderInsertMenu();

        // Floating panel + dock drop zones while redocking.
        renderDockDragOverlay();
        renderWindowBarTabDragOverlay();
        updateSoundPreview();
        if (runtimePlaying)
            updateRuntimeSounds();

        // Keep the actual editor visible behind the unsaved-changes warning.
        // Do not clear to a white background while the modal is open.
        renderProjectSaveDialog();
        renderGameSettingsDialog();
        renderStudioSettingsDialog();
        renderNewProjectTypeDialog();
        if (!welcomeScreenOpen && systemCursorHidden)
            renderStudioMouseCursor();

        EndDrawing();
    }
    // Always stop Luau before destroying the graphics/window context.
    if (runtimePlaying)
        stopRuntime();

    ShutdownEngine();
    ShowCursor();
    CloseWindow();
    if (!runtimeShaderTempRoot.empty())
    {
        char tempPath[MAX_PATH] = {};
        if (GetTempPathA(MAX_PATH, tempPath) > 0)
            SetCurrentDirectoryA(tempPath);
        error_code cleanupError;
        filesystem::remove_all(runtimeShaderTempRoot, cleanupError);
    }

    return 0;
}