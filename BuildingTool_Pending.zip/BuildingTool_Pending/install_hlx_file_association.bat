@echo off
setlocal

set "SILENT=0"
if /i "%~1"=="/silent" set "SILENT=1"

rem Register .hlx and .btproj for this Windows user only. No administrator rights are needed.
set "APP_DIR=%~dp0"
set "APP_EXE=%APP_DIR%buildingTool.exe"
set "FILE_ICON=%APP_DIR%assets\icons\Misc\File.ico"
set "PROG_ID=BuildingTool.HLX"
set "PROJECT_PROG_ID=BuildingTool.ProjectFolder"

if not exist "%APP_EXE%" (
    echo Could not find "%APP_EXE%".
    if "%SILENT%"=="0" pause
    exit /b 1
)

if not exist "%FILE_ICON%" (
    echo Could not find "%FILE_ICON%".
    if "%SILENT%"=="0" pause
    exit /b 1
)

reg add "HKCU\Software\Classes\.hlx" /ve /d "%PROG_ID%" /f >nul
reg add "HKCU\Software\Classes\%PROG_ID%" /ve /d "Building Tool Project" /f >nul
reg add "HKCU\Software\Classes\%PROG_ID%\DefaultIcon" /ve /d "%FILE_ICON%" /f >nul
reg add "HKCU\Software\Classes\%PROG_ID%\shell\open\command" /ve /d "\"%APP_EXE%\" \"%%1\"" /f >nul
reg add "HKCU\Software\Classes\.btproj" /ve /d "%PROJECT_PROG_ID%" /f >nul
reg add "HKCU\Software\Classes\%PROJECT_PROG_ID%" /ve /d "Building Tool Project Folder" /f >nul
reg add "HKCU\Software\Classes\%PROJECT_PROG_ID%\DefaultIcon" /ve /d "%FILE_ICON%" /f >nul
reg add "HKCU\Software\Classes\%PROJECT_PROG_ID%\shell\open\command" /ve /d "\"%APP_EXE%\" \"%%1\"" /f >nul

rem Ask Explorer to re-read user file associations.
ie4uinit.exe -show >nul 2>&1

if "%SILENT%"=="0" (
    echo .hlx and .btproj are now associated with Building Tool for this Windows user.
    echo Double-clicking either project file should open it with Building Tool.
    echo If an old icon remains visible, sign out and back in once.
    pause
)
endlocal
