// bt_script_runtime.h — Script editor, Luau runtime, context menu, physics include
#pragma once
#ifndef BT_SCRIPT_RUNTIME_H
#define BT_SCRIPT_RUNTIME_H

void loadLuauConfig()
{
    if (luauConfigLoaded)
        return;
    const char* candidates[] = {
        "assets/luau_config.json",
        "temp/luau_config.json",
        "luau_config.json"
    };
    string json;
    for (const char* path : candidates)
    {
        ifstream in(path, ios::binary);
        if (!in)
            continue;
        json.assign((istreambuf_iterator<char>(in)), istreambuf_iterator<char>());
        if (!json.empty())
        {
            addOutputLog(string("[LuauConfig] Loaded ") + path);
            break;
        }
    }
    if (json.empty())
    {
        // Defaults already set on the vectors; mark loaded so we don't spam.
        luauConfigLoaded = true;
        return;
    }

    auto extractStringArray = [&](const string& key) -> vector<string>
    {
        vector<string> result;
        string needle = "\"" + key + "\"";
        size_t k = json.find(needle);
        if (k == string::npos) return result;
        size_t lb = json.find('[', k);
        size_t rb = json.find(']', lb);
        if (lb == string::npos || rb == string::npos || rb <= lb) return result;
        string body = json.substr(lb + 1, rb - lb - 1);
        size_t pos = 0;
        while (pos < body.size())
        {
            size_t q1 = body.find('"', pos);
            if (q1 == string::npos) break;
            size_t q2 = body.find('"', q1 + 1);
            if (q2 == string::npos) break;
            result.push_back(body.substr(q1 + 1, q2 - q1 - 1));
            pos = q2 + 1;
        }
        return result;
    };

    auto applyColor = [&](const string& key, Color& out)
    {
        string needle = "\"" + key + "\"";
        size_t k = json.find(needle);
        if (k == string::npos) return;
        size_t lb = json.find('[', k);
        if (lb == string::npos) return;
        int vals[4] = { out.r, out.g, out.b, out.a };
        int n = 0;
        size_t p = lb + 1;
        while (n < 4 && p < json.size() && json[p] != ']')
        {
            while (p < json.size() && (json[p] == ' ' || json[p] == ',' || json[p] == '\n' || json[p] == '\r' || json[p] == '\t'))
                p++;
            if (p >= json.size() || json[p] == ']') break;
            vals[n++] = atoi(json.c_str() + p);
            while (p < json.size() && (isdigit((unsigned char)json[p]) || json[p] == '-'))
                p++;
        }
        if (n >= 3)
        {
            out.r = (unsigned char)vals[0];
            out.g = (unsigned char)vals[1];
            out.b = (unsigned char)vals[2];
            if (n >= 4) out.a = (unsigned char)vals[3];
        }
    };

    vector<string> kw = extractStringArray("keywords");
    if (!kw.empty()) luauConfigKeywords = kw;
    vector<string> bi = extractStringArray("builtins");
    if (!bi.empty()) luauConfigBuiltins = bi;
    vector<string> ty = extractStringArray("types");
    if (!ty.empty()) luauConfigTypes = ty;
    vector<string> cw = extractStringArray("completionWords");
    if (!cw.empty()) SCRIPT_COMPLETION_WORDS = cw;
    vector<string> pp = extractStringArray("pointerProperties");
    if (!pp.empty()) luauConfigPointerProperties = pp;

    // Theme (optional)
    applyColor("background", SCRIPT_BACKGROUND);
    applyColor("gutter", SCRIPT_GUTTER);
    applyColor("text", SCRIPT_TEXT);
    applyColor("comment", SCRIPT_COMMENT);
    applyColor("string", SCRIPT_STRING);
    applyColor("keyword", SCRIPT_KEYWORD);
    applyColor("literal", SCRIPT_LITERAL);
    applyColor("function", SCRIPT_FUNCTION);
    applyColor("number", SCRIPT_NUMBER);
    applyColor("builtin", SCRIPT_BUILTIN);
    applyColor("operator", SCRIPT_OPERATOR);
    applyColor("type", SCRIPT_TYPE);
    applyStudioScriptTheme();

    luauConfigLoaded = true;
}

bool isScriptKeyword(const string& word)
{
    return find(luauConfigKeywords.begin(), luauConfigKeywords.end(), word) != luauConfigKeywords.end();
}

bool isScriptBuiltin(const string& word)
{
    if (!luauConfigBuiltins.empty())
        return find(luauConfigBuiltins.begin(), luauConfigBuiltins.end(), word) != luauConfigBuiltins.end();
    static const vector<string> builtins = {
        "print", "warn", "error", "assert", "require", "wait", "task", "game", "workspace",
        "script", "plugin", "shared", "_G", "pointer",
        "Instance", "Vector2", "Vector3", "CFrame", "Color3", "UDim", "UDim2", "Enum",
        "BrickColor", "Ray", "Region3", "Random", "TweenInfo", "NumberRange",
        "math", "string", "table", "bit32", "coroutine", "debug", "os", "utf8", "buffer",
        "pairs", "ipairs", "tonumber", "tostring", "type", "typeof", "select", "unpack",
        "pcall", "xpcall", "setmetatable", "getmetatable", "rawget", "rawset", "rawequal", "next",
        "Players", "Lighting", "ReplicatedStorage", "ServerStorage", "RunService", "TweenService",
        "tick", "time"
    };
    return find(builtins.begin(), builtins.end(), word) != builtins.end();
}

bool isScriptTypeName(const string& word)
{
    if (word.size() < 2 || !isupper(static_cast<unsigned char>(word[0])))
        return false;
    if (!luauConfigTypes.empty())
        return find(luauConfigTypes.begin(), luauConfigTypes.end(), word) != luauConfigTypes.end();
    static const vector<string> types = {
        "Instance", "Vector2", "Vector3", "CFrame", "Color3", "UDim", "UDim2", "Enum",
        "BrickColor", "Ray", "Region3", "Random", "TweenInfo", "NumberRange", "NumberSequence",
        "ColorSequence", "Part", "Model", "Folder", "Script", "LocalScript", "ModuleScript",
        "Humanoid", "Sound", "Texture", "Players", "Lighting", "Workspace", "TweenService",
        "RunService", "UserInputService", "BindableEvent", "RemoteEvent", "WeldConstraint", "Motor6D"
    };
    return find(types.begin(), types.end(), word) != types.end();
}

vector<string> getScriptFunctionNames(const string& source)
{
    vector<string> names;
    size_t searchStart = 0;
    while ((searchStart = source.find("function", searchStart)) != string::npos)
    {
        size_t nameStart = searchStart + 8;
        while (nameStart < source.size() && isspace(static_cast<unsigned char>(source[nameStart])))
            nameStart++;
        size_t nameEnd = nameStart;
        while (nameEnd < source.size() && isScriptWordCharacter(source[nameEnd]))
            nameEnd++;
        if (nameEnd > nameStart)
            names.push_back(source.substr(nameStart, nameEnd - nameStart));
        searchStart = nameEnd;
    }
    return names;
}

bool isScriptLiteral(const string& word)
{
    return word == "true" || word == "false" || word == "nil";
}

bool isScriptFunctionName(const string& word, const vector<string>& functionNames)
{
    return find(functionNames.begin(), functionNames.end(), word) != functionNames.end();
}

struct ScriptHighlightState
{
    bool longComment = false;
    bool longString = false;
    int longBracketEquals = 0;
};

bool getLongBracketOpener(const string& text, int position, int& equalsCount, int& openerLength)
{
    if (position < 0 || position >= static_cast<int>(text.size()) || text[position] != '[')
        return false;
    int cursor = position + 1;
    while (cursor < static_cast<int>(text.size()) && text[cursor] == '=')
        cursor++;
    if (cursor >= static_cast<int>(text.size()) || text[cursor] != '[')
        return false;
    equalsCount = cursor - position - 1;
    openerLength = cursor - position + 1;
    return true;
}

void drawScriptText(const string& text, int x, int y, const vector<string>& functionNames,
    ScriptHighlightState& highlightState)
{
    int index = 0;
    while (index < static_cast<int>(text.size()))
    {
        if (highlightState.longComment || highlightState.longString)
        {
            string closing = "]" + string(highlightState.longBracketEquals, '=') + "]";
            size_t closePosition = text.find(closing, static_cast<size_t>(index));
            int end = closePosition == string::npos
                ? static_cast<int>(text.size())
                : static_cast<int>(closePosition + closing.size());
            string token = text.substr(index, end - index);
            bool isComment = highlightState.longComment;
            AppDrawTextStyled(token.c_str(), x, y, scriptFontSize,
                isComment ? SCRIPT_COMMENT : SCRIPT_STRING,
                isComment ? TextStyle::Italic : TextStyle::Regular);
            x += AppMeasureTextStyled(token.c_str(), scriptFontSize,
                isComment ? TextStyle::Italic : TextStyle::Regular);
            index = end;
            if (closePosition == string::npos)
                return;
            highlightState.longComment = false;
            highlightState.longString = false;
            continue;
        }

        if (text[index] == '-' && index + 1 < static_cast<int>(text.size()) && text[index + 1] == '-')
        {
            int equalsCount = 0;
            int openerLength = 0;
            if (getLongBracketOpener(text, index + 2, equalsCount, openerLength))
            {
                highlightState.longComment = true;
                highlightState.longBracketEquals = equalsCount;
                string opener = text.substr(index, 2 + openerLength);
                AppDrawTextStyled(opener.c_str(), x, y, scriptFontSize, SCRIPT_COMMENT, TextStyle::Italic);
                x += AppMeasureTextStyled(opener.c_str(), scriptFontSize, TextStyle::Italic);
                index += 2 + openerLength;
                continue;
            }
            // Comments are italicized, matching common editor conventions.
            AppDrawTextStyled(text.substr(index).c_str(), x, y, scriptFontSize, SCRIPT_COMMENT, TextStyle::Italic);
            return;
        }

        int start = index;
        Color color = SCRIPT_TEXT;
        TextStyle style = TextStyle::Regular;
        int equalsCount = 0;
        int openerLength = 0;
        if (getLongBracketOpener(text, index, equalsCount, openerLength))
        {
            highlightState.longString = true;
            highlightState.longBracketEquals = equalsCount;
            string opener = text.substr(index, openerLength);
            AppDrawTextStyled(opener.c_str(), x, y, scriptFontSize, SCRIPT_STRING, TextStyle::Regular);
            x += AppMeasureTextStyled(opener.c_str(), scriptFontSize, TextStyle::Regular);
            index += openerLength;
            continue;
        }
        if (text[index] == '"' || text[index] == '\'')
        {
            char quote = text[index++];
            while (index < static_cast<int>(text.size()))
            {
                if (text[index] == '\\' && index + 1 < static_cast<int>(text.size()))
                    index += 2;
                else if (text[index++] == quote)
                    break;
            }
            color = SCRIPT_STRING;
        }
        else if (isdigit(static_cast<unsigned char>(text[index])))
        {
            while (index < static_cast<int>(text.size()) &&
                   (isdigit(static_cast<unsigned char>(text[index])) || text[index] == '.'))
                index++;
            color = SCRIPT_NUMBER;
        }
        else if (isScriptWordCharacter(text[index]))
        {
            while (index < static_cast<int>(text.size()) && isScriptWordCharacter(text[index]))
                index++;
            string word = text.substr(start, index - start);
            // Children access: workspace.Part.Child stays blue until ':' (method)
            bool memberAccess = false;
            if (start > 0 && text[start - 1] == '.')
                memberAccess = true;
            bool methodCall = false;
            if (index < (int)text.size() && text[index] == ':')
                methodCall = true;
            else if (start > 0 && text[start - 1] == ':')
                methodCall = true;

            if (isScriptLiteral(word))
                color = SCRIPT_LITERAL;
            else if (isScriptKeyword(word))
            {
                color = SCRIPT_KEYWORD;
                style = TextStyle::Bold;
            }
            else if (methodCall || (index < (int)text.size() && text[index] == '(' && !memberAccess))
            {
                // method/function: GetChildren() / FindFirstChild after ':' → yellow
                color = SCRIPT_FUNCTION;
            }
            else if (memberAccess)
            {
                // Instance child path remains blue (SCRIPT_BUILTIN-ish property blue)
                color = SCRIPT_BUILTIN;
            }
            else if (isScriptFunctionName(word, functionNames))
                color = SCRIPT_FUNCTION;
            else if (isScriptBuiltin(word))
                color = SCRIPT_BUILTIN;
            else if (isScriptTypeName(word))
                color = SCRIPT_TYPE;
            else if (index < (int)text.size() && text[index] == '(')
                color = SCRIPT_FUNCTION;
        }
        else
            index++;

        string token = text.substr(start, index - start);
        AppDrawTextStyled(token.c_str(), x, y, scriptFontSize, color, style);
        x += AppMeasureTextStyled(token.c_str(), scriptFontSize, style);
    }
}


// Shared UTF-8 cleanup for Luau source (paste, load, Play).
// Invisible / smart Unicode is a common cause of "attempt to call a nil value"
// after paste from web/docs — Luau sees bad tokens the editor may not show.
struct LuauSanitizeResult
{
    string text;
    int replaced = 0; // how many problem codepoints were fixed/removed
};

LuauSanitizeResult sanitizeLuauSourceBytes(const unsigned char* p, size_t len)
{
    LuauSanitizeResult r;
    if (p == nullptr)
        return r;
    const unsigned char* end = (len > 0) ? (p + len) : p + strlen(reinterpret_cast<const char*>(p));
    // UTF-8 BOM
    if (end - p >= 3 && p[0] == 0xEF && p[1] == 0xBB && p[2] == 0xBF)
    {
        p += 3;
        r.replaced++;
    }
    while (p < end)
    {
        unsigned char c = *p;
        // CR / CRLF → LF
        if (c == '\r')
        {
            r.replaced++;
            p++;
            if (*p == '\n')
                p++;
            r.text.push_back('\n');
            continue;
        }
        // ASCII controls except tab / newline
        if (c < 32 && c != '\n' && c != '\t')
        {
            r.replaced++;
            p++;
            continue;
        }
        if (c == 0x7F)
        {
            r.replaced++;
            p++;
            continue;
        }
        // ASCII printable + tab/newline
        if (c < 0x80)
        {
            r.text.push_back(static_cast<char>(c));
            p++;
            continue;
        }
        // --- UTF-8 multi-byte ---
        // NBSP U+00A0 → space
        if (c == 0xC2 && p[1] == 0xA0)
        {
            r.text.push_back(' ');
            r.replaced++;
            p += 2;
            continue;
        }
        // Soft hyphen U+00AD → drop
        if (c == 0xC2 && p[1] == 0xAD)
        {
            r.replaced++;
            p += 2;
            continue;
        }
        // E2 80 xx block: quotes, dashes, zero-width, etc.
        if (c == 0xE2 && p[1] == 0x80)
        {
            unsigned char t = p[2];
            // “ ” ‚ „
            if (t == 0x9C || t == 0x9D || t == 0x9E || t == 0x9A)
            { r.text.push_back('"'); r.replaced++; p += 3; continue; }
            // ‘ ’ ‛
            if (t == 0x98 || t == 0x99 || t == 0x9B)
            { r.text.push_back('\''); r.replaced++; p += 3; continue; }
            // – — ―
            if (t == 0x93 || t == 0x94 || t == 0x95)
            { r.text.push_back('-'); r.replaced++; p += 3; continue; }
            // …
            if (t == 0xA6)
            { r.text += "..."; r.replaced++; p += 3; continue; }
            // zero-width space/joiner/nonjoiner U+200B/C/D, WJ U+2060, BOM-ish
            if (t == 0x8B || t == 0x8C || t == 0x8D || t == 0x8E || t == 0x8F ||
                t == 0xAA || t == 0xAF)
            { r.replaced++; p += 3; continue; }
            // left/right-to-left marks U+200E/F
            if (t == 0x8E || t == 0x8F)
            { r.replaced++; p += 3; continue; }
        }
        // U+FEFF zero-width no-break space (UTF-8 EF BB BF already BOM; lone FEFF = EF BB BF)
        // Replacement char U+FFFD → drop (often shows as ?)
        if (c == 0xEF && p[1] == 0xBF && p[2] == 0xBD)
        {
            r.replaced++;
            p += 3;
            continue;
        }
        // Drop any other non-ASCII (editor font shows "?" and Luau may mis-tokenize)
        {
            int len = (c >= 0xF0) ? 4 : (c >= 0xE0) ? 3 : (c >= 0xC0) ? 2 : 1;
            // validate continuation bytes; if invalid, skip one byte
            bool ok = true;
            for (int k = 1; k < len; k++)
            {
                if ((p[k] & 0xC0) != 0x80) { ok = false; break; }
            }
            r.replaced++;
            p += ok ? len : 1;
            continue;
        }
    }
    return r;
}

string sanitizeScriptClipboardText(const char* clipboard)
{
    if (clipboard == nullptr)
        return "";
    return sanitizeLuauSourceBytes(reinterpret_cast<const unsigned char*>(clipboard), 0).text;
}

// Clean a script's source in-place. Returns how many problematic chars were fixed.
int sanitizeScriptSourceInPlace(string& source)
{
    LuauSanitizeResult r = sanitizeLuauSourceBytes(
        reinterpret_cast<const unsigned char*>(source.c_str()), source.size());
    if (r.text == source)
        return 0;
    source.swap(r.text);
    return r.replaced;
}


int measureScriptText(const string& text)
{
    int width = 0;
    int index = 0;
    while (index < static_cast<int>(text.size()))
    {
        int start = index;
        if (text[index] == '-' && index + 1 < static_cast<int>(text.size()) && text[index + 1] == '-')
        {
            width += AppMeasureTextStyled(text.substr(index).c_str(), scriptFontSize, TextStyle::Italic);
            break;
        }

        TextStyle style = TextStyle::Regular;
        if (text[index] == '"' || text[index] == '\'')
        {
            char quote = text[index++];
            while (index < static_cast<int>(text.size()))
            {
                if (text[index] == '\\' && index + 1 < static_cast<int>(text.size()))
                    index += 2;
                else if (text[index++] == quote)
                    break;
            }
        }
        else if (isdigit(static_cast<unsigned char>(text[index])))
        {
            while (index < static_cast<int>(text.size()) &&
                   (isdigit(static_cast<unsigned char>(text[index])) || text[index] == '.'))
                index++;
        }
        else if (isScriptWordCharacter(text[index]))
        {
            while (index < static_cast<int>(text.size()) && isScriptWordCharacter(text[index]))
                index++;
            string word = text.substr(start, index - start);
            if (isScriptKeyword(word))
                style = TextStyle::Bold;
        }
        else
            index++;

        width += AppMeasureTextStyled(text.substr(start, index - start).c_str(), scriptFontSize, style);
    }
    return width;
}

int getScriptLineCount(const string& source)
{
    return 1 + static_cast<int>(count(source.begin(), source.end(), '\n'));
}

int getScriptContentWidth(const string& source)
{
    int widest = 0;
    size_t lineStart = 0;
    while (lineStart <= source.size())
    {
        size_t lineEnd = source.find('\n', lineStart);
        if (lineEnd == string::npos)
            lineEnd = source.size();
        widest = max(widest, measureScriptText(source.substr(lineStart, lineEnd - lineStart)));
        if (lineEnd == source.size())
            break;
        lineStart = lineEnd + 1;
    }
    return 68 + widest;
}

Vector2 getScriptCursorPosition(const string& source, int cursor)
{
    cursor = std::clamp(cursor, 0, static_cast<int>(source.size()));
    int lineStart = 0;
    int line = 0;
    for (int index = 0; index < cursor; ++index)
    {
        if (source[index] == '\n')
        {
            line++;
            lineStart = index + 1;
        }
    }

    string beforeCursor = source.substr(lineStart, cursor - lineStart);
    return {
        leftSlotWidth() + 68.0f + measureScriptText(beforeCursor) - scriptScrollX,
        EDITOR_CONTENT_TOP + 10.0f + line * static_cast<float>(scriptFontSize + 6) - scriptScrollY
    };
}

string getScriptCompletionPrefix(const string& source, int cursor)
{
    int start = cursor;
    while (start > 0 && isScriptWordCharacter(source[start - 1]))
        start--;
    return source.substr(start, cursor - start);
}

vector<string> getScriptLocalNames(const string& source)
{
    vector<string> names;
    size_t searchStart = 0;
    while ((searchStart = source.find("local", searchStart)) != string::npos)
    {
        size_t nameStart = searchStart + 5;
        while (nameStart < source.size() && isspace(static_cast<unsigned char>(source[nameStart])))
            nameStart++;
        if (source.compare(nameStart, 8, "function") == 0)
            nameStart += 8;
        while (nameStart < source.size() && isspace(static_cast<unsigned char>(source[nameStart])))
            nameStart++;
        size_t nameEnd = nameStart;
        while (nameEnd < source.size() && isScriptWordCharacter(source[nameEnd]))
            nameEnd++;
        if (nameEnd > nameStart)
            names.push_back(source.substr(nameStart, nameEnd - nameStart));
        searchStart = max(nameEnd, searchStart + 5);
    }

    vector<string> functionNames = getScriptFunctionNames(source);
    names.insert(names.end(), functionNames.begin(), functionNames.end());
    return names;
}

void sanitizeScriptEditorState(const string& source)
{
    int sourceSize = static_cast<int>(source.size());
    scriptCursor = std::clamp(scriptCursor, 0, sourceSize);
    if (scriptSelectionStart < 0 || scriptSelectionEnd < 0)
    {
        scriptSelectionStart = -1;
        scriptSelectionEnd = -1;
    }
    else
    {
        scriptSelectionStart = std::clamp(scriptSelectionStart, 0, sourceSize);
        scriptSelectionEnd = std::clamp(scriptSelectionEnd, 0, sourceSize);
    }
    if (scriptCompletionMatches.empty())
    {
        scriptCompletionVisible = false;
        scriptCompletionIndex = 0;
    }
    else
    {
        scriptCompletionIndex = std::clamp(scriptCompletionIndex, 0,
            static_cast<int>(scriptCompletionMatches.size()) - 1);
    }
}

Instance* findChildByName(Instance* parent, const string& name)
{
    if (parent == nullptr)
        return nullptr;
    for (Instance* child : parent->children)
        if (child != nullptr && child->name == name)
            return child;
    return nullptr;
}

string unescapeRuntimeValue(const string& value)
{
    string result;
    for (size_t index = 0; index < value.size(); ++index)
    {
        if (value[index] == '%')
        {
            size_t end = value.find('%', index + 1);
            if (end != string::npos)
            {
                string code = value.substr(index + 1, end - index - 1);
                char* parseEnd = nullptr;
                long number = strtol(code.c_str(), &parseEnd, 10);
                if (parseEnd != code.c_str() && *parseEnd == '\0' && number >= 0 && number <= 255)
                {
                    result += static_cast<char>(number);
                    index = end;
                    continue;
                }
            }
        }
        result += value[index];
    }
    return result;
}

Instance* findInstanceByRuntimePath(const string& path)
{
    if (path.empty() || path == "game")
        return &game;

    // Stable path map (survives Name changes)
    auto it = runtimePathToInstance.find(path);
    if (it != runtimePathToInstance.end() && it->second != nullptr)
        return it->second;
    // Alternate keys without "game/" prefix
    if (path.rfind("game/", 0) == 0)
    {
        auto it2 = runtimePathToInstance.find(path.substr(5));
        if (it2 != runtimePathToInstance.end() && it2->second != nullptr)
            return it2->second;
    }
    else
    {
        auto it2 = runtimePathToInstance.find("game/" + path);
        if (it2 != runtimePathToInstance.end() && it2->second != nullptr)
            return it2->second;
    }

    string p = path;
    if (p.rfind("game/", 0) == 0)
        p = p.substr(5);

    Instance* current = &game;
    size_t start = 0;
    while (start < p.size())
    {
        size_t end = p.find('/', start);
        string seg = p.substr(start, end == string::npos ? string::npos : end - start);
        if (!seg.empty())
        {
            current = findChildByName(current, seg);
            if (current == nullptr)
                return nullptr;
        }
        if (end == string::npos)
            break;
        start = end + 1;
    }
    return current;
}

void stopRuntimeSoundPath(const string& path)
{
    auto it = runtimeSoundStreams.find(path);
    if (it != runtimeSoundStreams.end())
    {
        StopMusicStream(it->second);
        UnloadMusicStream(it->second);
        runtimeSoundStreams.erase(it);
    }
    auto jt = runtimeSoundTempFiles.find(path);
    if (jt != runtimeSoundTempFiles.end())
    {
        error_code ec;
        filesystem::remove(jt->second, ec);
        runtimeSoundTempFiles.erase(jt);
    }
    runtimeSoundPlaying[path] = false;
}

bool playRuntimeSoundInstance(SoundInstance* sound, const string& path, bool fromStart)
{
    if (sound == nullptr || sound->soundId.empty() || !audioDeviceReady)
        return false;
    ProjectAsset* asset = findProjectAssetById(sound->soundId);
    if (asset == nullptr)
    {
        addOutputLog("[Sound] Unknown SoundId: " + sound->soundId);
        return false;
    }
    vector<uint8_t> raw = getProjectAssetRawBytes(*asset);
    if (raw.empty())
        return false;

    stopRuntimeSoundPath(path);
    string token = sanitizeAssetFileToken(asset->id);
    string tempPath = makeTempFilePath("bt_rt_" + token + "." + asset->fileType);
    {
        ofstream tmp(tempPath, ios::binary);
        if (!tmp)
            return false;
        const size_t chunk = 256ull * 1024ull;
        size_t off = 0;
        while (off < raw.size())
        {
            size_t n = min(chunk, raw.size() - off);
            tmp.write(reinterpret_cast<const char*>(raw.data() + off),
                static_cast<std::streamsize>(n));
            if (!tmp)
                return false;
            off += n;
        }
    }
    // Keep file until UnloadMusicStream — deleting early crashes the stream reader.
    Music music = LoadMusicStream(tempPath.c_str());
    if (music.frameCount == 0)
    {
        error_code ec;
        filesystem::remove(tempPath, ec);
        addOutputLog("[Sound] LoadMusicStream failed for " + sound->soundId);
        return false;
    }

    SetMusicVolume(music, std::clamp(sound->volume, 0.0f, 1.0f));
    SetMusicPitch(music, max(0.01f, sound->playbackSpeed));
    if (fromStart || sound->timePosition <= 0.0f)
        SeekMusicStream(music, 0.0f);
    else
        SeekMusicStream(music, sound->timePosition);
    PlayMusicStream(music);
    runtimeSoundStreams[path] = music;
    runtimeSoundTempFiles[path] = tempPath;
    runtimeSoundPlaying[path] = true;
    sound->playing = true;
    return true;
}

void applyRuntimeSoundCommand(const string& command)
{
    size_t bar = command.find('|');
    if (bar == string::npos)
        return;
    string path = unescapeRuntimeValue(command.substr(0, bar));
    string cmd = command.substr(bar + 1);
    Instance* instance = findInstanceByRuntimePath(path);
    if (instance == nullptr || instance->getType() != InstanceType::Sound)
        return;
    SoundInstance* sound = static_cast<SoundInstance*>(instance);
    if (cmd == "Play")
    {
        playRuntimeSoundInstance(sound, path, false);
    }
    else if (cmd == "Stop")
    {
        stopRuntimeSoundPath(path);
        sound->playing = false;
        sound->timePosition = 0.0f;
    }
}

void updateRuntimeSounds()
{
    for (auto& pair : runtimeSoundStreams)
    {
        UpdateMusicStream(pair.second);
        Instance* inst = findInstanceByRuntimePath(pair.first);
        SoundInstance* sound = (inst && inst->getType() == InstanceType::Sound)
            ? static_cast<SoundInstance*>(inst) : nullptr;
        bool looped = sound ? sound->looped : false;
        if (!IsMusicStreamPlaying(pair.second))
        {
            if (looped && runtimeSoundPlaying[pair.first])
            {
                SeekMusicStream(pair.second, 0.0f);
                PlayMusicStream(pair.second);
                if (sound) sound->timePosition = 0.0f;
            }
            else
            {
                runtimeSoundPlaying[pair.first] = false;
                if (sound)
                {
                    sound->playing = false;
                    sound->timePosition = 0.0f;
                }
            }
        }
        else if (sound)
        {
            sound->timePosition = GetMusicTimePlayed(pair.second);
            sound->playing = true;
        }
    }
}

void clearRuntimeSounds()
{
    for (auto& pair : runtimeSoundStreams)
    {
        StopMusicStream(pair.second);
        UnloadMusicStream(pair.second);
    }
    runtimeSoundStreams.clear();
    for (auto& pair : runtimeSoundTempFiles)
    {
        error_code ec;
        filesystem::remove(pair.second, ec);
    }
    runtimeSoundTempFiles.clear();
    runtimeSoundPlaying.clear();
}

void applyRuntimePropertyUpdate(const string& command)
{
    size_t first = command.find('|');
    size_t second = first == string::npos ? string::npos : command.find('|', first + 1);
    if (first == string::npos || second == string::npos)
        return;

    Instance* instance = findInstanceByRuntimePath(unescapeRuntimeValue(command.substr(0, first)));
    if (instance == nullptr)
        return;

    string property = unescapeRuntimeValue(command.substr(first + 1, second - first - 1));
    string value = unescapeRuntimeValue(command.substr(second + 1));

    if (property == "Name")
    {
        // Display name only — runtime path map keys stay stable so Size/Color/etc keep working
        if (!value.empty())
            instance->name = value;
        return;
    }

    if (property == "Parent")
    {
        // Client scripts are limited to Client-side changes: only allow reparent
        // of instances created at runtime in client mode (not the shared server tree).
        if (runtimeClientMode)
        {
            bool isRuntimeCreated = find(runtimeCreatedInstances.begin(), runtimeCreatedInstances.end(), instance)
                != runtimeCreatedInstances.end();
            if (!isRuntimeCreated)
            {
                // Soft block: ignore structural edits to pre-existing instances from client context.
                return;
            }
        }
        // value is parent runtime path, or empty to unparent
        if (value.empty() || value == "nil" || value == "null")
        {
            removeInstanceFromParent(instance);
            return;
        }
        Instance* newParent = findInstanceByRuntimePath(value);
        if (newParent == nullptr)
            return;
        if (newParent == instance)
            return;
        // Prevent parenting under own descendant
        for (Instance* walk = newParent; walk != nullptr; walk = walk->parent)
        {
            if (walk == instance)
                return;
        }
        removeInstanceFromParent(instance);
        addInstanceToParent(newParent, instance);
        return;
    }

    if (instance->getType() == InstanceType::Model && property == "Scale")
    {
        char* end = nullptr;
        float targetScale = strtof(value.c_str(), &end);
        if (end != value.c_str() && *end == '\0' && isfinite(targetScale) && targetScale > 0.0f)
            scaleModelTo(*static_cast<Model_Instance*>(instance), targetScale);
        return;
    }

    char* propertyNumberEnd = nullptr;
    const float propertyNumber = strtof(value.c_str(), &propertyNumberEnd);
    const bool validPropertyNumber = propertyNumberEnd != value.c_str() &&
        *propertyNumberEnd == '\0' && isfinite(propertyNumber);
    auto decodeLightColor = [](const string& encoded, Color fallback)
    {
        if (encoded.rfind("C3:", 0) != 0)
            return fallback;
        float r = 0.0f, g = 0.0f, b = 0.0f;
        if (sscanf(encoded.c_str() + 3, "%f,%f,%f", &r, &g, &b) != 3)
            return fallback;
        return Color{
            static_cast<unsigned char>(std::clamp(r * 255.0f, 0.0f, 255.0f)),
            static_cast<unsigned char>(std::clamp(g * 255.0f, 0.0f, 255.0f)),
            static_cast<unsigned char>(std::clamp(b * 255.0f, 0.0f, 255.0f)),
            255
        };
    };
    if (instance->getType() == InstanceType::PointLight)
    {
        auto* light = static_cast<PointLightInstance*>(instance);
        if (property == "Enabled") light->enabled = value == "true" || value == "True";
        else if (property == "Shadows") light->shadows = value == "true" || value == "True";
        else if (property == "Brightness" && validPropertyNumber) light->brightness = std::clamp(propertyNumber, 0.0f, 200.0f);
        else if (property == "Range" && validPropertyNumber) light->range = std::clamp(propertyNumber, 0.0f, 200.0f);
        else if (property == "Color") light->color = decodeLightColor(value, light->color);
        return;
    }
    if (instance->getType() == InstanceType::SpotLight)
    {
        auto* light = static_cast<SpotLightInstance*>(instance);
        if (property == "Enabled") light->enabled = value == "true" || value == "True";
        else if (property == "Shadows") light->shadows = value == "true" || value == "True";
        else if (property == "Brightness" && validPropertyNumber) light->brightness = std::clamp(propertyNumber, 0.0f, 200.0f);
        else if (property == "Range" && validPropertyNumber) light->range = std::clamp(propertyNumber, 0.0f, 200.0f);
        else if (property == "Angle" && validPropertyNumber) light->angle = std::clamp(propertyNumber, 0.0f, 180.0f);
        else if (property == "Face") light->face = value;
        else if (property == "Color") light->color = decodeLightColor(value, light->color);
        return;
    }
    if (instance->getType() == InstanceType::SurfaceLight)
    {
        auto* light = static_cast<SurfaceLightInstance*>(instance);
        if (property == "Enabled") light->enabled = value == "true" || value == "True";
        else if (property == "Shadows") light->shadows = value == "true" || value == "True";
        else if (property == "Brightness" && validPropertyNumber) light->brightness = std::clamp(propertyNumber, 0.0f, 200.0f);
        else if (property == "Range" && validPropertyNumber) light->range = std::clamp(propertyNumber, 0.0f, 200.0f);
        else if (property == "Angle" && validPropertyNumber) light->angle = std::clamp(propertyNumber, 0.0f, 180.0f);
        else if (property == "Face") light->face = value;
        else if (property == "Color") light->color = decodeLightColor(value, light->color);
        return;
    }

    if (instance->getType() == InstanceType::Sound)
    {
        SoundInstance* sound = static_cast<SoundInstance*>(instance);
        string path = unescapeRuntimeValue(command.substr(0, first));
        if (property == "SoundId")
            sound->soundId = normalizeAssetId(value);
        else if (property == "Volume")
        {
            sound->volume = std::clamp(strtof(value.c_str(), nullptr), 0.0f, 10.0f);
            auto it = runtimeSoundStreams.find(path);
            if (it != runtimeSoundStreams.end())
                SetMusicVolume(it->second, std::clamp(sound->volume, 0.0f, 1.0f));
        }
        else if (property == "PlaybackSpeed" || property == "PlayingSpeed")
        {
            sound->playbackSpeed = max(0.01f, strtof(value.c_str(), nullptr));
            auto it = runtimeSoundStreams.find(path);
            if (it != runtimeSoundStreams.end())
                SetMusicPitch(it->second, sound->playbackSpeed);
        }
        else if (property == "Looped")
            sound->looped = (value == "true" || value == "True");
        else if (property == "Playing")
        {
            bool play = (value == "true" || value == "True");
            if (play)
            {
                // Playing = true plays (without requiring :Play())
                playRuntimeSoundInstance(sound, path, false);
            }
            else
            {
                // Playing = false stops and restarts position to 0
                stopRuntimeSoundPath(path);
                sound->playing = false;
                sound->timePosition = 0.0f;
            }
        }
        else if (property == "TimePosition")
        {
            sound->timePosition = max(0.0f, strtof(value.c_str(), nullptr));
            auto it = runtimeSoundStreams.find(path);
            if (it != runtimeSoundStreams.end())
                SeekMusicStream(it->second, sound->timePosition);
        }
        return;
    }

    if (instance->getType() == InstanceType::Texture)
    {
        TextureInstance* tex = static_cast<TextureInstance*>(instance);
        if (property == "Texture")
            tex->texture = normalizeAssetId(value);
        else if (property == "Face")
            tex->face = value;
        else if (property == "StudsPerTileU")
            tex->studsPerTileU = max(0.01f, strtof(value.c_str(), nullptr));
        else if (property == "StudsPerTileV")
            tex->studsPerTileV = max(0.01f, strtof(value.c_str(), nullptr));
        else if (property == "Transparency")
            tex->transparency = std::clamp(strtof(value.c_str(), nullptr), 0.0f, 1.0f);
        return;
    }

    if (instance->getType() == InstanceType::Humanoid)
    {
        HumanoidInstance* humanoid = static_cast<HumanoidInstance*>(instance);
        if (property == "Health") humanoid->health = std::clamp(strtof(value.c_str(), nullptr), 0.0f, humanoid->maxHealth);
        else if (property == "MaxHealth") humanoid->maxHealth = max(1.0f, strtof(value.c_str(), nullptr));
        else if (property == "WalkSpeed") humanoid->walkSpeed = max(0.0f, strtof(value.c_str(), nullptr));
        else if (property == "JumpPower") humanoid->jumpPower = max(0.0f, strtof(value.c_str(), nullptr));
        else if (property == "HipHeight") humanoid->hipHeight = max(0.0f, strtof(value.c_str(), nullptr));
        return;
    }

    if (instance->getType() == InstanceType::Camera)
    {
        CameraInstance* cameraInstance = static_cast<CameraInstance*>(instance);
        if (property == "Mode")
            cameraInstance->mode = value == "Scriptable" ? BT_CameraMode::Scriptable : BT_CameraMode::Default;
        else if (property == "CFrame" && value.rfind("CF:", 0) == 0)
        {
            float px = 0, py = 0, pz = 0, rx = 0, ry = 0, rz = 0;
            if (sscanf(value.c_str() + 3, "%f,%f,%f,%f,%f,%f", &px, &py, &pz, &rx, &ry, &rz) == 6)
                cameraInstance->cframe = { { px, py, pz }, { rx, ry, rz } };
        }
        return;
    }

    if (instance->getType() != InstanceType::Part)
        return;

    Part* part = static_cast<Part*>(instance);
    auto parseV3 = [](const string& s, Vector3 fallback) -> Vector3
    {
        if (s.rfind("V3:", 0) != 0) return fallback;
        float x = 0, y = 0, z = 0;
        if (sscanf(s.c_str() + 3, "%f,%f,%f", &x, &y, &z) == 3)
            return { x, y, z };
        return fallback;
    };
    auto parseC3 = [](const string& s, Color fallback) -> Color
    {
        if (s.rfind("C3:", 0) != 0) return fallback;
        float r = 0, g = 0, b = 0;
        if (sscanf(s.c_str() + 3, "%f,%f,%f", &r, &g, &b) == 3)
            return {
                static_cast<unsigned char>(std::clamp(r * 255.0f, 0.0f, 255.0f)),
                static_cast<unsigned char>(std::clamp(g * 255.0f, 0.0f, 255.0f)),
                static_cast<unsigned char>(std::clamp(b * 255.0f, 0.0f, 255.0f)),
                255
            };
        return fallback;
    };

    if (property == "Anchored") part->anchored = (value == "true" || value == "True");
    else if (property == "CanCollide") part->canCollide = (value == "true" || value == "True");
    else if (property == "CastShadow") part->castShadow = (value == "true" || value == "True");
    else if (property == "AdvancedPhysics") part->advancedPhysics = (value == "true" || value == "True");
    else if (property == "Density" && validPropertyNumber)
        part->density = std::clamp(propertyNumber, 0.01f, 100.0f);
    else if (property == "Friction" && validPropertyNumber)
        part->friction = std::clamp(propertyNumber, 0.0f, 1.0f);
    else if (property == "Truss") part->truss = (value == "true" || value == "True");
    else if (property == "Locked") part->locked = (value == "true" || value == "True");
    else if (property == "LocalAxes" || property == "ShowLocalAxes")
        part->showLocalAxes = (value == "true" || value == "True");
    else if (property == "Transparency") part->transparency = std::clamp(strtof(value.c_str(), nullptr), 0.0f, 1.0f);
    else if (property == "MeshId" && part->isMeshPart)
        part->meshId = (value == "nil" || value == "null") ? "" : normalizeAssetId(value);
    else if (property == "TextureId" && part->isMeshPart)
        part->textureId = (value == "nil" || value == "null") ? "" : normalizeAssetId(value);
    else if (property == "CollisionFidelity" && part->isMeshPart)
        part->collisionFidelity = parseCollisionFidelity(value);
    else if (property == "PartType" && !part->isMeshPart) part->type = parsePartType(value);
    else if (property == "Position") part->cframe.position = parseV3(value, part->cframe.position);
    else if (property == "Orientation") part->cframe.rotation = parseV3(value, part->cframe.rotation);
    else if (property == "Size")
    {
        Vector3 sz = parseV3(value, part->size);
        part->size = { max(0.1f, sz.x), max(0.1f, sz.y), max(0.1f, sz.z) };
    }
    else if (property == "PivotOffset") part->pivotOffset = parseV3(value, part->pivotOffset);
    else if (property == "Color") part->color = parseC3(value, part->color);
    else if (property == "CFrame" && value.rfind("CF:", 0) == 0)
    {
        float x=0,y=0,z=0,rx=0,ry=0,rz=0;
        if (sscanf(value.c_str() + 3, "%f,%f,%f,%f,%f,%f", &x, &y, &z, &rx, &ry, &rz) == 6)
        {
            part->cframe.position = { x, y, z };
            part->cframe.rotation = { rx, ry, rz };
        }
    }
}

void applyRuntimeCreateCommand(const string& command)
{
    // class|stableName|parentPath   (stableName is path leaf; never changes when .Name is set)
    size_t b1 = command.find('|');
    if (b1 == string::npos) return;
    size_t b2 = command.find('|', b1 + 1);
    if (b2 == string::npos) return;
    string className = unescapeRuntimeValue(command.substr(0, b1));
    string stableName = unescapeRuntimeValue(command.substr(b1 + 1, b2 - b1 - 1));
    string parentPath = unescapeRuntimeValue(command.substr(b2 + 1));

    Instance* parent = findInstanceByRuntimePath(parentPath);
    if (parent == nullptr)
        parent = &workspace;

    Instance* created = nullptr;
    // Display name is the class type (Part, Folder, Model…) — stableName is only the path leaf
    string displayName = className.empty() ? "Instance" : className;
    if (className == "Part" || className == "MeshPart")
    {
        Part* p = new Part();
        p->name = displayName;
        p->type = PartType::Block;
        p->isMeshPart = className == "MeshPart";
        p->size = { 1, 1, 1 };
        p->cframe.position = { 0, 0.5f, 0 };
        p->color = { 163, 162, 165, 255 };
        p->anchored = true;
        p->canCollide = true;
        created = p;
    }
    else if (className == "PointLight")
    {
        auto* light = new PointLightInstance();
        light->name = displayName;
        created = light;
    }
    else if (className == "SpotLight")
    {
        auto* light = new SpotLightInstance();
        light->name = displayName;
        created = light;
    }
    else if (className == "SurfaceLight")
    {
        auto* light = new SurfaceLightInstance();
        light->name = displayName;
        created = light;
    }
    else if (className == "Folder")
    {
        Folder* f = new Folder();
        f->name = displayName;
        created = f;
    }
    else if (className == "Model")
    {
        Model_Instance* m = new Model_Instance();
        m->name = displayName;
        created = m;
    }
    else if (className == "SpawnLocation")
    {
        // Treat as an anchored Part (spawn pad)
        Part* p = new Part();
        p->name = displayName.empty() ? "SpawnLocation" : displayName;
        p->type = PartType::Block;
        p->size = { 4, 1, 4 };
        p->cframe.position = { 0, 0.5f, 0 };
        p->color = { 100, 180, 100, 255 };
        p->anchored = true;
        p->canCollide = true;
        created = p;
    }
    else if (className == "ScreenGui" || className == "SurfaceGui" || className == "BillboardGui")
    {
        auto* lc = new LayerCollectorInstance();
        if (className == "SurfaceGui") lc->layerType = InstanceType::SurfaceGui;
        else if (className == "BillboardGui") lc->layerType = InstanceType::BillboardGui;
        else lc->layerType = InstanceType::ScreenGui;
        lc->name = displayName;
        created = lc;
    }
    else if (className == "Frame" || className == "ScrollingFrame" || className == "TextLabel" ||
             className == "ImageLabel" || className == "TextButton" || className == "ImageButton" ||
             className == "TextBox")
    {
        auto* g = new GuiObjectInstance();
        if (className == "ScrollingFrame") g->guiType = InstanceType::ScrollingFrame;
        else if (className == "TextLabel") { g->guiType = InstanceType::TextLabel; g->text = "Label"; g->backgroundTransparency = 1.0f; }
        else if (className == "ImageLabel") { g->guiType = InstanceType::ImageLabel; g->backgroundTransparency = 1.0f; }
        else if (className == "TextButton") { g->guiType = InstanceType::TextButton; g->text = "Button"; }
        else if (className == "ImageButton") { g->guiType = InstanceType::ImageButton; g->backgroundTransparency = 1.0f; }
        else if (className == "TextBox") { g->guiType = InstanceType::TextBox; g->placeholderText = "Text here"; }
        else g->guiType = InstanceType::Frame;
        g->name = displayName;
        created = g;
    }
    else if (className == "UICorner" || className == "UIListLayout" || className == "UIStroke" ||
             className == "UIPadding" || className == "UIGridLayout" || className == "UIAspectRatioConstraint")
    {
        auto* m = new UIModifierInstance();
        if (className == "UIListLayout") m->modType = InstanceType::UIListLayout;
        else if (className == "UIStroke") m->modType = InstanceType::UIStroke;
        else if (className == "UIPadding") m->modType = InstanceType::UIPadding;
        else if (className == "UIGridLayout") m->modType = InstanceType::UIGridLayout;
        else if (className == "UIAspectRatioConstraint") m->modType = InstanceType::UIAspectRatioConstraint;
        else m->modType = InstanceType::UICorner;
        m->name = displayName;
        created = m;
    }
    if (created != nullptr)
    {
        addInstanceToParent(parent, created);
        runtimeCreatedInstances.push_back(created);
        // Runtime-created instances start with children collapsed in Explorer
        if (!created->children.empty())
            setExplorerExpanded(created, false);
        // Also collapse parent if it just gained a child (keeps tree tidy)
        if (parent != nullptr && !parent->children.empty())
            setExplorerExpanded(parent, false);

        // Register stable path keys (Name changes must NOT break lookups)
        string full = parentPath;
        if (!full.empty() && full.back() == '/')
            full.pop_back();
        if (full.empty())
            full = "game/Workspace";
        full += "/" + stableName;
        runtimePathToInstance[full] = created;
        if (full.rfind("game/", 0) == 0)
            runtimePathToInstance[full.substr(5)] = created;
        else
            runtimePathToInstance["game/" + full] = created;
    }
}


void captureRuntimeInstanceState(Instance* instance)
{
    if (instance == nullptr)
        return;

    RuntimeInstanceSnapshot snapshot;
    snapshot.instance = instance;
    snapshot.name = instance->name;
    snapshot.isPart = instance->getType() == InstanceType::Part;
    if (snapshot.isPart)
    {
        const Part* part = static_cast<const Part*>(instance);
        snapshot.anchored = part->anchored;
        snapshot.size = part->size;
        snapshot.color = part->color;
        snapshot.cframe = part->cframe;
        snapshot.velocity = part->velocity;
    }
    runtimeInstanceSnapshot.push_back(snapshot);

    for (Instance* child : instance->children)
        captureRuntimeInstanceState(child);
}

void restoreRuntimeInstanceState()
{
    for (const RuntimeInstanceSnapshot& snapshot : runtimeInstanceSnapshot)
    {
        if (snapshot.instance == nullptr)
            continue;

        snapshot.instance->name = snapshot.name;
        if (snapshot.isPart && snapshot.instance->getType() == InstanceType::Part)
        {
            Part* part = static_cast<Part*>(snapshot.instance);
            part->anchored = snapshot.anchored;
            part->size = snapshot.size;
            part->color = snapshot.color;
            part->cframe = snapshot.cframe;
            part->velocity = snapshot.velocity;
        }
    }
    runtimeInstanceSnapshot.clear();
}

// Parse ModuleScript source for exported keys: return { foo = ..., bar = function }
static vector<string> parseModuleExportKeys(const string& modSource)
{
    vector<string> keys;
    // Prefer last "return { ... }" table
    size_t ret = modSource.rfind("return");
    if (ret == string::npos) return keys;
    size_t brace = modSource.find('{', ret);
    if (brace == string::npos) return keys;
    size_t i = brace + 1;
    int depth = 1;
    while (i < modSource.size() && depth > 0)
    {
        char c = modSource[i];
        if (c == '{') depth++;
        else if (c == '}') depth--;
        else if (depth == 1)
        {
            // key =  or  ["key"] =  or  key =
            if (isScriptWordCharacter(c))
            {
                size_t start = i;
                while (i < modSource.size() && isScriptWordCharacter(modSource[i])) i++;
                string key = modSource.substr(start, i - start);
                while (i < modSource.size() && isspace((unsigned char)modSource[i])) i++;
                if (i < modSource.size() && modSource[i] == '=')
                {
                    if (!key.empty() && key != "function" && key != "local" && key != "end")
                        keys.push_back(key);
                }
                continue;
            }
            if (c == '"' || c == '\'')
            {
                char q = c;
                size_t start = ++i;
                while (i < modSource.size() && modSource[i] != q)
                {
                    if (modSource[i] == '\\' && i + 1 < modSource.size()) i += 2;
                    else i++;
                }
                string key = modSource.substr(start, i - start);
                if (i < modSource.size()) i++;
                while (i < modSource.size() && isspace((unsigned char)modSource[i])) i++;
                if (i < modSource.size() && modSource[i] == '=')
                    keys.push_back(key);
                continue;
            }
        }
        i++;
    }
    // Also: function ModuleName.foo / module.foo =
    size_t search = 0;
    while ((search = modSource.find("function ", search)) != string::npos)
    {
        size_t n = search + 9;
        while (n < modSource.size() && isspace((unsigned char)modSource[n])) n++;
        size_t nameStart = n;
        while (n < modSource.size() && (isScriptWordCharacter(modSource[n]) || modSource[n] == '.' || modSource[n] == ':'))
            n++;
        string full = modSource.substr(nameStart, n - nameStart);
        size_t dot = full.find_last_of(".:");
        if (dot != string::npos && dot + 1 < full.size())
        {
            string key = full.substr(dot + 1);
            if (!key.empty())
                keys.push_back(key);
        }
        search = n;
    }
    sort(keys.begin(), keys.end());
    keys.erase(unique(keys.begin(), keys.end()), keys.end());
    return keys;
}

static Script* findModuleScriptByName(Instance* root, const string& name)
{
    if (root == nullptr) return nullptr;
    if (root->getType() == InstanceType::Script)
    {
        Script* s = static_cast<Script*>(root);
        if (s->type == ScriptType::ModuleScript && s->name == name)
            return s;
    }
    for (Instance* c : root->children)
    {
        Script* found = findModuleScriptByName(c, name);
        if (found) return found;
    }
    return nullptr;
}

vector<string> getScriptMemberCompletions(const string& source, int cursor, char& separator)
{
    vector<string> members;
    separator = 0;
    int chainEnd = cursor;
    while (chainEnd > 0 && isScriptWordCharacter(source[chainEnd - 1]))
        chainEnd--;
    if (chainEnd <= 0 || (source[chainEnd - 1] != '.' && source[chainEnd - 1] != ':'))
        return members;

    separator = source[chainEnd - 1];
    int chainEndBeforeSeparator = chainEnd - 1;
    int chainStart = chainEndBeforeSeparator;
    int bracketDepth = 0;
    char bracketQuote = '\0';
    while (chainStart > 0)
    {
        char character = source[chainStart - 1];
        if (bracketQuote != '\0')
        {
            if (character == bracketQuote &&
                (chainStart < 2 || source[chainStart - 2] != '\\'))
                bracketQuote = '\0';
            chainStart--;
            continue;
        }
        if (bracketDepth > 0)
        {
            if (character == '"' || character == '\'')
                bracketQuote = character;
            else if (character == ']')
                bracketDepth++;
            else if (character == '[')
                bracketDepth--;
            chainStart--;
            continue;
        }
        if (isScriptWordCharacter(character) || character == '.')
            chainStart--;
        else if (character == ']')
        {
            bracketDepth = 1;
            chainStart--;
        }
        else
            break;
    }

    string chain = source.substr(chainStart, chainEndBeforeSeparator - chainStart);
    size_t cursorInChain = 0;
    while (cursorInChain < chain.size() &&
        isScriptWordCharacter(chain[cursorInChain]))
        cursorInChain++;
    string rootIdentifier = chain.substr(0, cursorInChain);
    vector<string> childNames;
    vector<int> childIndices;
    bool validChain = !rootIdentifier.empty();
    while (validChain && cursorInChain < chain.size())
    {
        if (chain[cursorInChain] == '.')
        {
            cursorInChain++;
            size_t nameStart = cursorInChain;
            while (cursorInChain < chain.size() &&
                isScriptWordCharacter(chain[cursorInChain]))
                cursorInChain++;
            if (nameStart == cursorInChain)
            {
                validChain = false;
                break;
            }
            childNames.push_back(chain.substr(nameStart, cursorInChain - nameStart));
            childIndices.push_back(0);
            continue;
        }
        if (chain[cursorInChain] != '[')
        {
            validChain = false;
            break;
        }
        cursorInChain++;
        while (cursorInChain < chain.size() && isspace(static_cast<unsigned char>(chain[cursorInChain])))
            cursorInChain++;
        if (cursorInChain >= chain.size())
        {
            validChain = false;
            break;
        }
        if (chain[cursorInChain] == '"' || chain[cursorInChain] == '\'')
        {
            char quote = chain[cursorInChain++];
            string name;
            while (cursorInChain < chain.size() && chain[cursorInChain] != quote)
            {
                if (chain[cursorInChain] == '\\' && cursorInChain + 1 < chain.size())
                    cursorInChain++;
                name += chain[cursorInChain++];
            }
            if (cursorInChain >= chain.size())
            {
                validChain = false;
                break;
            }
            cursorInChain++;
            while (cursorInChain < chain.size() && isspace(static_cast<unsigned char>(chain[cursorInChain])))
                cursorInChain++;
            if (cursorInChain >= chain.size() || chain[cursorInChain++] != ']')
            {
                validChain = false;
                break;
            }
            childNames.push_back(name);
            childIndices.push_back(0);
            continue;
        }

        size_t numberStart = cursorInChain;
        while (cursorInChain < chain.size() && isdigit(static_cast<unsigned char>(chain[cursorInChain])))
            cursorInChain++;
        if (numberStart == cursorInChain)
        {
            validChain = false;
            break;
        }
        int childIndex = atoi(chain.c_str() + numberStart);
        while (cursorInChain < chain.size() && isspace(static_cast<unsigned char>(chain[cursorInChain])))
            cursorInChain++;
        if (cursorInChain >= chain.size() || chain[cursorInChain++] != ']' || childIndex <= 0)
        {
            validChain = false;
            break;
        }
        childNames.push_back(string());
        childIndices.push_back(childIndex);
    }

    Instance* current = nullptr;
    if (validChain && rootIdentifier == "game")
        current = &game;
    else if (validChain && rootIdentifier == "workspace")
        current = &workspace;
    for (size_t index = 0; current != nullptr && index < childNames.size(); ++index)
    {
        if (childIndices[index] > 0)
        {
            int childIndex = childIndices[index] - 1;
            current = childIndex < static_cast<int>(current->children.size())
                ? current->children[childIndex] : nullptr;
        }
        else
            current = findChildByName(current, childNames[index]);
    }

    string prefix = getScriptCompletionPrefix(source, cursor);

    // Module require completion: local M = require(SomeModule) then M. → export keys
    if (current == nullptr && validChain && childNames.empty())
    {
        const string& varName = rootIdentifier;
        // Find: varName = require( ... ModuleName ... )
        size_t search = 0;
        Script* mod = nullptr;
        while ((search = source.find(varName, search)) != string::npos)
        {
            size_t after = search + varName.size();
            while (after < source.size() && isspace((unsigned char)source[after])) after++;
            if (after < source.size() && source[after] == '=')
            {
                size_t req = source.find("require", after);
                if (req != string::npos && req < after + 40)
                {
                    size_t open = source.find('(', req);
                    size_t close = open == string::npos ? string::npos : source.find(')', open);
                    if (open != string::npos && close != string::npos)
                    {
                        string arg = source.substr(open + 1, close - open - 1);
                        // Last identifier in require(...) is the ModuleScript name
                        size_t idEnd = arg.size();
                        while (idEnd > 0 && !isScriptWordCharacter(arg[idEnd - 1])) idEnd--;
                        size_t idStart = idEnd;
                        while (idStart > 0 && isScriptWordCharacter(arg[idStart - 1])) idStart--;
                        string modName = arg.substr(idStart, idEnd - idStart);
                        if (!modName.empty())
                        {
                            mod = findModuleScriptByName(&game, modName);
                            if (mod == nullptr) mod = findModuleScriptByName(&workspace, modName);
                        }
                    }
                }
            }
            search = after;
            if (mod) break;
        }
        if (mod != nullptr)
        {
            for (const string& key : parseModuleExportKeys(mod->source))
                if (key.rfind(prefix, 0) == 0)
                    members.push_back(key);
            return members;
        }
    }

    if (current != nullptr)
    {
        // Priority: children > properties > methods. Use the actual instance
        // class so communication APIs do not appear on unrelated objects.
        for (Instance* child : current->children)
            if (child != nullptr && (!child->hidden || showHiddenAssets) && child->name.rfind(prefix, 0) == 0)
                members.push_back(child->name);

        vector<string> properties = {
            "Name", "ClassName", "Parent", "Position", "Orientation", "Size", "Color",
            "CFrame", "Anchored", "AdvancedPhysics", "Density", "Friction", "CanCollide", "Locked",
            "LocalAxes", "Transparency", "CastShadow", "PivotOffset",
            "Changed", "Touched", "AncestryChanged", "GetPropertyChangedSignal", "GetAttributeChangedSignal"
        };

        if (current->getType() == InstanceType::BindableEvent)
            properties.insert(properties.end(), { "Event", "Fire" });
        else if (current->getType() == InstanceType::RemoteEvent)
            properties.insert(properties.end(), { "OnServerEvent", "OnClientEvent", "FireServer", "FireClient", "FireAllClients" });
        else if (current->getType() == InstanceType::BindableFunction)
            properties.insert(properties.end(), { "OnInvoke", "Invoke" });
        else if (current->getType() == InstanceType::RemoteFunction)
            properties.insert(properties.end(), { "OnServerInvoke", "OnClientInvoke", "InvokeServer", "InvokeClient" });
        else if (current->getType() == InstanceType::Humanoid)
            properties.insert(properties.end(), { "Health", "MaxHealth", "WalkSpeed", "JumpPower", "HipHeight", "RootPart" });
        else if (current->getType() == InstanceType::Camera)
            properties.insert(properties.end(), { "Mode", "Target" });

        for (const string& member : properties)
            if (member.rfind(prefix, 0) == 0)
                members.push_back(member);
        if (current->getType() == InstanceType::Part &&
            static_cast<const Part*>(current)->isMeshPart)
        {
            for (const string& member : { "MeshId", "TextureId", "CollisionFidelity" })
                if (member.rfind(prefix, 0) == 0)
                    members.push_back(member);
        }

        const vector<string> methods = {
            "GetChildren", "FindFirstChild", "FindFirstChildOfClass", "FindFirstChildWhichIsA",
            "FindFirstAncestor", "FindFirstAncestorOfClass", "FindFirstAncestorWhichIsA",
            "FindFirstDescendant", "WaitForChild", "GetService", "GetFullName",
            "IsA", "Destroy", "Clone"
        };
        for (const string& member : methods)
            if (member.rfind(prefix, 0) == 0)
                members.push_back(member);
    }
    return members;
}


ScriptCompletionKind classifyScriptCompletion(const string& word, bool isMember, char memberSeparator)
{
    if (isScriptKeyword(word))
        return ScriptCompletionKind::Keyword;
    if (isScriptTypeName(word))
        return ScriptCompletionKind::Type;
    static const vector<string> enums = {
        "Enum", "KeyCode", "UserInputType", "Material", "PartType", "CameraType",
        "NormalId", "Font", "ScaleType", "HumanoidStateType", "Shape"
    };
    if (find(enums.begin(), enums.end(), word) != enums.end())
        return ScriptCompletionKind::Enum;
    static const vector<string> events = {
        "Changed", "Touched", "AncestryChanged", "Event", "OnServerEvent", "OnClientEvent",
        "OnInvoke", "OnServerInvoke", "OnClientInvoke", "GetPropertyChangedSignal",
        "GetAttributeChangedSignal", "Heartbeat", "RenderStepped", "Stepped",
        "InputBegan", "InputEnded", "InputChanged"
    };
    if (find(events.begin(), events.end(), word) != events.end())
        return ScriptCompletionKind::Event;
    static const vector<string> methods = {
        "Fire", "FireServer", "FireClient", "FireAllClients", "Invoke", "InvokeServer", "InvokeClient",
        "GetChildren", "FindFirstChild", "FindFirstChildOfClass", "FindFirstChildWhichIsA",
        "FindFirstAncestor", "FindFirstAncestorOfClass", "FindFirstAncestorWhichIsA",
        "FindFirstDescendant", "WaitForChild", "GetService", "GetFullName",
        "IsA", "Destroy", "Clone", "Connect", "Once", "Disconnect",
        "new", "fromRGB", "fromHSV", "fromAxisAngle", "lookAt", "lerp", "inverse"
    };
    if (find(methods.begin(), methods.end(), word) != methods.end())
        return ScriptCompletionKind::Function;
    static const vector<string> props = {
        "Name", "Parent", "ClassName", "Position", "Orientation", "Size", "Color", "CFrame",
        "Anchored", "AdvancedPhysics", "Density", "Friction", "CanCollide", "Locked", "LocalAxes",
        "Transparency", "CastShadow", "PivotOffset",
        "Health", "MaxHealth", "WalkSpeed", "JumpPower", "HipHeight", "RootPart",
        "Mode", "Target", "SoundId", "Volume", "Looped", "Playing"
    };
    if (find(props.begin(), props.end(), word) != props.end())
        return ScriptCompletionKind::Property;
    if (isMember && memberSeparator == ':')
        return ScriptCompletionKind::Function;
    if (isMember && memberSeparator == '.')
        return ScriptCompletionKind::Property;
    if (word == "workspace" || word == "game" || word == "script" || word == "Players" ||
        word == "Lighting" || word == "ReplicatedStorage" || word == "ServerStorage")
        return ScriptCompletionKind::Folder;
    if (isScriptBuiltin(word))
        return ScriptCompletionKind::Function;
    return ScriptCompletionKind::Variable;
}

pair<string, string> getScriptSystemCompletionInfo(const string& name, ScriptCompletionKind kind)
{
    static const unordered_map<string, pair<string, string>> functionInfo = {
        { "print", { "print(...: any): ()", "Writes values to the output." } },
        { "warn", { "warn(...: any): ()", "Writes a warning to the output." } },
        { "error", { "error(message: any, level: number?): never", "Raises an error and stops the current operation." } },
        { "assert", { "assert(value: any, message: string?): any", "Raises an error when value is false or nil." } },
        { "require", { "require(module: ModuleScript): any", "Loads and returns a module's result." } },
        { "type", { "type(value: any): string", "Returns the Luau type of a value." } },
        { "typeof", { "typeof(value: any): string", "Returns the runtime type of a value." } },
        { "tonumber", { "tonumber(value: any, base: number?): number?", "Converts a value to a number when possible." } },
        { "tostring", { "tostring(value: any): string", "Converts a value to its string representation." } },
        { "select", { "select(index: number | string, ...any): any", "Returns selected arguments from a variadic call." } },
        { "unpack", { "unpack(list: { any }, first: number?, last: number?): ...any", "Returns the values in an array as multiple results." } },
        { "next", { "next(table: { [any]: any }, index: any?): (any, any)?", "Returns the next key and value in a table." } },
        { "rawget", { "rawget(table: { [any]: any }, index: any): any", "Reads a table value without invoking metamethods." } },
        { "rawset", { "rawset(table: { [any]: any }, index: any, value: any): { [any]: any }", "Writes a table value without invoking metamethods." } },
        { "rawequal", { "rawequal(a: any, b: any): boolean", "Compares values without invoking metamethods." } },
        { "setmetatable", { "setmetatable(table: {}, metatable: {}?): {}", "Sets a table's metatable." } },
        { "getmetatable", { "getmetatable(value: any): any", "Returns a value's metatable." } },
        { "pcall", { "pcall(callback: (...any) -> (), ...any): (boolean, ...any)", "Runs a function and returns whether it succeeded." } },
        { "xpcall", { "xpcall(callback: (...any) -> (), handler: (any) -> any): (boolean, ...any)", "Runs a function with a custom error handler." } },
        { "tick", { "tick(): number", "Returns the current time value." } },
        { "time", { "time(): number", "Returns the current elapsed runtime." } },
        { "pairs", { "pairs(table: { [any]: any }): () -> (any, any)", "Iterates over the key-value pairs in a table." } },
        { "ipairs", { "ipairs(array: { any }): () -> (number, any)", "Iterates over numeric entries in order." } },
        { "wait", { "wait(seconds: number?): number", "Yields for the requested duration." } },
        { "spawn", { "spawn(callback: (...any) -> (), ...any): thread", "Schedules a function to run asynchronously." } },
        { "delay", { "delay(seconds: number, callback: (...any) -> (), ...any): thread", "Schedules a function to run after a delay." } },
        { "defer", { "defer(callback: (...any) -> (), ...any): thread", "Schedules a function for a later task cycle." } },
        { "Instance.new", { "Instance.new(className: string, parent: Instance?): Instance", "Creates an instance of the requested class." } },
        { "new", { "new(className: string): Instance", "Creates a value or instance using this type's constructor." } },
        { "GetChildren", { "GetChildren(): { Instance }", "Returns this instance's direct children." } },
        { "FindFirstChild", { "FindFirstChild(name: string): Instance?", "Finds a direct child by name." } },
        { "WaitForChild", { "WaitForChild(name: string): Instance?", "Waits for a direct child with the given name." } },
        { "GetService", { "GetService(name: string): Instance", "Returns the named service." } },
        { "GetFullName", { "GetFullName(): string", "Returns this instance's full ancestry path." } },
        { "IsA", { "IsA(className: string): boolean", "Checks whether the instance inherits from a class." } },
        { "FindFirstChildOfClass", { "FindFirstChildOfClass(className: string): Instance?", "Finds a direct child by class name." } },
        { "FindFirstChildWhichIsA", { "FindFirstChildWhichIsA(className: string): Instance?", "Finds a direct child matching a class or subclass." } },
        { "GetPropertyChangedSignal", { "GetPropertyChangedSignal(property: string): RBXScriptSignal", "Returns the signal for changes to a property." } },
        { "Destroy", { "Destroy(): ()", "Removes this instance and its descendants." } },
        { "Clone", { "Clone(): Instance", "Creates a copy of this instance and its descendants." } },
        { "Connect", { "Connect(callback: (...any) -> ()): RBXScriptConnection", "Connects a callback to an event." } },
        { "fromRGB", { "fromRGB(r: number, g: number, b: number): Color3", "Creates a color from 0-255 RGB channels." } },
        { "fromHSV", { "fromHSV(h: number, s: number, v: number): Color3", "Creates a color from hue, saturation, and value." } },
        { "lerp", { "lerp(goal: any, alpha: number): any", "Interpolates between this value and a target." } }
    };
    auto function = functionInfo.find(name);
    if (function != functionInfo.end())
        return function->second;

    static const unordered_map<string, string> keywordDescriptions = {
        { "local", "Declares a variable with local scope." },
        { "function", "Declares a function." },
        { "return", "Returns values from the current function." },
        { "if", "Runs a block when its condition is true." },
        { "elseif", "Checks another condition in an if statement." },
        { "else", "Runs when no earlier if condition matched." },
        { "for", "Runs a numeric or generic loop." },
        { "while", "Repeats a block while its condition is true." },
        { "repeat", "Repeats a block until its condition is true." },
        { "break", "Exits the current loop." },
        { "continue", "Skips to the next loop iteration." },
        { "type", "Declares a Luau type alias." },
        { "export", "Exports a type alias for requiring scripts." }
    };
    if (kind == ScriptCompletionKind::Keyword)
    {
        auto description = keywordDescriptions.find(name);
        string signature = name;
        if (name == "if") signature = "if condition then ... end";
        else if (name == "for") signature = "for name in iterator do ... end";
        else if (name == "function") signature = "function name(parameters) ... end";
        else if (name == "local") signature = "local name: Type = value";
        return { signature, description == keywordDescriptions.end()
            ? "Luau language keyword." : description->second };
    }
    if (kind == ScriptCompletionKind::Function)
        return { name + "(...)", "Function in the Luau API." };
    string type = kind == ScriptCompletionKind::Type ? "Type" :
        kind == ScriptCompletionKind::Property ? "Property" :
        kind == ScriptCompletionKind::Event ? "Event" : "Value";
    return { name + " : " + type, "Available in the current context." };
}

string getScriptCompletionSourceSignature(const string& source, const string& name)
{
    size_t position = 0;
    while ((position = source.find("function", position)) != string::npos)
    {
        size_t nameStart = position + 8;
        while (nameStart < source.size() && isspace(static_cast<unsigned char>(source[nameStart])))
            nameStart++;
        size_t nameEnd = nameStart;
        while (nameEnd < source.size() &&
            (isScriptWordCharacter(source[nameEnd]) || source[nameEnd] == '.' || source[nameEnd] == ':'))
            nameEnd++;
        string declared = source.substr(nameStart, nameEnd - nameStart);
        size_t separator = declared.find_last_of(".:");
        string terminalName = separator == string::npos ? declared : declared.substr(separator + 1);
        if (terminalName == name)
        {
            size_t open = source.find('(', nameEnd);
            if (open != string::npos)
            {
                int depth = 1;
                size_t close = open + 1;
                while (close < source.size() && depth > 0)
                {
                    if (source[close] == '(') depth++;
                    else if (source[close] == ')') depth--;
                    close++;
                }
                if (depth == 0)
                    return name + source.substr(open, close - open);
            }
        }
        position = max(nameEnd, position + 8);
    }
    return {};
}

string getScriptCompletionSourceDescription(const string& source, const string& name)
{
    istringstream input(source);
    vector<string> lines;
    string line;
    while (getline(input, line))
        lines.push_back(line);
    for (size_t index = 0; index < lines.size(); ++index)
    {
        if (lines[index].find("function") == string::npos ||
            lines[index].find(name) == string::npos)
            continue;
        if (index > 0)
        {
            size_t closeLine = index - 1;
            int equalsCount = 0;
            int openerLength = 0;
            size_t closePosition = string::npos;
            for (size_t position = 0; position < lines[closeLine].size(); ++position)
            {
                if (lines[closeLine][position] != ']')
                    continue;
                size_t cursor = position + 1;
                while (cursor < lines[closeLine].size() && lines[closeLine][cursor] == '=')
                    cursor++;
                if (cursor < lines[closeLine].size() && lines[closeLine][cursor] == ']')
                {
                    closePosition = position;
                    break;
                }
            }
            if (closePosition != string::npos)
            {
                for (size_t first = closeLine + 1; first-- > 0;)
                {
                    string candidate = lines[first];
                    size_t marker = candidate.find("--");
                    if (marker != string::npos &&
                        getLongBracketOpener(candidate, static_cast<int>(marker + 2), equalsCount, openerLength))
                    {
                        string expectedClose = "]" + string(equalsCount, '=') + "]";
                        string description;
                        size_t contentStart = marker + 2 + static_cast<size_t>(openerLength);
                        size_t sameLineClose = candidate.find(expectedClose, contentStart);
                        if (sameLineClose != string::npos)
                            description = candidate.substr(contentStart, sameLineClose - contentStart);
                        else
                        {
                            if (contentStart < candidate.size())
                                description = candidate.substr(contentStart);
                            for (size_t commentLine = first + 1; commentLine <= closeLine; ++commentLine)
                            {
                                string text = lines[commentLine];
                                size_t end = text.find(expectedClose);
                                if (end != string::npos)
                                    text.erase(end);
                                if (!description.empty())
                                    description += "\n";
                                description += text;
                                if (end != string::npos)
                                    break;
                            }
                        }
                        if (!description.empty())
                            return description;
                        break;
                    }
                    if (first == 0)
                        break;
                }
            }
        }
        size_t first = index;
        while (first > 0)
        {
            size_t start = lines[first - 1].find_first_not_of(" \t");
            if (start == string::npos || lines[first - 1].compare(start, 2, "--") != 0)
                break;
            first--;
        }
        string description;
        for (size_t comment = first; comment < index; ++comment)
        {
            string text = lines[comment];
            size_t start = text.find_first_not_of(" \t");
            if (start == string::npos)
                continue;
            text.erase(0, start + 2);
            if (!text.empty() && text.front() == ' ')
                text.erase(0, 1);
            if (!description.empty())
                description += "\n";
            description += text;
        }
        if (!description.empty())
            return description;
    }
    return {};
}

Texture2D* completionIconForKind(ScriptCompletionKind kind)
{
    if (explorerIcons == nullptr)
        return nullptr;
    switch (kind)
    {
    case ScriptCompletionKind::Function: return &explorerIcons->acFunctionIcon;
    case ScriptCompletionKind::Property: return &explorerIcons->acPropertyIcon;
    case ScriptCompletionKind::Event: return &explorerIcons->acEventIcon;
    case ScriptCompletionKind::Value: return &explorerIcons->acValueIcon;
    case ScriptCompletionKind::Enum: return &explorerIcons->acEnumIcon;
    case ScriptCompletionKind::Snippet: return &explorerIcons->acSnippetIcon;
    case ScriptCompletionKind::Folder: return &explorerIcons->acFolderIcon;
    case ScriptCompletionKind::Text: return &explorerIcons->acTextIcon;
    case ScriptCompletionKind::Type: return &explorerIcons->acValueIcon;
    case ScriptCompletionKind::Keyword: return &explorerIcons->acTextIcon;
    case ScriptCompletionKind::Module: return &explorerIcons->acSnippetIcon;
    case ScriptCompletionKind::Variable:
    default: return &explorerIcons->acVariableIcon;
    }
}

void updateScriptCompletions(const string& source)
{
    sanitizeScriptEditorState(source);
    string prefix = getScriptCompletionPrefix(source, scriptCursor);
    if (prefix == scriptCompletionPrefix && scriptCompletionVisible)
        return;
    scriptCompletionPrefix = prefix;
    scriptCompletionMatches.clear();
    char memberSeparator = 0;
    vector<string> members = getScriptMemberCompletions(source, scriptCursor, memberSeparator);
    if (prefix.empty() && memberSeparator == 0)
    {
        scriptCompletionVisible = false;
        return;
    }
    // Member access (instance.children / properties): only real Instance members.
    // Do NOT mix in user-defined locals or free completion words.
    vector<string> words = memberSeparator != 0 ? members : SCRIPT_COMPLETION_WORDS;
    vector<string> localNames;
    bool isMember = memberSeparator != 0;
    if (!isMember)
    {
        localNames = getScriptLocalNames(source);
        words.insert(words.end(), localNames.begin(), localNames.end());
    }
    vector<string> sourceFunctionNames = getScriptFunctionNames(source);
    for (const string& word : words)
    {
        if (word.rfind(prefix, 0) != 0)
            continue;
        bool exists = false;
        for (const ScriptCompletionItem& it : scriptCompletionMatches)
            if (it.label == word) { exists = true; break; }
        if (exists)
            continue;
        ScriptCompletionItem item;
        item.label = word;
        item.kind = classifyScriptCompletion(word, isMember, memberSeparator);
        // Locals are variables (only relevant for free/global completion)
        if (!isMember && find(localNames.begin(), localNames.end(), word) != localNames.end())
            item.kind = find(sourceFunctionNames.begin(), sourceFunctionNames.end(), word) != sourceFunctionNames.end()
                ? ScriptCompletionKind::Function : ScriptCompletionKind::Variable;
        pair<string, string> info = getScriptSystemCompletionInfo(word, item.kind);
        item.signature = info.first;
        item.description = getScriptCompletionSourceDescription(source, word);
        string sourceSignature = getScriptCompletionSourceSignature(source, word);
        if (!sourceSignature.empty())
            item.signature = sourceSignature;
        if (item.description.empty())
            item.description = info.second;
        scriptCompletionMatches.push_back(item);
        if (scriptCompletionMatches.size() == 10)
            break;
    }
    if (!prefix.empty() &&
        find(words.begin(), words.end(), prefix) != words.end())
    {
        scriptCompletionVisible = false;
        scriptCompletionMatches.clear();
        return;
    }
    scriptCompletionIndex = 0;
    scriptCompletionVisible = !scriptCompletionMatches.empty();
}

void acceptScriptCompletion(string& source)
{
    if (!scriptCompletionVisible || scriptCompletionMatches.empty())
        return;

    scriptCompletionIndex = std::clamp(scriptCompletionIndex, 0,
        static_cast<int>(scriptCompletionMatches.size()) - 1);

    string prefix = getScriptCompletionPrefix(source, scriptCursor);
    int start = scriptCursor - static_cast<int>(prefix.size());
    const string& completion = scriptCompletionMatches[scriptCompletionIndex].label;
    source.replace(start, prefix.size(), completion);
    scriptCursor = start + static_cast<int>(completion.size());
    scriptCompletionVisible = false;
    scriptCompletionMatches.clear();
    scriptCompletionPrefix.clear();
    scriptSelectionStart = -1;
    scriptSelectionEnd = -1;
    scriptCaretResetTime = GetTime();
}

string truncateCompletionLabel(const string& label, int maxWidth)
{
    if (AppMeasureText(label.c_str(), scriptFontSize) <= maxWidth)
        return label;

    const string ellipsis = "...";
    int ellipsisWidth = AppMeasureText(ellipsis.c_str(), scriptFontSize);
    if (ellipsisWidth >= maxWidth)
        return ellipsis;

    string visible;
    for (char character : label)
    {
        string candidate = visible + character;
        if (AppMeasureText((candidate + ellipsis).c_str(), scriptFontSize) > maxWidth)
            break;
        visible += character;
    }
    return visible + ellipsis;
}

void renderScriptCompletions(const string& source)
{
    if (!scriptCompletionVisible || scriptCompletionMatches.empty())
        return;

    scriptCompletionIndex = std::clamp(scriptCompletionIndex, 0,
        static_cast<int>(scriptCompletionMatches.size()) - 1);

    Vector2 cursor = getScriptCursorPosition(source, scriptCursor);
    const int rowHeight = scriptFontSize + 6;
    const int width = 356;
    const int visibleRows = min(8, static_cast<int>(scriptCompletionMatches.size()));
    const int headerHeight = 28;
    const int footerHeight = 22;
    int x = static_cast<int>(cursor.x);
    int y = static_cast<int>(cursor.y + rowHeight);
    x = max(leftSlotWidth() + 58, min(x, GetScreenWidth() - rightSlotWidth() - width - 4));
    const int detailHeight = 300;
    y = min(y, GetScreenHeight() - EXPLORER_SCROLLBAR_SIZE - detailHeight);
    const int detailWidth = 320;
    int detailX = x + width + 4;
    int rightLimit = GetScreenWidth() - rightSlotWidth() - 4;
    if (detailX + detailWidth > rightLimit)
    {
        x = max(leftSlotWidth() + detailWidth + 4, x);
        detailX = x - detailWidth - 4;
    }
    scriptCompletionScrollIndex = std::clamp(scriptCompletionIndex - visibleRows + 1, 0,
        max(0, static_cast<int>(scriptCompletionMatches.size()) - visibleRows));
    scriptCompletionBounds = {
        static_cast<float>(x), static_cast<float>(y),
        static_cast<float>(width), static_cast<float>(headerHeight + footerHeight + visibleRows * rowHeight)
    };
    scriptCompletionDetailBounds = {
        static_cast<float>(detailX), static_cast<float>(y),
        static_cast<float>(detailWidth), static_cast<float>(detailHeight)
    };

    EditorThemeColors theme = getEditorThemeColors();
    DrawRectangleRounded(scriptCompletionBounds, 0.035f, 8, theme.panel);
    DrawRectangleRoundedLines(scriptCompletionBounds, 0.035f, 8, theme.border);
    DrawRectangleRounded({ (float)x + 1, (float)y + 1, (float)width - 2, (float)headerHeight },
        0.12f, 8, theme.header);
    DrawText("Suggestions", x + 12, y + 7, 13, theme.text);
    DrawText(TextFormat("%d results", (int)scriptCompletionMatches.size()),
        x + width - 80, y + 8, 11, theme.muted);
    BeginScissorMode(x + 2, y + headerHeight, width - 4, visibleRows * rowHeight);
    for (int row = 0; row < visibleRows; ++row)
    {
        int matchIndex = scriptCompletionScrollIndex + row;
        int rowY = y + headerHeight + row * rowHeight;
        Rectangle rowBounds = { (float)x + 5, (float)rowY, (float)width - 10, (float)rowHeight };
        if (matchIndex == scriptCompletionIndex)
            DrawRectangleRounded(rowBounds, 0.18f, 6, theme.selected);

        const ScriptCompletionItem& item = scriptCompletionMatches[matchIndex];
        Texture2D* icon = completionIconForKind(item.kind);
        const int iconSize = min(16, rowHeight - 4);
        if (icon != nullptr && icon->id != 0)
        {
            Rectangle iconTile = { (float)x + 10, (float)(rowY + 3), 20.0f, 20.0f };
            DrawRectangleRounded(iconTile, 0.22f, 6, theme.surface);
            DrawTexturePro(
                *icon,
                { 0, 0, (float)icon->width, (float)icon->height },
                { (float)(x + 12), (float)(rowY + (rowHeight - iconSize) / 2), (float)iconSize, (float)iconSize },
                { 0, 0 }, 0.0f, WHITE);
        }
        string label = truncateCompletionLabel(item.label, width - 136);

        const char* kindTag = "Variable";
        Color kindCol = { 170, 185, 200, 255 };
        switch (item.kind)
        {
        case ScriptCompletionKind::Function: kindTag = "Function"; kindCol = { 140, 170, 255, 255 }; break;
        case ScriptCompletionKind::Property: kindTag = "Property"; kindCol = { 120, 190, 255, 255 }; break;
        case ScriptCompletionKind::Event: kindTag = "Event"; kindCol = { 190, 140, 255, 255 }; break;
        case ScriptCompletionKind::Keyword: kindTag = "Keyword"; kindCol = { 248, 109, 124, 255 }; break;
        case ScriptCompletionKind::Type: kindTag = "Type"; kindCol = { 180, 160, 255, 255 }; break;
        case ScriptCompletionKind::Enum: kindTag = "Enum"; kindCol = { 230, 190, 120, 255 }; break;
        case ScriptCompletionKind::Value: kindTag = "Value"; kindCol = { 180, 220, 160, 255 }; break;
        case ScriptCompletionKind::Folder: kindTag = "Service"; kindCol = { 150, 180, 255, 255 }; break;
        case ScriptCompletionKind::Snippet: kindTag = "Snippet"; kindCol = { 200, 200, 200, 255 }; break;
        case ScriptCompletionKind::Text: kindTag = "Text"; kindCol = { 200, 180, 140, 255 }; break;
        default: break;
        }
        DrawText(label.c_str(), x + 36, rowY + 3, scriptFontSize, theme.text);
        int badgeWidth = MeasureText(kindTag, 10) + 12;
        Rectangle badge = { (float)x + width - badgeWidth - 10, (float)rowY + 3,
            (float)badgeWidth, (float)rowHeight - 6 };
        DrawRectangleRounded(badge, 0.3f, 6, theme.surface);
        DrawText(kindTag, (int)badge.x + 6, (int)badge.y + 3, 10, kindCol);
    }
    EndScissorMode();
    Rectangle footer = { (float)x + 1, (float)(y + scriptCompletionBounds.height - footerHeight - 1),
        (float)width - 2, (float)footerHeight };
    DrawRectangleRounded(footer, 0.25f, 6, theme.header);
    DrawText("↑ ↓ Navigate", x + 10, (int)footer.y + 5, 11, theme.muted);
    DrawText("Tab / Enter Insert", x + width - 120, (int)footer.y + 5, 11, theme.muted);

    const ScriptCompletionItem& selected = scriptCompletionMatches[scriptCompletionIndex];
    DrawRectangleRounded(scriptCompletionDetailBounds, 0.035f, 8, theme.panel);
    DrawRectangleRoundedLines(scriptCompletionDetailBounds, 0.035f, 8, theme.border);
    DrawRectangleRounded({ (float)detailX + 1, (float)y + 1, (float)detailWidth - 2,
        (float)headerHeight }, 0.12f, 8, theme.header);
    DrawText(selected.label.c_str(), detailX + 12, y + 7, 13, theme.text);
    const char* typeLabel = selected.kind == ScriptCompletionKind::Function ? "function" :
        selected.kind == ScriptCompletionKind::Keyword ? "keyword" :
        selected.kind == ScriptCompletionKind::Type ? "type" :
        selected.kind == ScriptCompletionKind::Property ? "property" :
        selected.kind == ScriptCompletionKind::Event ? "event" : "value";
    DrawText(TextFormat("Type: %s", typeLabel), detailX + 12, y + 38, 12, theme.accentHover);
    DrawText("Signature", detailX + 12, y + 60, 11, theme.muted);

    auto drawWrappedText = [&](const string& text, int startY, int fontSize, int maxLines, Color color)
    {
        istringstream lines(text);
        string paragraph;
        int drawY = startY;
        int lineCount = 0;
        while (getline(lines, paragraph) && lineCount < maxLines)
        {
            istringstream words(paragraph);
            string word;
            string current;
            while (words >> word)
            {
                string candidate = current.empty() ? word : current + " " + word;
                if (!current.empty() && MeasureText(candidate.c_str(), fontSize) > detailWidth - 24)
                {
                    DrawText(current.c_str(), detailX + 12, drawY, fontSize, color);
                    drawY += fontSize + 3;
                    lineCount++;
                    if (lineCount >= maxLines) return drawY;
                    current = word;
                }
                else
                    current = candidate;
            }
            if (!current.empty())
            {
                DrawText(current.c_str(), detailX + 12, drawY, fontSize, color);
                drawY += fontSize + 3;
                lineCount++;
            }
        }
        return drawY;
    };
    int descriptionY = drawWrappedText(selected.signature, y + 76, 12, 4, theme.text) + 8;
    DrawText("Description", detailX + 12, descriptionY, 11, theme.muted);
    drawWrappedText(selected.description, descriptionY + 18, 12, 8, theme.text);
}

// Proportional thumb size: shrinks as content grows; never below SCROLLBAR_MIN_THUMB.
float scrollbarThumbSize(float trackSize, float maxScroll)
{
    if (trackSize <= 0.0f || maxScroll <= 0.0f)
        return trackSize;
    float contentSize = trackSize + maxScroll;
    float ideal = trackSize * (trackSize / contentSize);
    return max(SCROLLBAR_MIN_THUMB, ideal);
}

// Map mouse position on a track to scroll offset. Small thumbs travel farther in content.
float scrollbarScrollFromMouse(float mousePos, float trackStart, float trackSize,
                                      float thumbSize, float maxScroll)
{
    if (maxScroll <= 0.0f || trackSize <= thumbSize)
        return 0.0f;
    float travel = trackSize - thumbSize;
    float t = (mousePos - trackStart - thumbSize * 0.5f) / travel;
    return std::clamp(t, 0.0f, 1.0f) * maxScroll;
}

void drawDocumentScrollbars(int contentX, int contentY, int contentWidth, int contentHeight,
                            float maxScrollX, float maxScrollY, float scrollX, float scrollY)
{
    const int barSize = EXPLORER_SCROLLBAR_SIZE;
    if (maxScrollY > 0.0f)
    {
        Rectangle track = { static_cast<float>(contentX + contentWidth - barSize), static_cast<float>(contentY),
            static_cast<float>(barSize), static_cast<float>(contentHeight - barSize) };
        float thumbHeight = scrollbarThumbSize(track.height, maxScrollY);
        Rectangle thumb = { track.x, track.y + scrollY / maxScrollY * (track.height - thumbHeight),
            track.width, thumbHeight };
        DrawRectangleRec(track, (Color){ 20, 24, 29, 255 });
        DrawRectangleRec(thumb, (Color){ 110, 121, 135, 255 });
    }
    if (maxScrollX > 0.0f)
    {
        Rectangle track = { static_cast<float>(contentX), static_cast<float>(contentY + contentHeight - barSize),
            static_cast<float>(contentWidth - barSize), static_cast<float>(barSize) };
        float thumbWidth = scrollbarThumbSize(track.width, maxScrollX);
        Rectangle thumb = { track.x + scrollX / maxScrollX * (track.width - thumbWidth), track.y,
            thumbWidth, track.height };
        DrawRectangleRec(track, (Color){ 20, 24, 29, 255 });
        DrawRectangleRec(thumb, (Color){ 110, 121, 135, 255 });
    }
    if (maxScrollX > 0.0f && maxScrollY > 0.0f)
        DrawRectangle(contentX + contentWidth - barSize, contentY + contentHeight - barSize, barSize, barSize, (Color){ 20, 24, 29, 255 });
}

static string truncateTextToWidth(const string& text, int fontSize, int maxWidth)
{
    if (maxWidth <= 0 || MeasureText(text.c_str(), fontSize) <= maxWidth)
        return text;
    const char* ellipsis = "...";
    int ellipsisW = MeasureText(ellipsis, fontSize);
    if (ellipsisW >= maxWidth)
        return "...";
    string result = text;
    while (!result.empty() && MeasureText((result + ellipsis).c_str(), fontSize) > maxWidth)
        result.pop_back();
    // trim trailing incomplete path noise
    while (!result.empty() && (result.back() == '\\' || result.back() == '/' || result.back() == ' '))
        result.pop_back();
    return result + ellipsis;
}

// Hit targets filled each frame by renderWelcomeScreen for reliable clicks
struct WelcomeHit { Rectangle rect; int kind; int index; }; // kind: 0=new 1=open 2=recent
vector<WelcomeHit> welcomeHits;

void renderWelcomeScreen()
{
    EditorThemeColors theme = getEditorThemeColors();
    int width = GetScreenWidth();
    int height = GetScreenHeight();
    welcomeHits.clear();

    Color topC = theme.hasGradient ? theme.gradientStart : theme.header;
    Color botC = theme.hasGradient ? theme.gradientEnd : theme.canvas;
    for (int y = 0; y < height; ++y)
    {
        float t = (float)y / max(1, height - 1);
        Color c = {
            (unsigned char)(topC.r + (botC.r - topC.r) * t),
            (unsigned char)(topC.g + (botC.g - topC.g) * t),
            (unsigned char)(topC.b + (botC.b - topC.b) * t),
            255
        };
        DrawRectangle(0, y, width, 1, c);
    }

    static Texture2D welcomeLogo = { 0 };
    static Texture2D welcomeFileIcon = { 0 };
    static bool welcomeIconsLoaded = false;
    if (!welcomeIconsLoaded)
    {
        welcomeLogo = loadImage("Logo3");
        welcomeFileIcon = loadImage("File");
        welcomeIconsLoaded = true;
    }

    Vector2 mouse = GetMousePosition();
    const Color titleOrange = theme.accent;
    const Color muted = theme.muted;

    // Header: logo + title
    float logoSize = 96.0f;
    float logoX = 48.0f;
    float logoY = 40.0f;
    if (welcomeLogo.id != 0)
    {
        DrawTexturePro(
            welcomeLogo,
            { 0, 0, (float)welcomeLogo.width, (float)welcomeLogo.height },
            { logoX, logoY, logoSize, logoSize },
            { 0, 0 }, 0.0f, getStudioMiscIconTint("Logo")
        );
    }
    else
    {
        DrawRectangleRounded({ logoX, logoY, logoSize, logoSize }, 0.2f, 8, theme.accent);
        DrawText("BT", (int)logoX + 22, (int)logoY + 28, 36, theme.text);
    }

    DrawText("Building Tool", (int)(logoX + logoSize + 18), (int)logoY + 28, 40, titleOrange);
    DrawText(BUILDING_TOOL_VERSION_LABEL.c_str(), (int)(logoX + logoSize + 20), (int)logoY + 72, 14, muted);

    // Compact New / Open under the title row
    float actionY = logoY + logoSize + 28.0f;
    Rectangle newRect = { 48, actionY, 150, 36 };
    Rectangle openRect = { 210, actionY, 150, 36 };
    bool newHover = CheckCollisionPointRec(mouse, newRect);
    bool openHover = CheckCollisionPointRec(mouse, openRect);
    DrawRectangleRounded(newRect, 0.25f, 6, newHover ? theme.selected : theme.surface);
    DrawRectangleRounded(openRect, 0.25f, 6, openHover ? theme.selected : theme.surface);
    DrawText("New Project", (int)newRect.x + 22, (int)newRect.y + 9, 16, theme.text);
    DrawText("Open Project", (int)openRect.x + 18, (int)openRect.y + 9, 16, theme.text);
    welcomeHits.push_back({ newRect, 0, -1 });
    welcomeHits.push_back({ openRect, 1, -1 });

    // Recent projects — card grid like the mockup
    float sectionY = actionY + 56.0f;
    DrawText("Recent projects", 52, (int)sectionY, 18, muted);
    sectionY += 36.0f;

    if (recentProjects.empty())
    {
        DrawText("No recent projects yet — create one to get started.", 52, (int)sectionY + 8, 16, theme.muted);
    }
    else
    {
        const float cardW = 112.0f;
        const float cardH = 128.0f;
        const float gap = 18.0f;
        const float iconBox = 88.0f;
        float x = 48.0f;
        float y = sectionY;
        int cols = max(1, (int)((width - 96) / (cardW + gap)));
        int col = 0;
        for (size_t i = 0; i < recentProjects.size(); ++i)
        {
            Rectangle card = { x, y, cardW, cardH };
            bool hover = CheckCollisionPointRec(mouse, card);
            Color cardBg = hover ? theme.selected : theme.surface;
            DrawRectangleRounded(card, 0.18f, 8, cardBg);
            if (hover)
            {
                Color outline = theme.accent;
                outline.a = 180;
                DrawRectangleRoundedLines(card, 0.18f, 8, outline);
            }

            // File icon centered in upper area
            float ix = x + (cardW - iconBox) * 0.5f;
            float iy = y + 10.0f;
            if (welcomeFileIcon.id != 0)
            {
                drawEditorIcon(welcomeFileIcon, ix, iy, iconBox, iconBox,
                    getStudioMiscIconTint("File"));
            }
            else if (welcomeLogo.id != 0)
            {
                drawEditorIcon(welcomeLogo, ix + 8, iy + 8, iconBox - 16,
                    iconBox - 16, WHITE);
            }

            string label = filesystem::path(recentProjects[i]).stem().string();
            if (label.size() > 14) label = label.substr(0, 12) + "..";
            int tw = MeasureText(label.c_str(), 14);
            DrawText(label.c_str(), (int)(x + (cardW - tw) * 0.5f), (int)(y + cardH - 22), 14, theme.text);

            welcomeHits.push_back({ card, 2, (int)i });

            col++;
            if (col >= cols)
            {
                col = 0;
                x = 48.0f;
                y += cardH + gap;
                if (y + cardH > height - 40) break;
            }
            else
            {
                x += cardW + gap;
            }
        }
    }
}

void handleLibraryInput()
{
    if (activeWindow != WindowType::Library)
        return;

    Vector2 mouse = GetMousePosition();
    int left = leftSlotWidth();
    int right = GetScreenWidth() - rightSlotWidth();
    int contentW = right - left;
    int top = EDITOR_CONTENT_TOP;
    int contentH = GetScreenHeight() - top;

    if (mouse.x >= left && mouse.x < right && mouse.y >= top &&
        (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) ||
         IsMouseButtonPressed(MOUSE_BUTTON_RIGHT) ||
         IsMouseButtonPressed(MOUSE_BUTTON_MIDDLE)))
        focusedZone = FocusZone::Library;

    Rectangle importRect = { static_cast<float>(left + contentW - 140), static_cast<float>(top + 12), 120, 30 };
    if (CheckCollisionPointRec(mouse, importRect) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
    {
        browseAndImportAsset();
        return;
    }

    float wheel = isZoneFocused(FocusZone::Library) ? GetMouseWheelMove() : 0.0f;
    if (wheel != 0.0f && mouse.x >= left && mouse.x < right && mouse.y >= top)
        libraryScrollY = max(0, libraryScrollY - static_cast<int>(wheel * 40));

    const int rowH = 96;
    const int listTop = top + 56;
    int y = listTop - libraryScrollY;
    libraryHoverIndex = -1;

    for (int i = 0; i < static_cast<int>(projectAssets.size()); ++i)
    {
        Rectangle row = {
            static_cast<float>(left + 12),
            static_cast<float>(y),
            static_cast<float>(contentW - 24),
            static_cast<float>(rowH - 8)
        };
        if (CheckCollisionPointRec(mouse, row))
            libraryHoverIndex = i;

        Rectangle preview = { row.x + 10, row.y + 10, 72, 72 };
        Rectangle deleteBtn = {
            row.x + row.width - 88, row.y + (row.height - 28) * 0.5f, 72, 28
        };

        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, deleteBtn))
        {
            deleteProjectAssetAt(i);
            return;
        }

        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, preview))
        {
            ProjectAsset& asset = projectAssets[i];
            if (asset.type == ProjectAssetType::Sound)
            {
                // Prefer short Sound sample; fall back to Music stream preview
                if (ensureProjectAssetLoaded(asset) && asset.sound.frameCount > 0)
                {
                    StopSound(asset.sound);
                    SetSoundVolume(asset.sound, 1.0f);
                    PlaySound(asset.sound);
                }
                else if (loadSoundPreviewForAssetId(asset.id))
                {
                    SeekMusicStream(soundPreviewMusic, 0.0f);
                    PlayMusicStream(soundPreviewMusic);
                    soundPreviewPlaying = true;
                }
                else
                {
                    addOutputLog("[Asset Manager] Could not play sound " + asset.id);
                }
            }
            else if (asset.type == ProjectAssetType::Mesh)
                ensureProjectAssetLoaded(asset);
            return;
        }

        y += rowH;
        if (y > top + contentH)
            break;
    }
}

void renderLibraryWindow()
{
    EditorThemeColors theme = getEditorThemeColors();
    int left = leftSlotWidth();
    int right = GetScreenWidth() - rightSlotWidth();
    int contentW = right - left;
    int top = EDITOR_CONTENT_TOP;
    int contentH = GetScreenHeight() - top;

    DrawRectangle(left, top, contentW, contentH, theme.panel);
    DrawText("Asset Manager", left + 16, top + 14, 22, theme.text);
    DrawText("Embedded images, sounds & meshes travel with the .hlx project file.",
        left + 200, top + 18, 14, theme.muted);

    Rectangle importRect = { static_cast<float>(left + contentW - 140), static_cast<float>(top + 12), 120, 30 };
    Vector2 mouse = GetMousePosition();
    bool importHover = CheckCollisionPointRec(mouse, importRect);
    DrawRectangleRec(importRect, importHover ? theme.accentHover : theme.accent);
    DrawText("Import…", static_cast<int>(importRect.x) + 28, static_cast<int>(importRect.y) + 7, 16, theme.text);

    const int rowH = 96;
    const int listTop = top + 56;
    BeginScissorMode(left, listTop, contentW, contentH - 56);

    if (projectAssets.empty())
    {
        DrawText("No assets yet. Use File → Import Asset or the Import button.",
            left + 24, listTop + 24, 16, theme.muted);
    }

    int y = listTop - libraryScrollY;
    for (int i = 0; i < static_cast<int>(projectAssets.size()); ++i)
    {
        ProjectAsset& asset = projectAssets[i];
        Rectangle row = {
            static_cast<float>(left + 12),
            static_cast<float>(y),
            static_cast<float>(contentW - 24),
            static_cast<float>(rowH - 8)
        };

        bool hovered = (libraryHoverIndex == i) || CheckCollisionPointRec(mouse, row);
        DrawRectangleRec(row, hovered ? theme.selected : theme.surface);
        DrawRectangleLinesEx(row, 1.0f, theme.border);

        Rectangle preview = { row.x + 10, row.y + 10, 72, 72 };
        DrawRectangleRec(preview, theme.canvas);
        DrawRectangleLinesEx(preview, 1.0f, theme.border);

        if (asset.type == ProjectAssetType::Image)
        {
            if (ensureProjectAssetLoaded(asset) && asset.texture.id != 0)
            {
                float scale = min(68.0f / max(1, asset.texture.width), 68.0f / max(1, asset.texture.height));
                float dw = asset.texture.width * scale;
                float dh = asset.texture.height * scale;
                DrawTexturePro(
                    asset.texture,
                    { 0, 0, (float)asset.texture.width, (float)asset.texture.height },
                    { preview.x + (72 - dw) * 0.5f, preview.y + (72 - dh) * 0.5f, dw, dh },
                    { 0, 0 }, 0.0f, WHITE
                );
            }
            else
            {
                DrawText("IMG", static_cast<int>(preview.x) + 22, static_cast<int>(preview.y) + 28, 16,
                    theme.muted);
            }
        }
        else if (asset.type == ProjectAssetType::Sound)
        {
            DrawCircle(static_cast<int>(preview.x + 36), static_cast<int>(preview.y + 36), 18,
                (Color){ 0, 150, 90, 255 });
            DrawTriangle(
                { preview.x + 30, preview.y + 26 },
                { preview.x + 30, preview.y + 46 },
                { preview.x + 48, preview.y + 36 },
                theme.text
            );
        }
        else
        {
            DrawText("3D", static_cast<int>(preview.x) + 22, static_cast<int>(preview.y) + 27,
                18, theme.accent);
        }

        int textX = static_cast<int>(preview.x + 88);
        int textY = static_cast<int>(row.y + 12);
        DrawText(("Name: " + asset.name).c_str(), textX, textY, 16, theme.text);
        DrawText(("AssetID: " + asset.id).c_str(), textX, textY + 22, 14, theme.accent);
        DrawText(("File type: " + assetTypeName(asset.type) + " (." + asset.fileType + ")  ·  " +
            to_string(asset.data.size()) + " bytes").c_str(),
            textX, textY + 42, 14, theme.muted);

        Rectangle deleteBtn = {
            row.x + row.width - 88, row.y + (row.height - 28) * 0.5f, 72, 28
        };
        bool delHover = CheckCollisionPointRec(mouse, deleteBtn);
        DrawRectangleRec(deleteBtn, delHover ? (Color){ 200, 60, 60, 255 } : (Color){ 140, 50, 50, 255 });
        DrawText("Delete", static_cast<int>(deleteBtn.x) + 12, static_cast<int>(deleteBtn.y) + 6, 14, WHITE);

        y += rowH;
    }
    EndScissorMode();
}


// Viewport bounds for 3D view + future 2D HUD (screen-space rect inside docks)
Rectangle getViewportBounds()
{
    if (runtimeOnlyBuild)
        return { 0.0f, 0.0f, static_cast<float>(GetScreenWidth()),
            static_cast<float>(GetScreenHeight()) };
    int left = leftSlotWidth();
    int right = GetScreenWidth() - rightSlotWidth();
    int top = EDITOR_CONTENT_TOP;
    int bottom = GetScreenHeight();
    // If output window is active full-height overlays may differ; viewport is the center column
    return {
        static_cast<float>(left),
        static_cast<float>(top),
        static_cast<float>(max(0, right - left)),
        static_cast<float>(max(0, bottom - top))
    };
}

// Resolve UDim against parent absolute size
static float udimToPx(const UDimValue& u, float parentPx)
{
    return u.scale * parentPx + u.offset;
}

// Collect UICorner radius (px) and UIStroke from direct children of a GuiObject.
static void guiCollectModifiers(Instance* inst, float& cornerRadiusPx, bool& hasStroke,
    float& strokeThickness, Color& strokeColor, float& strokeTransparency)
{
    cornerRadiusPx = 0.0f;
    hasStroke = false;
    strokeThickness = 0.0f;
    strokeColor = BLACK;
    strokeTransparency = 0.0f;
    if (inst == nullptr) return;
    for (Instance* c : inst->children)
    {
        if (c == nullptr) continue;
        if (c->getType() == InstanceType::UICorner)
        {
            auto* m = static_cast<UIModifierInstance*>(c);
            // Prefer offset; scale is relative to min(size) when used at draw time.
            cornerRadiusPx = max(cornerRadiusPx, m->cornerRadius.offset);
        }
        else if (c->getType() == InstanceType::UIStroke)
        {
            auto* m = static_cast<UIModifierInstance*>(c);
            if (m->strokeEnabled)
            {
                hasStroke = true;
                strokeThickness = m->strokeThickness;
                strokeColor = m->strokeColor;
                strokeTransparency = m->strokeTransparency;
            }
        }
    }
}

static Color guiApplyAlpha(Color c, float transparency)
{
    c.a = (unsigned char)std::clamp((1.0f - transparency) * (float)c.a, 0.0f, 255.0f);
    return c;
}

struct GuiScrollMetrics
{
    float contentWidth = 0.0f;
    float contentHeight = 0.0f;
    float maxX = 0.0f;
    float maxY = 0.0f;
    float barSize = 8.0f;
};

static GuiScrollMetrics guiGetScrollMetrics(GuiObjectInstance* gui, float width, float height)
{
    GuiScrollMetrics metrics;
    if (gui == nullptr)
        return metrics;
    metrics.contentWidth = width;
    metrics.contentHeight = height;
    metrics.barSize = std::clamp(gui->scrollBarThickness, 6.0f, 16.0f);
    for (Instance* child : gui->children)
    {
        if (child == nullptr)
            continue;
        InstanceType type = child->getType();
        if (type != InstanceType::Frame && type != InstanceType::ScrollingFrame &&
            type != InstanceType::TextLabel && type != InstanceType::ImageLabel &&
            type != InstanceType::TextButton && type != InstanceType::ImageButton &&
            type != InstanceType::TextBox)
            continue;
        auto* childGui = static_cast<GuiObjectInstance*>(child);
        float childWidth = udimToPx(childGui->size.x, width);
        float childHeight = udimToPx(childGui->size.y, height);
        float childX = udimToPx(childGui->position.x, width) - childGui->anchorPoint.x * childWidth;
        float childY = udimToPx(childGui->position.y, height) - childGui->anchorPoint.y * childHeight;
        metrics.contentWidth = max(metrics.contentWidth, childX + childWidth);
        metrics.contentHeight = max(metrics.contentHeight, childY + childHeight);
    }
    if (gui->getType() == InstanceType::ScrollingFrame)
    {
        metrics.contentWidth = max(metrics.contentWidth, udimToPx(gui->scrollCanvasSize.x, width));
        metrics.contentHeight = max(metrics.contentHeight, udimToPx(gui->scrollCanvasSize.y, height));
    }
    metrics.maxX = max(0.0f, metrics.contentWidth - width);
    metrics.maxY = max(0.0f, metrics.contentHeight - height);
    if (!gui->scrollingEnabled)
        metrics.maxX = metrics.maxY = 0.0f;
    if (gui->getType() == InstanceType::ScrollingFrame)
    {
        bool canScrollX = gui->scrollingDirection == "X" || gui->scrollingDirection == "XY";
        bool canScrollY = gui->scrollingDirection == "Y" || gui->scrollingDirection == "XY";
        if (!canScrollX) metrics.maxX = 0.0f;
        if (!canScrollY) metrics.maxY = 0.0f;
    }
    return metrics;
}

static void guiDrawTextAligned(const char* text, float x, float y, float w, float h,
    int fontSz, Color tc, const string& xAlign, const string& yAlign, bool stroke,
    Color strokeCol, const string& fontName = "SourceSans")
{
    if (text == nullptr || text[0] == '\0') return;
    fontSz = max(8, fontSz);
    Font* f = resolveProjectFont(fontName);
    Font use = f ? *f : (applicationFontLoaded ? applicationFont : GetFontDefault());
    Vector2 msz = MeasureTextEx(use, text, (float)fontSz, 0.0f);
    float tw = msz.x;
    float tx = x + 4.0f;
    if (xAlign == "Center") tx = x + (w - tw) * 0.5f;
    else if (xAlign == "Right") tx = x + w - tw - 4.0f;
    float ty = y + 2.0f;
    if (yAlign == "Center") ty = y + (h - (float)fontSz) * 0.5f;
    else if (yAlign == "Bottom") ty = y + h - (float)fontSz - 2.0f;
    if (stroke && strokeCol.a > 0)
    {
        DrawTextEx(use, text, { tx - 1, ty }, (float)fontSz, 0.0f, strokeCol);
        DrawTextEx(use, text, { tx + 1, ty }, (float)fontSz, 0.0f, strokeCol);
        DrawTextEx(use, text, { tx, ty - 1 }, (float)fontSz, 0.0f, strokeCol);
        DrawTextEx(use, text, { tx, ty + 1 }, (float)fontSz, 0.0f, strokeCol);
    }
    DrawTextEx(use, text, { tx, ty }, (float)fontSz, 0.0f, tc);
}

static void renderGuiObjectTree(Instance* inst, float parentX, float parentY, float parentW, float parentH)
{
    if (inst == nullptr) return;
    auto t = inst->getType();
    if (t == InstanceType::UICorner || t == InstanceType::UIListLayout || t == InstanceType::UIStroke ||
        t == InstanceType::UIPadding || t == InstanceType::UIGridLayout || t == InstanceType::UIAspectRatioConstraint)
        return; // modifiers applied while drawing parent GuiObject

    if (t == InstanceType::Frame || t == InstanceType::ScrollingFrame || t == InstanceType::TextLabel ||
        t == InstanceType::ImageLabel || t == InstanceType::TextButton || t == InstanceType::ImageButton ||
        t == InstanceType::TextBox)
    {
        auto* g = static_cast<GuiObjectInstance*>(inst);
        if (!g->visible) return;
        float w = udimToPx(g->size.x, parentW);
        float h = udimToPx(g->size.y, parentH);
        if (w < 1.0f || h < 1.0f) return;
        float x = parentX + udimToPx(g->position.x, parentW) - g->anchorPoint.x * w;
        float y = parentY + udimToPx(g->position.y, parentH) - g->anchorPoint.y * h;

        float cornerR = 0.0f;
        bool hasStroke = false;
        float strokeTh = 0.0f;
        Color strokeCol = BLACK;
        float strokeTrans = 0.0f;
        guiCollectModifiers(inst, cornerR, hasStroke, strokeTh, strokeCol, strokeTrans);
        // UICorner scale component relative to min side
        for (Instance* c : inst->children)
        {
            if (c && c->getType() == InstanceType::UICorner)
            {
                auto* m = static_cast<UIModifierInstance*>(c);
                cornerR = max(cornerR, m->cornerRadius.scale * min(w, h) + m->cornerRadius.offset);
            }
        }
        cornerR = std::clamp(cornerR, 0.0f, min(w, h) * 0.5f);

        Color bg = guiApplyAlpha(g->backgroundColor, g->backgroundTransparency + g->groupTransparency);
        if (bg.a > 0)
        {
            if (cornerR > 0.5f)
                DrawRectangleRounded({ x, y, w, h }, cornerR / min(w, h), 8, bg);
            else
                DrawRectangle((int)x, (int)y, (int)w, (int)h, bg);
        }

        if (g->borderSizePixel > 0)
        {
            Color bc = g->borderColor;
            bc.a = bg.a > 0 ? bg.a : 255;
            DrawRectangleLinesEx({ x, y, w, h }, (float)g->borderSizePixel, bc);
        }
        if (hasStroke && strokeTh > 0.0f)
        {
            Color sc = guiApplyAlpha(strokeCol, strokeTrans);
            DrawRectangleLinesEx({ x, y, w, h }, strokeTh, sc);
        }

        // Image placeholder (no asset loader yet — tinted rect + label)
        if ((t == InstanceType::ImageLabel || t == InstanceType::ImageButton) && !g->image.empty())
        {
            Color ic = guiApplyAlpha(g->imageColor, g->imageTransparency + g->groupTransparency);
            if (ic.a > 0)
            {
                if (cornerR > 0.5f)
                    DrawRectangleRounded({ x + 2, y + 2, w - 4, h - 4 }, cornerR / min(w, h), 6, ic);
                else
                    DrawRectangle((int)x + 2, (int)y + 2, (int)w - 4, (int)h - 4, ic);
            }
        }

        // Text / placeholder
        if (t == InstanceType::TextLabel || t == InstanceType::TextButton || t == InstanceType::TextBox)
        {
            string drawStr = g->text;
            Color tc = g->textColor;
            float tTrans = g->textTransparency;
            if (drawStr.empty() && t == InstanceType::TextBox && !g->placeholderText.empty())
            {
                drawStr = g->placeholderText;
                tc = g->placeholderColor;
                tTrans = 0.0f;
            }
            if (!drawStr.empty())
            {
                Color textCol = guiApplyAlpha(tc, tTrans + g->groupTransparency);
                Color strokeC = guiApplyAlpha(g->textStrokeColor, g->textStrokeTransparency);
                int fontSz = g->textScaled ? max(8, (int)(h * 0.55f)) : max(8, g->textSize);
                bool doStroke = g->textStrokeTransparency < 0.99f;
                guiDrawTextAligned(drawStr.c_str(), x, y, w, h, fontSz, textCol,
                    g->textXAlignment, g->textYAlignment, doStroke, strokeC, g->font);
            }
        }

        GuiScrollMetrics scroll = guiGetScrollMetrics(g, w, h);
        bool hasOverflow = scroll.maxX > 1.0f || scroll.maxY > 1.0f;
        bool clip = g->clipsDescendants || t == InstanceType::ScrollingFrame || hasOverflow;
        if (clip)
            BeginScissorMode((int)x, (int)y, max(1, (int)w), max(1, (int)h));

        g->canvasPosition.x = std::clamp(g->canvasPosition.x, 0.0f, scroll.maxX);
        g->canvasPosition.y = std::clamp(g->canvasPosition.y, 0.0f, scroll.maxY);
        float childOriginX = x - g->canvasPosition.x;
        float childOriginY = y - g->canvasPosition.y;

        for (Instance* child : inst->children)
            renderGuiObjectTree(child, childOriginX, childOriginY, w, h);

        if (hasOverflow && g->scrollingEnabled && g->scrollBarThickness > 0.0f)
        {
            Color sbc = guiApplyAlpha(g->scrollBarImageColor, g->scrollBarImageTransparency);
            if (scroll.maxY > 1.0f)
            {
                float thumbH = max(12.0f, h * h / (h + scroll.maxY));
                float thumbY = y + g->canvasPosition.y / scroll.maxY * (h - thumbH);
                float barX = x + w - scroll.barSize;
                DrawRectangleRounded({ barX, y, scroll.barSize, h }, 0.5f, 6, (Color){ 20, 24, 29, 100 });
                DrawRectangleRounded({ barX + 1, thumbY, max(2.0f, scroll.barSize - 2), thumbH },
                    0.5f, 6, sbc);
            }
            if (scroll.maxX > 1.0f)
            {
                float thumbW = max(12.0f, w * w / (w + scroll.maxX));
                float thumbX = x + g->canvasPosition.x / scroll.maxX * (w - thumbW);
                float barY = y + h - scroll.barSize;
                DrawRectangleRounded({ x, barY, w, scroll.barSize }, 0.5f, 6, (Color){ 20, 24, 29, 100 });
                DrawRectangleRounded({ thumbX, barY + 1, thumbW, max(2.0f, scroll.barSize - 2) },
                    0.5f, 6, sbc);
            }
        }

        if (clip)
            EndScissorMode();
        return;
    }

    // Nested ScreenGui / LayerCollector under another collector
    if (t == InstanceType::ScreenGui || t == InstanceType::SurfaceGui || t == InstanceType::BillboardGui)
    {
        auto* lc = static_cast<LayerCollectorInstance*>(inst);
        if (!lc->enabled) return;
        for (Instance* child : inst->children)
            renderGuiObjectTree(child, parentX, parentY, parentW, parentH);
        return;
    }

    for (Instance* child : inst->children)
        renderGuiObjectTree(child, parentX, parentY, parentW, parentH);
}

static bool guiPointHitsTree(Instance* inst, float parentX, float parentY, float parentW, float parentH,
    Vector2 point, bool parentClips, Rectangle parentClip)
{
    if (inst == nullptr)
        return false;
    InstanceType type = inst->getType();
    if (type == InstanceType::ScreenGui || type == InstanceType::SurfaceGui || type == InstanceType::BillboardGui)
    {
        auto* layer = static_cast<LayerCollectorInstance*>(inst);
        if (!layer->enabled) return false;
        for (Instance* child : inst->children)
            if (guiPointHitsTree(child, parentX, parentY, parentW, parentH, point, parentClips, parentClip))
                return true;
        return false;
    }
    if (type != InstanceType::Frame && type != InstanceType::ScrollingFrame &&
        type != InstanceType::TextLabel && type != InstanceType::ImageLabel &&
        type != InstanceType::TextButton && type != InstanceType::ImageButton &&
        type != InstanceType::TextBox)
    {
        for (Instance* child : inst->children)
            if (guiPointHitsTree(child, parentX, parentY, parentW, parentH, point, parentClips, parentClip))
                return true;
        return false;
    }
    auto* gui = static_cast<GuiObjectInstance*>(inst);
    if (!gui->visible) return false;
    float width = udimToPx(gui->size.x, parentW);
    float height = udimToPx(gui->size.y, parentH);
    float x = parentX + udimToPx(gui->position.x, parentW) - gui->anchorPoint.x * width;
    float y = parentY + udimToPx(gui->position.y, parentH) - gui->anchorPoint.y * height;
    Rectangle bounds = { x, y, width, height };
    bool withinParentClip = !parentClips || CheckCollisionPointRec(point, parentClip);
    if (withinParentClip)
    {
        GuiScrollMetrics scroll = guiGetScrollMetrics(gui, width, height);
        bool clipChildren = gui->clipsDescendants || gui->getType() == InstanceType::ScrollingFrame ||
            scroll.maxX > 1.0f || scroll.maxY > 1.0f;
        Rectangle childClip = clipChildren ? bounds : parentClip;
        float childX = x - std::clamp(gui->canvasPosition.x, 0.0f, scroll.maxX);
        float childY = y - std::clamp(gui->canvasPosition.y, 0.0f, scroll.maxY);
        for (Instance* child : gui->children)
            if (guiPointHitsTree(child, childX, childY, width, height, point, clipChildren, childClip))
                return true;
    }
    return withinParentClip && CheckCollisionPointRec(point, bounds);
}

bool isPointerOverScreenGui()
{
    if (activeWindow != WindowType::Viewport)
        return false;
    Instance* guiRoot = &StarterGui;
    if (runtimePlaying && runtimeClientMode && runtimePlayer != nullptr && runtimePlayer->playerGui != nullptr)
        guiRoot = runtimePlayer->playerGui;
    Rectangle vp = getViewportBounds();
    Vector2 mouse = GetMousePosition();
    for (Instance* child : guiRoot->children)
        if (child != nullptr && child->getType() == InstanceType::ScreenGui &&
            guiPointHitsTree(child, vp.x, vp.y, vp.width, vp.height, mouse, false, vp))
            return true;
    return false;
}

static GuiObjectInstance* guiScrollDragTarget = nullptr;
static bool guiScrollDragHorizontal = false;

static bool guiHandleScrollInputTree(Instance* inst, float parentX, float parentY, float parentW, float parentH,
    Vector2 mouse, float wheel, bool shift, bool parentClips, Rectangle parentClip)
{
    if (inst == nullptr)
        return false;
    InstanceType type = inst->getType();
    if (type == InstanceType::ScreenGui || type == InstanceType::SurfaceGui || type == InstanceType::BillboardGui)
    {
        auto* layer = static_cast<LayerCollectorInstance*>(inst);
        if (!layer->enabled) return false;
        for (Instance* child : inst->children)
            if (guiHandleScrollInputTree(child, parentX, parentY, parentW, parentH, mouse, wheel,
                shift, parentClips, parentClip))
                return true;
        return false;
    }
    if (type != InstanceType::Frame && type != InstanceType::ScrollingFrame &&
        type != InstanceType::TextLabel && type != InstanceType::ImageLabel &&
        type != InstanceType::TextButton && type != InstanceType::ImageButton &&
        type != InstanceType::TextBox)
    {
        for (Instance* child : inst->children)
            if (guiHandleScrollInputTree(child, parentX, parentY, parentW, parentH, mouse, wheel,
                shift, parentClips, parentClip))
                return true;
        return false;
    }
    auto* gui = static_cast<GuiObjectInstance*>(inst);
    if (!gui->visible) return false;
    float width = udimToPx(gui->size.x, parentW);
    float height = udimToPx(gui->size.y, parentH);
    float x = parentX + udimToPx(gui->position.x, parentW) - gui->anchorPoint.x * width;
    float y = parentY + udimToPx(gui->position.y, parentH) - gui->anchorPoint.y * height;
    Rectangle bounds = { x, y, width, height };
    if (parentClips && !CheckCollisionPointRec(mouse, parentClip))
        return false;
    GuiScrollMetrics metrics = guiGetScrollMetrics(gui, width, height);
    bool clipChildren = gui->clipsDescendants || gui->getType() == InstanceType::ScrollingFrame ||
        metrics.maxX > 1.0f || metrics.maxY > 1.0f;
    float childX = x - std::clamp(gui->canvasPosition.x, 0.0f, metrics.maxX);
    float childY = y - std::clamp(gui->canvasPosition.y, 0.0f, metrics.maxY);
    Rectangle childClip = clipChildren ? bounds : parentClip;
    for (auto iter = gui->children.rbegin(); iter != gui->children.rend(); ++iter)
        if (guiHandleScrollInputTree(*iter, childX, childY, width, height, mouse, wheel,
            shift, clipChildren, childClip))
            return true;

    if (!CheckCollisionPointRec(mouse, bounds))
        return false;
    float barSize = metrics.barSize;
    Rectangle verticalTrack = { x + width - barSize, y, barSize, height };
    Rectangle horizontalTrack = { x, y + height - barSize, width, barSize };
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && metrics.maxY > 1.0f &&
        CheckCollisionPointRec(mouse, verticalTrack))
    {
        guiScrollDragTarget = gui;
        guiScrollDragHorizontal = false;
    }
    else if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && metrics.maxX > 1.0f &&
        CheckCollisionPointRec(mouse, horizontalTrack))
    {
        guiScrollDragTarget = gui;
        guiScrollDragHorizontal = true;
    }
    if (guiScrollDragTarget == gui && IsMouseButtonDown(MOUSE_BUTTON_LEFT))
    {
        if (guiScrollDragHorizontal && metrics.maxX > 1.0f)
        {
            float thumbWidth = max(12.0f, width * width / (width + metrics.maxX));
            gui->canvasPosition.x = std::clamp(
                (mouse.x - x - thumbWidth * 0.5f) / max(1.0f, width - thumbWidth), 0.0f, 1.0f) * metrics.maxX;
        }
        else if (!guiScrollDragHorizontal && metrics.maxY > 1.0f)
        {
            float thumbHeight = max(12.0f, height * height / (height + metrics.maxY));
            gui->canvasPosition.y = std::clamp(
                (mouse.y - y - thumbHeight * 0.5f) / max(1.0f, height - thumbHeight), 0.0f, 1.0f) * metrics.maxY;
        }
        return true;
    }
    if (wheel != 0.0f && metrics.maxY > 1.0f)
        gui->canvasPosition.y = std::clamp(gui->canvasPosition.y - wheel * 36.0f, 0.0f, metrics.maxY);
    else if (wheel != 0.0f && metrics.maxX > 1.0f)
        gui->canvasPosition.x = std::clamp(gui->canvasPosition.x + (shift ? wheel : -wheel) * 36.0f,
            0.0f, metrics.maxX);
    return true;
}

static void handleScreenGuiPointerInput(Instance* root, const Rectangle& viewport)
{
    if (root == nullptr)
        return;
    Vector2 mouse = GetMousePosition();
    float wheel = CheckCollisionPointRec(mouse, viewport) ? GetMouseWheelMove() : 0.0f;
    bool shift = IsKeyDown(KEY_LEFT_SHIFT) || IsKeyDown(KEY_RIGHT_SHIFT);
    if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
        guiScrollDragTarget = nullptr;
    bool pointerHandled = false;
    for (Instance* child : root->children)
    {
        if (child == nullptr || child->getType() != InstanceType::ScreenGui)
            continue;
        auto* layer = static_cast<LayerCollectorInstance*>(child);
        if (layer->enabled && guiHandleScrollInputTree(child, viewport.x, viewport.y,
            viewport.width, viewport.height, mouse, wheel, shift, false, viewport))
        {
            pointerHandled = true;
            break;
        }
    }
    screenGuiPointerHovered = pointerHandled || isPointerOverScreenGui();
}

// Resolve adornee Part (or parent Part) world position for Billboard/Surface.
static bool guiResolveAdorneeWorldPos(LayerCollectorInstance* lc, Vector3& outPos)
{
    Instance* target = lc->adornee;
    if (target == nullptr && lc->parent != nullptr)
        target = lc->parent;
    // Walk up to find a Part
    Instance* walk = target;
    while (walk != nullptr && walk->getType() != InstanceType::Part)
        walk = walk->parent;
    if (walk != nullptr && walk->getType() == InstanceType::Part)
    {
        outPos = getPartWorldPivot(*static_cast<Part*>(walk));
        outPos = Vector3Add(outPos, lc->studsOffset);
        outPos = Vector3Add(outPos, lc->studsOffsetWorldSpace);
        return true;
    }
    // Fallback: studsOffset as world position if set, else origin
    outPos = Vector3Add(lc->studsOffset, lc->studsOffsetWorldSpace);
    return true;
}

// Draw a texture mapped onto a Part face (same axes as Texture / DrawTextureOnPartFace).
static void DrawTextureOnPartFaceEx(const Part& part, const string& faceIn, Texture2D tex, Color tint)
{
    if (tex.id == 0) return;
    string face = faceIn;
    for (char& c : face)
        if (c >= 'A' && c <= 'Z') c = static_cast<char>(c - 'A' + 'a');

    Vector3 centerU = { 0, 0.5f, 0 };
    Vector3 rightU  = { 1, 0, 0 };
    Vector3 upU     = { 0, 0, -1 };
    Vector3 normalU = { 0, 1, 0 };
    float faceW = part.size.x;
    float faceH = part.size.z;

    if (face == "top" || face == "up")
    {
        centerU = { 0, 0.5f, 0 }; rightU = { 1, 0, 0 }; upU = { 0, 0, -1 }; normalU = { 0, 1, 0 };
        faceW = part.size.x; faceH = part.size.z;
    }
    else if (face == "bottom" || face == "down")
    {
        centerU = { 0, -0.5f, 0 }; rightU = { 1, 0, 0 }; upU = { 0, 0, 1 }; normalU = { 0, -1, 0 };
        faceW = part.size.x; faceH = part.size.z;
    }
    else if (face == "front")
    {
        centerU = { 0, 0, -0.5f }; rightU = { -1, 0, 0 }; upU = { 0, 1, 0 }; normalU = { 0, 0, -1 };
        faceW = part.size.x; faceH = part.size.y;
    }
    else if (face == "back")
    {
        centerU = { 0, 0, 0.5f }; rightU = { 1, 0, 0 }; upU = { 0, 1, 0 }; normalU = { 0, 0, 1 };
        faceW = part.size.x; faceH = part.size.y;
    }
    else if (face == "left")
    {
        centerU = { -0.5f, 0, 0 }; rightU = { 0, 0, 1 }; upU = { 0, 1, 0 }; normalU = { -1, 0, 0 };
        faceW = part.size.z; faceH = part.size.y;
    }
    else if (face == "right")
    {
        centerU = { 0.5f, 0, 0 }; rightU = { 0, 0, -1 }; upU = { 0, 1, 0 }; normalU = { 1, 0, 0 };
        faceW = part.size.z; faceH = part.size.y;
    }

    const float eps = 0.04f;
    Vector3 cLocal = {
        centerU.x * part.size.x + normalU.x * eps,
        centerU.y * part.size.y + normalU.y * eps,
        centerU.z * part.size.z + normalU.z * eps
    };
    float hx = faceW * 0.5f;
    float hy = faceH * 0.5f;
    Vector3 r = Vector3Scale(rightU, hx);
    Vector3 u = Vector3Scale(upU, hy);

    Matrix world = GetCFrameMatrix(part.cframe);
    Vector3 p00 = Vector3Transform(Vector3Subtract(Vector3Subtract(cLocal, r), u), world);
    Vector3 p10 = Vector3Transform(Vector3Subtract(Vector3Add(cLocal, r), u), world);
    Vector3 p11 = Vector3Transform(Vector3Add(Vector3Add(cLocal, r), u), world);
    Vector3 p01 = Vector3Transform(Vector3Add(Vector3Subtract(cLocal, r), u), world);

    // Project to screen (overlay runs after EndMode3D)
    if (!viewportCameraValid) return;
    Vector2 s00 = GetWorldToScreen(p00, viewportCamera);
    Vector2 s10 = GetWorldToScreen(p10, viewportCamera);
    Vector2 s11 = GetWorldToScreen(p11, viewportCamera);
    Vector2 s01 = GetWorldToScreen(p01, viewportCamera);

    // Cull if camera is behind the outward face (content would look "inside"/behind)
    Vector3 faceCenter = Vector3Scale(Vector3Add(Vector3Add(p00, p11), Vector3Add(p10, p01)), 0.25f);
    Vector3 nWorld = rotateVector(normalU, part.cframe.rotation);
    float nlen = Vector3Length(nWorld);
    if (nlen > 1e-4f) nWorld = Vector3Scale(nWorld, 1.0f / nlen);
    Vector3 toCam = Vector3Subtract(viewportCamera.position, faceCenter);
    if (Vector3DotProduct(nWorld, toCam) < 0.0f)
        return;

    float cross = (s10.x - s00.x) * (s01.y - s00.y) - (s10.y - s00.y) * (s01.x - s00.x);
    rlDisableShader();
    rlSetShader(rlGetShaderIdDefault(), rlGetShaderLocsDefault());
    rlSetTexture(tex.id);
    rlBegin(RL_QUADS);
    rlColor4ub(tint.r, tint.g, tint.b, tint.a);
    // RenderTexture Y-flip + winding so GUI faces outward (not the back of the face)
    if (cross >= 0.0f)
    {
        rlTexCoord2f(0, 1); rlVertex2f(s00.x, s00.y);
        rlTexCoord2f(1, 1); rlVertex2f(s10.x, s10.y);
        rlTexCoord2f(1, 0); rlVertex2f(s11.x, s11.y);
        rlTexCoord2f(0, 0); rlVertex2f(s01.x, s01.y);
    }
    else
    {
        rlTexCoord2f(0, 1); rlVertex2f(s00.x, s00.y);
        rlTexCoord2f(0, 0); rlVertex2f(s01.x, s01.y);
        rlTexCoord2f(1, 0); rlVertex2f(s11.x, s11.y);
        rlTexCoord2f(1, 1); rlVertex2f(s10.x, s10.y);
    }
    rlEnd();
    rlSetTexture(0);
}

static void renderBillboardAndSurfaceGuis(Instance* root, const Rectangle& vp)
{
    if (root == nullptr || !viewportCameraValid) return;

    static RenderTexture2D surfaceGuiRT = { 0 };
    static int surfaceGuiRTW = 0, surfaceGuiRTH = 0;

    function<void(Instance*)> visit = [&](Instance* inst)
    {
        if (inst == nullptr) return;
        auto t = inst->getType();
        if (t == InstanceType::BillboardGui || t == InstanceType::SurfaceGui)
        {
            auto* lc = static_cast<LayerCollectorInstance*>(inst);
            if (!lc->enabled) { for (Instance* c : inst->children) visit(c); return; }

            // SurfaceGui: map onto Part face like a Texture (all faces including Front/Left/Right)
            if (t == InstanceType::SurfaceGui)
            {
                Instance* adornee = lc->adornee;
                if (adornee == nullptr) adornee = lc->parent;
                while (adornee != nullptr && adornee->getType() != InstanceType::Part)
                    adornee = adornee->parent;
                if (adornee == nullptr || adornee->getType() != InstanceType::Part)
                {
                    for (Instance* c : inst->children) visit(c);
                    return;
                }
                Part* part = static_cast<Part*>(adornee);

                float dist = Vector3Distance(viewportCamera.position, getPartWorldPivot(*part));
                if (lc->maxDistance > 0.0f && dist > lc->maxDistance)
                    return;

                int cw = max(32, (int)(lc->canvasSize.x > 0 ? lc->canvasSize.x : lc->pixelsPerStud * 4));
                int ch = max(32, (int)(lc->canvasSize.y > 0 ? lc->canvasSize.y : lc->pixelsPerStud * 2));
                if (lc->sizingMode == "PixelsPerStud")
                {
                    string f = lc->face;
                    for (char& c : f) if (c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a');
                    float fw = part->size.x, fh = part->size.z;
                    if (f == "front" || f == "back") { fw = part->size.x; fh = part->size.y; }
                    else if (f == "left" || f == "right") { fw = part->size.z; fh = part->size.y; }
                    cw = max(32, (int)(fw * max(1.0f, lc->pixelsPerStud)));
                    ch = max(32, (int)(fh * max(1.0f, lc->pixelsPerStud)));
                }
                cw = min(cw, 1024);
                ch = min(ch, 1024);

                if (surfaceGuiRT.id == 0 || surfaceGuiRTW != cw || surfaceGuiRTH != ch)
                {
                    if (surfaceGuiRT.id != 0) UnloadRenderTexture(surfaceGuiRT);
                    surfaceGuiRT = LoadRenderTexture(cw, ch);
                    surfaceGuiRTW = cw;
                    surfaceGuiRTH = ch;
                }
                if (surfaceGuiRT.id == 0) return;

                BeginTextureMode(surfaceGuiRT);
                ClearBackground((Color){ 0, 0, 0, 0 });
                renderGuiObjectTree(inst, 0, 0, (float)cw, (float)ch);
                EndTextureMode();

                Color tint = WHITE;
                if (lc->lightInfluence > 0.01f)
                {
                    float k = 1.0f - std::clamp(lc->lightInfluence * 0.4f, 0.0f, 0.6f);
                    tint = { (unsigned char)(255 * k), (unsigned char)(255 * k), (unsigned char)(255 * k), 255 };
                }
                DrawTextureOnPartFaceEx(*part, lc->face, surfaceGuiRT.texture, tint);
                return;
            }

            // BillboardGui: camera-facing 2D overlay
            Vector3 worldPos = { 0, 0, 0 };
            guiResolveAdorneeWorldPos(lc, worldPos);

            float dist = Vector3Distance(viewportCamera.position, worldPos);
            if (dist < 0.05f) return; // on top of camera — skip
            if (lc->maxDistance > 0.0f && dist > lc->maxDistance)
                return;
            if (lc->distanceUpperLimit > 0.0f && dist > lc->distanceUpperLimit)
                return;

            // Behind camera / extreme angle → skip (prevents full-screen smear)
            Vector3 camFwd = Vector3Normalize(Vector3Subtract(viewportCamera.target, viewportCamera.position));
            Vector3 toBill = Vector3Normalize(Vector3Subtract(worldPos, viewportCamera.position));
            float facing = Vector3DotProduct(camFwd, toBill);
            if (facing < 0.05f)
                return;

            Vector2 screen = GetWorldToScreen(worldPos, viewportCamera);
            if (screen.x < vp.x - 200 || screen.x > vp.x + vp.width + 200 ||
                screen.y < vp.y - 200 || screen.y > vp.y + vp.height + 200)
                return;

            // Stable scale: average of X/Y projected stud, clamped so glancing angles
            // never explode into a full-screen billboard.
            float pixelsPerStud = 50.0f;
            {
                Vector3 side = Vector3Add(worldPos, (Vector3){ 1, 0, 0 });
                Vector3 up = Vector3Add(worldPos, (Vector3){ 0, 1, 0 });
                Vector2 sSide = GetWorldToScreen(side, viewportCamera);
                Vector2 sUp = GetWorldToScreen(up, viewportCamera);
                float px = fabsf(sSide.x - screen.x);
                float py = fabsf(sUp.y - screen.y);
                float est = (px + py) * 0.5f;
                if (est < 1.0f) est = max(px, py);
                pixelsPerStud = std::clamp(est, 4.0f, 120.0f);
            }
            float scaledWidth = lc->billboardSize.x.scale * pixelsPerStud;
            float scaledHeight = lc->billboardSize.y.scale * pixelsPerStud;
            float pixelWidth = lc->billboardSize.x.offset;
            float pixelHeight = lc->billboardSize.y.offset;
            if (lc->distanceLowerLimit > 0.0f && dist < lc->distanceLowerLimit && dist > 0.01f)
            {
                float distanceScale = dist / lc->distanceLowerLimit;
                scaledWidth *= distanceScale;
                scaledHeight *= distanceScale;
            }
            float bw = scaledWidth + pixelWidth;
            float bh = scaledHeight + pixelHeight;
            // Hard cap vs viewport so content never smears across the whole screen
            float maxW = vp.width * 0.85f;
            float maxH = vp.height * 0.85f;
            if (bw > maxW) { bh *= maxW / bw; bw = maxW; }
            if (bh > maxH) { bw *= maxH / bh; bh = maxH; }
            bw = max(8.0f, bw);
            bh = max(8.0f, bh);
            float bx = screen.x - bw * 0.5f;
            float by = screen.y - bh * 0.5f;
            renderGuiObjectTree(inst, bx, by, bw, bh);
            return;
        }
        for (Instance* c : inst->children)
            visit(c);
    };
    visit(root);
}

void renderScreenGuisOverlay()
{
    if (activeWindow != WindowType::Viewport)
        return;
    Rectangle vp = getViewportBounds();
    if (vp.width < 2 || vp.height < 2) return;

    auto drawScreenGuis = [&](Instance* root)
    {
        if (root == nullptr) return;
        // Sort by DisplayOrder (stable simple pass)
        vector<Instance*> screens;
        for (Instance* child : root->children)
        {
            if (child == nullptr) continue;
            if (child->getType() == InstanceType::ScreenGui)
            {
                auto* sg = static_cast<LayerCollectorInstance*>(child);
                if (sg->enabled) screens.push_back(child);
            }
        }
        sort(screens.begin(), screens.end(), [](Instance* a, Instance* b) {
            return static_cast<LayerCollectorInstance*>(a)->displayOrder <
                   static_cast<LayerCollectorInstance*>(b)->displayOrder;
        });
        for (Instance* child : screens)
            renderGuiObjectTree(child, vp.x, vp.y, vp.width, vp.height);
    };

    auto drawWorldGuis = [&](Instance* root)
    {
        if (root == nullptr) return;
        // BillboardGui / SurfaceGui can live under Workspace or StarterGui
        renderBillboardAndSurfaceGuis(root, vp);
    };

    // Edit mode: preview StarterGui. Client play: LocalPlayer.PlayerGui. Server: StarterGui.
    Instance* guiRoot = &StarterGui;
    if (runtimePlaying && runtimeClientMode && runtimePlayer != nullptr && runtimePlayer->playerGui != nullptr)
        guiRoot = runtimePlayer->playerGui;

    handleScreenGuiPointerInput(guiRoot, vp);
    drawScreenGuis(guiRoot);
    drawWorldGuis(guiRoot);
    // Also scan Workspace for BillboardGui / SurfaceGui parented to parts
    drawWorldGuis(&workspace);
}

void renderViewportBorder()
{
    if (activeWindow != WindowType::Viewport && activeWindow != WindowType::Welcome)
        return;
    Rectangle vp = getViewportBounds();
    if (vp.width <= 1.0f || vp.height <= 1.0f)
        return;
    // Outer border (supports future 2D overlays aligned to this rect)
    DrawRectangleLinesEx(vp, 2.0f, (Color){ 55, 62, 74, 255 });
    // Subtle inner edge so the 3D area reads as a framed canvas
    DrawRectangleLinesEx(
        (Rectangle){ vp.x + 2.0f, vp.y + 2.0f, vp.width - 4.0f, vp.height - 4.0f },
        1.0f, (Color){ 30, 34, 42, 180 });
}

struct ScriptFindLayout
{
    Rectangle panel;
    Rectangle query;
    Rectangle replacement;
    Rectangle previous;
    Rectangle next;
    Rectangle replaceOne;
    Rectangle replaceAll;
    Rectangle close;
};

ScriptFindLayout getScriptFindLayout()
{
    float left = static_cast<float>(leftSlotWidth() + 64);
    float right = static_cast<float>(GetScreenWidth() - rightSlotWidth() - 8);
    float width = max(340.0f, min(500.0f, right - left));
    float x = max(left, right - width);
    float y = static_cast<float>(EDITOR_CONTENT_TOP + 8);
    float height = scriptFindReplaceOpen ? 66.0f : 36.0f;
    float buttonRight = x + width - 8.0f;
    ScriptFindLayout layout;
    layout.panel = { x, y, width, height };
    layout.close = { buttonRight - 22.0f, y + 5.0f, 18.0f, 22.0f };
    layout.next = { buttonRight - 68.0f, y + 5.0f, 40.0f, 22.0f };
    layout.previous = { buttonRight - 112.0f, y + 5.0f, 40.0f, 22.0f };
    layout.query = { x + 56.0f, y + 5.0f, max(70.0f, width - 56.0f - 128.0f), 22.0f };
    layout.replacement = { x + 56.0f, y + 36.0f, max(70.0f, width - 200.0f), 22.0f };
    layout.replaceAll = { buttonRight - 64.0f, y + 36.0f, 56.0f, 22.0f };
    layout.replaceOne = { buttonRight - 126.0f, y + 36.0f, 56.0f, 22.0f };
    return layout;
}

void renderScriptFindBar()
{
    if (!scriptFindOpen || activeWindow != WindowType::Script || activeScript == nullptr)
        return;
    EditorThemeColors theme = getEditorThemeColors();
    ScriptFindLayout layout = getScriptFindLayout();
    DrawRectangleRec(layout.panel, theme.panel);
    DrawRectangleLinesEx(layout.panel, 1.0f, theme.border);
    DrawText("Find", (int)layout.panel.x + 10, (int)layout.query.y + 4, 13, theme.muted);
    DrawRectangleRec(layout.query, scriptFindFocusedField == 0 ? theme.selected : theme.surface);
    DrawRectangleLinesEx(layout.query, 1.0f, theme.border);
    DrawText(scriptFindQuery.empty() ? "Search" : scriptFindQuery.c_str(),
        (int)layout.query.x + 6, (int)layout.query.y + 4, 13,
        scriptFindQuery.empty() ? theme.muted : theme.text);
    auto drawButton = [&](Rectangle rect, const char* label)
    {
        Vector2 mouse = GetMousePosition();
        DrawRectangleRec(rect, CheckCollisionPointRec(mouse, rect) ? theme.accentHover : theme.surface);
        DrawRectangleLinesEx(rect, 1.0f, theme.border);
        int textWidth = MeasureText(label, 12);
        DrawText(label, (int)(rect.x + (rect.width - textWidth) * 0.5f), (int)rect.y + 5, 12, theme.text);
    };
    drawButton(layout.previous, "Prev");
    drawButton(layout.next, "Next");
    drawButton(layout.close, "X");
    if (scriptFindReplaceOpen)
    {
        DrawText("With", (int)layout.panel.x + 10, (int)layout.replacement.y + 4, 13, theme.muted);
        DrawRectangleRec(layout.replacement, scriptFindFocusedField == 1 ? theme.selected : theme.surface);
        DrawRectangleLinesEx(layout.replacement, 1.0f, theme.border);
        DrawText(scriptReplaceText.empty() ? "Replace with" : scriptReplaceText.c_str(),
            (int)layout.replacement.x + 6, (int)layout.replacement.y + 4, 13,
            scriptReplaceText.empty() ? theme.muted : theme.text);
        drawButton(layout.replaceOne, "Replace");
        drawButton(layout.replaceAll, "All");
    }
}

void render2D()
{
    /*DrawText(
            "WASD Move | QE Up/Down | RMB Rotate | Shift Fast",
            10, 10, 20, BLACK
        );

    DrawFPS(10, 40);*/

    if (activeWindow == WindowType::Library)
    {
        renderLibraryWindow();
    }
    else if (activeWindow == WindowType::Output)
    {
        EditorThemeColors outputTheme = getEditorThemeColors();
        int outputLeft = leftSlotWidth();
        int outputRight = GetScreenWidth() - rightSlotWidth();
        int outputBottom = GetScreenHeight(); // fill entire view
        int contentWidth = outputRight - outputLeft;
        int contentHeight = outputBottom - EDITOR_CONTENT_TOP;
        float widestOutput = 0.0f;
        for (const OutputEntry& entry : outputEntries)
            widestOutput = max(widestOutput, static_cast<float>(MeasureText(entry.text.c_str(), 16) + 24));
        float maxScrollX = max(0.0f, widestOutput - static_cast<float>(contentWidth - EXPLORER_SCROLLBAR_SIZE));
        float contentPixelH = 48.0f + static_cast<float>(outputEntries.size()) * 22.0f;
        float maxScrollY = max(0.0f, contentPixelH - static_cast<float>(contentHeight - EXPLORER_SCROLLBAR_SIZE));
        if (outputFollowTail)
            outputScrollY = maxScrollY;
        outputScrollX = std::clamp(outputScrollX, 0.0f, maxScrollX);
        outputScrollY = std::clamp(outputScrollY, 0.0f, maxScrollY);
        // Clip output to the panel height (not full screen)
        int panelH = max(1, outputBottom - EDITOR_CONTENT_TOP);
        drawThemeBackground({ (float)outputLeft, (float)EDITOR_CONTENT_TOP,
            (float)contentWidth, (float)panelH }, outputTheme, outputTheme.canvas);
        DrawRectangle(outputLeft, EDITOR_CONTENT_TOP, contentWidth, 4, outputTheme.accent);
        // Dim the rest of the editor so Output does not look fullscreen
        if (outputBottom < GetScreenHeight())
            DrawRectangle(outputLeft, outputBottom, contentWidth, GetScreenHeight() - outputBottom, (Color){ 18, 20, 24, 160 });
        BeginScissorMode(outputLeft, EDITOR_CONTENT_TOP, contentWidth - EXPLORER_SCROLLBAR_SIZE, panelH - EXPLORER_SCROLLBAR_SIZE);
        DrawText("Output", outputLeft + 24 - static_cast<int>(outputScrollX), EDITOR_CONTENT_TOP + 12 - static_cast<int>(outputScrollY), 22, outputTheme.text);
        DrawText("Ctrl+C copy  ·  click lines", outputLeft + 120, EDITOR_CONTENT_TOP + 16 - static_cast<int>(outputScrollY), 14, outputTheme.muted);
        int y = EDITOR_CONTENT_TOP + 48 - static_cast<int>(outputScrollY);
        int lineIndex = 0;
        int selA = min(outputSelectStart, outputSelectEnd);
        int selB = max(outputSelectStart, outputSelectEnd);
        for (const OutputEntry& entry : outputEntries)
        {
            bool selected = (outputSelectStart >= 0 && lineIndex >= selA && lineIndex <= selB);
            bool isErr = entry.severity == OutputSeverity::Error;
            bool isWarn = entry.severity == OutputSeverity::Warning;
            if (isErr)
                DrawRectangle(outputLeft + 4, y - 2, contentWidth - 16, 20, (Color){ 180, 40, 40, 70 });
            else if (isWarn)
                DrawRectangle(outputLeft + 4, y - 2, contentWidth - 16, 20, (Color){ 200, 140, 20, 55 });
            if (selected)
                DrawRectangle(outputLeft + 8, y - 2, contentWidth - 24, 20, outputTheme.selected);
            Color color = isErr ? (Color){ 255, 120, 120, 255 } :
                isWarn ? (Color){ 255, 210, 100, 255 } :
                outputTheme.text;
            DrawText(entry.text.c_str(), outputLeft + 24 - static_cast<int>(outputScrollX), y, 16, color);
            y += 22;
            lineIndex++;
        }
        EndScissorMode();
        // Resize grip
        DrawRectangle(outputLeft, outputBottom - 3, contentWidth, 3, outputTheme.border);
        drawDocumentScrollbars(outputLeft, EDITOR_CONTENT_TOP, contentWidth, contentHeight, maxScrollX, maxScrollY, outputScrollX, outputScrollY);

        // Output selection + copy
        if (activeWindow == WindowType::Output)
        {
            Vector2 mouse = GetMousePosition();
            bool inOutput = mouse.x >= outputLeft && mouse.x < outputLeft + contentWidth
                && mouse.y >= EDITOR_CONTENT_TOP && mouse.y < EDITOR_CONTENT_TOP + contentHeight;
            if (inOutput && IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
            {
                // Must match draw origin: EDITOR_CONTENT_TOP + 48 (was +60 → selected line above).
                int line = static_cast<int>((mouse.y - (EDITOR_CONTENT_TOP + 48) + outputScrollY) / 22.0f);
                line = std::clamp(line, 0, max(0, static_cast<int>(outputEntries.size()) - 1));
                outputSelectStart = line;
                outputSelectEnd = line;
                outputSelecting = true;
            }
            if (outputSelecting && IsMouseButtonDown(MOUSE_BUTTON_LEFT) && inOutput)
            {
                int line = static_cast<int>((mouse.y - (EDITOR_CONTENT_TOP + 48) + outputScrollY) / 22.0f);
                line = std::clamp(line, 0, max(0, static_cast<int>(outputEntries.size()) - 1));
                outputSelectEnd = line;
            }
            if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
                outputSelecting = false;

            bool ctrl = IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL);
            if (ctrl && IsKeyPressed(KEY_A) && !outputEntries.empty())
            {
                outputSelectStart = 0;
                outputSelectEnd = static_cast<int>(outputEntries.size()) - 1;
            }
            if (ctrl && IsKeyPressed(KEY_C) && outputSelectStart >= 0 && !outputEntries.empty())
            {
                int a = min(outputSelectStart, outputSelectEnd);
                int b = max(outputSelectStart, outputSelectEnd);
                string clip;
                for (int i = a; i <= b && i < static_cast<int>(outputEntries.size()); ++i)
                {
                    if (!clip.empty()) clip += "\n";
                    clip += outputEntries[i].text;
                }
                if (!clip.empty())
                    SetClipboardText(clip.c_str());
            }
        }
    }
    else if (activeWindow == WindowType::Script && activeScript != nullptr)
    {
        sanitizeScriptEditorState(activeScript->source);
        {
            int cleanedChars = sanitizeScriptSourceInPlace(activeScript->source);
            if (cleanedChars > 0)
            {
                // Keep cursor valid after shrinking source
                sanitizeScriptEditorState(activeScript->source);
                scriptDiagnosticsSourceKey.clear();
            }
        }
        refreshScriptDiagnostics(activeScript->source);
        int editorLeft = leftSlotWidth();
        int editorRight = GetScreenWidth() - rightSlotWidth();
        int contentWidth = editorRight - editorLeft;
        int contentHeight = GetScreenHeight() - EDITOR_CONTENT_TOP;
        DrawRectangle(editorLeft, EDITOR_CONTENT_TOP, contentWidth, GetScreenHeight() - EDITOR_CONTENT_TOP, SCRIPT_BACKGROUND);
        DrawRectangle(editorLeft, EDITOR_CONTENT_TOP, 56, GetScreenHeight() - EDITOR_CONTENT_TOP, SCRIPT_GUTTER);

        float maxScrollX = max(0.0f, static_cast<float>(getScriptContentWidth(activeScript->source) - (contentWidth - EXPLORER_SCROLLBAR_SIZE)));
        float maxScrollY = max(0.0f, getScriptLineCount(activeScript->source) * static_cast<float>(scriptFontSize + 6) - (contentHeight - EXPLORER_SCROLLBAR_SIZE - 10.0f));
        scriptScrollX = std::clamp(scriptScrollX, 0.0f, maxScrollX);
        scriptScrollY = std::clamp(scriptScrollY, 0.0f, maxScrollY);
        BeginScissorMode(editorLeft, EDITOR_CONTENT_TOP, contentWidth - EXPLORER_SCROLLBAR_SIZE, contentHeight - EXPLORER_SCROLLBAR_SIZE);
        int line = 1;
        int lineStart = 0;
        int y = EDITOR_CONTENT_TOP + 10 - static_cast<int>(scriptScrollY);
        int lineHeight = scriptFontSize + 6;
        ScriptHighlightState scriptHighlightState;
        for (int i = 0; i <= static_cast<int>(activeScript->source.size()); ++i)
        {
            if (i == static_cast<int>(activeScript->source.size()) || activeScript->source[i] == '\n')
            {
                string text = activeScript->source.substr(lineStart, i - lineStart);
                int selectionLow = std::clamp(min(scriptSelectionStart, scriptSelectionEnd), 0, static_cast<int>(activeScript->source.size()));
                int selectionHigh = std::clamp(max(scriptSelectionStart, scriptSelectionEnd), 0, static_cast<int>(activeScript->source.size()));
                int selectedStart = max(lineStart, selectionLow);
                int selectedEnd = min(i, selectionHigh);
                if (scriptSelectionStart >= 0 && selectedStart < selectedEnd)
                {
                    string beforeSelection = activeScript->source.substr(lineStart, selectedStart - lineStart);
                    string selectionEndText = activeScript->source.substr(lineStart, selectedEnd - lineStart);
                    DrawRectangle(
                        editorLeft + 68 + measureScriptText(beforeSelection) - static_cast<int>(scriptScrollX),
                        y - 1,
                        max(2, measureScriptText(selectionEndText) - measureScriptText(beforeSelection)),
                        lineHeight,
                        SCRIPT_SELECTION
                    );
                }
                if (scriptFindOpen && scriptFindMatchStart >= 0 && !scriptFindQuery.empty())
                {
                    int findStart = max(lineStart, scriptFindMatchStart);
                    int findEnd = min(i, scriptFindMatchStart + static_cast<int>(scriptFindQuery.size()));
                    if (findStart < findEnd)
                    {
                        string beforeMatch = activeScript->source.substr(lineStart, findStart - lineStart);
                        string throughMatch = activeScript->source.substr(lineStart, findEnd - lineStart);
                        DrawRectangle(editorLeft + 68 + measureScriptText(beforeMatch) - static_cast<int>(scriptScrollX),
                            y - 1, max(2, measureScriptText(throughMatch) - measureScriptText(beforeMatch)),
                            lineHeight, SCRIPT_FIND_HIGHLIGHT);
                    }
                }
                // Diagnostic underline / row tint
                for (const ScriptDiagnostic& d : scriptDiagnostics)
                {
                    if (d.line != line) continue;
                    Color tint = d.severity == DiagnosticSeverity::Error
                        ? (Color){ 200, 50, 50, 55 }
                        : (Color){ 200, 150, 30, 45 };
                    DrawRectangle(editorLeft + 56, y - 1, contentWidth - 56, lineHeight, tint);
                    Color under = d.severity == DiagnosticSeverity::Error
                        ? (Color){ 255, 80, 80, 220 }
                        : (Color){ 255, 190, 60, 220 };
                    DrawRectangle(editorLeft + 68 - (int)scriptScrollX, y + lineHeight - 3, max(24, measureScriptText(text)), 2, under);
                    // gutter mark
                    DrawRectangle(editorLeft + 2, y + 2, 4, lineHeight - 4, under);
                }
                DrawText(TextFormat("%d", line), editorLeft + 12, y, scriptFontSize, (Color){ 120, 130, 143, 255 });
                vector<string> functionNames = getScriptFunctionNames(activeScript->source);
                drawScriptText(text, editorLeft + 68 - static_cast<int>(scriptScrollX), y,
                    functionNames, scriptHighlightState);

                if (scriptCursor >= lineStart && scriptCursor <= i &&
                    fmod(GetTime() - scriptCaretResetTime, 1.0) < 0.5)
                {
                    string beforeCursor = activeScript->source.substr(lineStart, scriptCursor - lineStart);
                    int caretX = editorLeft + 68 + measureScriptText(beforeCursor) - static_cast<int>(scriptScrollX);
                    DrawRectangle(caretX, y - 1, 2, lineHeight, SKYBLUE);
                }

                lineStart = i + 1;
                line++;
                y += lineHeight;
            }
        }

        // Diagnostic hover tooltip
        scriptDiagHoverIndex = -1;
        {
            Vector2 mouseH = GetMousePosition();
            int lineHeightH = scriptFontSize + 6;
            if (mouseH.x >= leftSlotWidth() + 56 && mouseH.x < GetScreenWidth() - rightSlotWidth() &&
                mouseH.y >= EDITOR_CONTENT_TOP)
            {
                int hoverLine = max(1, 1 + (int)((mouseH.y - (EDITOR_CONTENT_TOP + 10) + scriptScrollY) / lineHeightH));
                for (size_t di = 0; di < scriptDiagnostics.size(); ++di)
                {
                    if (scriptDiagnostics[di].line != hoverLine) continue;
                    scriptDiagHoverIndex = (int)di;
                    const ScriptDiagnostic& d = scriptDiagnostics[di];
                    string tip = (d.severity == DiagnosticSeverity::Error ? "Error: " : "Warning: ") + d.message;
                    int tipW = MeasureText(tip.c_str(), 14) + 16;
                    int tipX = min((int)mouseH.x + 12, GetScreenWidth() - tipW - 8);
                    int tipY = (int)mouseH.y + 18;
                    DrawRectangle(tipX, tipY, tipW, 22, (Color){ 40, 42, 48, 245 });
                    DrawRectangleLines(tipX, tipY, tipW, 22, d.severity == DiagnosticSeverity::Error
                        ? (Color){ 255, 100, 100, 255 } : (Color){ 255, 200, 80, 255 });
                    DrawText(tip.c_str(), tipX + 8, tipY + 4, 14, RAYWHITE);
                    break;
                }
            }
        }

        renderScriptCompletions(activeScript->source);
        EndScissorMode();
        drawDocumentScrollbars(editorLeft, EDITOR_CONTENT_TOP, contentWidth, contentHeight, maxScrollX, maxScrollY, scriptScrollX, scriptScrollY);
        renderScriptFindBar();
    }

    // Distance / angle meter intentionally not shown while dragging.

}

void handleOutputResize()
{
    if (activeWindow != WindowType::Output)
    {
        outputResizing = false;
        return;
    }

    Vector2 mouse = GetMousePosition();
    float edgeY = EDITOR_CONTENT_TOP + outputHeight;
    Rectangle edge = { static_cast<float>(leftSlotWidth()), edgeY - 6.0f, static_cast<float>(GetScreenWidth() - leftSlotWidth() - rightSlotWidth()), 12.0f };
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, edge))
        outputResizing = true;
    if (outputResizing && IsMouseButtonDown(MOUSE_BUTTON_LEFT))
        outputHeight = std::clamp(mouse.y - static_cast<float>(EDITOR_CONTENT_TOP), 140.0f,
            static_cast<float>(GetScreenHeight() - EDITOR_CONTENT_TOP));
    if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
        outputResizing = false;
}

void handleDocumentScrollInput()
{
    if (activeWindow != WindowType::Script && activeWindow != WindowType::Output)
        return;

    Vector2 mouse = GetMousePosition();
    int contentLeft = leftSlotWidth();
    int contentWidth = GetScreenWidth() - leftSlotWidth() - rightSlotWidth();
    // Output fills the entire center column; wheel/scroll detection covers that whole area.
    int contentHeight = GetScreenHeight() - EDITOR_CONTENT_TOP;
    float& scrollX = activeWindow == WindowType::Output ? outputScrollX : scriptScrollX;
    float& scrollY = activeWindow == WindowType::Output ? outputScrollY : scriptScrollY;
    float maxScrollX = 0.0f;
    float maxScrollY = 0.0f;
    if (activeWindow == WindowType::Output)
    {
        float widestOutput = 0.0f;
        for (const OutputEntry& entry : outputEntries)
            widestOutput = max(widestOutput, static_cast<float>(MeasureText(entry.text.c_str(), 16) + 24));
        maxScrollX = max(0.0f, widestOutput - static_cast<float>(contentWidth - EXPLORER_SCROLLBAR_SIZE));
        // Header (~48px) + lines * 22
        float contentPixelH = 48.0f + static_cast<float>(outputEntries.size()) * 22.0f;
        maxScrollY = max(0.0f, contentPixelH - static_cast<float>(contentHeight - EXPLORER_SCROLLBAR_SIZE));
    }
    else if (activeScript != nullptr)
    {
        maxScrollX = max(0.0f, static_cast<float>(getScriptContentWidth(activeScript->source) - (contentWidth - EXPLORER_SCROLLBAR_SIZE)));
        maxScrollY = max(0.0f, getScriptLineCount(activeScript->source) * static_cast<float>(scriptFontSize + 6) - (contentHeight - EXPLORER_SCROLLBAR_SIZE - 10.0f));
    }

    Rectangle verticalTrack = { static_cast<float>(contentLeft + contentWidth - EXPLORER_SCROLLBAR_SIZE), static_cast<float>(EDITOR_CONTENT_TOP),
        static_cast<float>(EXPLORER_SCROLLBAR_SIZE), static_cast<float>(contentHeight - EXPLORER_SCROLLBAR_SIZE) };
    Rectangle horizontalTrack = { static_cast<float>(contentLeft), static_cast<float>(EDITOR_CONTENT_TOP + contentHeight - EXPLORER_SCROLLBAR_SIZE),
        static_cast<float>(contentWidth - EXPLORER_SCROLLBAR_SIZE), static_cast<float>(EXPLORER_SCROLLBAR_SIZE) };
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && maxScrollY > 0.0f && CheckCollisionPointRec(mouse, verticalTrack))
        documentDraggingScrollY = true;
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && maxScrollX > 0.0f && CheckCollisionPointRec(mouse, horizontalTrack))
        documentDraggingScrollX = true;
    if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && documentDraggingScrollY)
    {
        float thumbHeight = scrollbarThumbSize(verticalTrack.height, maxScrollY);
        scrollY = scrollbarScrollFromMouse(mouse.y, verticalTrack.y, verticalTrack.height, thumbHeight, maxScrollY);
    }
    if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && documentDraggingScrollX)
    {
        float thumbWidth = scrollbarThumbSize(horizontalTrack.width, maxScrollX);
        scrollX = scrollbarScrollFromMouse(mouse.x, horizontalTrack.x, horizontalTrack.width, thumbWidth, maxScrollX);
    }
    if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
    {
        documentDraggingScrollX = false;
        documentDraggingScrollY = false;
    }

    // Entire output/script window (including scrollbar tracks) receives wheel events
    Rectangle windowArea = {
        static_cast<float>(contentLeft),
        static_cast<float>(EDITOR_CONTENT_TOP),
        static_cast<float>(contentWidth),
        static_cast<float>(contentHeight)
    };
    FocusZone documentZone = activeWindow == WindowType::Script
        ? FocusZone::ScriptEditor : FocusZone::Output;
    if ((IsMouseButtonPressed(MOUSE_BUTTON_LEFT) || IsMouseButtonPressed(MOUSE_BUTTON_RIGHT) ||
         IsMouseButtonPressed(MOUSE_BUTTON_MIDDLE)) && CheckCollisionPointRec(mouse, windowArea))
        focusedZone = documentZone;
    if (CheckCollisionPointRec(mouse, windowArea) && isZoneFocused(documentZone))
    {
        float wheel = GetMouseWheelMove();
        bool ctrl = IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL);
        bool shift = IsKeyDown(KEY_LEFT_SHIFT) || IsKeyDown(KEY_RIGHT_SHIFT);
        if (activeWindow == WindowType::Script && ctrl && wheel != 0.0f)
        {
            scriptFontSize = wheel > 0.0f ? min(32, scriptFontSize + 1) : max(10, scriptFontSize - 1);
        }
        else if (wheel != 0.0f)
        {
            float& target = shift ? scrollX : scrollY;
            float targetMax = shift ? maxScrollX : maxScrollY;
            target = std::clamp(target - wheel * 60.0f, 0.0f, targetMax);
        }
    }

    // Output follow-tail: break when user scrolls away from bottom; resume at bottom
    if (activeWindow == WindowType::Output && maxScrollY > 0.0f)
    {
        const float bottomEpsilon = 24.0f;
        if (scrollY < maxScrollY - bottomEpsilon)
            outputFollowTail = false;
        else
            outputFollowTail = true;
    }
    else if (activeWindow == WindowType::Output && maxScrollY <= 0.0f)
    {
        outputFollowTail = true;
    }
}

void handleScriptInput()
{
    if (activeWindow != WindowType::Script || activeScript == nullptr ||
        !isZoneFocused(FocusZone::ScriptEditor))
        return;

    bool ctrlShortcut = IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL);
    bool shiftShortcut = IsKeyDown(KEY_LEFT_SHIFT) || IsKeyDown(KEY_RIGHT_SHIFT);
    if (ctrlShortcut && IsKeyPressed(KEY_F))
    {
        scriptFindOpen = true;
        scriptFindReplaceOpen = shiftShortcut;
        scriptFindFocusedField = 0;
        if (scriptSelectionStart >= 0 && scriptSelectionStart != scriptSelectionEnd)
        {
            int start = min(scriptSelectionStart, scriptSelectionEnd);
            int end = max(scriptSelectionStart, scriptSelectionEnd);
            scriptFindQuery = activeScript->source.substr(start, end - start);
        }
        return;
    }

    string& source = activeScript->source;
    scriptCursor = std::clamp(scriptCursor, 0, static_cast<int>(source.size()));
    double now = GetTime();

    auto hasSelection = [&]()
    {
        return scriptSelectionStart >= 0 && scriptSelectionStart != scriptSelectionEnd;
    };

    auto clearSelection = [&]()
    {
        scriptSelectionStart = -1;
        scriptSelectionEnd = -1;
    };

    auto saveScriptUndo = [&]()
    {
        if (!scriptUndoHistory.empty() && scriptUndoHistory.back().script == activeScript &&
            scriptUndoHistory.back().source == source)
            return;
        scriptUndoHistory.push_back({ activeScript, source, scriptCursor, scriptSelectionStart, scriptSelectionEnd });
        if (scriptUndoHistory.size() > 200)
            scriptUndoHistory.erase(scriptUndoHistory.begin());
        scriptRedoHistory.clear();
    };

    auto deleteSelection = [&]()
    {
        if (!hasSelection())
            return false;

        int low = min(scriptSelectionStart, scriptSelectionEnd);
        int high = max(scriptSelectionStart, scriptSelectionEnd);
        source.erase(low, high - low);
        scriptCursor = low;
        clearSelection();
        return true;
    };

    auto insertText = [&](const string& text)
    {
        saveScriptUndo();
        deleteSelection();
        source.insert(scriptCursor, text);
        scriptCursor += static_cast<int>(text.size());
        scriptCaretResetTime = now;
    };

    auto selectFindMatch = [&](int match)
    {
        scriptFindMatchStart = match;
        scriptSelectionStart = match;
        scriptSelectionEnd = match + static_cast<int>(scriptFindQuery.size());
        scriptCursor = scriptSelectionEnd;
        scriptCaretResetTime = now;
    };

    auto findMatch = [&](bool backwards)
    {
        if (scriptFindQuery.empty())
        {
            scriptFindMatchStart = -1;
            return false;
        }
        size_t found = string::npos;
        if (backwards)
        {
            size_t start = scriptFindMatchStart >= 0
                ? static_cast<size_t>(max(0, scriptFindMatchStart - 1))
                : static_cast<size_t>(max(0, scriptCursor - 1));
            found = source.rfind(scriptFindQuery, start);
            if (found == string::npos)
                found = source.rfind(scriptFindQuery);
        }
        else
        {
            size_t start = static_cast<size_t>(std::clamp(scriptCursor, 0, static_cast<int>(source.size())));
            found = source.find(scriptFindQuery, start);
            if (found == string::npos)
                found = source.find(scriptFindQuery, 0);
        }
        if (found == string::npos)
        {
            scriptFindMatchStart = -1;
            return false;
        }
        selectFindMatch(static_cast<int>(found));
        return true;
    };

    if (scriptFindOpen)
    {
        ScriptFindLayout layout = getScriptFindLayout();
        Vector2 findMouse = GetMousePosition();
        if (IsKeyPressed(KEY_ESCAPE))
        {
            scriptFindOpen = false;
            scriptFindMatchStart = -1;
            scriptSelectionStart = -1;
            scriptSelectionEnd = -1;
            return;
        }
        if (IsKeyPressed(KEY_TAB) && scriptFindReplaceOpen)
            scriptFindFocusedField = 1 - scriptFindFocusedField;
        if (IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_DOWN))
            findMatch(false);
        else if (IsKeyPressed(KEY_UP))
            findMatch(true);

        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
        {
            if (CheckCollisionPointRec(findMouse, layout.close))
            {
                scriptFindOpen = false;
                scriptFindMatchStart = -1;
                scriptSelectionStart = -1;
                scriptSelectionEnd = -1;
                return;
            }
            if (CheckCollisionPointRec(findMouse, layout.query))
                scriptFindFocusedField = 0;
            else if (scriptFindReplaceOpen && CheckCollisionPointRec(findMouse, layout.replacement))
                scriptFindFocusedField = 1;
            else if (CheckCollisionPointRec(findMouse, layout.previous))
                findMatch(true);
            else if (CheckCollisionPointRec(findMouse, layout.next))
                findMatch(false);
            else if (scriptFindReplaceOpen && CheckCollisionPointRec(findMouse, layout.replaceOne))
            {
                if (scriptFindMatchStart < 0 && !findMatch(false)) return;
                if (scriptFindMatchStart >= 0 &&
                    source.compare(scriptFindMatchStart, scriptFindQuery.size(), scriptFindQuery) == 0)
                {
                    saveScriptUndo();
                    source.replace(scriptFindMatchStart, scriptFindQuery.size(), scriptReplaceText);
                    scriptCursor = scriptFindMatchStart + static_cast<int>(scriptReplaceText.size());
                    scriptFindMatchStart = -1;
                    scriptDiagnosticsSourceKey.clear();
                    findMatch(false);
                }
            }
            else if (scriptFindReplaceOpen && CheckCollisionPointRec(findMouse, layout.replaceAll))
            {
                if (!scriptFindQuery.empty())
                {
                    saveScriptUndo();
                    size_t position = 0;
                    int replacements = 0;
                    while ((position = source.find(scriptFindQuery, position)) != string::npos)
                    {
                        source.replace(position, scriptFindQuery.size(), scriptReplaceText);
                        position += scriptReplaceText.size();
                        replacements++;
                    }
                    if (replacements > 0)
                    {
                        scriptCursor = min(static_cast<int>(source.size()), scriptCursor);
                        scriptFindMatchStart = -1;
                        scriptDiagnosticsSourceKey.clear();
                        findMatch(false);
                    }
                }
            }
            return;
        }

        string& field = scriptFindFocusedField == 0 ? scriptFindQuery : scriptReplaceText;
        bool queryChanged = false;
        if (ctrlShortcut && IsKeyPressed(KEY_A))
        {
            field.clear();
            queryChanged = scriptFindFocusedField == 0;
        }
        else if ((IsKeyPressed(KEY_BACKSPACE) || IsKeyPressed(KEY_DELETE)) && !field.empty())
        {
            field.pop_back();
            queryChanged = scriptFindFocusedField == 0;
        }
        int codepoint = GetCharPressed();
        while (codepoint > 0)
        {
            if (!ctrlShortcut && codepoint >= 32 && codepoint <= 126 && field.size() < 256)
            {
                field.push_back(static_cast<char>(codepoint));
                queryChanged = scriptFindFocusedField == 0;
            }
            codepoint = GetCharPressed();
        }
        if (queryChanged)
        {
            scriptFindMatchStart = -1;
            findMatch(false);
        }
        return;
    }

    auto repeatKey = [&](KeyboardKey key, double& lastTime)
    {
        if (IsKeyPressed(key))
        {
            lastTime = now;
            return true;
        }
        if (IsKeyDown(key) && now - lastTime >= 0.5)
        {
            lastTime += 0.05;
            return true;
        }
        if (!IsKeyDown(key))
            lastTime = now;
        return false;
    };

    Vector2 mouse = GetMousePosition();
    if (scriptCompletionVisible && IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
    {
        bool inMain = CheckCollisionPointRec(mouse, scriptCompletionBounds);
        bool inDetails = CheckCollisionPointRec(mouse, scriptCompletionDetailBounds);
        const int completionHeader = 28;
        const int completionRow = scriptFontSize + 6;
        float listY = scriptCompletionBounds.y + completionHeader;
        float listBottom = listY + min(8, static_cast<int>(scriptCompletionMatches.size())) * completionRow;
        if (inMain && mouse.y >= listY && mouse.y < listBottom)
        {
            int row = static_cast<int>((mouse.y - listY) / completionRow);
            scriptCompletionIndex = scriptCompletionScrollIndex + row;
            acceptScriptCompletion(source);
            return;
        }
        if (!inMain && !inDetails)
        {
            scriptCompletionVisible = false;
            scriptCompletionMatches.clear();
            scriptCompletionPrefix.clear();
        }
    }

    if (scriptCompletionVisible && IsKeyPressed(KEY_UP))
    {
        scriptCompletionIndex = (scriptCompletionIndex + static_cast<int>(scriptCompletionMatches.size()) - 1) %
            static_cast<int>(scriptCompletionMatches.size());
    }
    if (scriptCompletionVisible && IsKeyPressed(KEY_DOWN))
    {
        scriptCompletionIndex = (scriptCompletionIndex + 1) % static_cast<int>(scriptCompletionMatches.size());
    }
    if (scriptCompletionVisible && (IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_TAB)))
    {
        acceptScriptCompletion(source);
        return;
    }
    if (scriptCompletionVisible &&
        (CheckCollisionPointRec(mouse, scriptCompletionBounds) ||
         CheckCollisionPointRec(mouse, scriptCompletionDetailBounds)))
    {
        float completionWheel = GetMouseWheelMove();
        if (completionWheel != 0.0f)
            scriptCompletionIndex = std::clamp(scriptCompletionIndex + (completionWheel < 0.0f ? 1 : -1),
                0, static_cast<int>(scriptCompletionMatches.size()) - 1);
    }

    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) &&
        !(scriptCompletionVisible && (CheckCollisionPointRec(mouse, scriptCompletionBounds) ||
            CheckCollisionPointRec(mouse, scriptCompletionDetailBounds))) &&
        mouse.y >= (float)EDITOR_CONTENT_TOP && mouse.x >= leftSlotWidth() && mouse.x < GetScreenWidth() - rightSlotWidth())
    {
        int lineHeight = scriptFontSize + 6;
        int targetLine = max(0, static_cast<int>((mouse.y - (float)(EDITOR_CONTENT_TOP + 10) + scriptScrollY) / lineHeight));
        int line = 0;
        int lineStart = 0;
        int lineEnd = static_cast<int>(source.size());
        for (int i = 0; i <= static_cast<int>(source.size()); ++i)
        {
            if (i == static_cast<int>(source.size()) || source[i] == '\n')
            {
                if (line == targetLine)
                {
                    lineEnd = i;
                    break;
                }
                line++;
                lineStart = i + 1;
            }
        }

        int targetCursor = lineStart;
        for (int i = lineStart; i < lineEnd; ++i)
        {
            string character = source.substr(lineStart, i - lineStart + 1);
            int characterRight = leftSlotWidth() + 68 - static_cast<int>(scriptScrollX) + measureScriptText(character);
            if (mouse.x < characterRight)
            {
                targetCursor = i;
                break;
            }
            targetCursor = i + 1;
        }

        scriptCursor = targetCursor;
        scriptSelectionStart = targetCursor;
        scriptSelectionEnd = targetCursor;
        scriptSelecting = true;
        scriptCaretResetTime = now;
    }

    if (scriptSelecting && IsMouseButtonDown(MOUSE_BUTTON_LEFT))
    {
        int targetCursor = scriptCursor;
        int lineHeight = scriptFontSize + 6;
        int targetLine = max(0, static_cast<int>((mouse.y - (float)(EDITOR_CONTENT_TOP + 10) + scriptScrollY) / lineHeight));
        int line = 0;
        int lineStart = 0;
        for (int i = 0; i <= static_cast<int>(source.size()); ++i)
        {
            if (i == static_cast<int>(source.size()) || source[i] == '\n')
            {
                if (line == targetLine)
                {
                    int lineEnd = i;
                    targetCursor = lineStart;
                    for (int j = lineStart; j < lineEnd; ++j)
                    {
                        string character = source.substr(lineStart, j - lineStart + 1);
                        if (mouse.x < leftSlotWidth() + 68 - static_cast<int>(scriptScrollX) + measureScriptText(character))
                        {
                            targetCursor = j;
                            break;
                        }
                        targetCursor = j + 1;
                    }
                    break;
                }
                line++;
                lineStart = i + 1;
            }
        }
        scriptCursor = targetCursor;
        scriptSelectionEnd = targetCursor;
    }
    if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
        scriptSelecting = false;

    bool ctrl = IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL);
    bool shift = IsKeyDown(KEY_LEFT_SHIFT) || IsKeyDown(KEY_RIGHT_SHIFT);
    // Script window: local undo/redo only (project undo is for non-script focus)
    if (ctrl && (IsKeyPressed(KEY_Z) || IsKeyPressed(KEY_Y)))
    {
        bool redo = IsKeyPressed(KEY_Y) || shift;
        vector<ScriptEditSnapshot>& from = redo ? scriptRedoHistory : scriptUndoHistory;
        vector<ScriptEditSnapshot>& to = redo ? scriptUndoHistory : scriptRedoHistory;
        if (!from.empty())
        {
            to.push_back({ activeScript, source, scriptCursor, scriptSelectionStart, scriptSelectionEnd });
            ScriptEditSnapshot snapshot = from.back();
            from.pop_back();
            if (snapshot.script == activeScript)
            {
                source = snapshot.source;
                scriptCursor = snapshot.cursor;
                scriptSelectionStart = snapshot.selectionStart;
                scriptSelectionEnd = snapshot.selectionEnd;
                scriptCaretResetTime = now;
            }
        }
        updateScriptCompletions(source);
        return;
    }
    if (ctrl && IsKeyPressed(KEY_A))
    {
        scriptSelectionStart = 0;
        scriptSelectionEnd = static_cast<int>(source.size());
        scriptCursor = scriptSelectionEnd;
    }
    if (ctrl && IsKeyPressed(KEY_C) && hasSelection())
    {
        int low = min(scriptSelectionStart, scriptSelectionEnd);
        int high = max(scriptSelectionStart, scriptSelectionEnd);
        SetClipboardText(source.substr(low, high - low).c_str());
    }
    if (ctrl && IsKeyPressed(KEY_X) && hasSelection())
    {
        int low = min(scriptSelectionStart, scriptSelectionEnd);
        int high = max(scriptSelectionStart, scriptSelectionEnd);
        SetClipboardText(source.substr(low, high - low).c_str());
        saveScriptUndo();
        deleteSelection();
    }
    if (ctrl && IsKeyPressed(KEY_V))
    {
        const char* clipboard = GetClipboardText();
        if (clipboard != nullptr)
        {
            string cleaned = sanitizeScriptClipboardText(clipboard);
            if (!cleaned.empty())
                insertText(cleaned.c_str());
        }
    }

    static double backspaceRepeat = 0.0;
    static double deleteRepeat = 0.0;
    static double leftRepeat = 0.0;
    static double rightRepeat = 0.0;
    if (repeatKey(KEY_BACKSPACE, backspaceRepeat))
    {
        saveScriptUndo();
        if (!deleteSelection() && scriptCursor > 0)
        {
            // If the four characters before the cursor are spaces (a Tab indent),
            // remove all four at once; otherwise delete a single character.
            int removeCount = 1;
            if (scriptCursor >= 4)
            {
                bool fourSpaces = true;
                for (int i = 0; i < 4; ++i)
                {
                    if (source[scriptCursor - 1 - i] != ' ')
                    {
                        fourSpaces = false;
                        break;
                    }
                }
                if (fourSpaces)
                    removeCount = 4;
            }
            source.erase(scriptCursor - removeCount, removeCount);
            scriptCursor -= removeCount;
        }
        scriptCaretResetTime = now;
    }
    if (repeatKey(KEY_DELETE, deleteRepeat))
    {
        saveScriptUndo();
        if (!deleteSelection() && scriptCursor < static_cast<int>(source.size()))
            source.erase(scriptCursor, 1);
        scriptCaretResetTime = now;
    }
    auto moveWord = [&](int dir) -> int
    {
        int c = scriptCursor;
        int n = static_cast<int>(source.size());
        if (dir < 0)
        {
            if (c > 0) c--;
            while (c > 0 && isspace(static_cast<unsigned char>(source[c]))) c--;
            while (c > 0 && !isspace(static_cast<unsigned char>(source[c - 1])) &&
                   (isalnum(static_cast<unsigned char>(source[c - 1])) || source[c - 1] == '_'))
                c--;
        }
        else
        {
            while (c < n && !isspace(static_cast<unsigned char>(source[c])) &&
                   (isalnum(static_cast<unsigned char>(source[c])) || source[c] == '_'))
                c++;
            while (c < n && isspace(static_cast<unsigned char>(source[c]))) c++;
        }
        return c;
    };
    auto lineBounds = [&](int pos, int& start, int& end)
    {
        start = pos;
        while (start > 0 && source[start - 1] != '\n') start--;
        end = pos;
        while (end < static_cast<int>(source.size()) && source[end] != '\n') end++;
    };

    auto applyCursorMove = [&](int newCursor)
    {
        newCursor = std::clamp(newCursor, 0, static_cast<int>(source.size()));
        if (shift)
        {
            if (!hasSelection())
                scriptSelectionStart = scriptCursor;
            scriptSelectionEnd = newCursor;
            scriptCursor = newCursor;
        }
        else
        {
            scriptCursor = newCursor;
            clearSelection();
        }
        scriptCaretResetTime = now;
    };

    if (repeatKey(KEY_LEFT, leftRepeat))
    {
        if (ctrl)
            applyCursorMove(moveWord(-1));
        else if (hasSelection() && !shift)
            applyCursorMove(min(scriptSelectionStart, scriptSelectionEnd));
        else
            applyCursorMove(scriptCursor - 1);
    }
    if (repeatKey(KEY_RIGHT, rightRepeat))
    {
        if (ctrl)
            applyCursorMove(moveWord(1));
        else if (hasSelection() && !shift)
            applyCursorMove(max(scriptSelectionStart, scriptSelectionEnd));
        else
            applyCursorMove(scriptCursor + 1);
    }
    static double upRepeat = 0.0;
    static double downRepeat = 0.0;
    if (repeatKey(KEY_UP, upRepeat) && !scriptCompletionVisible)
    {
        int ls, le;
        lineBounds(scriptCursor, ls, le);
        int col = scriptCursor - ls;
        if (ls == 0)
            applyCursorMove(0);
        else
        {
            int pls = ls - 1;
            while (pls > 0 && source[pls - 1] != '\n') pls--;
            int ple = ls - 1;
            applyCursorMove(min(pls + col, ple));
        }
    }
    if (repeatKey(KEY_DOWN, downRepeat) && !scriptCompletionVisible)
    {
        int ls, le;
        lineBounds(scriptCursor, ls, le);
        int col = scriptCursor - ls;
        if (le >= static_cast<int>(source.size()))
            applyCursorMove(static_cast<int>(source.size()));
        else
        {
            int nls = le + 1;
            int nle = nls;
            while (nle < static_cast<int>(source.size()) && source[nle] != '\n') nle++;
            applyCursorMove(min(nls + col, nle));
        }
    }
    if (IsKeyPressed(KEY_HOME))
    {
        int ls, le;
        lineBounds(scriptCursor, ls, le);
        applyCursorMove(ctrl ? 0 : ls);
    }
    if (IsKeyPressed(KEY_END))
    {
        int ls, le;
        lineBounds(scriptCursor, ls, le);
        applyCursorMove(ctrl ? static_cast<int>(source.size()) : le);
    }
    if (IsKeyPressed(KEY_PAGE_UP))
        applyCursorMove(max(0, scriptCursor - 40 * (scriptFontSize + 6)));
    if (IsKeyPressed(KEY_PAGE_DOWN))
        applyCursorMove(min(static_cast<int>(source.size()), scriptCursor + 40));
    // Tab inserts exactly 4 spaces; Shift+Tab outdents 4 spaces when possible.
    if (IsKeyPressed(KEY_TAB) && !ctrl)
    {
        if (shift)
        {
            // Outdent: remove up to 4 leading spaces before the cursor on this line
            int ls = scriptCursor;
            while (ls > 0 && source[ls - 1] != '\n') ls--;
            int spaces = 0;
            while (ls + spaces < scriptCursor && source[ls + spaces] == ' ' && spaces < 4)
                spaces++;
            if (spaces > 0)
            {
                saveScriptUndo();
                source.erase(ls, spaces);
                scriptCursor -= spaces;
                clearSelection();
                scriptCaretResetTime = now;
            }
        }
        else
            insertText("    ");
    }

    if (IsKeyPressed(KEY_ENTER))
    {
        size_t lineStart = source.rfind('\n', scriptCursor == 0 ? 0 : scriptCursor - 1);
        lineStart = lineStart == string::npos ? 0 : lineStart + 1;
        string beforeCursor = source.substr(lineStart, scriptCursor - static_cast<int>(lineStart));
        size_t firstContent = beforeCursor.find_first_not_of(' ');
        string indentation = firstContent == string::npos ? beforeCursor : beforeCursor.substr(0, firstContent);
        string trimmed = beforeCursor.substr(firstContent == string::npos ? 0 : firstContent);
        while (!trimmed.empty() && isspace(static_cast<unsigned char>(trimmed.back())))
            trimmed.pop_back();
        auto endsWith = [](const string& text, const string& suffix)
        {
            return text.size() >= suffix.size() &&
                text.compare(text.size() - suffix.size(), suffix.size(), suffix) == 0;
        };
        bool opensBlock = endsWith(trimmed, "then") || endsWith(trimmed, "do") ||
            endsWith(trimmed, "function") || trimmed == "repeat" || endsWith(trimmed, "else") || endsWith(trimmed, "elseif");
        insertText("\n" + indentation + (opensBlock ? "    " : ""));
    }

    int codepoint = GetCharPressed();
    while (codepoint > 0)
    {
        if (!ctrl && codepoint >= 32 && codepoint <= 126)
            insertText(string(1, static_cast<char>(codepoint)));
        codepoint = GetCharPressed();
    }

    updateScriptCompletions(source);
}

void handleHelpInput()
{
    if (IsKeyPressed(KEY_ESCAPE))
        helpOpen = false;

    if (!helpOpen || !IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
        return;

    int boardWidth = 500;
    int boardHeight = 360;
    int boardX = (GetScreenWidth() - boardWidth) / 2;
    int boardY = (GetScreenHeight() - boardHeight) / 2;

    Rectangle closeButton = {
        (float)(boardX + boardWidth - 42),
        (float)(boardY + 10),
        30.0f,
        30.0f
    };

    if (CheckCollisionPointRec(GetMousePosition(), closeButton))
        helpOpen = false;
}

void renderHelpBoard()
{
    if (!helpOpen)
        return;

    int boardWidth = 500;
    int boardHeight = 360;
    int boardX = (GetScreenWidth() - boardWidth) / 2;
    int boardY = (GetScreenHeight() - boardHeight) / 2;

    DrawRectangle(0, 0, GetScreenWidth(), GetScreenHeight(), (Color){ 0, 0, 0, 100 });
    DrawRectangle(boardX, boardY, boardWidth, boardHeight, RAYWHITE);
    DrawRectangleLines(boardX, boardY, boardWidth, boardHeight, DARKGRAY);

    DrawText("Help", boardX + 20, boardY + 18, 24, BLACK);
    DrawText("X", boardX + boardWidth - 32, boardY + 16, 24, BLACK);

    const char* keybinds[] = {
        "W A S D    Move camera",
        "Q / E      Move camera down / up",
        "RMB        Rotate camera",
        "Shift      Move camera faster",
        "2          Move gizmo",
        "3          Scale gizmo",
        "4          Rotate gizmo",
        "Ctrl+I     Insert object",
        "Ctrl       Center scale",
        "Alt        Resize from one side",
        "Esc        Close help / menus"
    };

    for (int i = 0; i < 11; i++)
        DrawText(keybinds[i], boardX + 30, boardY + 70 + i * 24, 18, BLACK);
}

// ============================================================
// Insert Object menu (Ctrl+I)
// ============================================================

struct InsertMenuEntry
{
    const char* name;
    // 0=Part 1=Script 2=LocalScript 3=ModuleScript 4=Model 5=Folder
    int kind;
};

static const InsertMenuEntry INSERT_MENU_ENTRIES[] = {
    { "Part", 0 },
    { "Script", 1 },
    { "LocalScript", 2 },
    { "ModuleScript", 3 },
    { "Model", 4 },
    { "Folder", 5 },
    { "Sound", 6 },
    { "Texture", 7 },
    { "WeldConstraint", 8 },
    { "Motor6D", 9 },
    { "BindableEvent", 10 },
    { "BindableFunction", 11 },
    { "RemoteEvent", 12 },
    { "RemoteFunction", 13 },
    { "Humanoid", 14 },
    { "Camera", 15 },
    // 2D GUI
    { "ScreenGui", 16 },
    { "SurfaceGui", 17 },
    { "BillboardGui", 18 },
    { "Frame", 19 },
    { "ScrollingFrame", 20 },
    { "TextLabel", 21 },
    { "ImageLabel", 22 },
    { "TextButton", 23 },
    { "ImageButton", 24 },
    { "TextBox", 25 },
    { "UICorner", 26 },
    { "UIListLayout", 27 },
    { "UIStroke", 28 },
    { "UIPadding", 29 },
    { "UIGridLayout", 30 },
    { "UIAspectRatioConstraint", 31 },
    { "PointLight", 32 },
    { "SpotLight", 33 },
    { "SurfaceLight", 34 },
    { "MeshPart", 35 }
};
static const int INSERT_MENU_COUNT = 36;

Texture2D getInsertMenuIcon(int kind)
{
    if (explorerIcons == nullptr)
        return { 0 };
    switch (kind)
    {
    case 0: return explorerIcons->partIcon;
    case 35: return explorerIcons->meshPartIcon.id != 0
        ? explorerIcons->meshPartIcon : explorerIcons->partIcon;
    case 1: return explorerIcons->scriptIcon;
    case 2: return explorerIcons->localScriptIcon;
    case 3: return explorerIcons->moduleScriptIcon;
    case 4: return explorerIcons->modelIcon;
    case 5: return explorerIcons->folderIcon;
    case 6: return explorerIcons->soundIcon;
    case 7: return explorerIcons->textureIcon;
    case 8: return explorerIcons->weldConstraintIcon;
    case 9: return explorerIcons->motor6DConstraintIcon;
    case 10: return explorerIcons->bindableEventIcon;
    case 11: return explorerIcons->bindableFunctionIcon;
    case 12: return explorerIcons->remoteEventIcon;
    case 13: return explorerIcons->remoteFunctionIcon;
    case 14: return explorerIcons->humanoidIcon;
    case 15: return explorerIcons->cameraIcon;
    case 16: return explorerIcons->screenGuiIcon.id ? explorerIcons->screenGuiIcon : explorerIcons->guiIcon;
    case 17: return explorerIcons->surfaceGuiIcon.id ? explorerIcons->surfaceGuiIcon : explorerIcons->guiIcon;
    case 18: return explorerIcons->billboardGuiIcon.id ? explorerIcons->billboardGuiIcon : explorerIcons->guiIcon;
    case 19: return explorerIcons->frameIcon.id ? explorerIcons->frameIcon : explorerIcons->guiIcon;
    case 20: return explorerIcons->scrollingFrameIcon.id ? explorerIcons->scrollingFrameIcon : explorerIcons->guiIcon;
    case 21: return explorerIcons->textLabelIcon.id ? explorerIcons->textLabelIcon : explorerIcons->guiIcon;
    case 22: return explorerIcons->imageLabelIcon.id ? explorerIcons->imageLabelIcon : explorerIcons->guiIcon;
    case 23: return explorerIcons->textButtonIcon.id ? explorerIcons->textButtonIcon : explorerIcons->guiIcon;
    case 24: return explorerIcons->imageButtonIcon.id ? explorerIcons->imageButtonIcon : explorerIcons->guiIcon;
    case 25: return explorerIcons->textBoxIcon.id ? explorerIcons->textBoxIcon : explorerIcons->guiIcon;
    case 26: return explorerIcons->uiCornerIcon.id ? explorerIcons->uiCornerIcon : explorerIcons->guiIcon;
    case 27: return explorerIcons->uiListIcon.id ? explorerIcons->uiListIcon : explorerIcons->guiIcon;
    case 28: return explorerIcons->uiStrokeIcon.id ? explorerIcons->uiStrokeIcon : explorerIcons->guiIcon;
    case 29: return explorerIcons->uiAspectIcon.id ? explorerIcons->uiAspectIcon : explorerIcons->guiIcon;
    case 30: return explorerIcons->uiGridIcon.id ? explorerIcons->uiGridIcon : explorerIcons->guiIcon;
    case 31: return explorerIcons->uiAspectIcon.id ? explorerIcons->uiAspectIcon : explorerIcons->guiIcon;
    case 32: return explorerIcons->pointLightIcon.id ? explorerIcons->pointLightIcon : explorerIcons->lightingIcon;
    case 33: return explorerIcons->spotLightIcon.id ? explorerIcons->spotLightIcon : explorerIcons->lightingIcon;
    case 34: return explorerIcons->surfaceLightIcon.id ? explorerIcons->surfaceLightIcon : explorerIcons->lightingIcon;
    default:
        return explorerIcons->folderIcon;
    }
}

string getInsertMenuIconGroup(int kind)
{
    if (kind == 0 || kind == 4 || kind == 8 || kind == 9 || kind == 35)
        return "Geometry";
    if (kind >= 1 && kind <= 3)
        return "Scripts";
    if (kind == 5)
        return "Containers";
    if (kind == 6 || kind == 7)
        return "Assets";
    if (kind >= 16 && kind <= 31)
        return "UI";
    return "Services";
}

string getInsertMenuIconKey(int kind)
{
    static const char* keys[] = {
        "Part", "Script", "LocalScript", "ModuleScript", "Model", "Folder", "Sound", "Texture",
        "WeldConstraint", "Motor6D", "BindableEvent", "BindableFunction", "RemoteEvent", "RemoteFunction",
        "Humanoid", "Camera", "ScreenGui", "SurfaceGui", "BillboardGui", "Frame", "ScrollingFrame",
        "TextLabel", "ImageLabel", "TextButton", "ImageButton", "TextBox", "UICorner", "UIListLayout",
        "UIStroke", "UIPadding", "UIGridLayout", "UIAspectRatioConstraint", "PointLight", "SpotLight", "SurfaceLight",
        "MeshPart"
    };
    if (kind >= 0 && kind < (int)(sizeof(keys) / sizeof(keys[0])))
        return keys[kind];
    return "Folder";
}

Instance* createInsertedInstance(int kind)
{
    switch (kind)
    {
    case 0:
    {
        Part* p = new Part();
        p->name = "Part";
        p->type = PartType::Block;
        p->size = { 4.0f, 1.0f, 2.0f };
        p->cframe.position = { 0.0f, 0.5f, 0.0f };
        p->color = { 163, 162, 165, 255 };
        p->anchored = true;
        return p;
    }
    case 35:
    {
        Part* p = new Part();
        p->name = "MeshPart";
        p->type = PartType::Block;
        p->isMeshPart = true;
        p->meshId.clear();
        p->size = { 4.0f, 1.0f, 2.0f };
        p->cframe.position = { 0.0f, 0.5f, 0.0f };
        p->color = { 163, 162, 165, 255 };
        p->anchored = true;
        return p;
    }
    case 1:
    {
        Script* s = new Script();
        s->name = "Script";
        s->type = ScriptType::Script;
        return s;
    }
    case 2:
    {
        Script* s = new Script();
        s->name = "LocalScript";
        s->type = ScriptType::LocalScript;
        return s;
    }
    case 3:
    {
        Script* s = new Script();
        s->name = "ModuleScript";
        s->type = ScriptType::ModuleScript;
        s->source = "local Module = {}\n\nreturn Module\n";
        return s;
    }
    case 4:
    {
        Model_Instance* m = new Model_Instance();
        m->name = "Model";
        return m;
    }
    case 5:
    {
        Folder* f = new Folder();
        f->name = "Folder";
        return f;
    }
    case 6:
    {
        SoundInstance* s = new SoundInstance();
        s->name = "Sound";
        s->soundId = "";
        return s;
    }
    case 7:
    {
        TextureInstance* t = new TextureInstance();
        t->name = "Texture";
        t->texture = "";
        return t;
    }
    case 8:
    {
        WeldConstraint* w = new WeldConstraint();
        w->name = "WeldConstraint";
        return w;
    }
    case 9:
    {
        Motor6DConstraint* m = new Motor6DConstraint();
        m->name = "Motor6D";
        return m;
    }
    case 10:
    {
        BindableEventInstance* event = new BindableEventInstance();
        event->name = "BindableEvent";
        return event;
    }
    case 11:
    {
        BindableFunctionInstance* function = new BindableFunctionInstance();
        function->name = "BindableFunction";
        return function;
    }
    case 12:
    {
        RemoteEventInstance* event = new RemoteEventInstance();
        event->name = "RemoteEvent";
        return event;
    }
    case 13:
    {
        RemoteFunctionInstance* function = new RemoteFunctionInstance();
        function->name = "RemoteFunction";
        return function;
    }
    case 14:
    {
        HumanoidInstance* humanoid = new HumanoidInstance();
        humanoid->name = "Humanoid";
        return humanoid;
    }
    case 15:
    {
        CameraInstance* cameraInstance = new CameraInstance();
        cameraInstance->name = "Camera";
        return cameraInstance;
    }
    case 16: case 17: case 18:
    {
        auto* lc = new LayerCollectorInstance();
        if (kind == 17) { lc->layerType = InstanceType::SurfaceGui; lc->name = "SurfaceGui"; }
        else if (kind == 18) { lc->layerType = InstanceType::BillboardGui; lc->name = "BillboardGui"; }
        else { lc->layerType = InstanceType::ScreenGui; lc->name = "ScreenGui"; }
        return lc;
    }
    case 19: case 20: case 21: case 22: case 23: case 24: case 25:
    {
        auto* g = new GuiObjectInstance();
        if (kind == 20) { g->guiType = InstanceType::ScrollingFrame; g->name = "ScrollingFrame"; g->size = { {0,200},{0,150} }; }
        else if (kind == 21) { g->guiType = InstanceType::TextLabel; g->name = "TextLabel"; g->text = "Label"; g->backgroundTransparency = 1.0f; }
        else if (kind == 22) { g->guiType = InstanceType::ImageLabel; g->name = "ImageLabel"; g->backgroundTransparency = 1.0f; }
        else if (kind == 23) { g->guiType = InstanceType::TextButton; g->name = "TextButton"; g->text = "Button"; }
        else if (kind == 24) { g->guiType = InstanceType::ImageButton; g->name = "ImageButton"; g->backgroundTransparency = 1.0f; }
        else if (kind == 25) { g->guiType = InstanceType::TextBox; g->name = "TextBox"; g->placeholderText = "Text here"; }
        else { g->guiType = InstanceType::Frame; g->name = "Frame"; }
        return g;
    }
    case 26: case 27: case 28: case 29: case 30: case 31:
    {
        auto* m = new UIModifierInstance();
        if (kind == 27) { m->modType = InstanceType::UIListLayout; m->name = "UIListLayout"; }
        else if (kind == 28) { m->modType = InstanceType::UIStroke; m->name = "UIStroke"; }
        else if (kind == 29) { m->modType = InstanceType::UIPadding; m->name = "UIPadding"; }
        else if (kind == 30) { m->modType = InstanceType::UIGridLayout; m->name = "UIGridLayout"; }
        else if (kind == 31) { m->modType = InstanceType::UIAspectRatioConstraint; m->name = "UIAspectRatioConstraint"; }
        else { m->modType = InstanceType::UICorner; m->name = "UICorner"; }
        return m;
    }
    default:
            case 32:
    {
        auto* L = new PointLightInstance();
        L->name = "PointLight";
        return L;
    }
    case 33:
    {
        auto* L = new SpotLightInstance();
        L->name = "SpotLight";
        return L;
    }
    case 34:
    {
        auto* L = new SurfaceLightInstance();
        L->name = "SurfaceLight";
        return L;
    }
return nullptr;
    }
}

void insertInstanceFromMenu(int kind)
{
    Instance* created = createInsertedInstance(kind);
    if (created == nullptr)
        return;

    Instance* parent = getExplorerPasteTarget(true);
    if (parent == nullptr)
        parent = &workspace;

    addInstanceToParent(parent, created);
    selectedInstances.clear();
    selectedInstances.push_back(created);
    projectDirty = true;
    insertMenuOpen = false;
    insertMenuHover = -1;
}

void handleInsertMenuInput()
{
    if (!insertMenuOpen)
        return;

    if (IsKeyPressed(KEY_ESCAPE))
    {
        insertMenuOpen = false;
        insertMenuHover = -1;
        return;
    }

    Vector2 mouse = GetMousePosition();
    int menuW = 600;
    int rowH = 40;
    int headerH = 52;
    int footerH = 48;
    int maxBodyH = max(160, GetScreenHeight() - 160);
    int contentH = ((INSERT_MENU_COUNT + 1) / 2) * rowH;
    int bodyH = min(contentH, maxBodyH);
    int menuH = headerH + bodyH + footerH;
    if (floatingInsertPos.x < 0)
        floatingInsertPos = { (float)((GetScreenWidth() - menuW) / 2), (float)((GetScreenHeight() - menuH) / 2) };
    int menuX = (int)floatingInsertPos.x;
    int menuY = (int)floatingInsertPos.y;
    float maxScroll = max(0.0f, (float)(contentH - bodyH));
    insertMenuScrollY = std::clamp(insertMenuScrollY, 0.0f, maxScroll);

    Rectangle menuRect = { (float)menuX, (float)menuY, (float)menuW, (float)menuH };
    Rectangle bodyRect = { (float)menuX + 8, (float)menuY + headerH, (float)menuW - 24, (float)bodyH };
    Rectangle cancelRect = {
        (float)(menuX + menuW - 110),
        (float)(menuY + menuH - 40),
        96.0f,
        32.0f
    };
    Rectangle closeRect = { (float)menuX + menuW - 42, (float)menuY + 12, 24.0f, 24.0f };

    if (CheckCollisionPointRec(mouse, bodyRect))
    {
        float wheel = GetMouseWheelMove();
        if (wheel != 0.0f)
            insertMenuScrollY = std::clamp(insertMenuScrollY - wheel * 40.0f, 0.0f, maxScroll);
    }

    insertMenuHover = -1;
    if (CheckCollisionPointRec(mouse, bodyRect))
    {
        float localY = mouse.y - bodyRect.y + insertMenuScrollY;
        int row = (int)(localY / rowH);
        int column = mouse.x < menuX + menuW / 2 ? 0 : 1;
        int i = row * 2 + column;
        if (i >= 0 && i < INSERT_MENU_COUNT)
            insertMenuHover = i;
    }

    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
    {
        if (CheckCollisionPointRec(mouse, closeRect))
        {
            insertMenuOpen = false;
            insertMenuHover = -1;
            return;
        }
        if (CheckCollisionPointRec(mouse, cancelRect) ||
            !CheckCollisionPointRec(mouse, menuRect))
        {
            insertMenuOpen = false;
            insertMenuHover = -1;
            return;
        }
        if (insertMenuHover >= 0 && insertMenuHover < INSERT_MENU_COUNT)
            insertInstanceFromMenu(INSERT_MENU_ENTRIES[insertMenuHover].kind);
    }
}

void renderInsertMenu()
{
    if (!insertMenuOpen)
        return;

    int menuW = 600;
    int rowH = 40;
    int headerH = 52;
    int footerH = 48;
    int maxBodyH = max(160, GetScreenHeight() - 160);
    int contentH = ((INSERT_MENU_COUNT + 1) / 2) * rowH;
    int bodyH = min(contentH, maxBodyH);
    int menuH = headerH + bodyH + footerH;
    if (floatingInsertPos.x < 0)
        floatingInsertPos = { (float)((GetScreenWidth() - menuW) / 2), (float)((GetScreenHeight() - menuH) / 2) };
    int menuX = (int)floatingInsertPos.x;
    int menuY = (int)floatingInsertPos.y;
    float maxScroll = max(0.0f, (float)(contentH - bodyH));
    insertMenuScrollY = std::clamp(insertMenuScrollY, 0.0f, maxScroll);
    Vector2 mouse = GetMousePosition();
    Rectangle titleBar = { (float)menuX, (float)menuY, (float)menuW, (float)headerH };
    Rectangle closeRect = { (float)menuX + menuW - 42, (float)menuY + 12, 24.0f, 24.0f };
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, titleBar))
    {
        if (CheckCollisionPointRec(mouse, closeRect))
        {
            insertMenuOpen = false;
            insertMenuHover = -1;
            return;
        }
        floatingInsertDrag = true;
        floatingDragOffset = { mouse.x - floatingInsertPos.x, mouse.y - floatingInsertPos.y };
    }
    if (floatingInsertDrag)
    {
        if (IsMouseButtonDown(MOUSE_BUTTON_LEFT))
        {
            floatingInsertPos.x = mouse.x - floatingDragOffset.x;
            floatingInsertPos.y = mouse.y - floatingDragOffset.y;
            floatingInsertPos.x = Clamp(floatingInsertPos.x, 0, (float)GetScreenWidth() - menuW);
            floatingInsertPos.y = Clamp(floatingInsertPos.y, (float)MENU_BAR_HEIGHT, (float)GetScreenHeight() - menuH);
            menuX = (int)floatingInsertPos.x;
            menuY = (int)floatingInsertPos.y;
        }
        else
            floatingInsertDrag = false;
    }

    // No full-screen dim — floating insert panel
    EditorThemeColors theme = getEditorThemeColors();
    DrawRectangleRounded({ (float)menuX, (float)menuY, (float)menuW, (float)menuH }, 0.025f, 8, theme.panel);
    DrawRectangleRoundedLines({ (float)menuX, (float)menuY, (float)menuW, (float)menuH }, 0.025f, 8, theme.accent);
    DrawRectangleRounded({ (float)menuX + 1, (float)menuY + 1, (float)menuW - 2, (float)headerH }, 0.12f, 8, theme.header);
    DrawText("Insert Object", menuX + 16, menuY + 14, 22, theme.text);
    DrawText("Ctrl+I", menuX + menuW - 112, menuY + 18, 14, theme.muted);
    DrawRectangleRounded(closeRect, 0.2f, 6,
        CheckCollisionPointRec(mouse, closeRect) ? theme.accentHover : theme.surface);
    DrawText("x", (int)closeRect.x + 8, (int)closeRect.y + 4, 15, theme.text);

    BeginScissorMode(menuX + 8, menuY + headerH, menuW - 24, bodyH);
    for (int i = 0; i < INSERT_MENU_COUNT; ++i)
    {
        int rowIndex = i / 2;
        int column = i % 2;
        float y = (float)(menuY + headerH + rowIndex * rowH) - insertMenuScrollY;
        Rectangle row = {
            (float)(menuX + 12 + column * 288),
            y,
            276.0f,
            (float)(rowH - 4)
        };
        bool hover = (i == insertMenuHover);
        DrawRectangleRounded(row, 0.14f, 6, hover ? theme.selected : theme.surface);

        Texture2D icon = getInsertMenuIcon(INSERT_MENU_ENTRIES[i].kind);
        if (icon.id != 0)
            drawEditorIcon(icon, row.x + 8, row.y + 6, 24.0f, 24.0f,
                getStudioInstanceIconTint(getInsertMenuIconKey(i), getInsertMenuIconGroup(i)));
        DrawText(INSERT_MENU_ENTRIES[i].name, (int)row.x + 44, (int)row.y + 10, 18, theme.text);
    }
    EndScissorMode();

    // Scrollbar
    if (maxScroll > 0.5f)
    {
        float trackX = (float)(menuX + menuW - 14);
        float trackY = (float)(menuY + headerH);
        float trackH = (float)bodyH;
        DrawRectangle((int)trackX, (int)trackY, 8, (int)trackH, theme.canvas);
        float thumbH = max(24.0f, trackH * trackH / (trackH + maxScroll));
        float thumbY = trackY + (insertMenuScrollY / maxScroll) * (trackH - thumbH);
        DrawRectangle((int)trackX, (int)thumbY, 8, (int)thumbH, theme.muted);
    }

    Rectangle cancelRect = {
        (float)(menuX + menuW - 110),
        (float)(menuY + menuH - 40),
        96.0f,
        32.0f
    };
    bool cancelHover = CheckCollisionPointRec(mouse, cancelRect);
    DrawRectangleRec(cancelRect, cancelHover ? theme.accentHover : theme.surface);
    DrawRectangleLinesEx(cancelRect, 1.0f, theme.border);
    DrawText("Cancel", (int)cancelRect.x + 22, (int)cancelRect.y + 7, 16, theme.text);
}

string escapeLuauString(const string& value)
{
    string escaped;
    for (char character : value)
    {
        if (character == '\\') escaped += "\\\\";
        else if (character == '"') escaped += "\\\"";
        else if (character == '\n') escaped += "\\n";
        else if (character == '\r') escaped += "\\r";
        else escaped += character;
    }
    return escaped;
}

string getRuntimeClassName(const Instance* instance)
{
    if (instance == nullptr) return "Instance";
    switch (instance->getType())
    {
    case InstanceType::Part:
        return static_cast<const Part*>(instance)->isMeshPart ? "MeshPart" : "Part";
    case InstanceType::Script:
    {
        const Script* s = static_cast<const Script*>(instance);
        return scriptTypeName(s->type);
    }
    case InstanceType::Model: return "Model";
    case InstanceType::Folder: return "Folder";
    case InstanceType::Service: return "Service";
    case InstanceType::Sound: return "Sound";
    case InstanceType::Texture: return "Texture";
    case InstanceType::Blur: return "Blur";
    case InstanceType::ColorCorrection: return "ColorCorrection";
    case InstanceType::SunLight: return "SunLight";
    case InstanceType::PointLight: return "PointLight";
    case InstanceType::SpotLight: return "SpotLight";
    case InstanceType::SurfaceLight: return "SurfaceLight";
    case InstanceType::Bloom: return "Bloom";
    case InstanceType::Player: return "Player";
    case InstanceType::BindableEvent: return "BindableEvent";
    case InstanceType::BindableFunction: return "BindableFunction";
    case InstanceType::RemoteEvent: return "RemoteEvent";
    case InstanceType::RemoteFunction: return "RemoteFunction";
    case InstanceType::Humanoid: return "Humanoid";
    case InstanceType::Camera: return "Camera";
    case InstanceType::ScreenGui: return "ScreenGui";
    case InstanceType::SurfaceGui: return "SurfaceGui";
    case InstanceType::BillboardGui: return "BillboardGui";
    case InstanceType::Frame: return "Frame";
    case InstanceType::ScrollingFrame: return "ScrollingFrame";
    case InstanceType::TextLabel: return "TextLabel";
    case InstanceType::ImageLabel: return "ImageLabel";
    case InstanceType::TextButton: return "TextButton";
    case InstanceType::ImageButton: return "ImageButton";
    case InstanceType::TextBox: return "TextBox";
    case InstanceType::UICorner: return "UICorner";
    case InstanceType::UIListLayout: return "UIListLayout";
    case InstanceType::UIStroke: return "UIStroke";
    case InstanceType::UIPadding: return "UIPadding";
    case InstanceType::UIGridLayout: return "UIGridLayout";
    case InstanceType::UIAspectRatioConstraint: return "UIAspectRatioConstraint";
    }
    return "Instance";
}

void appendRuntimeInstanceDefinition(string& definitions, const Instance* instance,
    const string& path, const string& variableName, int& nextId)
{
    if (instance != nullptr)
    {
        runtimePathToInstance.emplace(path, const_cast<Instance*>(instance));
        if (path.rfind("game/", 0) == 0)
            runtimePathToInstance.emplace(path.substr(5), const_cast<Instance*>(instance));
    }

    definitions += "local " + variableName + " = __buildingToolInstance(\"" +
        escapeLuauString(instance->name) + "\", \"" + escapeLuauString(path) +
        "\", \"" + getRuntimeClassName(instance) + "\")\n";

    // Seed real property values so scripts don't index nil for existing data
    if (instance->getType() == InstanceType::Model)
    {
        const Model_Instance* model = static_cast<const Model_Instance*>(instance);
        definitions += "__buildingToolSeed(" + variableName + ", { Scale = " +
            to_string(model->scale) + " })\n";
    }
    else if (instance->getType() == InstanceType::Part)
    {
        const Part* part = static_cast<const Part*>(instance);
        definitions += "__buildingToolSeed(" + variableName + ", {\n";
        definitions += "  Position = Vector3.new(" + to_string(part->cframe.position.x) + ", " +
            to_string(part->cframe.position.y) + ", " + to_string(part->cframe.position.z) + "),\n";
        definitions += "  Orientation = Vector3.new(" + to_string(part->cframe.rotation.x) + ", " +
            to_string(part->cframe.rotation.y) + ", " + to_string(part->cframe.rotation.z) + "),\n";
        definitions += "  Size = Vector3.new(" + to_string(part->size.x) + ", " +
            to_string(part->size.y) + ", " + to_string(part->size.z) + "),\n";
        definitions += "  Color = Color3.fromRGB(" + to_string(part->color.r) + ", " +
            to_string(part->color.g) + ", " + to_string(part->color.b) + "),\n";
        definitions += "  Anchored = " + string(part->anchored ? "true" : "false") + ",\n";
        definitions += "  AdvancedPhysics = " + string(part->advancedPhysics ? "true" : "false") + ",\n";
        definitions += "  Density = " + to_string(part->density) + ",\n";
        definitions += "  Friction = " + to_string(part->friction) + ",\n";
        definitions += "  CanCollide = " + string(part->canCollide ? "true" : "false") + ",\n";
        definitions += "  Transparency = " + to_string(part->transparency) + ",\n";
        definitions += "  Reflectance = " + to_string(part->reflectance) + ",\n";
        definitions += "  CastShadow = " + string(part->castShadow ? "true" : "false") + ",\n";
        definitions += "  PivotOffset = Vector3.new(" + to_string(part->pivotOffset.x) + ", " +
            to_string(part->pivotOffset.y) + ", " + to_string(part->pivotOffset.z) + "),\n";
        definitions += "  Truss = " + string(part->truss ? "true" : "false") + ",\n";
        if (part->isMeshPart)
        {
            definitions += "  MeshId = \"" + escapeLuauString(part->meshId) + "\",\n";
            definitions += "  TextureId = \"" + escapeLuauString(part->textureId) + "\",\n";
            definitions += "  CollisionFidelity = \"" +
                collisionFidelityName(part->collisionFidelity) + "\",\n";
        }
        else
            definitions += "  PartType = \"" + partTypeName(part->type) + "\",\n";
        definitions += "})\n";
    }
    else if (instance->getType() == InstanceType::PointLight)
    {
        const auto* light = static_cast<const PointLightInstance*>(instance);
        definitions += "__buildingToolSeed(" + variableName + ", { Enabled = " +
            string(light->enabled ? "true" : "false") + ", Shadows = " +
            string(light->shadows ? "true" : "false") + ", Brightness = " +
            to_string(light->brightness) + ", Range = " + to_string(light->range) +
            ", Color = Color3.fromRGB(" + to_string(light->color.r) + ", " +
            to_string(light->color.g) + ", " + to_string(light->color.b) + ") })\n";
    }
    else if (instance->getType() == InstanceType::SpotLight)
    {
        const auto* light = static_cast<const SpotLightInstance*>(instance);
        definitions += "__buildingToolSeed(" + variableName + ", { Enabled = " +
            string(light->enabled ? "true" : "false") + ", Shadows = " +
            string(light->shadows ? "true" : "false") + ", Brightness = " +
            to_string(light->brightness) + ", Range = " + to_string(light->range) +
            ", Angle = " + to_string(light->angle) + ", Face = \"" +
            escapeLuauString(light->face) + "\", Color = Color3.fromRGB(" +
            to_string(light->color.r) + ", " + to_string(light->color.g) + ", " +
            to_string(light->color.b) + ") })\n";
    }
    else if (instance->getType() == InstanceType::SurfaceLight)
    {
        const auto* light = static_cast<const SurfaceLightInstance*>(instance);
        definitions += "__buildingToolSeed(" + variableName + ", { Enabled = " +
            string(light->enabled ? "true" : "false") + ", Shadows = " +
            string(light->shadows ? "true" : "false") + ", Brightness = " +
            to_string(light->brightness) + ", Range = " + to_string(light->range) +
            ", Angle = " + to_string(light->angle) + ", Face = \"" +
            escapeLuauString(light->face) + "\", Color = Color3.fromRGB(" +
            to_string(light->color.r) + ", " + to_string(light->color.g) + ", " +
            to_string(light->color.b) + ") })\n";
    }
    else if (instance->getType() == InstanceType::Sound)
    {
        const SoundInstance* s = static_cast<const SoundInstance*>(instance);
        definitions += "__buildingToolSeed(" + variableName + ", {\n";
        definitions += "  SoundId = \"" + escapeLuauString(s->soundId) + "\",\n";
        definitions += "  Volume = " + to_string(s->volume) + ",\n";
        definitions += "  PlaybackSpeed = " + to_string(s->playbackSpeed) + ",\n";
        definitions += "  PlayingSpeed = " + to_string(s->playbackSpeed) + ",\n";
        definitions += "  Looped = " + string(s->looped ? "true" : "false") + ",\n";
        definitions += "  Playing = " + string(s->playing ? "true" : "false") + ",\n";
        definitions += "  TimePosition = " + to_string(s->timePosition) + ",\n";
        definitions += "})\n";
    }
    else if (instance->getType() == InstanceType::Texture)
    {
        const TextureInstance* t = static_cast<const TextureInstance*>(instance);
        definitions += "__buildingToolSeed(" + variableName + ", {\n";
        definitions += "  Texture = \"" + escapeLuauString(t->texture) + "\",\n";
        definitions += "  StudsPerTileU = " + to_string(t->studsPerTileU) + ",\n";
        definitions += "  StudsPerTileV = " + to_string(t->studsPerTileV) + ",\n";
        definitions += "  Face = \"" + escapeLuauString(t->face) + "\",\n";
        definitions += "  Transparency = " + to_string(t->transparency) + ",\n";
        definitions += "})\n";
    }

    for (const Instance* child : instance->children)
    {
        if (child == nullptr)
            continue;
        string childVariable = "__buildingToolObject" + to_string(nextId++);
        appendRuntimeInstanceDefinition(definitions, child, path + "/" + child->name, childVariable, nextId);
        definitions += "__buildingToolAddChild(" + variableName + ", " + childVariable + ")\n";
    }

    if (instance->getType() == InstanceType::Script &&
        static_cast<const Script*>(instance)->type == ScriptType::ModuleScript)
    {
        const Script* module = static_cast<const Script*>(instance);
        if (!module->compiledBytecode.empty())
        {
            definitions += "__buildingToolRegisterModule(" + variableName +
                ", function(...) return __buildingToolRunCompiledModule(\"" +
                module->compiledBytecode + "\") end)\n";
        }
        else
        {
            // When the module does `module.__index = module`, method calls with `:` get `self`.
            definitions += "__buildingToolRegisterModule(" + variableName + ", function(...)\n";
            definitions += "local script = " + variableName + "\n";
            definitions += module->source;
            definitions += "\nend)\n";
        }
    }
    // Map path → proxy so running Scripts/LocalScripts can resolve `script`.
    // Register both slash and dotted forms to avoid path-format mismatches.
    if (instance->getType() == InstanceType::Script)
    {
        definitions += "__buildingToolScriptByPath[\"" + escapeLuauString(path) + "\"] = " + variableName + "\n";
        string dotted = path;
        for (char& c : dotted) if (c == '/') c = '.';
        if (dotted != path)
            definitions += "__buildingToolScriptByPath[\"" + escapeLuauString(dotted) + "\"] = " + variableName + "\n";
        // Also seed Enabled / RunContext on the proxy
        const Script* s = static_cast<const Script*>(instance);
        definitions += "__buildingToolSeed(" + variableName + ", { Enabled = " +
            string(s->enabled ? "true" : "false") + ", RunContext = \"" +
            escapeLuauString(s->runContextName()) + "\" })\n";
    }
}

string buildLuauDefinitions()
{
    string definitions;
    // Static API surface from assets/Headers/luau_api.h (print/warn/task/Vector3/UDim2/Enum/…)
    // so luau_config.json keywords map to real callable code in the runtime.
    definitions += buildingToolLuauStaticPrelude();
    definitions += "\n-- BuildingTool Luau host-injected definitions\n";
    // Keep thin re-wrappers if prelude already defined print/warn (idempotent for older chunks)
    definitions += "local __buildingToolPrint = print\n";
    definitions += "local __buildingToolWarn = warn\n";
    definitions += "local function __buildingToolTrace()\n";
    definitions += "    local source, line = debug.info(2, 'sl')\n";
    definitions += "    return tostring(source) .. ':' .. tostring(line)\n";
    definitions += "end\n";
    definitions += "function print(...) __buildingToolPrint(__buildingToolTrace() .. ':', ...) end\n";
    definitions += "function warn(...) __buildingToolWarn(__buildingToolTrace() .. ':', ...) end\n";
    definitions += "local __buildingToolAssert = assert\n";
    definitions += "function assert(condition, ...)\n";
    definitions += "    if not condition then __buildingToolWarn(__buildingToolTrace() .. ': assertion failed') end\n";
    definitions += "    return __buildingToolAssert(condition, ...)\n";
    definitions += "end\n\n";
    definitions += "local __buildingToolChildren = setmetatable({}, { __mode = 'k' })\n";
    definitions += "local __buildingToolChildOrder = setmetatable({}, { __mode = 'k' })\n";
    definitions += "local __buildingToolValues = setmetatable({}, { __mode = 'k' })\n";
    definitions += "local __buildingToolModules = setmetatable({}, { __mode = 'k' })\n";
    definitions += "local __buildingToolModuleCache = setmetatable({}, { __mode = 'k' })\n";
    definitions += "__buildingToolScriptByPath = {}\n";
    definitions += "script = nil\n"; // default; each running script overwrites with its own instance
    definitions += "function __buildingToolRegisterModule(module, factory) __buildingToolModules[module] = factory end\n";
    definitions += "function require(module)\n";
    definitions += "    if __buildingToolModuleCache[module] ~= nil then return __buildingToolModuleCache[module] end\n";
    definitions += "    local factory = __buildingToolModules[module]\n";
    definitions += "    if factory == nil then error('require expects a ModuleScript') end\n";
    definitions += "    local prevScript = script\n";
    definitions += "    script = module\n";
    definitions += "    local packed = table.pack(factory())\n";
    definitions += "    script = prevScript\n";
    definitions += "    local value = packed.n > 0 and packed[1] or true\n";
    definitions += "    -- If module returns a table and sets module.__index = module, `self` works via `:` calls.\n";
    definitions += "    __buildingToolModuleCache[module] = value\n";
    definitions += "    return value\n";
    definitions += "end\n";
    definitions += "local function __buildingToolEncode(value: any): string\n";
    definitions += "    if type(value) == 'table' then\n";
    definitions += "        if value.X ~= nil and value.Y ~= nil and value.Z ~= nil then\n";
    definitions += "            return string.format('V3:%g,%g,%g', value.X, value.Y, value.Z)\n";
    definitions += "        end\n";
    definitions += "        if value.R ~= nil and value.G ~= nil and value.B ~= nil then\n";
    definitions += "            return string.format('C3:%g,%g,%g', value.R, value.G, value.B)\n";
    definitions += "        end\n";
    definitions += "        if value.Position ~= nil then\n";
    definitions += "            local p = value.Position\n";
    definitions += "            local r = value.Rotation or { X = 0, Y = 0, Z = 0 }\n";
    definitions += "            return string.format('CF:%g,%g,%g,%g,%g,%g', p.X, p.Y, p.Z, r.X or 0, r.Y or 0, r.Z or 0)\n";
    definitions += "        end\n";
    definitions += "    end\n";
    definitions += "    return tostring(value):gsub('[%%|\\\\\\r\\n]', function(character) return '%' .. string.byte(character) .. '%' end)\n";
    definitions += "end\n";
    definitions += "local __buildingToolAddChild\n";
    definitions += "local __buildingToolRemoveChild\n";
    definitions += "local __buildingToolSeed\n";
    definitions += "local function __buildingToolInstance(name: string, path: string, className: string): any\n";
    definitions += "    local values = {\n";
    definitions += "        Name = name, ClassName = className, Parent = nil, __Path = path,\n";
    definitions += "        Position = Vector3.new(0, 0, 0), Orientation = Vector3.new(0, 0, 0),\n";
    definitions += "        Size = Vector3.new(1, 1, 1), Color = Color3.fromRGB(163, 162, 165),\n";
    definitions += "        PartType = 'Block', MeshId = nil, TextureId = nil, CollisionFidelity = 'Default',\n";
    definitions += "        Enabled = true, Shadows = false, Brightness = 1, Range = 8, Angle = 90,\n";
    definitions += "        SoundId = '', Volume = 0.5, PlaybackSpeed = 1, PlayingSpeed = 1,\n";
    definitions += "        Looped = false, Playing = false, TimePosition = 0,\n";
    definitions += "        Texture = '', StudsPerTileU = 2, StudsPerTileV = 2, Face = 'Top',\n";
    definitions += "        CFrame = CFrame.new(0, 0, 0), Anchored = true, CanCollide = true,\n";
    definitions += "        Transparency = 0, Reflectance = 0, CastShadow = true,\n";
    definitions += "        AdvancedPhysics = false, Density = 1, Friction = 0.55,\n";
    definitions += "        PivotOffset = Vector3.new(0, 0, 0),\n";
    definitions += "        Health = 100, MaxHealth = 100, WalkSpeed = 16, JumpPower = 50, HipHeight = 3, Mode = 'Default', Target = nil\n";
    definitions += "    }\n";
    definitions += "    if className == 'SpotLight' or className == 'SurfaceLight' then values.Range = 16; values.Face = 'Front' end\n";
    definitions += "    local object = {}\n";
    definitions += "    __buildingToolChildren[object] = {}\n";
    definitions += "    __buildingToolChildOrder[object] = {}\n";
    definitions += "    __buildingToolValues[object] = values\n";
    definitions += "    local function __btMakeSignal()\n";
    definitions += "      local signal = { _handlers = {} }\n";
    definitions += "      function signal:Connect(fn) table.insert(self._handlers, {fn=fn, once=false}); return {Disconnect=function() end, Connected=true} end\n";
    definitions += "      function signal:Once(fn) table.insert(self._handlers, {fn=fn, once=true}); return {Disconnect=function() end, Connected=true} end\n";
    definitions += "      function signal:Fire(...) local a=table.pack(...) local i=1 while i<=#self._handlers do local h=self._handlers[i] h.fn(table.unpack(a,1,a.n)) if h.once then table.remove(self._handlers,i) else i+=1 end end end\n";
    definitions += "      return signal\n";
    definitions += "    end\n";
    definitions += "    object.Changed = __btMakeSignal()\n";
    definitions += "    object.Touched = __btMakeSignal()\n";
    definitions += "    object.AncestryChanged = __btMakeSignal()\n";
    definitions += "    if className == 'BindableEvent' then\n";
    definitions += "      object.Event = __btMakeSignal()\n";
    definitions += "      function object:Fire(...) self.Event:Fire(...) end\n";
    definitions += "    elseif className == 'RemoteEvent' then\n";
    definitions += "      object.OnServerEvent = __btMakeSignal()\n";
    definitions += "      object.OnClientEvent = __btMakeSignal()\n";
    definitions += "      function object:FireServer(...) self.OnServerEvent:Fire(self, ...) end\n";
    definitions += "      function object:FireClient(player, ...) self.OnClientEvent:Fire(...) end\n";
    definitions += "      function object:FireAllClients(...) self.OnClientEvent:Fire(...) end\n";
    definitions += "    elseif className == 'BindableFunction' then\n";
    definitions += "      object.OnInvoke = nil\n";
    definitions += "      function object:Invoke(...) if self.OnInvoke ~= nil then return self.OnInvoke(...) end return nil end\n";
    definitions += "    elseif className == 'RemoteFunction' then\n";
    definitions += "      object.OnServerInvoke = nil\n";
    definitions += "      object.OnClientInvoke = nil\n";
    definitions += "      function object:InvokeServer(...) if self.OnServerInvoke ~= nil then return self.OnServerInvoke(...) end return nil end\n";
    definitions += "      function object:InvokeClient(player, ...) if self.OnClientInvoke ~= nil then return self.OnClientInvoke(player, ...) end return nil end\n";
    definitions += "    end\n";
    definitions += "    function object:GetAttributeChangedSignal(attr) return __btMakeSignal() end\n";
    definitions += "    function object:GetPropertyChangedSignal(prop) return __btMakeSignal() end\n";
    definitions += "    function object:GetChildren()\n";
    definitions += "        local result = {}\n";
    definitions += "        for _, child in ipairs(__buildingToolChildOrder[self] or {}) do\n";
    definitions += "            if __buildingToolChildren[self] ~= nil and __buildingToolChildren[self][child] ~= nil then table.insert(result, child) end\n";
    definitions += "        end\n";
    definitions += "        return result\n";
    definitions += "    end\n";
    definitions += "    function object:ScaleTo(targetScale: number)\n";
    definitions += "        if self.ClassName ~= 'Model' then error('ScaleTo is only available on Model instances') end\n";
    definitions += "        targetScale = tonumber(targetScale)\n";
    definitions += "        if targetScale == nil or targetScale ~= targetScale or targetScale <= 0 or targetScale == math.huge then error('ScaleTo expects a positive finite number') end\n";
    definitions += "        local vals = __buildingToolValues[self]\n";
    definitions += "        vals.Scale = targetScale\n";
    definitions += "        local pth = vals.__Path or path or ''\n";
    definitions += "        __buildingToolPrint('__BUILDING_TOOL_PROPERTY_UPDATE__' .. __buildingToolEncode(pth) .. '|' .. __buildingToolEncode('Scale') .. '|' .. __buildingToolEncode(targetScale))\n";
    definitions += "    end\n";
    definitions += "    function object:IsA(className: string)\n";
    definitions += "        local vals = __buildingToolValues[self]\n";
    definitions += "        local actual = vals and vals.ClassName or self.ClassName\n";
    definitions += "        if actual == className or className == 'Instance' then return true end\n";
    definitions += "        local classParents = {\n";
    definitions += "            Part = {'BasePart', 'PVInstance'}, MeshPart = {'BasePart', 'PVInstance'}, SpawnLocation = {'BasePart', 'PVInstance'}, Model = {'PVInstance'},\n";
    definitions += "            Frame = {'GuiObject'}, ScrollingFrame = {'GuiObject'}, TextLabel = {'GuiObject'}, ImageLabel = {'GuiObject'},\n";
    definitions += "            TextButton = {'GuiButton', 'GuiObject'}, ImageButton = {'GuiButton', 'GuiObject'}, TextBox = {'GuiObject'},\n";
    definitions += "            ScreenGui = {'LayerCollector'}, SurfaceGui = {'LayerCollector'}, BillboardGui = {'LayerCollector'}\n";
    definitions += "        }\n";
    definitions += "        for _, parentClass in ipairs(classParents[actual] or {}) do\n";
    definitions += "            if parentClass == className then return true end\n";
    definitions += "        end\n";
    definitions += "        return false\n";
    definitions += "    end\n";
    definitions += "    function object:Clone()\n";
    definitions += "        local vals = __buildingToolValues[self]\n";
    definitions += "        local className = vals and vals.ClassName or self.ClassName or 'Folder'\n";
    definitions += "        local sameName = (vals and vals.Name) or self.Name or className\n";
    definitions += "        local copy = Instance.new(className, nil)\n";
    definitions += "        local skip = { Parent = true, __Path = true, Name = true, ClassName = true }\n";
    definitions += "        if vals ~= nil then\n";
    definitions += "            for k, v in pairs(vals) do\n";
    definitions += "                if not skip[k] then\n";
    definitions += "                    -- assignment goes through __newindex so host gets Size/Color/etc\n";
    definitions += "                    copy[k] = v\n";
    definitions += "                end\n";
    definitions += "            end\n";
    definitions += "        end\n";
    definitions += "        -- Keep the same display name (Roblox-style; not Name_Clone)\n";
    definitions += "        copy.Name = sameName\n";
    definitions += "        for _, child in ipairs(self:GetChildren()) do\n";
    definitions += "            local cc = child:Clone()\n";
    definitions += "            if cc ~= nil then cc.Parent = copy end\n";
    definitions += "        end\n";
    definitions += "        return copy\n";
    definitions += "    end\n";
    definitions += "    function object:Destroy()\n";
    definitions += "        local parent = self.Parent or (__buildingToolValues[self] and __buildingToolValues[self].Parent)\n";
    definitions += "        if parent ~= nil and __buildingToolChildren[parent] ~= nil then\n";
    definitions += "            __buildingToolRemoveChild(parent, self)\n";
    definitions += "        end\n";
    definitions += "        local kids = self:GetChildren()\n";
    definitions += "        for _, child in ipairs(kids) do child:Destroy() end\n";
    definitions += "        __buildingToolChildren[self] = nil\n";
    definitions += "        __buildingToolChildOrder[self] = nil\n";
    definitions += "        __buildingToolValues[self] = nil\n";
    definitions += "        if self.AncestryChanged ~= nil then self.AncestryChanged:Fire(nil) end\n";
    definitions += "    end\n";
    definitions += "    function object:FindFirstChild(childName: string, recursive: boolean?)\n";
    definitions += "        local kids = __buildingToolChildren[self] or {}\n";
    definitions += "        for _, child in pairs(kids) do\n";
    definitions += "            if child.Name == childName then return child end\n";
    definitions += "        end\n";
    definitions += "        if not recursive then return nil end\n";
    definitions += "        for _, descendant in pairs(kids) do\n";
    definitions += "            local found = descendant:FindFirstChild(childName, true)\n";
    definitions += "            if found ~= nil then return found end\n";
    definitions += "        end\n";
    definitions += "        return nil\n";
    definitions += "    end\n";
    definitions += "    function object:FindFirstChildOfClass(className: string)\n";
    definitions += "        for _, child in ipairs(self:GetChildren()) do\n";
    definitions += "            if child.ClassName == className then return child end\n";
    definitions += "        end\n";
    definitions += "        return nil\n";
    definitions += "    end\n";
    definitions += "    function object:FindFirstChildWhichIsA(className: string, recursive: boolean)\n";
    definitions += "        local function findIn(parent)\n";
    definitions += "            for _, child in ipairs(parent:GetChildren()) do\n";
    definitions += "                if child:IsA(className) then return child end\n";
    definitions += "                if recursive then\n";
    definitions += "                    local found = findIn(child)\n";
    definitions += "                    if found ~= nil then return found end\n";
    definitions += "                end\n";
    definitions += "            end\n";
    definitions += "            return nil\n";
    definitions += "        end\n";
    definitions += "        return findIn(self)\n";
    definitions += "    end\n";
    definitions += "    function object:FindFirstAncestor(name: string)\n";
    definitions += "        local ancestor = self.Parent\n";
    definitions += "        while ancestor ~= nil do\n";
    definitions += "            if ancestor.Name == name then return ancestor end\n";
    definitions += "            ancestor = ancestor.Parent\n";
    definitions += "        end\n";
    definitions += "        return nil\n";
    definitions += "    end\n";
    definitions += "    function object:FindFirstAncestorOfClass(className: string)\n";
    definitions += "        local ancestor = self.Parent\n";
    definitions += "        while ancestor ~= nil do\n";
    definitions += "            if ancestor.ClassName == className then return ancestor end\n";
    definitions += "            ancestor = ancestor.Parent\n";
    definitions += "        end\n";
    definitions += "        return nil\n";
    definitions += "    end\n";
    definitions += "    function object:FindFirstAncestorWhichIsA(className: string)\n";
    definitions += "        local ancestor = self.Parent\n";
    definitions += "        while ancestor ~= nil do\n";
    definitions += "            if ancestor:IsA(className) then return ancestor end\n";
    definitions += "            ancestor = ancestor.Parent\n";
    definitions += "        end\n";
    definitions += "        return nil\n";
    definitions += "    end\n";
    definitions += "    function object:FindFirstDescendant(name: string)\n";
    definitions += "        return self:FindFirstChild(name, true)\n";
    definitions += "    end\n";
    definitions += "    function object:WaitForChild(childName: string, timeout: number?)\n";
    definitions += "        local found = self:FindFirstChild(childName, true)\n";
    definitions += "        if found ~= nil then return found end\n";
    definitions += "        local limit = timeout or 5\n";
    definitions += "        local started = __buildingToolClock()\n";
    definitions += "        while __buildingToolClock() - started < limit do\n";
    definitions += "            found = self:FindFirstChild(childName, true)\n";
    definitions += "            if found ~= nil then return found end\n";
    definitions += "            task.wait(0.05)\n";
    definitions += "        end\n";
    definitions += "        warn('WaitForChild timed out: ' .. tostring(childName))\n";
    definitions += "        return nil\n";
    definitions += "    end\n";
    // Roblox-like GetFullName: dotted path from root (game.Workspace.Part)
    definitions += "    function object:GetFullName()\n";
    definitions += "        local vals = __buildingToolValues[self]\n";
    definitions += "        local p = (vals and vals.__Path) or path or self.Name or ''\n";
    definitions += "        if type(p) == 'string' and #p > 0 then\n";
    definitions += "            return (string.gsub(p, '/', '.'))\n";
    definitions += "        end\n";
    definitions += "        return tostring(self.Name or 'Instance')\n";
    definitions += "    end\n";
    // GetService: resolve a top-level service under game (Workspace, Lighting, ...)
    // Also returns global API tables (RunService, TweenService, ...) so methods like
    // RunService:IsClient() work when obtained via game:GetService("RunService").
    definitions += "    function object:GetService(serviceName: string)\n";
    definitions += "        if type(serviceName) ~= 'string' or #serviceName == 0 then return nil end\n";
    definitions += "        -- API services that live as globals (not always tree children).\n";
    definitions += "        -- Looked up at call-time so the final RunService table (with IsClient etc.) is returned.\n";
    definitions += "        if serviceName == 'RunService' then return RunService end\n";
    definitions += "        if serviceName == 'TweenService' then return TweenService end\n";
    definitions += "        if serviceName == 'UserInputService' then return UserInputService end\n";
    definitions += "        if serviceName == 'SoundService' then return SoundService end\n";
    definitions += "        local root = game or self\n";
    definitions += "        local found = root:FindFirstChild(serviceName, false)\n";
    definitions += "        if found ~= nil then return found end\n";
    definitions += "        -- common aliases / tree services\n";
    definitions += "        if serviceName == 'Workspace' or serviceName == 'workspace' then return workspace or root:FindFirstChild('Workspace', false) end\n";
    definitions += "        if serviceName == 'Players' then return Players or root:FindFirstChild('Players', false) end\n";
    definitions += "        if serviceName == 'Lighting' then return Lighting or root:FindFirstChild('Lighting', false) end\n";
    definitions += "        if serviceName == 'ReplicatedStorage' then return ReplicatedStorage or root:FindFirstChild('ReplicatedStorage', false) end\n";
    definitions += "        if serviceName == 'ServerStorage' then return ServerStorage or root:FindFirstChild('ServerStorage', false) end\n";
    definitions += "        if serviceName == 'ServerScriptService' then return ServerScriptService or root:FindFirstChild('ServerScriptService', false) end\n";
    definitions += "        return root:FindFirstChild(serviceName, true)\n";
    definitions += "    end\n";
    // Sound:Play / Sound:Stop (Roblox-like)
    definitions += "    function object:Play()\n";
    definitions += "        if self.ClassName ~= 'Sound' then return end\n";
    definitions += "        local vals = __buildingToolValues[self]\n";
    definitions += "        if vals ~= nil then vals.Playing = true end\n";
    definitions += "        __buildingToolPrint('__BUILDING_TOOL_SOUND_CMD__' .. __buildingToolEncode(path) .. '|Play')\n";
    definitions += "    end\n";
    definitions += "    function object:Stop()\n";
    definitions += "        if self.ClassName ~= 'Sound' then return end\n";
    definitions += "        local vals = __buildingToolValues[self]\n";
    definitions += "        if vals ~= nil then vals.Playing = false; vals.TimePosition = 0 end\n";
    definitions += "        __buildingToolPrint('__BUILDING_TOOL_SOUND_CMD__' .. __buildingToolEncode(path) .. '|Stop')\n";
    definitions += "    end\n";
    definitions += "    return setmetatable(object, {\n";
    definitions += "        __index = function(self, key)\n";
    definitions += "            local kids = __buildingToolChildren[self]\n";
    definitions += "            if kids ~= nil then\n";
    definitions += "                if type(key) == 'number' and key > 0 and key % 1 == 0 then\n";
    definitions += "                    local ordered = __buildingToolChildOrder[self] or {}\n";
    definitions += "                    local child = ordered[key]\n";
    definitions += "                    if child ~= nil and kids[child] ~= nil then return child end\n";
    definitions += "                end\n";
    definitions += "                for _, child in pairs(kids) do\n";
    definitions += "                    if child.Name == key then return child end\n";
    definitions += "                end\n";
    definitions += "            end\n";
    definitions += "            local vals = __buildingToolValues[self]\n";
    definitions += "            if vals ~= nil and vals[key] ~= nil then return vals[key] end\n";
    definitions += "            return nil\n";
    definitions += "        end,\n";
    definitions += "        __newindex = function(self, key, value)\n";
    definitions += "            local vals = __buildingToolValues[self]\n";
    definitions += "            if vals == nil then return end\n";
    definitions += "            if key == 'Name' then\n";
    definitions += "                local newName = tostring(value or '')\n";
    definitions += "                if newName == '' then return end\n";
    definitions += "                vals.Name = newName\n";
    definitions += "                local pth = vals.__Path or path or ''\n";
    definitions += "                __buildingToolPrint('__BUILDING_TOOL_PROPERTY_UPDATE__' .. __buildingToolEncode(pth) .. '|' .. __buildingToolEncode('Name') .. '|' .. __buildingToolEncode(newName))\n";
    definitions += "                if self.Changed ~= nil then self.Changed:Fire('Name') end\n";
    definitions += "                return\n";
    definitions += "            end\n";
    definitions += "            if key == 'Parent' then\n";
    definitions += "                local oldParent = vals.Parent\n";
    definitions += "                if oldParent ~= nil and __buildingToolChildren[oldParent] ~= nil then\n";
    definitions += "                    __buildingToolRemoveChild(oldParent, self)\n";
    definitions += "                end\n";
    definitions += "                vals.Parent = value\n";
    definitions += "                if value ~= nil then\n";
    definitions += "                    __buildingToolAddChild(value, self)\n";
    definitions += "                end\n";
    definitions += "                local pth = vals.__Path or path or ''\n";
    definitions += "                local parentPath = ''\n";
    definitions += "                if value ~= nil then\n";
    definitions += "                    local pv = __buildingToolValues[value]\n";
    definitions += "                    parentPath = (pv and pv.__Path) or ''\n";
    definitions += "                end\n";
    definitions += "                __buildingToolPrint('__BUILDING_TOOL_PROPERTY_UPDATE__' .. __buildingToolEncode(pth) .. '|' .. __buildingToolEncode('Parent') .. '|' .. __buildingToolEncode(parentPath))\n";
    definitions += "                if self.Changed ~= nil then self.Changed:Fire('Parent') end\n";
    definitions += "                if self.AncestryChanged ~= nil then self.AncestryChanged:Fire(value) end\n";
    definitions += "                return\n";
    definitions += "            end\n";
    definitions += "            vals[key] = value\n";
    definitions += "            if key == 'Position' and type(value) == 'table' then\n";
    definitions += "                vals.CFrame = CFrame.new(value)\n";
    definitions += "            end\n";
    definitions += "            if key == 'CFrame' and type(value) == 'table' and value.Position ~= nil then\n";
    definitions += "                vals.Position = value.Position\n";
    definitions += "                if value.Rotation ~= nil then vals.Orientation = value.Rotation end\n";
    definitions += "            end\n";
    definitions += "            local pth = (vals and vals.__Path) or path or ''\n";
    definitions += "            __buildingToolPrint('__BUILDING_TOOL_PROPERTY_UPDATE__' .. __buildingToolEncode(pth) .. '|' .. __buildingToolEncode(key) .. '|' .. __buildingToolEncode(value))\n";
    definitions += "            if self.Changed ~= nil then self.Changed:Fire(key) end\n";
    definitions += "            local pcs = self:GetPropertyChangedSignal(key)\n";
    definitions += "            if pcs ~= nil then pcs:Fire() end\n";
    definitions += "        end\n";
    definitions += "    })\n";
    definitions += "end\n\n";
    definitions += "__buildingToolSeed = function(object: any, props: any)\n";
    definitions += "    local vals = __buildingToolValues[object]\n";
    definitions += "    if vals == nil then return end\n";
    definitions += "    for key, value in pairs(props) do vals[key] = value end\n";
    definitions += "    if props.Position ~= nil then vals.CFrame = CFrame.new(props.Position) end\n";
    definitions += "end\n\n";
    definitions += "__buildingToolAddChild = function(parent: any, child: any)\n";
    definitions += "    if parent == nil or child == nil then return end\n";
    definitions += "    if __buildingToolChildren[parent] == nil then __buildingToolChildren[parent] = {} end\n";
    definitions += "    if __buildingToolChildOrder[parent] == nil then __buildingToolChildOrder[parent] = {} end\n";
    definitions += "    if __buildingToolChildren[parent][child] == nil then table.insert(__buildingToolChildOrder[parent], child) end\n";
    definitions += "    __buildingToolChildren[parent][child] = child\n";
    definitions += "    local vals = __buildingToolValues[child]\n";
    definitions += "    if vals ~= nil then vals.Parent = parent end\n";
    definitions += "end\n\n";
    definitions += "__buildingToolRemoveChild = function(parent: any, child: any)\n";
    definitions += "    if __buildingToolChildren[parent] ~= nil then __buildingToolChildren[parent][child] = nil end\n";
    definitions += "    local order = __buildingToolChildOrder[parent]\n";
    definitions += "    if order ~= nil then\n";
    definitions += "        for index = #order, 1, -1 do\n";
    definitions += "            if order[index] == child then table.remove(order, index) end\n";
    definitions += "        end\n";
    definitions += "    end\n";
    definitions += "end\n\n";
    definitions += "Color3 = {}\n";
    definitions += "function Color3.fromRGB(r: number?, g: number?, b: number?)\n";
    definitions += "    return { R = (r or 0) / 255, G = (g or 0) / 255, B = (b or 0) / 255 }\n";
    definitions += "end\n";
    definitions += "function Color3.new(r: number?, g: number?, b: number?)\n";
    definitions += "    return { R = r or 0, G = g or 0, B = b or 0 }\n";
    definitions += "end\n\n";
    definitions += "local function __buildingToolVectorMetatable(kind: string)\n";
    definitions += "    return {\n";
    definitions += "        __add = function(a, b) return setmetatable({ X = a.X + b.X, Y = a.Y + b.Y, Z = (a.Z or 0) + (b.Z or 0) }, getmetatable(a)) end,\n";
    definitions += "        __sub = function(a, b) return setmetatable({ X = a.X - b.X, Y = a.Y - b.Y, Z = (a.Z or 0) - (b.Z or 0) }, getmetatable(a)) end,\n";
    definitions += "        __unm = function(a) return setmetatable({ X = -a.X, Y = -a.Y, Z = -(a.Z or 0) }, getmetatable(a)) end,\n";
    definitions += "        __mul = function(a, b)\n";
    definitions += "            if type(a) == 'number' then return setmetatable({ X = a * b.X, Y = a * b.Y, Z = a * (b.Z or 0) }, getmetatable(b)) end\n";
    definitions += "            return setmetatable({ X = a.X * b, Y = a.Y * b, Z = (a.Z or 0) * b }, getmetatable(a))\n";
    definitions += "        end,\n";
    definitions += "        __div = function(a, b) return setmetatable({ X = a.X / b, Y = a.Y / b, Z = (a.Z or 0) / b }, getmetatable(a)) end,\n";
    definitions += "        __tostring = function(a) return kind .. '(' .. a.X .. ', ' .. a.Y .. (a.Z ~= nil and ', ' .. a.Z or '') .. ')' end\n";
    definitions += "    }\n";
    definitions += "end\n";
    definitions += "Vector2 = {}\n";
    definitions += "local __buildingToolVector2Metatable = __buildingToolVectorMetatable('Vector2')\n";
    definitions += "function Vector2.new(x: number?, y: number?) return setmetatable({ X = x or 0, Y = y or 0 }, __buildingToolVector2Metatable) end\n";
    definitions += "Vector2.zero = Vector2.new(0, 0)\n";
    definitions += "Vector2.xAxis = Vector2.new(1, 0)\n";
    definitions += "Vector2.yAxis = Vector2.new(0, 1)\n\n";
    definitions += "Vector3 = {}\n";
    definitions += "local __buildingToolVector3Metatable = __buildingToolVectorMetatable('Vector3')\n";
    definitions += "function Vector3.new(x: number?, y: number?, z: number?) return setmetatable({ X = x or 0, Y = y or 0, Z = z or 0 }, __buildingToolVector3Metatable) end\n";
    definitions += "Vector3.zero = Vector3.new(0, 0, 0)\n";
    definitions += "Vector3.xAxis = Vector3.new(1, 0, 0)\n";
    definitions += "Vector3.yAxis = Vector3.new(0, 1, 0)\n";
    definitions += "Vector3.zAxis = Vector3.new(0, 0, 1)\n";
    definitions += "Vector3.forward = Vector3.new(0, 0, -1)\n";
    definitions += "Vector3.back = Vector3.new(0, 0, 1)\n\n";
    definitions += "CFrame = {}\n";
    definitions += "local __buildingToolCFrameMetatable = { __tostring = function(value) return 'CFrame(' .. value.Position.X .. ', ' .. value.Position.Y .. ', ' .. value.Position.Z .. ')' end }\n";
    definitions += "local function __buildingToolCFrame(position, rotation)\n";
    definitions += "    return setmetatable({ Position = position, Rotation = rotation or Vector3.zero, LookVector = Vector3.forward, RightVector = Vector3.xAxis, UpVector = Vector3.yAxis }, __buildingToolCFrameMetatable)\n";
    definitions += "end\n";
    definitions += "__buildingToolCFrameMetatable.__index = {\n";
    definitions += "    Lerp = function(value, goal, alpha)\n";
    definitions += "        alpha = math.max(0, math.min(1, alpha or 0))\n";
    definitions += "        local p = Vector3.new(value.Position.X + (goal.Position.X - value.Position.X) * alpha, value.Position.Y + (goal.Position.Y - value.Position.Y) * alpha, value.Position.Z + (goal.Position.Z - value.Position.Z) * alpha)\n";
    definitions += "        local function angleLerp(from, to)\n";
    definitions += "            local delta = (to - from + 180) % 360 - 180\n";
    definitions += "            return from + delta * alpha\n";
    definitions += "        end\n";
    definitions += "        local r = Vector3.new(angleLerp(value.Rotation.X, goal.Rotation.X), angleLerp(value.Rotation.Y, goal.Rotation.Y), angleLerp(value.Rotation.Z, goal.Rotation.Z))\n";
    definitions += "        return __buildingToolCFrame(p, r)\n";
    definitions += "    end\n";
    definitions += "}\n";
    definitions += "function CFrame.new(x: any?, y: number?, z: number?)\n";
    definitions += "    if type(x) == 'table' and x.X ~= nil and x.Y ~= nil then return __buildingToolCFrame(Vector3.new(x.X, x.Y, x.Z)) end\n";
    definitions += "    return __buildingToolCFrame(Vector3.new(x or 0, y or 0, z or 0))\n";
    definitions += "end\n";
    definitions += "function CFrame.Angles(x: number?, y: number?, z: number?)\n";
    definitions += "    local yaw = y or 0\n";
    definitions += "    return __buildingToolCFrame(Vector3.zero, Vector3.new(x or 0, yaw, z or 0))\n";
    definitions += "end\n\n";
    definitions += "task = {}\n";
    definitions += "function task.wait(seconds)\n";
    definitions += "    seconds = seconds or 0\n";
    definitions += "    return coroutine.yield(seconds)\n";
    definitions += "end\n\n";
    definitions += "function task.spawn(callback, ...)\n";
    definitions += "    return __buildingToolTaskSpawn(callback, ...)\n";
    definitions += "end\n";
    definitions += "function task.defer(callback, ...)\n";
    definitions += "    return __buildingToolTaskDefer(callback, ...)\n";
    definitions += "end\n";
    definitions += "function task.delay(seconds, callback, ...)\n";
    definitions += "    return __buildingToolTaskDelay(seconds, callback, ...)\n";
    definitions += "end\n\n";
    int nextRuntimeObjectId = 0;
    definitions += string("__buildingToolIsClient = ") + (runtimeClientMode ? "true\n" : "false\n");
    appendRuntimeInstanceDefinition(definitions, &game, "game", "__buildingToolGame", nextRuntimeObjectId);
    // IMPORTANT: game/workspace must be GLOBALS (not local) so script threads can see them.
    definitions += "workspace = __buildingToolGame.Workspace\n";
    definitions += "game = __buildingToolGame\n";
    definitions += "if workspace == nil then workspace = __buildingToolGame end\n\n";
    // Raycast + camera projection (workspace/camera exist now)
    definitions += "if type(__btAttachRaycast) == 'function' and type(workspace) == 'table' then __btAttachRaycast(workspace) end\n";
    definitions += "do local cam = workspace and workspace.CurrentCamera; "
                   "if type(__btAttachCameraProjection) == 'function' and type(cam) == 'table' then __btAttachCameraProjection(cam) end end\n\n";
    if (runtimeClientMode)
        definitions += "if game.Players and game.Players.LocalPlayer then game.Players.LocalPlayer.Character = workspace.Character end\n\n";

    // Enum library (Roblox-like)
    definitions += "Enum = {\n";
    definitions += "  Material = { Plastic = 0, SmoothPlastic = 1, Neon = 2, Wood = 3, Metal = 4, Concrete = 5, Glass = 6 },\n";
    definitions += "  PartType = { Block = 0, Ball = 1, Cylinder = 2 },\n";
    definitions += "  KeyCode = { W = 'W', A = 'A', S = 'S', D = 'D', Space = 'Space', E = 'E', Q = 'Q' },\n";
    definitions += "  UserInputType = { MouseButton1 = 0, MouseButton2 = 1, Keyboard = 2 },\n";
    definitions += "  EasingStyle = { Linear = 0, Sine = 1, Quad = 2, Cubic = 3, Quart = 4, Quint = 5, Bounce = 6, Elastic = 7 },\n";
    definitions += "  EasingDirection = { In = 0, Out = 1, InOut = 2 },\n";
    definitions += "}\n\n";

    // TweenInfo + TweenService (simplified)
    definitions += "TweenInfo = {}\n";
    definitions += "function TweenInfo.new(time: number?, easingStyle: any?, easingDirection: any?, repeatCount: number?, reverses: boolean?, delayTime: number?)\n";
    definitions += "  return { Time = time or 1, EasingStyle = easingStyle or Enum.EasingStyle.Quad, EasingDirection = easingDirection or Enum.EasingDirection.Out,\n";
    definitions += "    RepeatCount = repeatCount or 0, Reverses = reverses or false, DelayTime = delayTime or 0 }\n";
    definitions += "end\n\n";
    definitions += "TweenService = {}\n";
    definitions += "function TweenService:Create(instance: any, info: any, goals: any)\n";
    definitions += "  local tween = { Instance = instance, Info = info, Goals = goals, _playing = false }\n";
    definitions += "  function tween:Play()\n";
    definitions += "    self._playing = true\n";
    definitions += "    if type(goals) == 'table' and instance ~= nil then\n";
    definitions += "      for key, value in pairs(goals) do instance[key] = value end\n";
    definitions += "    end\n";
    definitions += "    self._playing = false\n";
    definitions += "  end\n";
    definitions += "  function tween:Cancel() self._playing = false end\n";
    definitions += "  function tween:Pause() self._playing = false end\n";
    definitions += "  return tween\n";
    definitions += "end\n\n";

    // RunService
    definitions += "RunService = { Heartbeat = {}, RenderStepped = {}, Stepped = {} }\n";
    definitions += "local function __btSignal()\n";
    definitions += "  local signal = { _handlers = {} }\n";
    definitions += "  function signal:Connect(fn)\n";
    definitions += "    table.insert(self._handlers, { fn = fn, once = false })\n";
    definitions += "    return { Disconnect = function() end, Connected = true }\n";
    definitions += "  end\n";
    definitions += "  function signal:Once(fn)\n";
    definitions += "    table.insert(self._handlers, { fn = fn, once = true })\n";
    definitions += "    return { Disconnect = function() end, Connected = true }\n";
    definitions += "  end\n";
    definitions += "  function signal:Fire(...)\n";
    definitions += "    local args = table.pack(...)\n";
    definitions += "    local i = 1\n";
    definitions += "    while i <= #self._handlers do\n";
    definitions += "      local h = self._handlers[i]\n";
    definitions += "      h.fn(table.unpack(args, 1, args.n))\n";
    definitions += "      if h.once then table.remove(self._handlers, i) else i += 1 end\n";
    definitions += "    end\n";
    definitions += "  end\n";
    definitions += "  return signal\n";
    definitions += "end\n";
    definitions += "RunService.Heartbeat = __btSignal()\n";
    definitions += "RunService.RenderStepped = __btSignal()\n";
    definitions += "RunService.Stepped = __btSignal()\n";
    definitions += "function RunService:IsStudio() return true end\n";
    definitions += "function RunService:IsServer() return not __buildingToolIsClient end\n";
    definitions += "function RunService:IsClient() return __buildingToolIsClient end\n\n";

    for (const LuauTypeDefinition& type : luauTypeDefinitions)
    {
        definitions += "type " + type.name + " = {\n";
        for (const LuauPropertyDefinition& property : type.properties)
            definitions += "    " + property.name + ": " + property.type + ",\n";
        for (const LuauFunctionDefinition& function : type.functions)
            definitions += "    " + function.name + ": (" + function.parameters + ") -> " + function.returnType + ",\n";
        definitions += "}\n\n";
    }

    for (const LuauGlobalDefinition& global : luauGlobalDefinitions)
    {
        if (global.name == "game" || global.name == "workspace")
            continue; // already set as globals above
        string expression = global.expression.empty() ? "{}" : global.expression;
        if (global.name == "pointer")
            expression = runtimeClientMode ? "game.Players.LocalPlayer.Character" : "nil";
        definitions += global.name + " = " + expression + "\n";
        for (const LuauFunctionDefinition& function : global.functions)
        {
            definitions += "function " + global.name + "." + function.name + "(" + function.parameters + ")\n";
            definitions += "    " + function.body + "\n";
            definitions += "end\n";
        }
        definitions += "\n";
    }

    for (const LuauFunctionDefinition& function : luauGlobalFunctions)
    {
        definitions += "function " + function.name + "(" + function.parameters + ")\n";
        definitions += "    " + function.body + "\n";
        definitions += "end\n\n";
    }

    
    // -------------------------------------------------------------------------
    // Expanded Roblox-like Luau API (only types/services that exist in this tool)
    // -------------------------------------------------------------------------
    definitions += R"LUA(
-- Ensure all library tables exist before function X.new assignments
Instance = Instance or {}
Vector2 = Vector2 or {}
Vector3 = Vector3 or {}
CFrame = CFrame or {}
Color3 = Color3 or {}
UDim = UDim or {}
UDim2 = UDim2 or {}
BrickColor = BrickColor or {}
NumberRange = NumberRange or {}
NumberSequence = NumberSequence or {}
NumberSequenceKeypoint = NumberSequenceKeypoint or {}
ColorSequence = ColorSequence or {}
ColorSequenceKeypoint = ColorSequenceKeypoint or {}
Ray = Ray or {}
RaycastParams = RaycastParams or {}
Random = Random or {}
TweenInfo = TweenInfo or {}
Region3 = Region3 or {}
Enum = Enum or {}
task = task or {}

-- Enums (subset matching editor features)
Enum = Enum or {}
Enum.NormalId = { Top = "Top", Bottom = "Bottom", Front = "Front", Back = "Back", Left = "Left", Right = "Right" }
Enum.KeyCode = {
  Unknown = 0, A = 1, B = 2, C = 3, D = 4, E = 5, F = 6, G = 7, H = 8, I = 9, J = 10, K = 11, L = 12, M = 13,
  N = 14, O = 15, P = 16, Q = 17, R = 18, S = 19, T = 20, U = 21, V = 22, W = 23, X = 24, Y = 25, Z = 26,
  Space = 32, LeftShift = 33, RightShift = 34, LeftControl = 35, RightControl = 36, Tab = 37, Return = 38, Escape = 39,
  One = 49, Two = 50, Three = 51, Four = 52, Five = 53, Six = 54, Seven = 55, Eight = 56, Nine = 57, Zero = 48
}
Enum.UserInputType = { MouseButton1 = 1, MouseButton2 = 2, MouseButton3 = 3, MouseMovement = 4, Keyboard = 5, Touch = 6 }
Enum.CameraType = { Fixed = "Fixed", Watch = "Watch", Attach = "Attach", Track = "Track", Follow = "Follow", Custom = "Custom", Scriptable = "Scriptable" }
Enum.Material = { Plastic = "Plastic", SmoothPlastic = "SmoothPlastic", Neon = "Neon", Wood = "Wood", Metal = "Metal", Concrete = "Concrete", Grass = "Grass", Sand = "Sand", Ice = "Ice", Brick = "Brick", Granite = "Granite", Marble = "Marble", ForceField = "ForceField" }
Enum.PartType = { Ball = "Ball", Block = "Block", Cylinder = "Cylinder" }
Enum.RaycastFilterType = { Exclude = "Exclude", Include = "Include", Blacklist = "Exclude", Whitelist = "Include" }
Enum.ScaleType = { Stretch = "Stretch", Slice = "Slice", Tile = "Tile", Fit = "Fit", Crop = "Crop" }
Enum.Font = { SourceSans = "SourceSans", SourceSansBold = "SourceSansBold", Code = "Code", Legacy = "Legacy" }
Enum.HumanoidStateType = { Running = "Running", Jumping = "Jumping", Freefall = "Freefall", Landed = "Landed", Seated = "Seated", Dead = "Dead", Physics = "Physics" }
Enum.Shape = Enum.PartType
Enum.SurfaceType = { Smooth = "Smooth", Glue = "Glue", Weld = "Weld", Studs = "Studs", Inlet = "Inlet", Universal = "Universal", SmoothNoOutlines = "SmoothNoOutlines" }

-- UDim / UDim2
UDim = {}
function UDim.new(scale, offset) return { Scale = scale or 0, Offset = offset or 0 } end
UDim2 = {}
function UDim2.new(xScale, xOffset, yScale, yOffset)
  return { X = UDim.new(xScale, xOffset), Y = UDim.new(yScale, yOffset) }
end
function UDim2.fromScale(x, y) return UDim2.new(x or 0, 0, y or 0, 0) end
function UDim2.fromOffset(x, y) return UDim2.new(0, x or 0, 0, y or 0) end

-- BrickColor (simple named table)
BrickColor = {}
function BrickColor.new(nameOrR, g, b)
  if type(nameOrR) == "string" then return { Name = nameOrR, Color = Color3.new(1, 1, 1) } end
  return { Name = "Custom", Color = Color3.new(nameOrR or 0, g or 0, b or 0) }
end
function BrickColor.Random() return BrickColor.new("Medium stone grey") end
function BrickColor.White() return BrickColor.new("White") end
function BrickColor.Black() return BrickColor.new("Black") end
function BrickColor.Red() return BrickColor.new("Really red") end
function BrickColor.Blue() return BrickColor.new("Really blue") end
function BrickColor.Green() return BrickColor.new("Lime green") end

-- NumberRange / NumberSequence / ColorSequence (lightweight)
NumberRange = {}
function NumberRange.new(a, b) return { Min = a or 0, Max = b or a or 0 } end
NumberSequenceKeypoint = {}
function NumberSequenceKeypoint.new(time, value, envelope)
  return { Time = time or 0, Value = value or 0, Envelope = envelope or 0 }
end
NumberSequence = {}
function NumberSequence.new(a, b)
  if type(a) == "table" then return { Keypoints = a } end
  return { Keypoints = { NumberSequenceKeypoint.new(0, a or 0), NumberSequenceKeypoint.new(1, b or a or 0) } }
end
ColorSequenceKeypoint = {}
function ColorSequenceKeypoint.new(time, color)
  return { Time = time or 0, Value = color or Color3.new(1,1,1) }
end
ColorSequence = {}
function ColorSequence.new(a, b)
  if type(a) == "table" and a.R then
    return { Keypoints = { ColorSequenceKeypoint.new(0, a), ColorSequenceKeypoint.new(1, b or a) } }
  end
  return { Keypoints = a or {} }
end

-- Ray helpers + RaycastParams (3D, 3D→2D, 2D→3D)
Ray = {}
function Ray.new(origin, direction)
  return { Origin = origin or Vector3.zero, Direction = direction or Vector3.yAxis }
end
RaycastParams = RaycastParams or {}
function RaycastParams.new()
  return {
    FilterDescendantsInstances = {},
    FilterType = Enum.RaycastFilterType.Exclude,
    IgnoreWater = true,
    CollisionGroup = "Default",
    BruteForceAllSlow = false,
  }
end

-- workspace:Raycast(origin, direction, params?) → result | nil
-- result: { Position, Normal, Distance, InstanceName, InstancePath }
local function __btAttachRaycast(ws)
  if type(ws) ~= "table" then return end
  rawset(ws, "Raycast", function(self, origin, direction, params)
    return __buildingToolRaycast(origin, direction, params)
  end)
end

-- Camera projection: WorldToScreenPoint (3D→2D), ScreenPointToRay / ViewportPointToRay (2D→3D)
local function __btAttachCameraProjection(cam)
  if type(cam) ~= "table" then return end
  rawset(cam, "WorldToScreenPoint", function(self, worldPos)
    return __buildingToolWorldToScreen(worldPos)
  end)
  rawset(cam, "WorldToViewportPoint", function(self, worldPos)
    return __buildingToolWorldToScreen(worldPos)
  end)
  rawset(cam, "ScreenPointToRay", function(self, x, y, depth)
    return __buildingToolScreenPointToRay(x, y, depth)
  end)
  rawset(cam, "ViewportPointToRay", function(self, x, y, depth)
    return __buildingToolViewportPointToRay(x, y, depth)
  end)
end

-- Random
Random = Random or {}
function Random.new(seed)
  local state = seed or math.floor(__buildingToolClock() * 1000)
  local obj = {}
  function obj:NextNumber(a, b)
    state = (state * 1103515245 + 12345) % 2147483648
    local r = state / 2147483648
    if a and b then return a + (b - a) * r end
    return r
  end
  function obj:NextInteger(a, b)
    return math.floor(self:NextNumber(a, b + 1))
  end
  return obj
end

-- Attach raycast / projection APIs once services exist
do
  local ws = rawget(_G, "workspace") or rawget(_G, "Workspace")
  if type(ws) == "table" and type(__btAttachRaycast) == "function" then
    __btAttachRaycast(ws)
  end
  local cam = nil
  if type(ws) == "table" then cam = ws.CurrentCamera end
  if type(cam) == "table" and type(__btAttachCameraProjection) == "function" then
    __btAttachCameraProjection(cam)
  end
  _G.__btAttachCameraProjection = __btAttachCameraProjection
  _G.__btAttachRaycast = __btAttachRaycast
end

-- tick / time
function tick() return __buildingToolClock() end
function time() return __buildingToolClock() end

-- typeof
function typeof(value)
  local t = type(value)
  if t ~= "table" then return t end
  if value.X ~= nil and value.Y ~= nil and value.Z ~= nil and value.Position == nil then return "Vector3" end
  if value.X ~= nil and value.Y ~= nil and value.Z == nil and value.Scale == nil then return "Vector2" end
  if value.Position ~= nil and value.Rotation ~= nil then return "CFrame" end
  if value.R ~= nil and value.G ~= nil and value.B ~= nil then return "Color3" end
  if value.Scale ~= nil and value.Offset ~= nil then return "UDim" end
  if value.X ~= nil and value.Y ~= nil and value.X.Scale ~= nil then return "UDim2" end
  if value.ClassName ~= nil then return "Instance" end
  return "table"
end

-- Instance table must exist before Instance.new (else: attempt to index nil with 'new')
Instance = Instance or {}
local __btCreatable = {
  Part = true, MeshPart = true, Model = true, Folder = true, Script = true, LocalScript = true, ModuleScript = true,
  Sound = true, Texture = true, WeldConstraint = true, Motor6D = true,
  BindableEvent = true, BindableFunction = true, RemoteEvent = true, RemoteFunction = true,
  Humanoid = true, Camera = true, BlurEffect = true, ColorCorrectionEffect = true, BloomEffect = true,
  SunLight = true,
  PointLight = true, SpotLight = true, SurfaceLight = true,
  ScreenGui = true, SurfaceGui = true, BillboardGui = true,
  Frame = true, ScrollingFrame = true, TextLabel = true, ImageLabel = true,
  TextButton = true, ImageButton = true, TextBox = true,
  UICorner = true, UIListLayout = true, UIStroke = true, UIPadding = true,
  UIGridLayout = true, UIAspectRatioConstraint = true
}
function Instance.new(className, parent)
  className = tostring(className or "Folder")
  if className == "Blur" then className = "BlurEffect" end
  if className == "ColorCorrection" then className = "ColorCorrectionEffect" end
  if className == "Bloom" then className = "BloomEffect" end
  local id = tostring(math.random(1, 1000000000))
  -- Stable path leaf: never changes when script sets .Name (that was breaking Size/Color updates)
  local stableName = "__rt_" .. id
  local parentPath = "game/Workspace"
  if parent ~= nil then
    local pv = __buildingToolValues[parent]
    if pv and type(pv.__Path) == "string" and pv.__Path ~= "" then
      parentPath = pv.__Path
    end
  end
  local path = parentPath .. "/" .. stableName
  local inst = __buildingToolInstance(className, path, className)
  if type(inst) == "table" then
    local vals = __buildingToolValues[inst]
    if vals then
      vals.ClassName = className
      vals.Name = className
      vals.Parent = nil
      vals.__Path = path
    end
    if parent ~= nil then
      __buildingToolAddChild(parent, inst)
      inst.Parent = parent
      if vals then vals.Parent = parent end
    end
    if __btCreatable[className] or className == "SpawnLocation" then
      __buildingToolPrint("__BUILDING_TOOL_CREATE__" .. __buildingToolEncode(className) .. "|" .. __buildingToolEncode(stableName) .. "|" .. __buildingToolEncode(parentPath))
    end
  end
  return inst
end

-- Humanoid helpers (proxy methods via metatable values when present)
function __buildingToolHumanoidMove(humanoid, walkDirection, relativeToCamera)
  if humanoid == nil then return end
  local vals = __buildingToolValues[humanoid]
  if vals then vals.MoveDirection = walkDirection end
end
function __buildingToolHumanoidTakeDamage(humanoid, amount)
  if humanoid == nil then return end
  local vals = __buildingToolValues[humanoid]
  if vals and vals.Health ~= nil then
    vals.Health = math.max(0, (vals.Health or 100) - (amount or 0))
  end
end

-- Players service helpers
Players = game:GetService("Players") or game.Players
Lighting = game:GetService("Lighting") or game.Lighting
ReplicatedStorage = game:GetService("ReplicatedStorage") or game.ReplicatedStorage
ServerStorage = game:GetService("ServerStorage") or game.ServerStorage
ServerScriptService = game:GetService("ServerScriptService") or game.ServerScriptService
StarterGui = game:GetService("StarterGui") or game.StarterGui
StarterPack = game:GetService("StarterPack") or game.StarterPack
StarterPlayer = game:GetService("StarterPlayer") or game.StarterPlayer
SoundService = game:GetService("SoundService") or game.SoundService
TweenService = game:GetService("TweenService") or game.TweenService
UserInputService = game:GetService("UserInputService") or game.UserInputService

-- RunService API table (always a real table with methods — never nil).
-- Use: RunService:IsClient()  RunService:IsServer()  RunService:IsStudio()  (need parentheses)
-- game:GetService("RunService") returns this same table.
RunService = {}
local function __btMakeRSSignal()
  local signal = { _handlers = {} }
  function signal:Connect(fn)
    if type(fn) ~= "function" then return { Disconnect = function() end, Connected = false } end
    local entry = { fn = fn, once = false }
    table.insert(self._handlers, entry)
    local sig = self
    return {
      Connected = true,
      Disconnect = function()
        for i = #sig._handlers, 1, -1 do
          if sig._handlers[i] == entry then table.remove(sig._handlers, i) break end
        end
      end
    }
  end
  function signal:Once(fn)
    if type(fn) ~= "function" then return { Disconnect = function() end, Connected = false } end
    local entry = { fn = fn, once = true }
    table.insert(self._handlers, entry)
    local sig = self
    return {
      Connected = true,
      Disconnect = function()
        for i = #sig._handlers, 1, -1 do
          if sig._handlers[i] == entry then table.remove(sig._handlers, i) break end
        end
      end
    }
  end
  function signal:Fire(...)
    local args = table.pack(...)
    local i = 1
    while i <= #self._handlers do
      local h = self._handlers[i]
      local ok, err = pcall(h.fn, table.unpack(args, 1, args.n))
      if not ok then warn("[RunService]", err) end
      if h.once then table.remove(self._handlers, i) else i += 1 end
    end
  end
  return signal
end
RunService.Heartbeat = __btMakeRSSignal()
RunService.RenderStepped = __btMakeRSSignal()
RunService.Stepped = __btMakeRSSignal()
-- Boolean *functions* — call with parentheses: RunService:IsClient()
function RunService:IsClient() return __buildingToolIsClient == true end
function RunService:IsServer() return __buildingToolIsClient ~= true end
function RunService:IsStudio() return true end
function RunService:IsRunning() return true end
-- Also expose as plain functions on the table (RunService.IsClient()) for both call styles
RunService.IsClient = RunService.IsClient
RunService.IsServer = RunService.IsServer
RunService.IsStudio = RunService.IsStudio
RunService.IsRunning = RunService.IsRunning

function __buildingToolFireRunService(dt)
  dt = dt or 0
  if RunService.RenderStepped then RunService.RenderStepped:Fire(dt) end
  if RunService.Stepped then RunService.Stepped:Fire(0, dt) end
  if RunService.Heartbeat then RunService.Heartbeat:Fire(dt) end
end

-- TweenService driven by RunService.Heartbeat (reliable; no task.spawn dependency)
TweenService = {}
local function __btLerp(a, b, t)
  if type(a) == "number" and type(b) == "number" then return a + (b - a) * t end
  if type(a) == "table" and type(b) == "table" then
    if a.R ~= nil and b.R ~= nil then
      return Color3.new(
        (a.R or 0) + ((b.R or 0) - (a.R or 0)) * t,
        (a.G or 0) + ((b.G or 0) - (a.G or 0)) * t,
        (a.B or 0) + ((b.B or 0) - (a.B or 0)) * t)
    end
    if a.X ~= nil and b.X ~= nil then
      if a.Z ~= nil or b.Z ~= nil then
        return Vector3.new(
          (a.X or 0) + ((b.X or 0) - (a.X or 0)) * t,
          (a.Y or 0) + ((b.Y or 0) - (a.Y or 0)) * t,
          (a.Z or 0) + ((b.Z or 0) - (a.Z or 0)) * t)
      end
      return Vector2.new(
        (a.X or 0) + ((b.X or 0) - (a.X or 0)) * t,
        (a.Y or 0) + ((b.Y or 0) - (a.Y or 0)) * t)
    end
  end
  if t < 1 then return a else return b end
end
function TweenService:Create(instance, info, goals)
  local duration = 1
  if type(info) == "table" then
    duration = info.Time or info.time or 1
  elseif type(info) == "number" then
    duration = info
  end
  if duration < 0.01 then duration = 0.01 end
  local state = { cancelled = false, conn = nil, playing = false }
  local tween = {}
  function tween:Play()
    if instance == nil or goals == nil or state.playing then return end
    state.playing = true
    state.cancelled = false
    local startVals = {}
    for k, _ in pairs(goals) do
      startVals[k] = instance[k]
    end
    local t0 = tick()
    state.conn = RunService.Heartbeat:Connect(function()
      if state.cancelled then
        if state.conn then state.conn:Disconnect() end
        state.playing = false
        return
      end
      local a = (tick() - t0) / duration
      if a >= 1 then a = 1 end
      for k, goal in pairs(goals) do
        pcall(function()
          instance[k] = __btLerp(startVals[k], goal, a)
        end)
      end
      if a >= 1 then
        state.cancelled = true
        if state.conn then state.conn:Disconnect() end
        state.playing = false
      end
    end)
  end
  function tween:Cancel()
    state.cancelled = true
    if state.conn then state.conn:Disconnect() end
    state.playing = false
  end
  function tween:Pause() end
  function tween:Destroy() tween:Cancel() end
  return tween
end

function wait(seconds) return task.wait(seconds) end
function delay(seconds, callback) return task.delay(seconds, callback) end
function spawn(callback) return task.spawn(callback) end

-- settings stub
settings = settings or function() return { Studio = {} } end

-- plugin / shared stubs safe no-ops
shared = shared or {}
_G = _G or {}
)LUA";


    return definitions;
}

void stopRuntime()
{
    // Stop simulation first so physics/animation/input cannot touch freeing objects.
    runtimePlaying = false;
    runtimeClientMode = false;

    runtimeLuauCoroutines.clear();
    if (runtimeLuauState != nullptr)
    {
        lua_close(runtimeLuauState);
        runtimeLuauState = nullptr;
    }

    for (const auto& snapshot : runtimeSourceSnapshot)
    {
        if (snapshot.first != nullptr)
            snapshot.first->source = snapshot.second;
    }
    runtimeSourceSnapshot.clear();

    clearRuntimeSounds();

    // Destroy instances spawned via Instance.new during this Play session (parents first order inverted)
    // Walk from end so children listed after parents still get cleaned safely via tree destroy.
    selectedInstances.erase(
        remove_if(selectedInstances.begin(), selectedInstances.end(),
            [&](Instance* i) {
                return find(runtimeCreatedInstances.begin(), runtimeCreatedInstances.end(), i)
                    != runtimeCreatedInstances.end();
            }),
        selectedInstances.end());
    if (find(runtimeCreatedInstances.begin(), runtimeCreatedInstances.end(), hoveredInstance)
        != runtimeCreatedInstances.end())
        hoveredInstance = nullptr;
    if (find(runtimeCreatedInstances.begin(), runtimeCreatedInstances.end(), renamingInstance)
        != runtimeCreatedInstances.end())
        renamingInstance = nullptr;

    // Sort so parents are destroyed once: only destroy roots (not parented to another created)
    vector<Instance*> roots;
    for (Instance* created : runtimeCreatedInstances)
    {
        if (created == nullptr) continue;
        bool parentAlsoCreated = false;
        Instance* p = created->parent;
        while (p != nullptr)
        {
            if (find(runtimeCreatedInstances.begin(), runtimeCreatedInstances.end(), p)
                != runtimeCreatedInstances.end())
            {
                parentAlsoCreated = true;
                break;
            }
            p = p->parent;
        }
        if (!parentAlsoCreated)
            roots.push_back(created);
    }
    for (Instance* root : roots)
    {
        removeInstanceFromParent(root);
        destroyInstanceTree(root);
    }
    runtimeCreatedInstances.clear();
    runtimePathToInstance.clear();

    restoreRuntimeInstanceState();

    // Drop any editor selection / hover that points into the runtime tree
    // (dangling pointers were a common stop-time crash).
    auto isRuntimeInstance = [&](Instance* inst) -> bool
    {
        while (inst != nullptr)
        {
            if (inst == runtimeCharacter || inst == runtimePlayer || inst == runtimeCameraInstance)
                return true;
            inst = inst->parent;
        }
        return false;
    };
    if (isRuntimeInstance(hoveredInstance))
        hoveredInstance = nullptr;
    selectedInstances.erase(
        remove_if(selectedInstances.begin(), selectedInstances.end(),
            [&](Instance* i) { return i == nullptr || isRuntimeInstance(i); }),
        selectedInstances.end());
    if (renamingInstance != nullptr && isRuntimeInstance(renamingInstance))
        renamingInstance = nullptr;

    // Null cross-refs before free
    if (runtimePlayer != nullptr)
    {
        runtimePlayer->character = nullptr;
        runtimePlayer->camera = nullptr;
    }
    if (runtimeCameraInstance != nullptr)
        runtimeCameraInstance->target = nullptr;
    runtimeHumanoid = nullptr;

    if (runtimeCameraInstance != nullptr)
    {
        removeInstanceFromParent(runtimeCameraInstance);
        destroyInstanceTree(runtimeCameraInstance);
        runtimeCameraInstance = nullptr;
    }
    if (runtimeCharacter != nullptr)
    {
        removeInstanceFromParent(runtimeCharacter);
        destroyInstanceTree(runtimeCharacter);
        runtimeCharacter = nullptr;
    }
    if (runtimePlayer != nullptr)
    {
        removeInstanceFromParent(runtimePlayer);
        destroyInstanceTree(runtimePlayer);
        runtimePlayer = nullptr;
    }

    runtimeStatus = "Stopped - runtime state reset";
    addOutputLog("[Luau] stopped; instance and script state restored");
}

void createRuntimePlayerCharacter()
{
    runtimeCharacter = new Model_Instance();
    runtimeCharacter->name = "Character";
    addInstanceToParent(&workspace, runtimeCharacter);

    auto makePart = [&](const string& name, Vector3 size, Vector3 position, Color color)
    {
        Part* part = new Part();
        part->name = name;
        part->size = size;
        part->cframe.position = position;
        part->color = color;
        // Unanchored so physics + Motor6D drive the character.
        // ONLY the torso collides — limbs are kinematic Motor6D slaves (no collide)
        // so feet don't fight the floor solver or sink the root.
        part->anchored = false;
        part->canCollide = (name == "Torso");
        part->velocity = { 0, 0, 0 };
        part->angularVelocity = { 0, 0, 0 };
        addInstanceToParent(runtimeCharacter, part);
        return part;
    };

    // R6-ish proportions. Initial positions are overwritten by Motor6D each step.
    // Motor formula: part1.pos = part0.pos + R*(C0) - R*(C1)  (see physic.h)
    Part* root = makePart("Torso", { 2, 2, 1 }, { 0, 5, 0 }, { 70, 120, 210, 255 });
    Part* head = makePart("Head", { 1, 1, 1 }, { 0, 6.5f, 0 }, { 245, 205, 160, 255 });
    Part* leftArm = makePart("Left Arm", { 1, 2, 1 }, { -1.5f, 5, 0 }, { 245, 205, 160, 255 });
    Part* rightArm = makePart("Right Arm", { 1, 2, 1 }, { 1.5f, 5, 0 }, { 245, 205, 160, 255 });
    Part* leftLeg = makePart("Left Leg", { 1, 2, 1 }, { -0.5f, 3, 0 }, { 45, 65, 150, 255 });
    Part* rightLeg = makePart("Right Leg", { 1, 2, 1 }, { 0.5f, 3, 0 }, { 45, 65, 150, 255 });

    // Roblox Motor6D rest pose: Part1 = Part0 * C0 * C1:Inverse()
    // Animation writes motor->transform (like Animate sets Motor6D.Transform).
    auto makeMotor = [&](const string& name, Part* child, Vector3 c0Pos, Vector3 c1Pos)
    {
        Motor6DConstraint* motor = new Motor6DConstraint();
        motor->name = name;
        motor->part0 = root;
        motor->part1 = child;
        motor->c0.position = c0Pos;
        motor->c0.rotation = { 0, 0, 0 };
        motor->c1.position = c1Pos;
        motor->c1.rotation = { 0, 0, 0 };
        motor->transform = { { 0, 0, 0 }, { 0, 0, 0 } };
        motor->desiredAngle = 0.0f;
        motor->currentAngle = 0.0f;
        motor->maxVelocity = 0.0f;
        motor->enabled = true;
        addInstanceToParent(runtimeCharacter, motor);
    };
    // Attachment points only (no C0 twist hacks)
    makeMotor("Neck", head, { 0, 1.0f, 0 }, { 0, -0.5f, 0 });
    makeMotor("Left Shoulder", leftArm, { -1.0f, 0.5f, 0 }, { 0.5f, 0.5f, 0 });
    makeMotor("Right Shoulder", rightArm, { 1.0f, 0.5f, 0 }, { -0.5f, 0.5f, 0 });
    makeMotor("Left Hip", leftLeg, { -0.5f, -1.0f, 0 }, { 0, 1.0f, 0 });
    makeMotor("Right Hip", rightLeg, { 0.5f, -1.0f, 0 }, { 0, 1.0f, 0 });

    runtimeHumanoid = new HumanoidInstance();
    runtimeHumanoid->name = "Humanoid";
    runtimeHumanoid->rootPart = root;
    runtimeHumanoid->hipHeight = 3.0f; // ground → torso center (1 half-torso + 2 leg)
    runtimeHumanoid->jumpPower = 50.0f;
    runtimeHumanoid->walkSpeed = 16.0f;
    addInstanceToParent(runtimeCharacter, runtimeHumanoid);

    runtimeCameraInstance = new CameraInstance();
    runtimeCameraInstance->name = "Camera";
    runtimeCameraInstance->target = runtimeHumanoid;
    addInstanceToParent(&workspace, runtimeCameraInstance);
    runtimePlayer->character = runtimeCharacter;
    runtimePlayer->camera = runtimeCameraInstance;
}

void updateRuntimePlayerCamera(Camera3D& camera, float dt)
{
    if (!runtimeClientMode || runtimeHumanoid == nullptr || runtimeHumanoid->rootPart == nullptr)
        return;

    Part* root = runtimeHumanoid->rootPart;
    static float orbitYaw = 0.65f;
    static float orbitPitch = 0.45f;
    static float orbitDistance = 12.0f;

    if (runtimeHumanoid->climbing)
    {
        // Climbing a Truss part or squeezed into a tight gap: gravity is
        // suspended by taking direct control of vertical velocity (W = up,
        // S = down) instead of letting updateBasicPhysics() integrate it.
        // Horizontal drift is locked out so the character stays pinned to
        // the surface. Space jumps off, pushing the character back away
        // from the surface (climbNormal) and ending the climb.
        float vertical = 0.0f;
        if (IsKeyDown(KEY_W)) vertical += 1.0f;
        if (IsKeyDown(KEY_S)) vertical -= 1.0f;

        root->velocity.x = 0.0f;
        root->velocity.z = 0.0f;
        root->velocity.y = vertical * runtimeHumanoid->walkSpeed;
        root->angularVelocity = { 0, 0, 0 };

        if (IsKeyPressed(KEY_SPACE))
        {
            float pushSpeed = max(6.0f, runtimeHumanoid->walkSpeed * 0.9f);
            Vector3 pushBack = Vector3Scale(runtimeHumanoid->climbNormal, pushSpeed);
            root->velocity = { pushBack.x, max(8.0f, runtimeHumanoid->jumpPower * 0.6f), pushBack.z };
            runtimeHumanoid->climbing = false;
            runtimeHumanoid->grounded = false;
        }
    }
    else
    {
        // Camera-relative horizontal input (WASD). Physics integrates position.
        Vector3 wish = { 0, 0, 0 };
        if (IsKeyDown(KEY_W)) wish.z -= 1.0f;
        if (IsKeyDown(KEY_S)) wish.z += 1.0f;
        if (IsKeyDown(KEY_A)) wish.x -= 1.0f;
        if (IsKeyDown(KEY_D)) wish.x += 1.0f;

        // Rotate wish by orbit yaw so movement follows look direction on XZ.
        float cy = cosf(orbitYaw);
        float sy = sinf(orbitYaw);
        Vector3 worldWish = {
            wish.x * cy + wish.z * sy,
            0.0f,
            -wish.x * sy + wish.z * cy
        };
        if (Vector3Length(worldWish) > 0.001f)
            worldWish = Vector3Normalize(worldWish);

        float speed = runtimeHumanoid->walkSpeed;
        // Preserve vertical velocity from gravity / jump; drive horizontal from input.
        float vy = root->velocity.y;
        root->velocity.x = worldWish.x * speed;
        root->velocity.z = worldWish.z * speed;
        root->velocity.y = vy;

        // Jump: Space while grounded (grounded already accounts for SlopeAngle —
        // too-steep ground is reported as not grounded, so jump/standing-still
        // naturally isn't available there).
        if ((IsKeyPressed(KEY_SPACE) || (runtimeHumanoid->autoJump && IsKeyDown(KEY_SPACE)))
            && runtimeHumanoid->grounded)
        {
            root->velocity.y = runtimeHumanoid->jumpPower;
            runtimeHumanoid->grounded = false;
        }

        // Avatar root never tumbles — controller owns yaw only.
        root->angularVelocity = { 0, 0, 0 };
        Vector3 targetRotation = { 0.0f, root->cframe.rotation.y, 0.0f };

        // Face movement direction (not camera look) — only when actually walking
        if (Vector3Length(worldWish) > 0.001f)
        {
            float faceYaw = atan2f(worldWish.x, worldWish.z) * RAD2DEG;
            targetRotation.y = faceYaw;
        }
        root->cframe.rotation = lerpRotation(root->cframe.rotation, targetRotation,
            std::clamp(dt * 8.0f, 0.0f, 1.0f));
    }

    if (runtimeCameraInstance != nullptr && runtimeCameraInstance->mode == BT_CameraMode::Scriptable)
    {
        camera.position = runtimeCameraInstance->cframe.position;
        camera.target = Vector3Add(camera.position, GetUpDirection(runtimeCameraInstance->cframe.rotation));
        return;
    }

    if (IsMouseButtonDown(MOUSE_BUTTON_RIGHT))
    {
        Vector2 mouseDelta = GetMouseDelta();
        orbitYaw -= mouseDelta.x * 0.005f;
        orbitPitch = Clamp(orbitPitch + mouseDelta.y * 0.005f, -1.35f, 1.35f);
    }
    float wheel = isZoneFocused(FocusZone::Viewport) ? GetMouseWheelMove() : 0.0f;
    if (wheel != 0.0f)
        orbitDistance = Clamp(orbitDistance - wheel * 1.5f, 4.0f, 40.0f);

    Vector3 target = root->cframe.position;
    Vector3 desiredPosition = Vector3Add(target, {
        cosf(orbitPitch) * sinf(orbitYaw) * orbitDistance,
        sinf(orbitPitch) * orbitDistance,
        cosf(orbitPitch) * cosf(orbitYaw) * orbitDistance
    });
    camera.position = Vector3Lerp(camera.position, desiredPosition, std::clamp(dt * 8.0f, 0.0f, 1.0f));
    camera.target = Vector3Lerp(camera.target, Vector3Add(target, { 0, 2.0f, 0 }),
        std::clamp(dt * 10.0f, 0.0f, 1.0f));
}


void updateCharacterAnimation(float dt)
{
    // Animate through Motor6D.Transform so limbs remain attached to the torso.
    if (!runtimePlaying || !runtimeClientMode || runtimeCharacter == nullptr || runtimeHumanoid == nullptr)
        return;
    Part* root = runtimeHumanoid->rootPart;
    if (root == nullptr)
        return;

    static float walkPhase = 0.0f;
    bool hasMoveInput = IsKeyDown(KEY_W) || IsKeyDown(KEY_A) ||
        IsKeyDown(KEY_S) || IsKeyDown(KEY_D);
    float horizontalSpeed = hasMoveInput ? runtimeHumanoid->walkSpeed : 0.0f;
    bool walking = runtimeHumanoid->grounded && horizontalSpeed > 0.8f &&
        !runtimeHumanoid->climbing;
    if (walking)
        walkPhase += dt * std::clamp(horizontalSpeed * 0.55f, 4.0f, 14.0f);
    else
        walkPhase *= (1.0f - std::min(1.0f, dt * 10.0f));

    float swingDegrees = walking ? sinf(walkPhase) * 42.0f : 0.0f;
    float armDegrees = -swingDegrees * 0.85f;
    float bobDegrees = walking ? sinf(walkPhase * 2.0f) * 4.0f : 0.0f;
    auto setMotorTransform = [&](const char* name, Vector3 rotation)
    {
        for (Instance* child : runtimeCharacter->children)
        {
            if (child == nullptr || child->getType() != InstanceType::Motor6D || child->name != name)
                continue;
            auto* motor = static_cast<Motor6DConstraint*>(child);
            motor->transform.position = { 0, 0, 0 };
            motor->transform.rotation = rotation;
            motor->desiredAngle = 0.0f;
            motor->currentAngle = 0.0f;
            return;
        }
    };

    // Walk animation stays in the rig's local forward plane. Deriving limb
    // axes from world velocity made the offsets jump while the root was turning.
    setMotorTransform("Left Hip", { swingDegrees, 0.0f, walking ? 4.0f : 0.0f });
    setMotorTransform("Right Hip", { -swingDegrees, 0.0f, walking ? -4.0f : 0.0f });
    setMotorTransform("Left Shoulder", { armDegrees, 0.0f, 0.0f });
    setMotorTransform("Right Shoulder", { -armDegrees, 0.0f, 0.0f });
    setMotorTransform("Neck", { bobDegrees * 0.25f, 0.0f, 0.0f });
}

void queueRuntimeLuauCoroutine(lua_State* thread, const string& label, double resumeAt, int resumeArguments)
{
    runtimeLuauCoroutines.push_back({ thread, label, resumeAt, resumeArguments });
}

int runtimeTaskSchedule(lua_State* state, double delay, const char* label)
{
    if (runtimeLuauState == nullptr)
        return 0;

    if (!lua_isfunction(state, 1))
    {
        luaL_error(state, "task.%s expects a function as the first argument", label);
        return 0;
    }

    int argumentCount = lua_gettop(state) - 1;
    lua_State* thread = lua_newthread(runtimeLuauState);
    if (thread == nullptr)
    {
        luaL_error(state, "could not create Luau task coroutine");
        return 0;
    }

    // Move callback + extra args onto the new thread (callback at index 1)
    lua_pushvalue(state, 1);
    lua_xmove(state, thread, 1);
    for (int index = 2; index <= argumentCount + 1; ++index)
    {
        lua_pushvalue(state, index);
        lua_xmove(state, thread, 1);
    }

    queueRuntimeLuauCoroutine(thread, string("task.") + label, GetTime() + max(0.0, delay), argumentCount);
    return 0;
}

int runtimeTaskSpawn(lua_State* state)
{
    return runtimeTaskSchedule(state, 0.0, "spawn");
}

int runtimeTaskDefer(lua_State* state)
{
    return runtimeTaskSchedule(state, 0.0, "defer");
}

int runtimeTaskDelay(lua_State* state)
{
    double delay = luaL_checknumber(state, 1);
    if (!lua_isfunction(state, 2))
    {
        luaL_error(state, "task.delay expects a function as the second argument");
        return 0;
    }

    // Shift the callback and its arguments into the same layout expected by runtimeTaskSchedule.
    lua_remove(state, 1);
    return runtimeTaskSchedule(state, delay, "delay");
}


int runtimeLuauClock(lua_State* state)
{
    lua_pushnumber(state, GetTime());
    return 1;
}
int runtimeLuauPrint(lua_State* state)
{
    int count = lua_gettop(state);
    string line;
    for (int index = 1; index <= count; ++index)
    {
        size_t length = 0;
        const char* value = luaL_tolstring(state, index, &length);
        if (!line.empty())
            line += '\t';
        if (value != nullptr)
            line.append(value, length);
        lua_pop(state, 1);
    }
    // Host protocol may be buried after a print-trace prefix ("src:line:\t__BUILDING_TOOL_…").
    // Search the whole line so Instance.new / .Name / .Parent are not skipped.
    auto extractHostCmd = [&](const string& prefix) -> string
    {
        size_t pos = line.find(prefix);
        if (pos == string::npos) return {};
        return line.substr(pos + prefix.size());
    };
    string cmd;
    if (!(cmd = extractHostCmd(RUNTIME_PROPERTY_UPDATE_PREFIX)).empty())
    {
        applyRuntimePropertyUpdate(cmd);
    }
    else if (!(cmd = extractHostCmd(RUNTIME_SOUND_CMD_PREFIX)).empty())
    {
        applyRuntimeSoundCommand(cmd);
        addOutputLog("[Runtime] sound " + cmd);
    }
    else if (!(cmd = extractHostCmd(RUNTIME_CREATE_PREFIX)).empty())
    {
        applyRuntimeCreateCommand(cmd);
        addOutputLog("[Runtime] create " + cmd);
    }
    else if (!line.empty())
        addOutputLog(line);
    return 0;
}

int runtimeLuauWarn(lua_State* state)
{
    int count = lua_gettop(state);
    string line;
    for (int index = 1; index <= count; ++index)
    {
        size_t length = 0;
        const char* value = luaL_tolstring(state, index, &length);
        if (!line.empty())
            line += '\t';
        if (value != nullptr)
            line.append(value, length);
        lua_pop(state, 1);
    }
    if (line.empty())
        line = "(warn)";
    addOutputLog("[Warning] " + line);
    return 0;
}


// Forward decl — definition later in this header
Part* raycastParts(Instance* instance, Ray ray, float& closestDistance);
Part* raycastParts(Instance* instance, Ray ray, float& closestDistance,
    const unordered_set<const Instance*>* filter, bool includeFilter,
    bool includeLocked = false);

// --- Host raycast / projection (3D, 3D→2D, 2D→3D) ---
static Vector3 luaToVec3(lua_State* state, int idx)
{
    Vector3 v = { 0, 0, 0 };
    if (!lua_istable(state, idx)) return v;
    lua_getfield(state, idx, "X"); if (lua_isnumber(state, -1)) v.x = (float)lua_tonumber(state, -1); lua_pop(state, 1);
    lua_getfield(state, idx, "Y"); if (lua_isnumber(state, -1)) v.y = (float)lua_tonumber(state, -1); lua_pop(state, 1);
    lua_getfield(state, idx, "Z"); if (lua_isnumber(state, -1)) v.z = (float)lua_tonumber(state, -1); lua_pop(state, 1);
    return v;
}

static void luaPushVec3(lua_State* state, Vector3 v)
{
    lua_createtable(state, 0, 3);
    lua_pushnumber(state, v.x); lua_setfield(state, -2, "X");
    lua_pushnumber(state, v.y); lua_setfield(state, -2, "Y");
    lua_pushnumber(state, v.z); lua_setfield(state, -2, "Z");
}

static void luaPushVec2(lua_State* state, Vector2 v)
{
    lua_createtable(state, 0, 2);
    lua_pushnumber(state, v.x); lua_setfield(state, -2, "X");
    lua_pushnumber(state, v.y); lua_setfield(state, -2, "Y");
}

// workspace:Raycast(origin, direction, params?) → RaycastResult | nil
int runtimeLuauWorkspaceRaycast(lua_State* state)
{
    // The Luau wrapper removes the workspace self argument before entering C++.
    if (!lua_istable(state, 1) || !lua_istable(state, 2))
    {
        lua_pushnil(state);
        return 1;
    }
    Vector3 origin = luaToVec3(state, 1);
    Vector3 direction = luaToVec3(state, 2);

    float maxDist = Vector3Length(direction);
    if (maxDist < 1e-6f)
    {
        lua_pushnil(state);
        return 1;
    }
    Vector3 dirN = Vector3Normalize(direction);
    Ray ray = { origin, dirN };
    float closest = maxDist;
    unordered_set<const Instance*> filterInstances;
    bool includeFilter = false;
    if (lua_istable(state, 3))
    {
        lua_getfield(state, 3, "FilterType");
        if (lua_isstring(state, -1))
        {
            const char* filterType = lua_tostring(state, -1);
            includeFilter = filterType != nullptr &&
                (string(filterType) == "Include" || string(filterType) == "Whitelist");
        }
        lua_pop(state, 1);

        lua_getfield(state, 3, "FilterDescendantsInstances");
        if (lua_istable(state, -1))
        {
            int listIndex = lua_gettop(state);
            int count = lua_objlen(state, listIndex);
            for (int i = 1; i <= count; ++i)
            {
                lua_rawgeti(state, listIndex, i);
                if (lua_istable(state, -1))
                {
                    lua_getfield(state, -1, "__Path");
                    if (lua_isstring(state, -1))
                    {
                        const char* path = lua_tostring(state, -1);
                        if (path != nullptr)
                        {
                            Instance* filterRoot = findInstanceByRuntimePath(path);
                            if (filterRoot != nullptr)
                            {
                                function<void(const Instance*)> addDescendants =
                                    [&](const Instance* current)
                                {
                                    if (current == nullptr ||
                                        !filterInstances.insert(current).second)
                                        return;
                                    for (const Instance* child : current->children)
                                        addDescendants(child);
                                };
                                addDescendants(filterRoot);
                            }
                        }
                    }
                    lua_pop(state, 1);
                }
                lua_pop(state, 1);
            }
        }
        lua_pop(state, 1);
    }

    Part* hit = raycastParts(&workspace, ray, closest,
        &filterInstances, includeFilter, true);
    if (hit == nullptr || closest > maxDist)
    {
        lua_pushnil(state);
        return 1;
    }
    Vector3 pos = Vector3Add(origin, Vector3Scale(dirN, closest));
    // Approximate normal from which face is closest (axis-aligned in local space is hard; use up for now from hit direction)
    Vector3 normal = { 0, 1, 0 };
    {
        Vector3 toCenter = Vector3Subtract(pos, hit->cframe.position);
        float ax = fabsf(toCenter.x) / max(0.001f, hit->size.x * 0.5f);
        float ay = fabsf(toCenter.y) / max(0.001f, hit->size.y * 0.5f);
        float az = fabsf(toCenter.z) / max(0.001f, hit->size.z * 0.5f);
        if (ax >= ay && ax >= az) normal = { (toCenter.x >= 0 ? 1.f : -1.f), 0, 0 };
        else if (ay >= ax && ay >= az) normal = { 0, (toCenter.y >= 0 ? 1.f : -1.f), 0 };
        else normal = { 0, 0, (toCenter.z >= 0 ? 1.f : -1.f) };
    }
    lua_createtable(state, 0, 5);
    luaPushVec3(state, pos); lua_setfield(state, -2, "Position");
    luaPushVec3(state, normal); lua_setfield(state, -2, "Normal");
    lua_pushnumber(state, closest); lua_setfield(state, -2, "Distance");
    lua_pushstring(state, getInstancePath(hit).c_str()); lua_setfield(state, -2, "InstancePath");
    lua_pushstring(state, hit->name.c_str()); lua_setfield(state, -2, "InstanceName");
    return 1;
}

// Camera:WorldToScreenPoint(worldPos) → Vector3(x,y,depth)  (3D→2D)
int runtimeLuauWorldToScreenPoint(lua_State* state)
{
    Vector3 world = { 0, 0, 0 };
    if (lua_istable(state, 1) && lua_istable(state, 2))
        world = luaToVec3(state, 2); // self, pos
    else if (lua_istable(state, 1))
        world = luaToVec3(state, 1);
    Camera3D cam = viewportCameraValid ? viewportCamera : (Camera3D){ 0 };
    if (!viewportCameraValid)
    {
        luaPushVec3(state, { 0, 0, 0 });
        return 1;
    }
    Vector2 screen = GetWorldToScreen(world, cam);
    // Depth: distance along camera forward
    Vector3 forward = Vector3Normalize(Vector3Subtract(cam.target, cam.position));
    float depth = Vector3DotProduct(Vector3Subtract(world, cam.position), forward);
    lua_createtable(state, 0, 3);
    lua_pushnumber(state, screen.x); lua_setfield(state, -2, "X");
    lua_pushnumber(state, screen.y); lua_setfield(state, -2, "Y");
    lua_pushnumber(state, depth); lua_setfield(state, -2, "Z");
    return 1;
}

// Camera:ScreenPointToRay(x, y, depth?) → Ray  (2D→3D)
int runtimeLuauScreenPointToRay(lua_State* state)
{
    float x = 0, y = 0;
    int idx = 1;
    if (lua_istable(state, 1) && (lua_isnumber(state, 2) || lua_isnumber(state, 3)))
        idx = 2; // self
    if (lua_isnumber(state, idx)) x = (float)lua_tonumber(state, idx);
    if (lua_isnumber(state, idx + 1)) y = (float)lua_tonumber(state, idx + 1);
    Camera3D cam = viewportCameraValid ? viewportCamera : (Camera3D){ 0 };
    if (!viewportCameraValid)
    {
        lua_createtable(state, 0, 2);
        luaPushVec3(state, { 0, 0, 0 }); lua_setfield(state, -2, "Origin");
        luaPushVec3(state, { 0, -1, 0 }); lua_setfield(state, -2, "Direction");
        return 1;
    }
    Ray ray = GetMouseRay({ x, y }, cam);
    // GetMouseRay direction is unit length; Roblox Direction is unit * far — keep unit
    lua_createtable(state, 0, 2);
    luaPushVec3(state, ray.position); lua_setfield(state, -2, "Origin");
    luaPushVec3(state, ray.direction); lua_setfield(state, -2, "Direction");
    return 1;
}

// Camera:ViewportPointToRay(x, y) same as Screen for our single-viewport setup
int runtimeLuauViewportPointToRay(lua_State* state)
{
    return runtimeLuauScreenPointToRay(state);
}

bool loadRuntimeLuauChunk(lua_State* thread, const string& name, const string& source)
{
    lua_CompileOptions options = {};
    options.debugLevel = 1;   // line info for accurate error locations
    options.coverageLevel = 0;
    size_t bytecodeSize = 0;
    char* bytecode = luau_compile(source.c_str(), source.size(), &options, &bytecodeSize);
    int result = luau_load(thread, name.c_str(), bytecode, bytecodeSize, 0);
    free(bytecode);
    if (result != LUA_OK)
    {
        const char* error = lua_tostring(thread, -1);
        string errText = error != nullptr ? error : "could not load Luau chunk";
        int ln = -1, col = -1;
        string msg = errText;
        parseLuauErrorLocation(errText, ln, col, msg);
        addOutputLog("[Error] [" + name + "] " + errText, ln, col, nullptr);
        lua_pop(thread, 1);
        return false;
    }
    return true;
}

string buildRuntimeScriptChunk(const Script* script, const string& source)
{
    string slashPath = getInstanceRuntimePath(const_cast<Script*>(script));
    string dottedPath = getInstancePath(script);
    return
        "do\n"
        "  local s = __buildingToolScriptByPath[\"" + escapeLuauString(slashPath) + "\"] "
        "or __buildingToolScriptByPath[\"" + escapeLuauString(dottedPath) + "\"]\n"
        "  if s == nil then\n"
        "    s = { Name = \"" + escapeLuauString(script->name) + "\", "
        "ClassName = \"" + escapeLuauString(scriptTypeName(script->type)) + "\", "
        "Enabled = " + string(script->enabled ? "true" : "false") + ", "
        "RunContext = \"" + escapeLuauString(script->runContextName()) + "\" }\n"
        "  end\n"
        "  script = s\n"
        "end\n" + source;
}

bool loadRuntimeLuauBytecodeChunk(lua_State* thread, const string& name,
    const string& encodedBytecode)
{
    vector<uint8_t> bytecode = base64Decode(encodedBytecode);
    if (bytecode.empty())
    {
        addOutputLog("[Error] [" + name + "] Exported Luau bytecode is empty or invalid.");
        return false;
    }
    int result = luau_load(thread, name.c_str(),
        reinterpret_cast<const char*>(bytecode.data()), bytecode.size(), 0);
    if (result != LUA_OK)
    {
        const char* error = lua_tostring(thread, -1);
        addOutputLog("[Error] [" + name + "] " +
            string(error != nullptr ? error : "could not load exported bytecode"));
        lua_pop(thread, 1);
        return false;
    }
    return true;
}

string compileScriptBytecodeForExport(const Script* script, bool& success)
{
    success = false;
    if (script == nullptr)
        return {};
    string source = script->source;
    sanitizeScriptSourceInPlace(source);
    string chunk = script->type == ScriptType::ModuleScript
        ? source : buildRuntimeScriptChunk(script, source);
    lua_CompileOptions options = {};
    options.debugLevel = 0;
    options.coverageLevel = 0;
    size_t bytecodeSize = 0;
    char* bytecode = luau_compile(chunk.c_str(), chunk.size(), &options, &bytecodeSize);
    if (bytecode == nullptr || bytecodeSize == 0)
    {
        free(bytecode);
        addOutputLog("[Error] Could not compile script for export: " + script->name);
        return {};
    }
    lua_State* validator = luaL_newstate();
    int loadResult = validator != nullptr
        ? luau_load(validator, script->name.c_str(), bytecode, bytecodeSize, 0)
        : LUA_ERRMEM;
    string result;
    if (loadResult == LUA_OK)
    {
        vector<uint8_t> bytes(bytecode, bytecode + bytecodeSize);
        result = base64Encode(bytes);
        success = true;
    }
    else
    {
        const char* error = validator != nullptr ? lua_tostring(validator, -1) : nullptr;
        addOutputLog("[Error] Could not compile script for export (" + script->name + "): " +
            string(error != nullptr ? error : "Luau compiler validation failed"));
    }
    if (validator != nullptr)
        lua_close(validator);
    free(bytecode);
    return result;
}

int runtimeLuauRunCompiledModule(lua_State* state)
{
    const char* encoded = lua_tostring(state, 1);
    if (encoded == nullptr)
    {
        lua_pushstring(state, "compiled ModuleScript has no bytecode");
        lua_error(state);
        return 0;
    }
    vector<uint8_t> bytecode = base64Decode(encoded);
    if (bytecode.empty())
    {
        lua_pushstring(state, "compiled ModuleScript bytecode is invalid");
        lua_error(state);
        return 0;
    }
    lua_State* thread = lua_newthread(state);
    int result = luau_load(thread, "[ModuleScript bytecode]",
        reinterpret_cast<const char*>(bytecode.data()), bytecode.size(), 0);
    if (result == LUA_OK)
        result = lua_pcall(thread, 0, LUA_MULTRET, 0);
    if (result != LUA_OK)
    {
        const char* error = lua_tostring(thread, -1);
        lua_pushstring(state, error != nullptr ? error : "compiled ModuleScript failed");
        lua_error(state);
        return 0;
    }
    int returnCount = lua_gettop(thread);
    lua_xmove(thread, state, returnCount);
    return returnCount;
}

// Physics lives in assets/Headers/physic.h (improved substeps, solid + dynamic contacts).
#include "../assets/Headers/physic.h"


void fireRuntimeRunService(float dt)
{
    if (!runtimePlaying || runtimeLuauState == nullptr)
        return;
    lua_getglobal(runtimeLuauState, "__buildingToolFireRunService");
    if (!lua_isfunction(runtimeLuauState, -1))
    {
        lua_pop(runtimeLuauState, 1);
        return;
    }
    lua_pushnumber(runtimeLuauState, dt);
    if (lua_pcall(runtimeLuauState, 1, 0, 0) != LUA_OK)
    {
        const char* err = lua_tostring(runtimeLuauState, -1);
        addOutputLog(string("[Error] RunService: ") + (err ? err : "unknown"));
        lua_pop(runtimeLuauState, 1);
    }
}

void updateRuntimeLuauScheduler()
{
    if (!runtimePlaying || runtimeLuauState == nullptr)
        return;

    const double now = GetTime();
    
    for (size_t index = 0; index < runtimeLuauCoroutines.size();)
    {
        if (now < runtimeLuauCoroutines[index].resumeAt)
        {
            ++index;
            continue;
        }

        // Copy the thread data before lua_resume: the script can call task.spawn/defer/delay,
        // which may append to runtimeLuauCoroutines and reallocate the vector.
        lua_State* thread = runtimeLuauCoroutines[index].thread;
        string label = runtimeLuauCoroutines[index].label;
        int arguments = runtimeLuauCoroutines[index].resumeArguments;
        runtimeLuauCoroutines[index].resumeArguments = 0;

        int result = lua_resume(thread, runtimeLuauState, arguments);

        if (result == LUA_YIELD)
        {
            double delay = 0.0;
            if (lua_gettop(thread) > 0 && lua_isnumber(thread, -1))
                delay = lua_tonumber(thread, -1);
            lua_settop(thread, 0);
            runtimeLuauCoroutines[index].resumeAt = now + max(0.0, delay);
            ++index;
        }
        else if (result == LUA_OK)
        {
            lua_settop(thread, 0);
            runtimeLuauCoroutines.erase(runtimeLuauCoroutines.begin() + static_cast<ptrdiff_t>(index));
        }
        else
        {
            const char* error = lua_tostring(thread, -1);
            string errText = error != nullptr ? error : "Luau runtime error";
            int ln = -1, col = -1;
            string msg = errText;
            parseLuauErrorLocation(errText, ln, col, msg);
            Script* errScript = nullptr;
            for (const auto& snap : runtimeSourceSnapshot)
            {
                if (snap.first != nullptr && getInstancePath(snap.first) == label)
                {
                    errScript = snap.first;
                    break;
                }
            }
            // Prelude errors must not highlight a random line in the user script
            bool fromPrelude = errText.find("[BuildingTool runtime prelude]") != string::npos
                || errText.find("runtime prelude") != string::npos;
            if (fromPrelude)
            {
                addOutputLog("[Error] [" + label + "] " + errText, -1, -1, nullptr);
                addOutputLog("[Hint] This error is inside the runtime API layer (not your script line " +
                    to_string(max(0, ln)) + "). Often Parent/Name/Instance helpers.");
            }
            else
            {
                addOutputLog("[Error] [" + label + "] " + errText, ln, col, errScript);
                if (errScript != nullptr && activeScript == errScript)
                    scriptDiagnosticsSourceKey.clear();
            }
            // Only kill this script's coroutine — keep physics + other scripts running
            lua_settop(thread, 0);
            runtimeLuauCoroutines.erase(runtimeLuauCoroutines.begin() + static_cast<ptrdiff_t>(index));
            // do not set failed → do not stopRuntime
        }
    }

    if (runtimeLuauCoroutines.empty() && runtimePlaying)
    {
        runtimeStatus = "Finished - press Stop to reset";
        //addOutputLog("[Luau] all scripts finished; runtime state is kept until Stop");
    }
}

void startRuntime(bool clientMode)
{
    if (runtimePlaying)
        return;

    outputEntries.clear();
    scriptRuntimeDiagnostics.clear();
    scriptDiagnosticsSourceKey.clear();
    runtimeInstanceSnapshot.clear();
    runtimeCreatedInstances.clear();
    runtimePathToInstance.clear();
    runtimeSourceSnapshot.clear();
    runtimeLuauCoroutines.clear();
    runtimeClientMode = clientMode;
    if (runtimeClientMode)
    {
        runtimePlayer = new PlayerInstance();
        runtimePlayer->name = "LocalPlayer";
        addInstanceToParent(&Players, runtimePlayer);
        createRuntimePlayerCharacter();
        // Per-player StarterGui: clone StarterGui children into LocalPlayer.PlayerGui
        {
            Folder* playerGui = new Folder();
            playerGui->name = "PlayerGui";
            addInstanceToParent(runtimePlayer, playerGui);
            runtimePlayer->playerGui = playerGui;
            for (Instance* child : StarterGui.children)
            {
                if (child == nullptr) continue;
                Instance* copy = cloneInstance(child);
                if (copy != nullptr)
                    addInstanceToParent(playerGui, copy);
            }
            // Also clone StarterPlayerScripts-style content if present under StarterPlayer
            for (Instance* child : StarterPlayer.children)
            {
                if (child == nullptr) continue;
                // LocalScripts under StarterPlayer are handled by collectScripts if we parent a folder
                (void)child;
            }
        }
    }

    // Snapshot world so Stop can restore positions / velocities after physics.
    captureRuntimeInstanceState(&game);

    // Freeze weld relative poses now so Part1 cannot drift under gravity
    {
        function<void(Instance*)> freezeWelds = [&](Instance* inst)
        {
            if (!inst) return;
            if (inst->getType() == InstanceType::WeldConstraint)
            {
                auto* w = static_cast<WeldConstraint*>(inst);
                if (w->enabled && w->part0 && w->part1)
                    captureWeldRelative(w);
            }
            for (Instance* c : inst->children)
                freezeWelds(c);
        };
        freezeWelds(&workspace);
        freezeWelds(&game);
    }

    vector<Script*> scripts;
    collectScripts(game.children, scripts);
    scripts.erase(remove_if(scripts.begin(), scripts.end(), [](Script* script)
    {
        // ModuleScripts only run via require; disabled scripts never run;
        // LocalScripts only in client mode; Server scripts run in both.
        return script == nullptr
            || !script->enabled
            || script->type == ScriptType::ModuleScript
            || (!runtimeClientMode && script->type == ScriptType::LocalScript);
    }), scripts.end());

    // Physics-only Play is allowed: no scripts required.
    if (scripts.empty())
    {
        runtimePlaying = true;
        runtimeLuauState = nullptr;
        runtimeStatus = "Running (physics only — no scripts)";
        addOutputLog("[Play] Physics running (no scripts in game tree)");
        return;
    }

    addOutputLog("[Luau] starting " + to_string(scripts.size()) + " script(s)");
    runtimeSourceSnapshot.reserve(scripts.size());
    for (Script* script : scripts)
    {
        runtimeSourceSnapshot.push_back({ script, script->source });
    }

    runtimeLuauState = luaL_newstate();
    if (runtimeLuauState == nullptr)
    {
        runtimeStatus = "Could not create embedded Luau VM";
        addOutputLog("[Error] " + runtimeStatus);
        runtimeSourceSnapshot.clear();
        // Still allow physics-only if VM fails
        runtimePlaying = true;
        runtimeStatus = "Running (physics only — Luau VM failed)";
        addOutputLog("[Play] Physics running despite Luau VM failure");
        return;
    }
    luaL_openlibs(runtimeLuauState);
    lua_pushcfunction(runtimeLuauState, runtimeLuauPrint, "print");
    lua_setglobal(runtimeLuauState, "print");
    lua_pushcfunction(runtimeLuauState, runtimeLuauWarn, "warn");
    lua_setglobal(runtimeLuauState, "warn");
    lua_pushcfunction(runtimeLuauState, runtimeLuauWorkspaceRaycast, "__buildingToolRaycast");
    lua_setglobal(runtimeLuauState, "__buildingToolRaycast");
    lua_pushcfunction(runtimeLuauState, runtimeLuauWorldToScreenPoint, "__buildingToolWorldToScreen");
    lua_setglobal(runtimeLuauState, "__buildingToolWorldToScreen");
    lua_pushcfunction(runtimeLuauState, runtimeLuauScreenPointToRay, "__buildingToolScreenPointToRay");
    lua_setglobal(runtimeLuauState, "__buildingToolScreenPointToRay");
    lua_pushcfunction(runtimeLuauState, runtimeLuauViewportPointToRay, "__buildingToolViewportPointToRay");
    lua_setglobal(runtimeLuauState, "__buildingToolViewportPointToRay");
    lua_pushcfunction(runtimeLuauState, runtimeLuauClock, "__buildingToolClock");
    lua_setglobal(runtimeLuauState, "__buildingToolClock");
    lua_pushcfunction(runtimeLuauState, runtimeTaskSpawn, "__buildingToolTaskSpawn");
    lua_setglobal(runtimeLuauState, "__buildingToolTaskSpawn");
    lua_pushcfunction(runtimeLuauState, runtimeTaskDefer, "__buildingToolTaskDefer");
    lua_setglobal(runtimeLuauState, "__buildingToolTaskDefer");
    lua_pushcfunction(runtimeLuauState, runtimeTaskDelay, "__buildingToolTaskDelay");
    lua_setglobal(runtimeLuauState, "__buildingToolTaskDelay");
    lua_pushcfunction(runtimeLuauState, runtimeLuauRunCompiledModule,
        "__buildingToolRunCompiledModule");
    lua_setglobal(runtimeLuauState, "__buildingToolRunCompiledModule");

    string definitions = buildLuauDefinitions();
    if (!loadRuntimeLuauChunk(runtimeLuauState, "[BuildingTool runtime prelude]", definitions) ||
        lua_pcall(runtimeLuauState, 0, 0, 0) != LUA_OK)
    {
        const char* error = lua_tostring(runtimeLuauState, -1);
        if (error != nullptr)
            addOutputLog("[Error] runtime prelude: " + string(error));
        if (runtimeLuauState != nullptr)
        {
            lua_close(runtimeLuauState);
            runtimeLuauState = nullptr;
        }
        runtimeSourceSnapshot.clear();
        runtimePlaying = true;
        runtimeStatus = "Running (physics only — prelude failed)";
        addOutputLog("[Play] Physics running despite prelude failure");
        return;
    }

    for (Script* script : scripts)
    {
        lua_State* thread = lua_newthread(runtimeLuauState); // Kept alive by the main VM stack.
        {
            int cleaned = sanitizeScriptSourceInPlace(script->source);
            if (cleaned > 0)
                addOutputLog("[Warning] Cleaned " + to_string(cleaned) +
                    " invisible/non-ASCII character(s) from " + getInstancePath(script));
        }
        // Inject `script` global referring to this running Script/LocalScript instance.
        // Use slash runtime path (matches __Path registration); also try dotted form.
        string dottedPath = getInstancePath(script);
        bool loaded = script->compiledBytecode.empty()
            ? loadRuntimeLuauChunk(thread, dottedPath,
                buildRuntimeScriptChunk(script, script->source))
            : loadRuntimeLuauBytecodeChunk(thread, dottedPath, script->compiledBytecode);
        if (!loaded)
        {
            addOutputLog("[Warning] Skipping script that failed to load: " + dottedPath);
            continue;
        }
        runtimeLuauCoroutines.push_back({ thread, dottedPath, GetTime() });
    }

    runtimePlaying = true;
    if (runtimeLuauCoroutines.empty())
    {
        runtimeStatus = "Running (physics only — no runnable scripts)";
        addOutputLog("[Play] Physics running (no runnable scripts)");
    }
    else
    {
        runtimeStatus = "Running " + to_string(runtimeLuauCoroutines.size()) + " script(s) + physics";
        addOutputLog("[Luau] embedded coroutine scheduler running");
    }
}

// ============================================================
// Click Handling
// ============================================================

void handleTopBarClick(vector<TopBarItem*>& topBarItems)
{
    if (!IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
        return;

    Vector2 mouse = GetMousePosition();

    // 1) Open dropdown children — highest click priority (block all editor UI under it)
    if (openMenu != nullptr)
    {
        int menuX = topBarItemX(topBarItems, 0);
        for (size_t i = 0; i < topBarItems.size(); ++i)
        {
            if (topBarItems[i] == openMenu)
            {
                menuX = topBarItemX(topBarItems, i);
                break;
            }
        }

        TopBarItem* clickedItem = nullptr;
        if (handleTopBarMenuItemClick(openMenu, menuX, MENU_BAR_HEIGHT, clickedItem))
        {
            if (clickedItem != nullptr && clickedItem->children.empty())
            {
                performTopBarMenuAction(clickedItem);
                openMenu = nullptr;
            }
            return;
        }

        // Click outside the dropdown closes it and still consumes the click
        openMenu = nullptr;
        // Fall through so a menu title click can open another menu same frame
    }

    // 2) Ribbon controls
    if (handleRibbonBarClick())
        return;

    // 3) Action bar (play / stop / POV)
    if (!welcomeScreenOpen && studioSettings.showActionBar &&
        mouse.y >= (float)editorActionBarY() && mouse.y < (float)editorRibbonBarY() && mouse.x < 230.0f)
    {
        int index = static_cast<int>((mouse.x - 8.0f) / 54.0f);
        if (index >= 0 && index < 4 && mouse.x >= 8.0f + index * 54.0f)
        {
            if (index == 0)
            {
                editorClientPOV = false;
                startRuntime(false);
            }
            else if (index == 1)
            {
                editorClientPOV = true;
                startRuntime(true);
            }
            else if (index == 2)
            {
                stopRuntime();
            }
            else if (index == 3)
            {
                editorClientPOV = !editorClientPOV;
                if (runtimePlaying)
                {
                    stopRuntime();
                    startRuntime(editorClientPOV);
                }
                addOutputLog(string("[POV] Switched to ") + (editorClientPOV ? "Client" : "Server"));
            }
            return;
        }
    }

    // 4) Menu bar titles (File / View / Help)
    if (mouse.y < (float)MENU_BAR_HEIGHT)
    {
        for (size_t i = 0; i < topBarItems.size(); ++i)
        {
            TopBarItem* item = topBarItems[i];
            if (item == nullptr)
                continue;

            int x = topBarItemX(topBarItems, i);
            int w = topBarItemWidth(item);
            Rectangle rect = { (float)x, 0.0f, (float)w, (float)MENU_BAR_HEIGHT };
            if (!CheckCollisionPointRec(mouse, rect))
                continue;

            if (item->label == "Help" && item->children.empty())
            {
                helpOpen = true;
                return;
            }

            if (!item->children.empty())
            {
                openMenu = (openMenu == item) ? nullptr : item;
                return;
            }
        }
    }
}

Part* raycastParts(Instance* instance, Ray ray, float& closestDistance,
    const unordered_set<const Instance*>* filter, bool includeFilter, bool includeLocked)
{
    if (instance == nullptr)
        return nullptr;

    Part* closestPart = nullptr;

    // Check if this is a Part
    if (instance->getType() == InstanceType::Part)
    {
        Part* part = static_cast<Part*>(instance);
        const bool filtered = filter != nullptr && filter->count(part) != 0;
        const bool allowedByFilter = filter == nullptr || filtered == includeFilter;
        // Locked parts are not pickable (existing selection is kept)
        if ((includeLocked || !part->locked) && allowedByFilter)
        {
        Vector3 position = part->cframe.position;
        Vector3 size = part->size;

        RayCollision collision = { 0 };

        switch (part->type)
        {
            case PartType::Block:
            {
                BoundingBox box;

                box.min = {
                    position.x - size.x / 2.0f,
                    position.y - size.y / 2.0f,
                    position.z - size.z / 2.0f
                };

                box.max = {
                    position.x + size.x / 2.0f,
                    position.y + size.y / 2.0f,
                    position.z + size.z / 2.0f
                };

                collision = GetRayCollisionBox(ray, box);

                break;
            }

            case PartType::Sphere:
            {
                collision = GetRayCollisionSphere(
                    ray,
                    position,
                    size.x / 2.0f
                );

                break;
            }

            case PartType::Cylinder:
            {
                BoundingBox box;

                box.min = {
                    position.x - size.x / 2.0f,
                    position.y - size.y / 2.0f,
                    position.z - size.x / 2.0f
                };

                box.max = {
                    position.x + size.x / 2.0f,
                    position.y + size.y / 2.0f,
                    position.z + size.x / 2.0f
                };

                collision = GetRayCollisionBox(ray, box);

                break;
            }

            case PartType::Cone:
            {
                BoundingBox box;

                box.min = {
                    position.x - size.x / 2.0f,
                    position.y,
                    position.z - size.x / 2.0f
                };

                box.max = {
                    position.x + size.x / 2.0f,
                    position.y + size.y,
                    position.z + size.x / 2.0f
                };

                collision = GetRayCollisionBox(ray, box);

                break;
            }

            case PartType::Wedge:
            case PartType::CornerWedge:
                break;
        }

        // We hit this part
        if (collision.hit &&
            collision.distance < closestDistance)
        {
            closestDistance = collision.distance;
            closestPart = part;
        }
        } // !locked
    }

    // Check children
    for (Instance* child : instance->children)
    {
        Part* hitPart = raycastParts(
            child,
            ray,
            closestDistance,
            filter,
            includeFilter,
            includeLocked
        );

        if (hitPart != nullptr)
        {
            closestPart = hitPart;
        }
    }

    return closestPart;
}

Part* raycastParts(Instance* instance, Ray ray, float& closestDistance)
{
    return raycastParts(instance, ray, closestDistance, nullptr, false);
}

void updateHover(Camera3D& camera)
{
    Vector2 mouse = GetMousePosition();

    // Don't raycast through the top UI
    if (mouse.y <= (float)EDITOR_CONTENT_TOP || activeWindow != WindowType::Viewport || renamingInstance != nullptr)
    {
        hoveredInstance = nullptr;
        return;
    }

    Ray ray = GetMouseRay(mouse, camera);

    float closestDistance = FLT_MAX;

    hoveredInstance = raycastParts(
        &workspace,
        ray,
        closestDistance
    );
}


static void closeContextMenu()
{
    contextMenu.open = false;
    contextMenu.hover = -1;
}

static void openContextMenuAt(float x, float y)
{
    contextMenu.open = true;
    contextMenu.x = x;
    contextMenu.y = y;
    contextMenu.hover = -1;
    contextMenu.mode = selectedInstances.empty() ? 0 : 1;
}

static vector<string> contextMenuItems()
{
    vector<string> items;
    if (contextMenu.mode == 0)
    {
        items = { "Move Gizmo", "Rotate Gizmo", "Scale Gizmo", "Insert Object..." };
    }
    else
    {
        items = { "Select Children", "Select Parent", "Deselect", "Move Gizmo", "Rotate Gizmo", "Scale Gizmo", "Insert Object..." };
        bool anyPart = false;
        for (Instance* inst : selectedInstances)
            if (inst && inst->getType() == InstanceType::Part) { anyPart = true; break; }
        if (anyPart)
            items.insert(items.begin(), "Local Axes");
    }
    return items;
}

static void applyContextMenuAction(const string& action)
{
    if (action == "Move Gizmo") currentGizmo = GizmoType::Move;
    else if (action == "Rotate Gizmo") currentGizmo = GizmoType::Rotate;
    else if (action == "Scale Gizmo") currentGizmo = GizmoType::Scale;
    else if (action == "Insert Object...")
    {
        insertMenuOpen = true;
        floatingInsertPos = { contextMenu.x, contextMenu.y };
    }
    else if (action == "Deselect")
        selectedInstances.clear();
    else if (action == "Select Children")
    {
        vector<Instance*> next;
        unordered_set<Instance*> seen;
        for (Instance* s : selectedInstances)
        {
            if (!s) continue;
            for (Instance* c : s->children)
            {
                if (c && seen.insert(c).second)
                    next.push_back(c);
            }
        }
        if (!next.empty())
            selectedInstances = next;
    }
    else if (action == "Select Parent")
    {
        vector<Instance*> next;
        unordered_set<Instance*> seen;
        for (Instance* s : selectedInstances)
        {
            if (!s || !s->parent) continue;
            if (s->parent == &game) continue; // never select root game
            if (seen.insert(s->parent).second)
                next.push_back(s->parent);
        }
        if (!next.empty())
            selectedInstances = next;
    }
    else if (action == "Local Axes")
    {
        // Toggle per selected part (not tied to gizmo)
        bool anyOff = false;
        for (Instance* inst : selectedInstances)
            if (inst && inst->getType() == InstanceType::Part &&
                !static_cast<Part*>(inst)->showLocalAxes)
                anyOff = true;
        for (Instance* inst : selectedInstances)
        {
            if (!inst || inst->getType() != InstanceType::Part) continue;
            static_cast<Part*>(inst)->showLocalAxes = anyOff; // all on if any off, else all off
        }
        projectDirty = true;
    }
    closeContextMenu();
}

void renderContextMenu()
{
    if (!contextMenu.open)
        return;
    vector<string> items = contextMenuItems();
    const int rowH = 28;
    const int pad = 10;
    int width = 180;
    for (const string& s : items)
        width = max(width, MeasureText(s.c_str(), 15) + pad * 2);
    int height = (int)items.size() * rowH;
    float x = contextMenu.x;
    float y = contextMenu.y;
    if (x + width > GetScreenWidth()) x = (float)GetScreenWidth() - width - 4;
    if (y + height > GetScreenHeight()) y = (float)GetScreenHeight() - height - 4;
    contextMenu.x = x;
    contextMenu.y = y;

    DrawRectangle((int)x, (int)y, width, height, (Color){ 45, 45, 48, 255 });
    DrawRectangleLines((int)x, (int)y, width, height, (Color){ 70, 70, 76, 255 });
    Vector2 mouse = GetMousePosition();
    contextMenu.hover = -1;
    for (int i = 0; i < (int)items.size(); ++i)
    {
        Rectangle row = { x, y + i * rowH, (float)width, (float)rowH };
        bool hover = CheckCollisionPointRec(mouse, row);
        if (hover)
        {
            contextMenu.hover = i;
            DrawRectangleRec(row, (Color){ 0, 120, 215, 255 });
        }
        DrawText(items[i].c_str(), (int)x + pad, (int)y + i * rowH + 6, 15,
            hover ? WHITE : (Color){ 220, 220, 220, 255 });
    }
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
    {
        if (contextMenu.hover >= 0 && contextMenu.hover < (int)items.size())
            applyContextMenuAction(items[contextMenu.hover]);
        else
            closeContextMenu();
    }
}

// Draw a solid bar with gizmoMaterial so lighting shader does not strip it
static void drawOrientationBar(Vector3 start, Vector3 direction, float length, float radius, Color color)
{
    direction = Vector3Normalize(direction);
    if (length < 0.01f) return;
    gizmoMaterial.maps[MATERIAL_MAP_DIFFUSE].color = color;
    Quaternion q = QuaternionFromVector3ToVector3({ 0, 1, 0 }, direction);
    Matrix rot = QuaternionToMatrix(q);
    Vector3 center = Vector3Add(start, Vector3Scale(direction, length * 0.5f));
    Matrix xform = MatrixMultiply(
        MatrixMultiply(MatrixScale(radius, length, radius), rot),
        MatrixTranslate(center.x, center.y, center.z)
    );
    DrawMesh(cylinderMesh, gizmoMaterial, xform);
    // Small tip sphere (also material-based)
    Vector3 tip = Vector3Add(start, Vector3Scale(direction, length));
    float tipR = radius * 1.6f;
    Matrix tipX = MatrixMultiply(MatrixScale(tipR, tipR, tipR), MatrixTranslate(tip.x, tip.y, tip.z));
    DrawMesh(sphereMesh, gizmoMaterial, tipX);
}

static void renderLocalAxesForPart(Part* p)
{
    if (!p || !p->showLocalAxes) return;
    Vector3 pos = getPartWorldPivot(*p);
    Vector3 forward = rotateVector({ 0, 0, -1 }, p->cframe.rotation);
    Vector3 up = rotateVector({ 0, 1, 0 }, p->cframe.rotation);
    float barLen = max(p->size.x, max(p->size.y, p->size.z)) * 0.5f + 1.2f;
    drawOrientationBar(pos, forward, barLen, 0.07f, (Color){ 80, 180, 255, 255 }); // Forward
    drawOrientationBar(pos, up, barLen, 0.07f, (Color){ 232, 140, 48, 255 });      // Up
}

static void renderLocalAxesTree(Instance* root)
{
    if (!root) return;
    if (root->getType() == InstanceType::Part)
        renderLocalAxesForPart(static_cast<Part*>(root));
    for (Instance* c : root->children)
        renderLocalAxesTree(c);
}

void renderPartOrientationGuides()
{
    // Per-part Local Axes (independent of selection / gizmo)
    renderLocalAxesTree(&workspace);
}

void handleContextMenuInput(Camera3D& camera)
{
    if (welcomeScreenOpen || projectSaveDialogOpen)
        return;

    Vector2 mouse = GetMousePosition();

    // --- Press: arm a potential right-click (do not open menu yet) ---
    if (IsMouseButtonPressed(MOUSE_BUTTON_RIGHT))
    {
        rightClickPending = true;
        rightClickDragged = false;
        rightClickOrigin = mouse;
        rightClickPressTime = GetTime();
        rightClickZone = RightClickZone::None;
        rightClickExplorerTarget = nullptr;

        int explorerX = getExplorerX();
        if (mouse.x >= explorerX && mouse.x < explorerX + EXPLORER_WIDTH &&
            mouse.y >= EXPLORER_TOP && isDockPanelActiveTab(DockPanelKind::Explorer))
        {
            rightClickZone = RightClickZone::Explorer;
            // Resolve row under cursor
            vector<Instance*> flat;
            flattenInstances(game.children, flat);
            int contentTop = EXPLORER_TOP + 32;
            int index = static_cast<int>((mouse.y - contentTop + explorerScrollY) / EXPLORER_ROW_HEIGHT);
            if (index >= 0 && index < (int)flat.size())
                rightClickExplorerTarget = flat[index];
        }
        else if (mouse.y > (float)EDITOR_CONTENT_TOP &&
                 activeWindow == WindowType::Viewport &&
                 mouse.x >= leftSlotWidth() &&
                 mouse.x < GetScreenWidth() - rightSlotWidth())
        {
            rightClickZone = RightClickZone::Viewport;
        }
        else
        {
            rightClickPending = false;
        }
    }

    // --- Hold: if mouse moves enough, treat as orbit/drag, not a click ---
    if (rightClickPending && IsMouseButtonDown(MOUSE_BUTTON_RIGHT))
    {
        if (Vector2Distance(mouse, rightClickOrigin) > 5.0f)
            rightClickDragged = true;
    }

    // --- Release: open menu only if it was a click (not a hold-drag) ---
    if (rightClickPending && IsMouseButtonReleased(MOUSE_BUTTON_RIGHT))
    {
        bool shortHold = (GetTime() - rightClickPressTime) < 0.45;
        if (!rightClickDragged && shortHold)
        {
            if (rightClickZone == RightClickZone::Explorer && rightClickExplorerTarget != nullptr)
            {
                bool already = find(selectedInstances.begin(), selectedInstances.end(),
                    rightClickExplorerTarget) != selectedInstances.end();
                if (!already && !(IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL)))
                {
                    selectedInstances.clear();
                    selectedInstances.push_back(rightClickExplorerTarget);
                }
                else if (!already)
                    selectedInstances.push_back(rightClickExplorerTarget);
                openContextMenuAt(mouse.x, mouse.y);
            }
            else if (rightClickZone == RightClickZone::Viewport)
            {
                Ray ray = GetMouseRay(mouse, camera);
                float closest = FLT_MAX;
                Part* hit = raycastParts(&workspace, ray, closest);
                if (hit != nullptr)
                {
                    bool already = find(selectedInstances.begin(), selectedInstances.end(), hit)
                        != selectedInstances.end();
                    if (!already && !(IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL)))
                    {
                        selectedInstances.clear();
                        selectedInstances.push_back(hit);
                    }
                    else if (!already)
                        selectedInstances.push_back(hit);
                }
                openContextMenuAt(mouse.x, mouse.y);
            }
        }
        rightClickPending = false;
        rightClickDragged = false;
        rightClickZone = RightClickZone::None;
        rightClickExplorerTarget = nullptr;
    }
}

static bool isInstanceSelectedOrDescendant(const vector<Instance*>& instances, Instance* candidate)
{
    for (Instance* selected : instances)
        if (selected == candidate || isInstanceInBranch(selected, candidate))
            return true;
    return false;
}

static void selectInstancesInViewportRectangle(Camera3D& camera, Rectangle selection, bool additive)
{
    vector<Instance*> hits;
    function<void(Instance*)> walk = [&](Instance* instance)
    {
        if (instance == nullptr)
            return;
        if (instance->getType() == InstanceType::Part)
        {
            Part* part = static_cast<Part*>(instance);
            if (part->transparency < 0.999f)
            {
                Rectangle projectedBounds = {
                    static_cast<float>(GetScreenWidth()),
                    static_cast<float>(GetScreenHeight()),
                    0.0f,
                    0.0f
                };
                float minX = projectedBounds.x;
                float minY = projectedBounds.y;
                float maxX = 0.0f;
                float maxY = 0.0f;
                for (int corner = 0; corner < 8; ++corner)
                {
                    Vector3 local = {
                        (corner & 1) ? part->size.x * 0.5f : -part->size.x * 0.5f,
                        (corner & 2) ? part->size.y * 0.5f : -part->size.y * 0.5f,
                        (corner & 4) ? part->size.z * 0.5f : -part->size.z * 0.5f
                    };
                    Vector3 world = Vector3Add(part->cframe.position, rotateVector(local, part->cframe.rotation));
                    Vector2 screen = GetWorldToScreen(world, camera);
                    minX = min(minX, screen.x);
                    minY = min(minY, screen.y);
                    maxX = max(maxX, screen.x);
                    maxY = max(maxY, screen.y);
                }
                Rectangle partBounds = { minX, minY, max(1.0f, maxX - minX), max(1.0f, maxY - minY) };
                if (CheckCollisionRecs(selection, partBounds))
                {
                    Instance* target = part;
                    for (Instance* ancestor = part->parent; ancestor != nullptr; ancestor = ancestor->parent)
                    {
                        if (ancestor->getType() == InstanceType::Model)
                        {
                            target = ancestor;
                            break;
                        }
                    }
                    if (!isInstanceSelectedOrDescendant(hits, target))
                        hits.push_back(target);
                }
            }
        }
        for (Instance* child : instance->children)
            walk(child);
    };
    walk(&workspace);

    if (!additive)
        selectedInstances.clear();
    for (Instance* hit : hits)
    {
        if (!isInstanceSelectedOrDescendant(selectedInstances, hit))
            selectedInstances.push_back(hit);
        revealExplorerAncestors(hit);
    }
}

void renderViewportSelectionBox()
{
    if (!viewportSelectionBoxActive ||
        Vector2Distance(viewportSelectionBoxStart, viewportSelectionBoxEnd) <= 4.0f)
        return;
    EditorThemeColors theme = getEditorThemeColors();
    float left = static_cast<float>(leftSlotWidth());
    float right = static_cast<float>(GetScreenWidth() - rightSlotWidth());
    float top = static_cast<float>(EDITOR_CONTENT_TOP);
    float bottom = static_cast<float>(GetScreenHeight());
    Vector2 start = {
        Clamp(viewportSelectionBoxStart.x, left, right),
        Clamp(viewportSelectionBoxStart.y, top, bottom)
    };
    Vector2 end = {
        Clamp(viewportSelectionBoxEnd.x, left, right),
        Clamp(viewportSelectionBoxEnd.y, top, bottom)
    };
    Rectangle box = {
        min(start.x, end.x),
        min(start.y, end.y),
        fabsf(end.x - start.x),
        fabsf(end.y - start.y)
    };
    BeginScissorMode(static_cast<int>(left), static_cast<int>(top),
        max(0, static_cast<int>(right - left)), max(0, static_cast<int>(bottom - top)));
    DrawRectangleRec(box, (Color){ theme.accent.r, theme.accent.g, theme.accent.b, 45 });
    DrawRectangleLinesEx(box, 1.5f, theme.accent);
    EndScissorMode();
}

void WhenClicked(Camera3D& camera)
{
    if (draggingGizmo)
        return;
    if (activeWindow != WindowType::Viewport || !isZoneFocused(FocusZone::Viewport) ||
        dockDragActive || floatingStudioDrag || floatingGameDrag || floatingInsertDrag ||
        floatingPropertyColorDrag || studioSettingsOpen || gameSettingsOpen || insertMenuOpen ||
        propertyColorPickerOpen || explorerResizing || propertyResizing || isPointerOverScreenGui())
        return;

    Vector2 mouse = GetMousePosition();
    int leftPanelWidth = leftSlotWidth();
    int rightPanelX = GetScreenWidth() - rightSlotWidth();
    bool nearLeftDockResize = leftPanelWidth > 40 && mouse.x >= leftPanelWidth - 6 &&
        mouse.x <= leftPanelWidth + 6;
    bool nearRightDockResize = rightSlotWidth() > 40 && mouse.x >= rightPanelX - 6 &&
        mouse.x <= rightPanelX + 6;
    if (mouse.y >= EDITOR_CONTENT_TOP && (nearLeftDockResize || nearRightDockResize))
        return;
    if (viewportSelectionBoxActive)
    {
        viewportSelectionBoxEnd = mouse;
        if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
        {
                float left = static_cast<float>(leftSlotWidth());
                float right = static_cast<float>(GetScreenWidth() - rightSlotWidth());
                float top = static_cast<float>(EDITOR_CONTENT_TOP);
                float bottom = static_cast<float>(GetScreenHeight());
                Vector2 start = {
                    Clamp(viewportSelectionBoxStart.x, left, right),
                    Clamp(viewportSelectionBoxStart.y, top, bottom)
                };
                Vector2 end = {
                    Clamp(viewportSelectionBoxEnd.x, left, right),
                    Clamp(viewportSelectionBoxEnd.y, top, bottom)
                };
                Rectangle selection = {
                    min(start.x, end.x), min(start.y, end.y),
                    fabsf(end.x - start.x), fabsf(end.y - start.y)
                };
                if (Vector2Distance(start, end) > 4.0f)
                    selectInstancesInViewportRectangle(camera, selection, viewportSelectionBoxAdditive);
            viewportSelectionBoxActive = false;
        }
        return;
    }
    if (!IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
        return;

    if (mouse.y <= (float)EDITOR_CONTENT_TOP || renamingInstance != nullptr)
        return;

    if (mouse.x < leftSlotWidth() || mouse.x >= GetScreenWidth() - rightSlotWidth())
    {
        return;
    }

    viewportSelectionBoxActive = true;
    viewportSelectionBoxStart = mouse;
    viewportSelectionBoxEnd = mouse;
    viewportSelectionBoxAdditive =
        IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL);

    openMenu = nullptr;

    Ray ray = GetMouseRay(mouse, camera);

    float closestDistance = FLT_MAX;

    Part* clickedPart = raycastParts(
        &workspace,
        ray,
        closestDistance
    );

    if (clickedPart == nullptr)
    {
        if (!viewportSelectionBoxAdditive)
            selectedInstances.clear();
        return;
    }

    if (pointerPickOwner != nullptr && assignPointerProperty(clickedPart))
    {
        viewportSelectionBoxActive = false;
        return;
    }

    revealExplorerAncestors(clickedPart);

    Instance* selectionTarget = clickedPart;
    bool alt = IsKeyDown(KEY_LEFT_ALT) || IsKeyDown(KEY_RIGHT_ALT);
    if (!alt)
    {
        for (Instance* ancestor = clickedPart->parent; ancestor != nullptr; ancestor = ancestor->parent)
        {
            if (ancestor->getType() == InstanceType::Model)
            {
                selectionTarget = ancestor;
                break;
            }
        }
    }

    // Ctrl = add/remove from selection
    if (IsKeyDown(KEY_LEFT_CONTROL) ||
        IsKeyDown(KEY_RIGHT_CONTROL))
    {
        auto it = find(
            selectedInstances.begin(),
            selectedInstances.end(),
            selectionTarget
        );

        if (it != selectedInstances.end())
        {
            // Already selected → deselect
            selectedInstances.erase(it);
        }
        else
        {
            // Not selected → add
            selectedInstances.push_back(selectionTarget);
        }
    }
    else
    {
        // Normal click → replace selection
        selectedInstances.clear();
        selectedInstances.push_back(selectionTarget);
    }
}

// ============================================================
// Example
// ============================================================

void InitEngine()
{
    // Higher base size + bilinear filter → less pixelation when drawn at 14–18px
    const int fontBaseSize = 32;
    applicationFont = LoadFontEx("C:/Windows/Fonts/consola.ttf", fontBaseSize, 0, 0);
    applicationFontLoaded = applicationFont.texture.id != 0;
    if (applicationFontLoaded)
        SetTextureFilter(applicationFont.texture, TEXTURE_FILTER_BILINEAR);

    applicationFontBold = LoadFontEx("C:/Windows/Fonts/consolab.ttf", fontBaseSize, 0, 0);
    applicationFontBoldLoaded = applicationFontBold.texture.id != 0;
    if (applicationFontBoldLoaded)
        SetTextureFilter(applicationFontBold.texture, TEXTURE_FILTER_BILINEAR);

    applicationFontItalic = LoadFontEx("C:/Windows/Fonts/consolai.ttf", fontBaseSize, 0, 0);
    applicationFontItalicLoaded = applicationFontItalic.texture.id != 0;
    if (applicationFontItalicLoaded)
        SetTextureFilter(applicationFontItalic.texture, TEXTURE_FILTER_BILINEAR);

    applicationFontBoldItalic = LoadFontEx("C:/Windows/Fonts/consolaz.ttf", fontBaseSize, 0, 0);
    applicationFontBoldItalicLoaded = applicationFontBoldItalic.texture.id != 0;
    if (applicationFontBoldItalicLoaded)
        SetTextureFilter(applicationFontBoldItalic.texture, TEXTURE_FILTER_BILINEAR);

    explorerIcons = new iconLib();

    torusMesh = CreateTorusMesh(1.0f, 0.05f, 32, 16);
    torusMaterial = LoadMaterialDefault();
    gizmoMaterial = LoadMaterialDefault();
    // Unit cone (base radius 1, height 1) — same DrawMesh path as the rotation torus
    gizmoConeMesh = GenMeshCone(1.0f, 1.0f, 20);
    ComputeConeMeshLocalBounds(gizmoConeMesh, gizmoConeLocalBaseY, gizmoConeLocalTipY);

    loadResources();

    InitAudioDevice();
    audioDeviceReady = IsAudioDeviceReady();

    workspace.name = "Workspace";
    addInstanceToParent(&game, &workspace);

    Players.name = "Players";
    addInstanceToParent(&game, &Players);

    Lighting.name = "Lighting";
    Lighting.id = "Lighting";
    addInstanceToParent(&game, &Lighting);
    ensureLightingEffectInstances();

    ReplicatedStorage.name = "ReplicatedStorage";
    addInstanceToParent(&game, &ReplicatedStorage);

    ServerScriptService.name = "ServerScriptService";
    addInstanceToParent(&game, &ServerScriptService);

    ServerStorage.name = "ServerStorage";
    addInstanceToParent(&game, &ServerStorage);

    CoreStorage.name = "CoreStorage";
    CoreStorage.hidden = true;
    addInstanceToParent(&game, &CoreStorage);
    ensureCharacterRigModule();

    sun.direction = Vector3Normalize(sun.direction);
}

void registerHlxFileAssociation()
{
    char modulePath[MAX_PATH] = {};
    DWORD pathLength = GetModuleFileNameA(nullptr, modulePath, MAX_PATH);
    if (pathLength == 0 || pathLength >= MAX_PATH)
        return;

    string executablePath(modulePath, pathLength);
    size_t slash = executablePath.find_last_of("\\/");
    string executableDirectory = slash == string::npos ? "." : executablePath.substr(0, slash);
    string fileIconPath = executableDirectory + "\\assets\\icons\\Misc\\File.ico";
    string openCommand = "\"" + executablePath + "\" \"%1\"";

    auto setDefaultValue = [](HKEY key, const string& value)
    {
        RegSetValueExA(key, nullptr, 0, REG_SZ,
            reinterpret_cast<const BYTE*>(value.c_str()),
            static_cast<DWORD>(value.size() + 1));
    };
    auto setKeyValue = [&](const char* subkey, const string& value)
    {
        HKEY key = nullptr;
        if (RegCreateKeyExA(HKEY_CURRENT_USER, subkey, 0, nullptr, 0,
            KEY_SET_VALUE, nullptr, &key, nullptr) != ERROR_SUCCESS)
            return;
        setDefaultValue(key, value);
        RegCloseKey(key);
    };

    setKeyValue("Software\\Classes\\.hlx", "BuildingTool.HLX");
    setKeyValue("Software\\Classes\\BuildingTool.HLX", "Building Tool Project");
    setKeyValue("Software\\Classes\\BuildingTool.HLX\\DefaultIcon", fileIconPath);
    setKeyValue("Software\\Classes\\BuildingTool.HLX\\shell\\open\\command", openCommand);
    setKeyValue("Software\\Classes\\.btproj", "BuildingTool.ProjectFolder");
    setKeyValue("Software\\Classes\\BuildingTool.ProjectFolder", "Building Tool Project Folder");
    setKeyValue("Software\\Classes\\BuildingTool.ProjectFolder\\DefaultIcon", fileIconPath);
    setKeyValue("Software\\Classes\\BuildingTool.ProjectFolder\\shell\\open\\command", openCommand);
}

void runHlxAssociationBatchFirstLaunch()
{
    HKEY settingsKey = nullptr;
    const char* settingsPath = "Software\\BuildingTool";
    if (RegCreateKeyExA(HKEY_CURRENT_USER, settingsPath, 0, nullptr, 0,
        KEY_QUERY_VALUE | KEY_SET_VALUE, nullptr, &settingsKey, nullptr) != ERROR_SUCCESS)
        return;

    DWORD marker = 0;
    DWORD markerSize = sizeof(marker);
    DWORD markerType = 0;
    bool alreadyRun = RegQueryValueExA(settingsKey, "HlxAssociationBatchVersion", nullptr,
        &markerType, reinterpret_cast<BYTE*>(&marker), &markerSize) == ERROR_SUCCESS &&
        markerType == REG_DWORD && marker >= 1;
    if (!alreadyRun)
    {
        DWORD version = 1;
        RegSetValueExA(settingsKey, "HlxAssociationBatchVersion", 0, REG_DWORD,
            reinterpret_cast<const BYTE*>(&version), sizeof(version));
    }
    RegCloseKey(settingsKey);
    if (alreadyRun)
        return;

    char modulePath[MAX_PATH] = {};
    DWORD pathLength = GetModuleFileNameA(nullptr, modulePath, MAX_PATH);
    if (pathLength == 0 || pathLength >= MAX_PATH)
        return;
    string executablePath(modulePath, pathLength);
    size_t slash = executablePath.find_last_of("\\/");
    string executableDirectory = slash == string::npos ? "." : executablePath.substr(0, slash);
    string batchPath = executableDirectory + "\\install_hlx_file_association.bat";
    if (!filesystem::exists(batchPath))
        return;

    string command = "cmd.exe /d /c \"\"" + batchPath + "\" /silent\"";
    STARTUPINFOA startupInfo = {};
    startupInfo.cb = sizeof(startupInfo);
    startupInfo.dwFlags = STARTF_USESHOWWINDOW;
    startupInfo.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION processInfo = {};
    vector<char> commandLine(command.begin(), command.end());
    commandLine.push_back('\0');
    if (CreateProcessA(nullptr, commandLine.data(), nullptr, nullptr, FALSE,
        CREATE_NO_WINDOW, nullptr, executableDirectory.c_str(), &startupInfo, &processInfo))
    {
        CloseHandle(processInfo.hThread);
        CloseHandle(processInfo.hProcess);
    }
}

void ShutdownEngine()
{
    // Order matters more than delay here: stop all logic touching GPU/audio
    // resources first, then tear down audio, then GPU resources, then fonts.
    // The previous version added seven Sleep(35) calls (~245ms total) between
    // unrelated GL object deletions for no functional reason — glDelete*-style
    // calls don't need the CPU to sleep in between them, the driver handles
    // that internally. The one place a brief pause is arguably still worth
    // keeping is right after CloseAudioDevice(), since a few audio backends
    // have had real teardown races if something touches the device a moment
    // too soon; everything else closes back-to-back.
    if (runtimePlaying || runtimeLuauState != nullptr || runtimeCharacter != nullptr ||
        runtimePlayer != nullptr || runtimeCameraInstance != nullptr)
        stopRuntime();

    stopSoundPreview();
    clearProjectAssets();
    if (audioDeviceReady)
    {
        CloseAudioDevice();
        audioDeviceReady = false;
        Sleep(10); // brief settle time for the audio backend, not a general-purpose pause
    }

    delete explorerIcons;
    explorerIcons = nullptr;

    UnloadMesh(torusMesh);
    UnloadMaterial(torusMaterial);
    UnloadMesh(gizmoConeMesh);
    UnloadMaterial(gizmoMaterial);

    UnloadMesh(blockMesh);
    UnloadMesh(sphereMesh);
    UnloadMesh(cylinderMesh);
    UnloadMesh(sphereMeshMedium);
    UnloadMesh(sphereMeshLow);
    UnloadMesh(cylinderMeshMedium);
    UnloadMesh(cylinderMeshLow);

    UnloadMaterial(blockMaterial);

    UnloadShader(blockShader);

    UnloadRenderTexture(shadowMap);
    UnloadShader(shadowShader);

    if (lightingSceneTarget.texture.id != 0)
        UnloadRenderTexture(lightingSceneTarget);

    UnloadShader(postProcessShader);

    if (applicationFontLoaded)
        UnloadFont(applicationFont);
    applicationFontLoaded = false;

    if (applicationFontBoldLoaded)
        UnloadFont(applicationFontBold);
    applicationFontBoldLoaded = false;

    if (applicationFontItalicLoaded)
        UnloadFont(applicationFontItalic);
    applicationFontItalicLoaded = false;

    if (applicationFontBoldItalicLoaded)
        UnloadFont(applicationFontBoldItalic);
    applicationFontBoldItalicLoaded = false;
}



#endif // BT_SCRIPT_RUNTIME_H