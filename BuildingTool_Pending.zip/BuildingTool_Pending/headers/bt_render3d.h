// bt_render3d.h — Meshes, instance render, lights, shaders, post
#pragma once
#ifndef BT_RENDER3D_H
#define BT_RENDER3D_H

void loadResources()
{
    blockShader = LoadShader(
        "shaders/part_depth.vs",
        "shaders/part_depth.fs"
    );

    shadowShader =
    LoadShader(
        "shaders/shadow_depth.vs",
        "shaders/shadow_depth.fs"
    );

    // Post-process shader is used for Lighting.Blur.
    postProcessShader =
    LoadShader(
        "shaders/postprocess.vs",
        "shaders/postprocess.fs"
    );

    blockMesh = GenMeshCube(1.0f, 1.0f, 1.0f);

    sphereMesh =
        GenMeshSphere(
            1.0f,
            32,
            16
        );

    cylinderMesh =
        GenMeshCylinder(
            1.0f,
            1.0f,
            64
        );

    sphereMeshMedium = GenMeshSphere(1.0f, 16, 8);
    sphereMeshLow = GenMeshSphere(1.0f, 8, 4);
    cylinderMeshMedium = GenMeshCylinder(1.0f, 1.0f, 32);
    cylinderMeshLow = GenMeshCylinder(1.0f, 1.0f, 16);


    blockMaterial = LoadMaterialDefault();
    blockMaterial.shader = blockShader;

    shadowMaterial = LoadMaterialDefault();
    shadowMaterial.shader = shadowShader;

    shadowMap =
        LoadShadowMap(1024, 1024);

    lightingSceneTarget =
        LoadRenderTexture(
            GetScreenWidth(),
            GetScreenHeight()
        );

    sunDirectionLoc =
    GetShaderLocation(
        blockShader,
        "sunDirection"
    );

    sunColorLoc =
    GetShaderLocation(
        blockShader,
        "sunColor"
    );

    sunIntensityLoc =
    GetShaderLocation(
        blockShader,
        "sunIntensity"
    );

    ambientLoc =
    GetShaderLocation(
        blockShader,
        "ambientStrength"
    );

    ambientColorLoc =
    GetShaderLocation(
        blockShader,
        "ambientColor"
    );

    outdoorAmbientLoc =
    GetShaderLocation(
        blockShader,
        "outdoorAmbient"
    );

    brightnessLoc =
    GetShaderLocation(
        blockShader,
        "brightness"
    );

    exposureCompensationLoc =
    GetShaderLocation(
        blockShader,
        "exposureCompensation"
    );

    colorShiftTopLoc =
    GetShaderLocation(
        blockShader,
        "colorShiftTop"
    );

    colorShiftBottomLoc =
    GetShaderLocation(
        blockShader,
        "colorShiftBottom"
    );

    fogColorLoc =
    GetShaderLocation(
        blockShader,
        "fogColor"
    );

    fogStartLoc =
    GetShaderLocation(
        blockShader,
        "fogStart"
    );

    fogEndLoc =
    GetShaderLocation(
        blockShader,
        "fogEnd"
    );

    cameraPositionLoc =
    GetShaderLocation(
        blockShader,
        "cameraPosition"
    );

    globalShadowsLoc =
    GetShaderLocation(
        blockShader,
        "globalShadows"
    );

    shadowSoftnessLoc =
    GetShaderLocation(
        blockShader,
        "shadowSoftness"
    );

    shadowFilterSizeLoc =
    GetShaderLocation(
        blockShader,
        "shadowFilterSize"
    );

    shadowMapLoc =
    GetShaderLocation(
        blockShader,
        "shadowMap"
    );

    shadowMapTexelSizeLoc =
        GetShaderLocation(
            blockShader,
            "shadowMapTexelSize"
        );

    lightSpaceMatrixLoc =
        GetShaderLocation(
            blockShader,
            "lightSpaceMatrix"
        );

    shadowLightSpaceLoc =
    GetShaderLocation(
        shadowShader,
        "lightSpaceMatrix"
    );

    postProcessTexelSizeLoc =
        GetShaderLocation(
            postProcessShader,
            "texelSize"
        );

    postProcessBlurLoc =
        GetShaderLocation(
            postProcessShader,
            "blurStrength"
        );

    reflectanceLoc = GetShaderLocation(blockShader, "reflectance");
    environmentSpecularScaleLoc = GetShaderLocation(blockShader, "environmentSpecularScale");
    lightCountLoc = GetShaderLocation(blockShader, "lightCount");
    lightPosLoc = GetShaderLocation(blockShader, "lightPos");
    lightColorLoc = GetShaderLocation(blockShader, "lightColor");
    lightDirLoc = GetShaderLocation(blockShader, "lightDir");
    lightBrightnessLoc = GetShaderLocation(blockShader, "lightBrightness");
    lightRangeLoc = GetShaderLocation(blockShader, "lightRange");
    lightAngleLoc = GetShaderLocation(blockShader, "lightAngle");
    lightKindLoc = GetShaderLocation(blockShader, "lightKind");
}

void resizeLightingSceneTargetIfNeeded()
{
    if (lightingSceneTarget.texture.id == 0)
    {
        lightingSceneTarget =
            LoadRenderTexture(
                GetScreenWidth(),
                GetScreenHeight()
            );
        return;
    }

    if (lightingSceneTarget.texture.width != GetScreenWidth() ||
        lightingSceneTarget.texture.height != GetScreenHeight())
    {
        UnloadRenderTexture(lightingSceneTarget);

        lightingSceneTarget =
            LoadRenderTexture(
                GetScreenWidth(),
                GetScreenHeight()
            );
    }
}

// ============================================================
// Render 3D
// ============================================================
static bool isPartVisibleInCamera(const Part& part, const Camera3D& camera)
{
    Vector3 forward = Vector3Normalize(Vector3Subtract(camera.target, camera.position));
    Vector3 right = Vector3Normalize(Vector3CrossProduct(forward, camera.up));
    Vector3 up = Vector3Normalize(Vector3CrossProduct(right, forward));
    Vector3 offset = Vector3Subtract(part.cframe.position, camera.position);
    float depth = Vector3DotProduct(offset, forward);
    float radius = Vector3Length(part.size) * 0.5f;

    if (depth + radius < 0.01f)
        return false;

    float halfVertical = 0.0f;
    if (camera.projection == CAMERA_ORTHOGRAPHIC)
    {
        halfVertical = max(0.01f, camera.fovy * 0.5f);
        if (depth + radius < 0.01f)
            return false;
        if (depth < -radius)
            return false;
    }
    else
    {
        float tanHalfFov = tanf(camera.fovy * DEG2RAD * 0.5f);
        halfVertical = max(0.0f, depth) * tanHalfFov;
    }

    float aspect = static_cast<float>(max(1, GetScreenWidth())) /
        static_cast<float>(max(1, GetScreenHeight()));
    float tanHalfVertical = camera.projection == CAMERA_ORTHOGRAPHIC
        ? 0.0f : tanf(camera.fovy * DEG2RAD * 0.5f);
    float tanHalfHorizontal = tanHalfVertical * aspect;
    float halfHorizontal = halfVertical * aspect;
    float planeRadiusVertical = radius * sqrtf(1.0f + tanHalfVertical * tanHalfVertical);
    float planeRadiusHorizontal = radius * sqrtf(1.0f + tanHalfHorizontal * tanHalfHorizontal);
    float horizontal = Vector3DotProduct(offset, right);
    float vertical = Vector3DotProduct(offset, up);

    if (fabsf(horizontal) > halfHorizontal + planeRadiusHorizontal ||
        fabsf(vertical) > halfVertical + planeRadiusVertical)
        return false;

    return true;
}

static float getPartProjectedDiameter(const Part& part, const Camera3D& camera, float radius)
{
    float distance = max(0.01f, Vector3Distance(camera.position, part.cframe.position));
    if (camera.projection == CAMERA_ORTHOGRAPHIC)
        return 2.0f * radius * GetScreenHeight() / max(0.01f, camera.fovy);
    return 2.0f * radius * GetScreenHeight() /
        (2.0f * distance * max(0.0001f, tanf(camera.fovy * DEG2RAD * 0.5f)));
}

static int getPartLodSlices(const Part& part, const Camera3D* camera, float radius)
{
    if (camera == nullptr)
        return 32;
    float projectedDiameter = getPartProjectedDiameter(part, *camera, radius);
    return projectedDiameter >= 48.0f ? 32 : (projectedDiameter >= 16.0f ? 16 : 8);
}

static const Mesh& getPartLodMesh(const Part& part, const Camera3D* camera, float radius)
{
    bool sphere = part.type == PartType::Sphere;
    const Mesh& high = sphere ? sphereMesh : cylinderMesh;
    const Mesh& medium = sphere ? sphereMeshMedium : cylinderMeshMedium;
    const Mesh& low = sphere ? sphereMeshLow : cylinderMeshLow;
    if (camera == nullptr)
        return high;

    float projectedDiameter = getPartProjectedDiameter(part, *camera, radius);

    if (projectedDiameter >= 48.0f)
        return high;
    if (projectedDiameter >= 16.0f)
        return medium;
    return low;
}

void DrawTorus(Vector3 position,float radius,float thickness,Vector3 axis,Color color)
{
    torusMaterial.maps[MATERIAL_MAP_DIFFUSE].color = color;

    Quaternion rotationQuat =
        QuaternionFromVector3ToVector3(
            { 0, 1, 0 },
            Vector3Normalize(axis)
        );

    Matrix rotationMatrix =
        QuaternionToMatrix(rotationQuat);

    // The mesh was created with majorRadius=1 and minorRadius=0.05.
    // Convert the requested tube radius back from that native 0.05 radius.
    const float TORUS_MESH_TUBE_RADIUS = 0.05f;

    Matrix scaleMatrix = MatrixScale(
        radius,
        thickness / TORUS_MESH_TUBE_RADIUS,
        radius
    );

    Matrix transform =
        MatrixMultiply(
            scaleMatrix,
            rotationMatrix
        );

    transform = MatrixMultiply(
        transform,
        MatrixTranslate(
            position.x,
            position.y,
            position.z
        )
    );

    DrawMesh(
        torusMesh,
        torusMaterial,
        transform
    );
}

void DrawCubeCFrame(const CFrame& cframe,Vector3 size,Color color)
{
    BeginCFrame(cframe);

    DrawCubeV(
        { 0.0f, 0.0f, 0.0f },
        size,
        color
    );

    EndCFrame();
}

// Draw a Texture instance mapped onto one face of its parent Part (Roblox-like decal).
void DrawTextureOnPartFace(const Part& part, const TextureInstance& tex)
{
    if (tex.transparency >= 0.999f)
        return;
    ProjectAsset* asset = findProjectAssetById(tex.texture);
    if (asset == nullptr || asset->type != ProjectAssetType::Image)
        return;
    if (!ensureProjectAssetLoaded(*asset) || asset->texture.id == 0)
        return;

    string face = tex.face;
    for (char& c : face)
        if (c >= 'A' && c <= 'Z') c = static_cast<char>(c - 'A' + 'a');

    // Unit-cube face center, tangent axes, and explicit OUTWARD normal.
    // (Previously side-face normals pointed inward, so the quad was buried
    // inside the mesh and depth-tested away — only Top/Bottom worked.)
    Vector3 centerU = { 0, 0.5f, 0 };
    Vector3 rightU  = { 1, 0, 0 };
    Vector3 upU     = { 0, 0, -1 };
    Vector3 normalU = { 0, 1, 0 };
    float faceW = part.size.x;
    float faceH = part.size.z;

    if (face == "top" || face == "up")
    {
        centerU = { 0, 0.5f, 0 };
        rightU  = { 1, 0, 0 };
        upU     = { 0, 0, -1 };
        normalU = { 0, 1, 0 };
        faceW = part.size.x; faceH = part.size.z;
    }
    else if (face == "bottom" || face == "down")
    {
        centerU = { 0, -0.5f, 0 };
        rightU  = { 1, 0, 0 };
        upU     = { 0, 0, 1 };
        normalU = { 0, -1, 0 };
        faceW = part.size.x; faceH = part.size.z;
    }
    else if (face == "front")
    {
        // Outward -Z; right × up must equal normal
        centerU = { 0, 0, -0.5f };
        rightU  = { -1, 0, 0 };
        upU     = { 0, 1, 0 };
        normalU = { 0, 0, -1 };
        faceW = part.size.x; faceH = part.size.y;
    }
    else if (face == "back")
    {
        // Outward +Z
        centerU = { 0, 0, 0.5f };
        rightU  = { 1, 0, 0 };
        upU     = { 0, 1, 0 };
        normalU = { 0, 0, 1 };
        faceW = part.size.x; faceH = part.size.y;
    }
    else if (face == "left")
    {
        // Outward -X
        centerU = { -0.5f, 0, 0 };
        rightU  = { 0, 0, 1 };
        upU     = { 0, 1, 0 };
        normalU = { -1, 0, 0 };
        faceW = part.size.z; faceH = part.size.y;
    }
    else if (face == "right")
    {
        // Outward +X
        centerU = { 0.5f, 0, 0 };
        rightU  = { 0, 0, -1 };
        upU     = { 0, 1, 0 };
        normalU = { 1, 0, 0 };
        faceW = part.size.z; faceH = part.size.y;
    }

    // Outward epsilon so the quad clears the solid face (larger on sides)
    const float eps = 0.04f;
    Vector3 cLocal = {
        centerU.x * part.size.x + normalU.x * eps,
        centerU.y * part.size.y + normalU.y * eps,
        centerU.z * part.size.z + normalU.z * eps
    };

    float hx = faceW * 0.5f;
    float hy = faceH * 0.5f;
    Vector3 r = Vector3Scale(rightU, hx);
    Vector3 u = Vector3Scale(upU, hy);

    // Stud tiling UV
    float tilesU = max(0.01f, faceW / max(0.01f, tex.studsPerTileU));
    float tilesV = max(0.01f, faceH / max(0.01f, tex.studsPerTileV));
    float u0 = tex.offsetStudsU / max(0.01f, tex.studsPerTileU);
    float v0 = tex.offsetStudsV / max(0.01f, tex.studsPerTileV);
    float u1 = u0 + tilesU;
    float v1 = v0 + tilesV;

    Color tint = tex.color3;
    tint.a = static_cast<unsigned char>(std::clamp(255.0f * (1.0f - tex.transparency), 0.0f, 255.0f));

    Matrix world = GetCFrameMatrix(part.cframe);
    Vector3 p00 = Vector3Transform(Vector3Subtract(Vector3Subtract(cLocal, r), u), world);
    Vector3 p10 = Vector3Transform(Vector3Subtract(Vector3Add(cLocal, r), u), world);
    Vector3 p11 = Vector3Transform(Vector3Add(Vector3Add(cLocal, r), u), world);
    Vector3 p01 = Vector3Transform(Vector3Add(Vector3Subtract(cLocal, r), u), world);

    Vector3 nWorld = rotateVector(normalU, part.cframe.rotation);
    float nl = Vector3Length(nWorld);
    if (nl > 0.0001f) nWorld = Vector3Scale(nWorld, 1.0f / nl);

    // Reset shader so part_depth doesn't eat immediate-mode UVs. Draw with
    // depth test ON but polygon offset / slight outward eps so sides stay visible.
    EndShaderMode();
    rlDisableShader();
    rlSetShader(rlGetShaderIdDefault(), rlGetShaderLocsDefault());
    rlDisableBackfaceCulling();
    rlEnableDepthTest();
    rlSetTexture(asset->texture.id);
    rlBegin(RL_QUADS);
    rlColor4ub(tint.r, tint.g, tint.b, tint.a);
    rlNormal3f(nWorld.x, nWorld.y, nWorld.z);
    // CCW from outside (right × up = normal)
    rlTexCoord2f(u0, v1); rlVertex3f(p00.x, p00.y, p00.z);
    rlTexCoord2f(u1, v1); rlVertex3f(p10.x, p10.y, p10.z);
    rlTexCoord2f(u1, v0); rlVertex3f(p11.x, p11.y, p11.z);
    rlTexCoord2f(u0, v0); rlVertex3f(p01.x, p01.y, p01.z);
    rlEnd();
    rlSetTexture(0);
    rlEnableBackfaceCulling();
}


static void drawAllPartFaceTextures(Instance* root)
{
    if (root == nullptr) return;
    if (root->getType() == InstanceType::Part)
    {
        Part* part = static_cast<Part*>(root);
        for (Instance* child : part->children)
        {
            if (child != nullptr && child->getType() == InstanceType::Texture)
                DrawTextureOnPartFace(*part, *static_cast<const TextureInstance*>(child));
        }
    }
    for (Instance* child : root->children)
        drawAllPartFaceTextures(child);
}

void DrawCubeWiresCFrame(const CFrame& cframe,Vector3 size,Color color)
{
    Matrix transform = GetBlockTransform(cframe, size);

    Vector3 corners[8] = {
        Vector3Transform({ -0.5f, -0.5f, -0.5f }, transform),
        Vector3Transform({  0.5f, -0.5f, -0.5f }, transform),
        Vector3Transform({  0.5f,  0.5f, -0.5f }, transform),
        Vector3Transform({ -0.5f,  0.5f, -0.5f }, transform),
        Vector3Transform({ -0.5f, -0.5f,  0.5f }, transform),
        Vector3Transform({  0.5f, -0.5f,  0.5f }, transform),
        Vector3Transform({  0.5f,  0.5f,  0.5f }, transform),
        Vector3Transform({ -0.5f,  0.5f,  0.5f }, transform)
    };

    const int edges[12][2] = {
        { 0, 1 }, { 1, 2 }, { 2, 3 }, { 3, 0 },
        { 4, 5 }, { 5, 6 }, { 6, 7 }, { 7, 4 },
        { 0, 4 }, { 1, 5 }, { 2, 6 }, { 3, 7 }
    };

    for (const auto& edge : edges)
    {
        DrawLine3D(
            corners[edge[0]],
            corners[edge[1]],
            color
        );
    }
}

void DrawSphereWiresCFrame(const CFrame& cframe, float radius, Color color)
{
    DrawSphereWires(cframe.position, radius, 16, 16, color);
}

void DrawCylinderWiresCFrame(const CFrame& cframe, Vector3 size, Color color)
{
    constexpr int segments = 32;
    const float halfX = size.x * 0.5f;
    const float halfY = size.y * 0.5f;
    const float halfZ = size.z * 0.5f;
    const Matrix transform = GetCFrameMatrix(cframe);
    Vector3 top[segments];
    Vector3 bottom[segments];
    for (int i = 0; i < segments; ++i)
    {
        const float angle = static_cast<float>(i) / segments * 2.0f * PI;
        const float x = cosf(angle) * halfX;
        const float z = sinf(angle) * halfZ;
        top[i] = Vector3Transform({ x, halfY, z }, transform);
        bottom[i] = Vector3Transform({ x, -halfY, z }, transform);
        const int next = (i + 1) % segments;
        DrawLine3D(top[i], Vector3Transform({
            cosf(static_cast<float>(next) / segments * 2.0f * PI) * halfX,
            halfY,
            sinf(static_cast<float>(next) / segments * 2.0f * PI) * halfZ
        }, transform), color);
        DrawLine3D(bottom[i], Vector3Transform({
            cosf(static_cast<float>(next) / segments * 2.0f * PI) * halfX,
            -halfY,
            sinf(static_cast<float>(next) / segments * 2.0f * PI) * halfZ
        }, transform), color);
    }
    for (int i : { 0, segments / 4, segments / 2, segments * 3 / 4 })
        DrawLine3D(bottom[i], top[i], color);
}

static Matrix getCylinderTransform(const CFrame& cframe, Vector3 size)
{
    return MatrixMultiply(
        MatrixMultiply(
            MatrixTranslate(0.0f, -0.5f, 0.0f),
            MatrixScale(size.x * 0.5f, size.y, size.z * 0.5f)),
        GetCFrameMatrix(cframe));
}

void DrawCylinderCFrame(const CFrame& cframe,float radius,float height,Color color)
{
    BeginCFrame(cframe);

    DrawCylinder(
        { 0.0f, 0.0f, 0.0f },
        radius,
        radius,
        height,
        32,
        color
    );

    EndCFrame();
}

void DrawCone(const CFrame& cframe,float radius,float height,Color color,int slices = 32)
{
    Matrix transform = GetCFrameMatrix(cframe);

    rlPushMatrix();

    rlMultMatrixf(
        MatrixToFloat(transform)
    );

    DrawCylinder(
        { 0, 0, 0 },
        radius,
        0.0f,
        height,
        slices,
        color
    );

    rlPopMatrix();
}

void DrawConeAxis(Vector3 position,Vector3 direction,float radius,float height,Color color)
{
    // Raylib DrawCone points along its local Y axis.
    // Rotate the Y axis so it points in `direction`.

    direction = Vector3Normalize(direction);

    Vector3 up = { 0, 1, 0 };

    float dot =
        Vector3DotProduct(up, direction);

    // Same direction as +Y
    if (dot > 0.9999f)
    {
        DrawCylinderEx(
            position,
            Vector3Add(
                position,
                Vector3Scale(direction, height)
            ),
            radius,
            0.0f,
            16,
            color
        );

        return;
    }

    // Opposite direction from +Y
    if (dot < -0.9999f)
    {
        DrawCylinderEx(
            position,
            Vector3Add(
                position,
                Vector3Scale(direction, height)
            ),
            radius,
            0.0f,
            16,
            color
        );

        return;
    }

    // Axis-angle rotation from +Y to direction.
    Vector3 rotationAxis =
        Vector3CrossProduct(
            up,
            direction
        );

    rotationAxis =
        Vector3Normalize(rotationAxis);

    float angle =
        acosf(
            Clamp(dot, -1.0f, 1.0f)
        ) * RAD2DEG;

    rlPushMatrix();

    rlTranslatef(
        position.x,
        position.y,
        position.z
    );

    rlRotatef(
        angle,
        rotationAxis.x,
        rotationAxis.y,
        rotationAxis.z
    );

    DrawCone(
        { 0, 0, 0 },
        radius,
        height,
        color
    );

    rlPopMatrix();
}

void DrawGizmoArrow(Vector3 start, Vector3 direction, float length, float radius, Color color, bool drawCone = true)
{
    // Shaft bar via mesh material (avoids lighting strip). Optional cone tip.
    direction = Vector3Normalize(direction);
    if (length < 0.01f)
        return;

    float headLen = drawCone ? Clamp(length * 0.16f, 0.22f, 0.38f) : 0.0f;
    float shaftLen = max(0.08f, length - headLen);
    float shaftRadius = max(0.035f, radius * 0.38f);
    float headRadius = max(shaftRadius * 2.1f, radius * 1.15f);

    Vector3 shaftEnd = Vector3Add(start, Vector3Scale(direction, shaftLen));
    Vector3 tip = Vector3Add(start, Vector3Scale(direction, length));

    gizmoMaterial.maps[MATERIAL_MAP_DIFFUSE].color = color;

    Quaternion rotationQuat =
        QuaternionFromVector3ToVector3({ 0, 1, 0 }, direction);
    Matrix rotationMatrix = QuaternionToMatrix(rotationQuat);
    Vector3 shaftCenter = Vector3Add(start, Vector3Scale(direction, shaftLen * 0.5f));
    Matrix shaftTransform = MatrixMultiply(
        MatrixMultiply(MatrixScale(shaftRadius, shaftLen, shaftRadius), rotationMatrix),
        MatrixTranslate(shaftCenter.x, shaftCenter.y, shaftCenter.z)
    );
    DrawMesh(cylinderMesh, gizmoMaterial, shaftTransform);

    if (drawCone)
        DrawCylinderEx(shaftEnd, tip, headRadius, 0.001f, 14, color);
}

void renderInstance(const Instance* instance,const CFrame& parentCFrame = {}, const Camera3D* renderCamera = nullptr,
    bool transparentPass = false, bool renderChildren = true)
{
    if (instance == nullptr)
        return;

    switch (instance->getType())
    {
        case InstanceType::Part:
        {
            const Part* part =
                static_cast<const Part*>(instance);

            if (part->transparency >= 0.999f)
                break; // fully invisible

            if ((part->transparency > 0.001f) != transparentPass)
                break;

            if (renderCamera != nullptr && !isPartVisibleInCamera(*part, *renderCamera))
                break;

            CFrame cframe = part->cframe;
            Vector3 position = cframe.position;
            Vector3 size = part->size;
            Color drawColor = part->color;
            drawColor.a = static_cast<unsigned char>(
                std::clamp(255.0f * (1.0f - part->transparency), 0.0f, 255.0f));
            // Per-part reflectance for specular in part_depth.fs
            float refl = std::clamp(part->reflectance, 0.0f, 1.0f)
                * getGraphicsQualityCaps(gameSettings.graphicsQuality).reflectanceScale;
            SetShaderValue(blockShader, reflectanceLoc, &refl, SHADER_UNIFORM_FLOAT);

            if (part->isMeshPart)
            {
                ProjectAsset* meshAsset = findProjectAssetById(part->meshId);
                bool drewMesh = false;
                if (meshAsset != nullptr && meshAsset->type == ProjectAssetType::Mesh &&
                    ensureProjectAssetLoaded(*meshAsset))
                {
                    Vector3 meshSize = {
                        max(0.0001f, meshAsset->meshBoundsMax.x - meshAsset->meshBoundsMin.x),
                        max(0.0001f, meshAsset->meshBoundsMax.y - meshAsset->meshBoundsMin.y),
                        max(0.0001f, meshAsset->meshBoundsMax.z - meshAsset->meshBoundsMin.z)
                    };
                    Vector3 scale = {
                        size.x / meshSize.x, size.y / meshSize.y, size.z / meshSize.z
                    };
                    Vector3 center = {
                        (meshAsset->meshBoundsMin.x + meshAsset->meshBoundsMax.x) * 0.5f * scale.x,
                        (meshAsset->meshBoundsMin.y + meshAsset->meshBoundsMax.y) * 0.5f * scale.y,
                        (meshAsset->meshBoundsMin.z + meshAsset->meshBoundsMax.z) * 0.5f * scale.z
                    };
                    Matrix rotation = MatrixRotateXYZ({
                        cframe.rotation.x * DEG2RAD,
                        cframe.rotation.y * DEG2RAD,
                        cframe.rotation.z * DEG2RAD
                    });
                    Vector3 rotatedCenter = Vector3Transform(center, rotation);
                    Vector3 modelPosition = Vector3Subtract(position, rotatedCenter);
                    Quaternion orientation = QuaternionFromEuler(
                        cframe.rotation.x * DEG2RAD,
                        cframe.rotation.y * DEG2RAD,
                        cframe.rotation.z * DEG2RAD);
                    Vector3 rotationAxis = { 0.0f, 1.0f, 0.0f };
                    float rotationAngle = 0.0f;
                    QuaternionToAxisAngle(orientation, &rotationAxis, &rotationAngle);

                    ProjectAsset* textureAsset = findProjectAssetById(part->textureId);
                    vector<pair<MaterialMap*, Texture2D>> originalTextures;
                    Model& model = meshAsset->meshModel;
                    if (textureAsset != nullptr && textureAsset->type == ProjectAssetType::Image &&
                        ensureProjectAssetLoaded(*textureAsset) &&
                        model.materials != nullptr && model.materialCount > 0)
                    {
                        for (int materialIndex = 0; materialIndex < model.materialCount; ++materialIndex)
                        {
                            Material& material = model.materials[materialIndex];
                            if (material.maps == nullptr)
                                continue;
                            MaterialMap& diffuse = material.maps[MATERIAL_MAP_DIFFUSE];
                            originalTextures.push_back({ &diffuse, diffuse.texture });
                            diffuse.texture = textureAsset->texture;
                        }
                    }

                    DrawModelEx(model, modelPosition, rotationAxis,
                        rotationAngle * RAD2DEG, scale, drawColor);

                    if (!originalTextures.empty())
                    {
                        for (const auto& original : originalTextures)
                            original.first->texture = original.second;
                    }
                    drewMesh = true;
                }
                if (!drewMesh)
                {
                    blockMaterial.maps[MATERIAL_MAP_DIFFUSE].color = drawColor;
                    DrawMesh(blockMesh, blockMaterial, GetBlockTransform(cframe, size));
                }
            }
            else switch (part->type)
            {
                case PartType::Block:
                {
                    blockMaterial.maps[
                        MATERIAL_MAP_DIFFUSE
                    ].color = drawColor;

                    Matrix transform = GetBlockTransform(cframe, size);

                    DrawMesh(
                        blockMesh,
                        blockMaterial,
                        transform
                    );

                    /*DrawCubeWiresCFrame(
                        cframe,
                        size,
                        BLACK
                    );*/

                    break;
                }

                case PartType::Cylinder:
                {
                    Matrix transform = getCylinderTransform(cframe, size);

                    blockMaterial.maps[
                        MATERIAL_MAP_DIFFUSE
                    ].color = drawColor;

                    DrawMesh(
                        getPartLodMesh(*part, renderCamera, size.x * 0.5f),
                        blockMaterial,
                        transform
                    );

                    break;
                }

                case PartType::Sphere:
                {
                    Matrix transform =
                        GetCFrameMatrix(cframe);

                    transform =
                        MatrixMultiply(
                            MatrixScale(
                                size.x * 0.5f,
                                size.y * 0.5f,
                                size.z * 0.5f
                            ),
                            transform
                        );

                    blockMaterial.maps[
                        MATERIAL_MAP_DIFFUSE
                    ].color = drawColor;

                    DrawMesh(
                        getPartLodMesh(*part, renderCamera, size.x * 0.5f),
                        blockMaterial,
                        transform
                    );

                    break;
                }

                case PartType::Cone:
                {
                    float radius = size.x / 2.0f;
                    float height = size.y;

                    DrawCone(
                        cframe,
                        radius,
                        height,
                        drawColor,
                        getPartLodSlices(*part, renderCamera, radius)
                    );

                    break;
                }

                case PartType::Wedge:
                {
                    // TODO:
                    // Create a custom wedge mesh.

                    break;
                }

                case PartType::CornerWedge:
                {
                    // TODO:
                    // Create a custom corner-wedge mesh.

                    break;
                }
            }

            // Texture children warp onto the chosen face of this Part
            for (const Instance* child : part->children)
            {
                if (child != nullptr && child->getType() == InstanceType::Texture)
                    DrawTextureOnPartFace(*part, *static_cast<const TextureInstance*>(child));
            }

            break;
        }

        case InstanceType::Model:
        {
            // Models don't necessarily need to draw anything.
            // Their children will be rendered below.
            break;
        }

        case InstanceType::Script:
        {
            // Scripts aren't rendered.
            break;
        }

        case InstanceType::Folder:
        {
            // Folders aren't rendered.
            break;
        }
    }

    // Render children
    if (renderChildren)
        for (const Instance* child : instance->children)
            renderInstance(child, parentCFrame, renderCamera, transparentPass, true);
}

static void collectTransparentParts(const Instance* instance, const Camera3D& camera,
    vector<const Part*>& parts)
{
    if (instance == nullptr)
        return;
    if (instance->getType() == InstanceType::Part)
    {
        const Part* part = static_cast<const Part*>(instance);
        if (part->transparency > 0.001f && part->transparency < 0.999f &&
            isPartVisibleInCamera(*part, camera))
            parts.push_back(part);
    }
    for (const Instance* child : instance->children)
        collectTransparentParts(child, camera, parts);
}

static void renderTransparentParts(const vector<Instance*>& roots, const Camera3D& camera)
{
    vector<const Part*> parts;
    for (const Instance* root : roots)
        collectTransparentParts(root, camera, parts);
    sort(parts.begin(), parts.end(), [&](const Part* a, const Part* b)
    {
        return Vector3Distance(camera.position, a->cframe.position) >
            Vector3Distance(camera.position, b->cframe.position);
    });

    rlEnableDepthTest();
    rlDisableDepthMask();
    for (const Part* part : parts)
        renderInstance(part, {}, &camera, true, false);
    rlEnableDepthMask();
}

void renderShadowCasters(Instance* instance,const CFrame& parentCFrame = {})
{
    if (!instance)
        return;

    if (instance->getType() == InstanceType::Part)
    {
        Part* shadowPart = static_cast<Part*>(instance);
        if (!shadowPart->castShadow || shadowPart->transparency >= 0.999f)
        {
            for (Instance* child : instance->children)
                renderShadowCasters(child, parentCFrame);
            return;
        }
        Part* part =
            static_cast<Part*>(instance);

        CFrame cframe = part->cframe;

        if (part->isMeshPart)
        {
            ProjectAsset* asset = findProjectAssetById(part->meshId);
            if (asset != nullptr && asset->type == ProjectAssetType::Mesh &&
                ensureProjectAssetLoaded(*asset) && asset->meshModel.materials != nullptr)
            {
                Vector3 meshSize = {
                    max(0.0001f, asset->meshBoundsMax.x - asset->meshBoundsMin.x),
                    max(0.0001f, asset->meshBoundsMax.y - asset->meshBoundsMin.y),
                    max(0.0001f, asset->meshBoundsMax.z - asset->meshBoundsMin.z)
                };
                Vector3 scale = {
                    part->size.x / meshSize.x,
                    part->size.y / meshSize.y,
                    part->size.z / meshSize.z
                };
                Vector3 center = {
                    (asset->meshBoundsMin.x + asset->meshBoundsMax.x) * 0.5f * scale.x,
                    (asset->meshBoundsMin.y + asset->meshBoundsMax.y) * 0.5f * scale.y,
                    (asset->meshBoundsMin.z + asset->meshBoundsMax.z) * 0.5f * scale.z
                };
                Matrix rotation = MatrixRotateXYZ({
                    cframe.rotation.x * DEG2RAD,
                    cframe.rotation.y * DEG2RAD,
                    cframe.rotation.z * DEG2RAD
                });
                Vector3 modelPosition = Vector3Subtract(cframe.position,
                    Vector3Transform(center, rotation));
                Quaternion orientation = QuaternionFromEuler(
                    cframe.rotation.x * DEG2RAD,
                    cframe.rotation.y * DEG2RAD,
                    cframe.rotation.z * DEG2RAD);
                Vector3 axis = { 0.0f, 1.0f, 0.0f };
                float angle = 0.0f;
                QuaternionToAxisAngle(orientation, &axis, &angle);
                Model& model = asset->meshModel;
                for (int i = 0; i < model.materialCount; ++i)
                    model.materials[i].shader = shadowShader;
                DrawModelEx(model, modelPosition, axis, angle * RAD2DEG, scale, WHITE);
                for (int i = 0; i < model.materialCount; ++i)
                    model.materials[i].shader = blockShader;
            }
        }
        else if (part->type == PartType::Block)
        {
            Matrix transform = GetBlockTransform(cframe, part->size);

            DrawMesh(
                blockMesh,
                shadowMaterial,
                transform
            );
        }
        else if (part->type == PartType::Sphere)
        {
            Matrix transform =
                GetCFrameMatrix(cframe);

            transform =
                MatrixMultiply(
                    MatrixScale(
                        part->size.x * 0.5f,
                        part->size.y * 0.5f,
                        part->size.z * 0.5f
                    ),
                    transform
                );

            DrawMesh(
                sphereMesh,
                shadowMaterial,
                transform
            );
        }
        else if (part->type == PartType::Cylinder)
        {
            Matrix transform = getCylinderTransform(cframe, part->size);

            DrawMesh(
                cylinderMesh,
                shadowMaterial,
                transform
            );
        }
    }

    for (Instance* child : instance->children)
    {
        renderShadowCasters(child, parentCFrame);
    }
}

static uint64_t appendShadowHash(uint64_t hash, uint64_t value)
{
    hash ^= value + 0x9e3779b97f4a7c15ull + (hash << 6) + (hash >> 2);
    return hash;
}

static uint64_t shadowSceneHash(const Instance* instance, uint64_t hash)
{
    if (instance == nullptr)
        return hash;
    if (instance->getType() == InstanceType::Part)
    {
        const Part* part = static_cast<const Part*>(instance);
        if (part->castShadow && part->transparency < 0.999f)
        {
            hash = appendShadowHash(hash, std::hash<string>{}(part->meshId));
            hash = appendShadowHash(hash, static_cast<uint64_t>(part->type));
            hash = appendShadowHash(hash, static_cast<uint64_t>(part->isMeshPart));
            const float values[] = {
                part->cframe.position.x, part->cframe.position.y, part->cframe.position.z,
                part->cframe.rotation.x, part->cframe.rotation.y, part->cframe.rotation.z,
                part->size.x, part->size.y, part->size.z, part->transparency
            };
            for (float value : values)
                hash = appendShadowHash(hash, std::hash<float>{}(value));
        }
    }
    for (const Instance* child : instance->children)
        hash = shadowSceneHash(child, hash);
    return hash;
}

static uint64_t currentShadowSceneHash(const Vector3& focus)
{
    uint64_t hash = 0xcbf29ce484222325ull;
    const float values[] = {
        sun.direction.x, sun.direction.y, sun.direction.z,
        focus.x, focus.y, focus.z
    };
    for (float value : values)
        hash = appendShadowHash(hash, std::hash<float>{}(value));
    return shadowSceneHash(&workspace, hash);
}

void renderGizmo(GizmoType gizmoType,const Part& part,Camera3D& camera)
{
    // Gizmo origin = world pivot (position + rotated PivotOffset)
    Vector3 position = getPartWorldPivot(part);

    Vector3 xAxis = rotateVector({ 1, 0, 0 }, part.cframe.rotation);
    Vector3 yAxis = rotateVector({ 0, 1, 0 }, part.cframe.rotation);
    Vector3 zAxis = rotateVector({ 0, 0, 1 }, part.cframe.rotation);

    float xDistance = part.size.x * 0.5f + 0.35f;
    float yDistance = part.size.y * 0.5f + 0.35f;
    float zDistance = part.size.z * 0.5f + 0.35f;

    Color xColor = hoveredGizmoAxis == GizmoAxis::X ? (Color){ 255, 160, 120, 255 } : (Color){ 232, 110, 80, 255 };
    Color yColor = hoveredGizmoAxis == GizmoAxis::Y ? (Color){ 140, 220, 150, 255 } : (Color){ 80, 185, 115, 255 };
    Color zColor = hoveredGizmoAxis == GizmoAxis::Z ? (Color){ 130, 175, 255, 255 } : (Color){ 85, 140, 230, 255 };

    // ============================================================
    // MOVE (Roblox-style: +X/+Y/+Z arrows + center sphere)
    // ============================================================

    // Shared center drag sphere (all gizmo modes) — smaller than before
    auto drawCenterSphere = [&]()
    {
        Color centerColor = hoveredGizmoAxis == GizmoAxis::Center
            ? (Color){ 255, 255, 255, 255 }
            : (Color){ 230, 230, 235, 255 };
        gizmoMaterial.maps[MATERIAL_MAP_DIFFUSE].color = centerColor;
        float r = 0.14f;
        Matrix centerXform = MatrixMultiply(
            MatrixScale(r, r, r),
            MatrixTranslate(position.x, position.y, position.z)
        );
        DrawMesh(sphereMesh, gizmoMaterial, centerXform);
    };

    if (gizmoType == GizmoType::Move)
    {
        // Constant-size bars only (no cones) so move handles stay readable
        const float arrowLen = 2.4f;
        const float arrowRadius = 0.11f;
        DrawGizmoArrow(position, xAxis, arrowLen, arrowRadius, xColor, false);
        DrawGizmoArrow(position, Vector3Scale(xAxis, -1.0f), arrowLen, arrowRadius, xColor, false);
        DrawGizmoArrow(position, yAxis, arrowLen, arrowRadius, yColor, false);
        DrawGizmoArrow(position, Vector3Scale(yAxis, -1.0f), arrowLen, arrowRadius, yColor, false);
        DrawGizmoArrow(position, zAxis, arrowLen, arrowRadius, zColor, false);
        DrawGizmoArrow(position, Vector3Scale(zAxis, -1.0f), arrowLen, arrowRadius, zColor, false);
        drawCenterSphere();
    }
    else if (gizmoType == GizmoType::Scale)
    {
        // Material + DrawMesh so scale handles don't strip under lighting shader
        auto drawScaleHandle = [&](Vector3 pos, Color c)
        {
            gizmoMaterial.maps[MATERIAL_MAP_DIFFUSE].color = c;
            const float r = 0.28f; // bigger scale spheres
            Matrix t = MatrixMultiply(
                MatrixScale(r, r, r),
                MatrixTranslate(pos.x, pos.y, pos.z)
            );
            DrawMesh(sphereMesh, gizmoMaterial, t);
        };

        drawScaleHandle(Vector3Add(position, Vector3Scale(xAxis, xDistance)), xColor);
        drawScaleHandle(Vector3Add(position, Vector3Scale(xAxis, -xDistance)), xColor);
        drawScaleHandle(Vector3Add(position, Vector3Scale(yAxis, yDistance)), yColor);
        drawScaleHandle(Vector3Add(position, Vector3Scale(yAxis, -yDistance)), yColor);
        drawScaleHandle(Vector3Add(position, Vector3Scale(zAxis, zDistance)), zColor);
        drawScaleHandle(Vector3Add(position, Vector3Scale(zAxis, -zDistance)), zColor);
        drawCenterSphere();
    }


    // ============================================================
    // ROTATE
    // ============================================================

    else if (gizmoType == GizmoType::Rotate)
    {
        float radius =
            max(
                max(
                    part.size.x,
                    part.size.y
                ),
                part.size.z
            ) * 0.5f + 1.0f;


        DrawTorus(
            position,
            radius,
            0.06f,
            xAxis,
            xColor
        );

        DrawTorus(
            position,
            radius,
            0.06f,
            yAxis,
            yColor
        );

        DrawTorus(
            position,
            radius,
            0.06f,
            zAxis,
            zColor
        );
        drawCenterSphere();
    }
}

void renderSunLight()
{
    Vector3 sunPosition =
        Vector3Scale(
            Vector3Normalize(sun.direction),
            -10.0f
        );

    DrawSphere(
        sunPosition,
        0.5f,
        sun.color
    );
}

// World position for a light parented under a Part (or free under Workspace)
static Vector3 getLightWorldPosition(Instance* light)
{
    if (light == nullptr) return { 0, 0, 0 };
    for (Instance* p = light->parent; p != nullptr; p = p->parent)
    {
        if (p->getType() == InstanceType::Part)
            return static_cast<Part*>(p)->cframe.position;
    }
    return { 0, 2, 0 };
}

static Vector3 faceToDirection(const string& face)
{
    string f = face;
    for (char& c : f) c = (char)tolower((unsigned char)c);
    if (f == "back") return { 0, 0, 1 };
    if (f == "left") return { -1, 0, 0 };
    if (f == "right") return { 1, 0, 0 };
    if (f == "top") return { 0, 1, 0 };
    if (f == "bottom") return { 0, -1, 0 };
    return { 0, 0, -1 }; // Front
}

// Roblox-style light range debug (Show Light Ranges): spheres / cones
void renderLightRangeDebug(Instance* root)
{
    if (root == nullptr) return;
    function<void(Instance*)> walk = [&](Instance* inst)
    {
        if (!inst) return;
        if (inst->getType() == InstanceType::PointLight)
        {
            auto* L = static_cast<PointLightInstance*>(inst);
            if (L->enabled)
            {
                Vector3 pos = getLightWorldPosition(inst);
                Color c = { L->color.r, L->color.g, L->color.b, 90 };
                float r = max(0.1f, L->range);
                DrawSphereWires(pos, r, 16, 16, c);
                DrawSphere(pos, 0.18f, L->color);
                // Light path rays (axis + diagonals) show how far light reaches
                Color ray = { L->color.r, L->color.g, L->color.b, 160 };
                const Vector3 dirs[] = {
                    { 1, 0, 0 }, { -1, 0, 0 }, { 0, 1, 0 }, { 0, -1, 0 },
                    { 0, 0, 1 }, { 0, 0, -1 },
                    { 0.707f, 0.707f, 0 }, { -0.707f, 0.707f, 0 },
                    { 0.707f, 0, 0.707f }, { 0, 0.707f, 0.707f }
                };
                for (const Vector3& d : dirs)
                    DrawLine3D(pos, Vector3Add(pos, Vector3Scale(d, r)), ray);
            }
        }
        else if (inst->getType() == InstanceType::SpotLight || inst->getType() == InstanceType::SurfaceLight)
        {
            bool isSpot = inst->getType() == InstanceType::SpotLight;
            float range = isSpot ? static_cast<SpotLightInstance*>(inst)->range
                                 : static_cast<SurfaceLightInstance*>(inst)->range;
            float angle = isSpot ? static_cast<SpotLightInstance*>(inst)->angle
                                 : static_cast<SurfaceLightInstance*>(inst)->angle;
            Color col = isSpot ? static_cast<SpotLightInstance*>(inst)->color
                               : static_cast<SurfaceLightInstance*>(inst)->color;
            bool en = isSpot ? static_cast<SpotLightInstance*>(inst)->enabled
                             : static_cast<SurfaceLightInstance*>(inst)->enabled;
            string face = isSpot ? static_cast<SpotLightInstance*>(inst)->face
                                 : static_cast<SurfaceLightInstance*>(inst)->face;
            if (en)
            {
                Vector3 pos = getLightWorldPosition(inst);
                Vector3 dir = faceToDirection(face);
                // Rotate by parent part orientation if any
                for (Instance* p = inst->parent; p; p = p->parent)
                {
                    if (p->getType() == InstanceType::Part)
                    {
                        dir = rotateVector(dir, static_cast<Part*>(p)->cframe.rotation);
                        break;
                    }
                }
                float rad = angle * DEG2RAD * 0.5f;
                float tipR = max(0.1f, range * tanf(rad));
                Vector3 tip = Vector3Add(pos, Vector3Scale(dir, range));
                Color wire = { col.r, col.g, col.b, 100 };
                Color ray = { col.r, col.g, col.b, 180 };
                DrawLine3D(pos, tip, col);
                // Cone edge rays (light path)
                Vector3 up = { 0, 1, 0 };
                if (fabsf(Vector3DotProduct(dir, up)) > 0.95f)
                    up = { 1, 0, 0 };
                Vector3 right = Vector3Normalize(Vector3CrossProduct(dir, up));
                Vector3 up2 = Vector3Normalize(Vector3CrossProduct(right, dir));
                for (int i = 0; i < 8; ++i)
                {
                    float a = (float)i * (2.0f * PI / 8.0f);
                    Vector3 edge = Vector3Add(
                        Vector3Scale(right, cosf(a) * tipR),
                        Vector3Scale(up2, sinf(a) * tipR));
                    DrawLine3D(pos, Vector3Add(tip, edge), ray);
                }
                DrawCircle3D(tip, tipR, dir, 0.0f, wire);
                DrawSphere(pos, 0.14f, col);
            }
        }
        for (Instance* c : inst->children)
            walk(c);
    };
    walk(root);
    walk(&workspace);
}

// Accumulate enabled local lights for multi-light shading (up to 8)
struct RuntimeLocalLight
{
    int kind; // 0=point 1=spot 2=surface
    Vector3 position;
    Vector3 direction;
    Color color;
    float brightness;
    float range;
    float angle;
    bool shadows;
};
vector<RuntimeLocalLight> collectRuntimeLocalLights()
{
    vector<RuntimeLocalLight> lights;
    function<void(Instance*)> walk = [&](Instance* inst)
    {
        if (!inst || lights.size() >= 8) return;
        if (inst->getType() == InstanceType::PointLight)
        {
            auto* L = static_cast<PointLightInstance*>(inst);
            if (!L->enabled) { for (auto* c : inst->children) walk(c); return; }
            RuntimeLocalLight rl{};
            rl.kind = 0;
            rl.position = getLightWorldPosition(inst);
            rl.color = L->color;
            rl.brightness = L->brightness;
            rl.range = L->range;
            rl.shadows = L->shadows;
            lights.push_back(rl);
        }
        else if (inst->getType() == InstanceType::SpotLight)
        {
            auto* L = static_cast<SpotLightInstance*>(inst);
            if (L->enabled)
            {
                RuntimeLocalLight rl{};
                rl.kind = 1;
                rl.position = getLightWorldPosition(inst);
                rl.direction = faceToDirection(L->face);
                for (Instance* p = inst->parent; p; p = p->parent)
                {
                    if (p->getType() == InstanceType::Part)
                    {
                        rl.direction = rotateVector(rl.direction, static_cast<Part*>(p)->cframe.rotation);
                        break;
                    }
                }
                rl.color = L->color;
                rl.brightness = L->brightness;
                rl.range = L->range;
                rl.angle = L->angle;
                rl.shadows = L->shadows;
                lights.push_back(rl);
            }
        }
        else if (inst->getType() == InstanceType::SurfaceLight)
        {
            auto* L = static_cast<SurfaceLightInstance*>(inst);
            if (L->enabled)
            {
                RuntimeLocalLight rl{};
                rl.kind = 2;
                rl.position = getLightWorldPosition(inst);
                rl.direction = faceToDirection(L->face);
                for (Instance* p = inst->parent; p; p = p->parent)
                {
                    if (p->getType() == InstanceType::Part)
                    {
                        rl.direction = rotateVector(rl.direction, static_cast<Part*>(p)->cframe.rotation);
                        break;
                    }
                }
                rl.color = L->color;
                rl.brightness = L->brightness;
                rl.range = L->range;
                rl.angle = L->angle;
                rl.shadows = L->shadows;
                lights.push_back(rl);
            }
        }
        for (Instance* c : inst->children)
            walk(c);
    };
    walk(&workspace);
    walk(&game);
    walk(&Lighting); // lights parented under Lighting service
    return lights;
}

void updateSunDirectionFromClockTime()
{
    // Lightweight approximation of Roblox-style ClockTime behavior.
    // 12:00 is overhead-ish daylight; 0:00 is the opposite side.
    float hourAngle =
        (lightingSettings.clockTime / 24.0f) * 2.0f * PI;

    float latitude =
        Clamp(lightingSettings.geographicLatitude, -90.0f, 90.0f) * DEG2RAD;

    float elevation =
        sinf(hourAngle);

    float horizontal =
        cosf(hourAngle);

    // Keep the sun usable in the editor even at extreme latitude values.
    float y =
        Clamp(
            elevation * 0.85f +
            cosf(latitude) * 0.15f,
            -0.98f,
            0.98f
        );

    sun.direction = Vector3Normalize({
        -horizontal,
        -y,
        -0.55f
    });
}

void updateSunShader(const Camera3D& camera)
{
    Vector3 direction =
        Vector3Normalize(sun.direction);

    float sunColorData[3] = {
        sun.color.r / 255.0f,
        sun.color.g / 255.0f,
        sun.color.b / 255.0f
    };

    float ambientColorData[3] = {
        lightingSettings.ambient.r / 255.0f,
        lightingSettings.ambient.g / 255.0f,
        lightingSettings.ambient.b / 255.0f
    };

    float colorShiftTopData[3] = {
        lightingSettings.colorShiftTop.r / 255.0f,
        lightingSettings.colorShiftTop.g / 255.0f,
        lightingSettings.colorShiftTop.b / 255.0f
    };

    float colorShiftBottomData[3] = {
        lightingSettings.colorShiftBottom.r / 255.0f,
        lightingSettings.colorShiftBottom.g / 255.0f,
        lightingSettings.colorShiftBottom.b / 255.0f
    };

    float fogColorData[3] = {
        lightingSettings.fogColor.r / 255.0f,
        lightingSettings.fogColor.g / 255.0f,
        lightingSettings.fogColor.b / 255.0f
    };

    float brightness =
        max(0.0f, lightingSettings.brightness);

    float exposure =
        lightingSettings.exposureCompensation;

    float ambientStrength =
        Clamp(
            sun.ambient * lightingSettings.environmentDiffuseScale,
            0.0f,
            1.0f
        );

    SetShaderValue(
        blockShader,
        sunDirectionLoc,
        &direction,
        SHADER_UNIFORM_VEC3
    );

    SetShaderValue(
        blockShader,
        sunColorLoc,
        sunColorData,
        SHADER_UNIFORM_VEC3
    );

    // Dim directional sun at night so local lights dominate
    float hourAngle = (lightingSettings.clockTime / 24.0f) * 2.0f * PI;
    float dayF = Clamp(powf(Clamp(sinf(hourAngle) * 0.5f + 0.5f, 0.0f, 1.0f), 0.65f), 0.0f, 1.0f);
    float sunIntensity = sun.intensity * (0.08f + 0.92f * dayF);

    SetShaderValue(
        blockShader,
        sunIntensityLoc,
        &sunIntensity,
        SHADER_UNIFORM_FLOAT
    );

    SetShaderValue(
        blockShader,
        ambientLoc,
        &ambientStrength,
        SHADER_UNIFORM_FLOAT
    );

    SetShaderValue(
        blockShader,
        ambientColorLoc,
        ambientColorData,
        SHADER_UNIFORM_VEC3
    );

    float outdoorAmbientData[3] = {
        lightingSettings.outdoorAmbient.r / 255.0f,
        lightingSettings.outdoorAmbient.g / 255.0f,
        lightingSettings.outdoorAmbient.b / 255.0f
    };

    SetShaderValue(
        blockShader,
        outdoorAmbientLoc,
        outdoorAmbientData,
        SHADER_UNIFORM_VEC3
    );

    SetShaderValue(
        blockShader,
        brightnessLoc,
        &brightness,
        SHADER_UNIFORM_FLOAT
    );

    SetShaderValue(
        blockShader,
        exposureCompensationLoc,
        &exposure,
        SHADER_UNIFORM_FLOAT
    );

    SetShaderValue(
        blockShader,
        colorShiftTopLoc,
        colorShiftTopData,
        SHADER_UNIFORM_VEC3
    );

    SetShaderValue(
        blockShader,
        colorShiftBottomLoc,
        colorShiftBottomData,
        SHADER_UNIFORM_VEC3
    );

    SetShaderValue(
        blockShader,
        fogColorLoc,
        fogColorData,
        SHADER_UNIFORM_VEC3
    );

    float fogStart =
        max(0.0f, lightingSettings.fogStart);

    float fogEnd =
        max(fogStart + 0.001f, lightingSettings.fogEnd);

    SetShaderValue(
        blockShader,
        fogStartLoc,
        &fogStart,
        SHADER_UNIFORM_FLOAT
    );

    SetShaderValue(
        blockShader,
        fogEndLoc,
        &fogEnd,
        SHADER_UNIFORM_FLOAT
    );

    float cameraPositionData[3] = {
        camera.position.x,
        camera.position.y,
        camera.position.z
    };

    SetShaderValue(
        blockShader,
        cameraPositionLoc,
        cameraPositionData,
        SHADER_UNIFORM_VEC3
    );

    GraphicsQualityCaps gfx = getGraphicsQualityCaps(gameSettings.graphicsQuality);

    int globalShadows =
        (lightingSettings.globalShadows && gfx.shadowsEnabled) ? 1 : 0;

    SetShaderValue(
        blockShader,
        globalShadowsLoc,
        &globalShadows,
        SHADER_UNIFORM_INT
    );

    // Lighting.ShadowSoftness kept for API; filter density comes from graphics quality
    int shadowSoftness = 0;
    if (lightingSettings.shadowSoftness == "Hard") shadowSoftness = 1;
    else if (lightingSettings.shadowSoftness == "Sharp") shadowSoftness = 2;
    SetShaderValue(
        blockShader,
        shadowSoftnessLoc,
        &shadowSoftness,
        SHADER_UNIFORM_INT
    );

    int shadowFilterSize = gfx.shadowFilterSize;
    SetShaderValue(
        blockShader,
        shadowFilterSizeLoc,
        &shadowFilterSize,
        SHADER_UNIFORM_INT
    );

    // Shadow information
    SetShaderValueMatrix(
        blockShader,
        lightSpaceMatrixLoc,
        lightSpaceMatrix
    );

    float shadowMapTexelSize[2] = {
        1.0f / shadowMap.depth.width,
        1.0f / shadowMap.depth.height
    };

    SetShaderValue(
        blockShader,
        shadowMapTexelSizeLoc,
        shadowMapTexelSize,
        SHADER_UNIFORM_VEC2
    );

    int shadowTextureUnit = 1;

    SetShaderValue(
        blockShader,
        shadowMapLoc,
        &shadowTextureUnit,
        SHADER_UNIFORM_INT
    );

    // Environment specular scale (feeds Part.Reflectance) — scaled by graphics quality
    GraphicsQualityCaps gfxSpec = getGraphicsQualityCaps(gameSettings.graphicsQuality);
    float envSpec = lightingSettings.environmentSpecularScale * gfxSpec.specularScale;
    SetShaderValue(blockShader, environmentSpecularScaleLoc, &envSpec, SHADER_UNIFORM_FLOAT);
    float defaultRefl = 0.0f;
    SetShaderValue(blockShader, reflectanceLoc, &defaultRefl, SHADER_UNIFORM_FLOAT);

    // Multi local lights → shader arrays (capped by graphics quality)
    vector<RuntimeLocalLight> localLights = collectRuntimeLocalLights();
    int nLights = (int)localLights.size();
    int maxL = getGraphicsQualityCaps(gameSettings.graphicsQuality).maxLights;
    if (nLights > maxL) nLights = maxL;
    if (nLights > 8) nLights = 8;
    float posData[8 * 3] = {};
    float colData[8 * 3] = {};
    float dirData[8 * 3] = {};
    float brightData[8] = {};
    float rangeData[8] = {};
    float angleData[8] = {};
    int kindData[8] = {};
    for (int i = 0; i < nLights; ++i)
    {
        const auto& L = localLights[i];
        posData[i * 3 + 0] = L.position.x;
        posData[i * 3 + 1] = L.position.y;
        posData[i * 3 + 2] = L.position.z;
        colData[i * 3 + 0] = L.color.r / 255.0f;
        colData[i * 3 + 1] = L.color.g / 255.0f;
        colData[i * 3 + 2] = L.color.b / 255.0f;
        Vector3 d = Vector3Normalize(L.direction);
        dirData[i * 3 + 0] = d.x;
        dirData[i * 3 + 1] = d.y;
        dirData[i * 3 + 2] = d.z;
        brightData[i] = max(0.0f, L.brightness);
        rangeData[i] = max(0.01f, L.range);
        angleData[i] = max(1.0f, L.angle);
        kindData[i] = L.kind;
    }
    SetShaderValue(blockShader, lightCountLoc, &nLights, SHADER_UNIFORM_INT);
    if (nLights > 0)
    {
        SetShaderValueV(blockShader, lightPosLoc, posData, SHADER_UNIFORM_VEC3, nLights);
        SetShaderValueV(blockShader, lightColorLoc, colData, SHADER_UNIFORM_VEC3, nLights);
        SetShaderValueV(blockShader, lightDirLoc, dirData, SHADER_UNIFORM_VEC3, nLights);
        SetShaderValueV(blockShader, lightBrightnessLoc, brightData, SHADER_UNIFORM_FLOAT, nLights);
        SetShaderValueV(blockShader, lightRangeLoc, rangeData, SHADER_UNIFORM_FLOAT, nLights);
        SetShaderValueV(blockShader, lightAngleLoc, angleData, SHADER_UNIFORM_FLOAT, nLights);
        SetShaderValueV(blockShader, lightKindLoc, kindData, SHADER_UNIFORM_INT, nLights);
    }

    rlActiveTextureSlot(shadowTextureUnit);
    rlEnableTexture(shadowMap.depth.id);
}

void renderLightingPostProcess()
{
    GraphicsQualityCaps gfx = getGraphicsQualityCaps(gameSettings.graphicsQuality);
    if (!gfx.postProcess)
    {
        // Blit scene as-is (skip blur shader work)
        Rectangle source = {
            0.0f, 0.0f,
            static_cast<float>(lightingSceneTarget.texture.width),
            -static_cast<float>(lightingSceneTarget.texture.height)
        };
        Rectangle destination = {
            0.0f, 0.0f,
            static_cast<float>(GetScreenWidth()),
            static_cast<float>(GetScreenHeight())
        };
        DrawTexturePro(lightingSceneTarget.texture, source, destination, { 0, 0 }, 0.0f, WHITE);
        return;
    }

    float texelSize[2] = {
        1.0f / max(1, lightingSceneTarget.texture.width),
        1.0f / max(1, lightingSceneTarget.texture.height)
    };

    float blur =
        Clamp(
            lightingSettings.blur,
            0.0f,
            8.0f
        );

    SetShaderValue(
        postProcessShader,
        postProcessTexelSizeLoc,
        texelSize,
        SHADER_UNIFORM_VEC2
    );

    SetShaderValue(
        postProcessShader,
        postProcessBlurLoc,
        &blur,
        SHADER_UNIFORM_FLOAT
    );

    Rectangle source = {
        0.0f,
        0.0f,
        static_cast<float>(lightingSceneTarget.texture.width),
        -static_cast<float>(lightingSceneTarget.texture.height)
    };

    Rectangle destination = {
        0.0f,
        0.0f,
        static_cast<float>(GetScreenWidth()),
        static_cast<float>(GetScreenHeight())
    };

    BeginShaderMode(postProcessShader);

    DrawTexturePro(
        lightingSceneTarget.texture,
        source,
        destination,
        { 0.0f, 0.0f },
        0.0f,
        WHITE
    );

    EndShaderMode();
}

// ============================================================
// Render 2D

// ============================================================


#endif // BT_RENDER3D_H