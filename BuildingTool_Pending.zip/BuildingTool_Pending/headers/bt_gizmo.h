// bt_gizmo.h — Gizmo handles, interaction, draw helpers
#pragma once
#ifndef BT_GIZMO_H
#define BT_GIZMO_H



// ===========================================================
// Gizmo Functions
// ===========================================================

float getCameraRelativeAxisDrag(Camera3D& camera,Vector3 axis,Vector2 mouseDelta)
{
    axis = Vector3Normalize(axis);

    // Camera forward
    Vector3 forward =
        Vector3Normalize(
            Vector3Subtract(
                camera.target,
                camera.position
            )
        );

    // Camera up
    Vector3 up =
        Vector3Normalize(camera.up);

    // Camera right
    Vector3 right =
        Vector3Normalize(
            Vector3CrossProduct(
                forward,
                up
            )
        );

    // Project the 3D axis onto the camera screen.
    float screenX =
        Vector3DotProduct(
            axis,
            right
        );

    float screenY =
        Vector3DotProduct(
            axis,
            up
        );

    Vector2 screenAxis = {
        screenX,
        -screenY
    };

    float length =
        Vector2Length(screenAxis);

    // Axis is pointing almost directly at camera.
    if (length < 0.05f)
        return 0.0f;

    screenAxis =
        Vector2Scale(
            screenAxis,
            1.0f / length
        );

    // How much the mouse moved along
    // the projected gizmo axis.
    return Vector2DotProduct(
        mouseDelta,
        screenAxis
    );
}

float getWorldUnitsPerScreenPixel(Camera3D& camera, Vector3 origin, Vector3 axis)
{
    Vector2 originScreen = GetWorldToScreen(origin, camera);
    Vector2 axisScreen = GetWorldToScreen(Vector3Add(origin, Vector3Normalize(axis)), camera);
    float pixelsPerUnit = Vector2Distance(originScreen, axisScreen);
    return pixelsPerUnit > 0.001f ? 1.0f / pixelsPerUnit : 0.0f;
}

GizmoAxis getGizmoAxis(Camera3D& camera,Vector3 position,float size)
{
    Vector2 mouse = GetMousePosition();
    Ray ray = GetMouseRay(mouse, camera);

    float closestDistance = FLT_MAX;
    GizmoAxis closestAxis = GizmoAxis::None;

    // Make the axes into thin boxes so the ray can hit them.
    float thickness = 0.12f;

    // X axis
    {
        BoundingBox box = {
            {
                position.x,
                position.y - thickness,
                position.z - thickness
            },
            {
                position.x + size,
                position.y + thickness,
                position.z + thickness
            }
        };

        RayCollision hit = GetRayCollisionBox(ray, box);

        if (hit.hit && hit.distance < closestDistance)
        {
            closestDistance = hit.distance;
            closestAxis = GizmoAxis::X;
        }
    }

    // Y axis
    {
        BoundingBox box = {
            {
                position.x - thickness,
                position.y,
                position.z - thickness
            },
            {
                position.x + thickness,
                position.y + size,
                position.z + thickness
            }
        };

        RayCollision hit = GetRayCollisionBox(ray, box);

        if (hit.hit && hit.distance < closestDistance)
        {
            closestDistance = hit.distance;
            closestAxis = GizmoAxis::Y;
        }
    }

    // Z axis
    {
        BoundingBox box = {
            {
                position.x - thickness,
                position.y - thickness,
                position.z
            },
            {
                position.x + thickness,
                position.y + thickness,
                position.z + size
            }
        };

        RayCollision hit = GetRayCollisionBox(ray, box);

        if (hit.hit && hit.distance < closestDistance)
        {
            closestDistance = hit.distance;
            closestAxis = GizmoAxis::Z;
        }
    }

    return closestAxis;
}

GizmoHandle getGizmoHandle(const Part& part,GizmoAxis axis,int sign)
{
    Vector3 axisDirection;

    float distance = 0.0f;

    switch (axis)
    {
        case GizmoAxis::X:
            axisDirection =
                rotateVector(
                    { 1, 0, 0 },
                    part.cframe.rotation
                );

            distance =
                part.size.x * 0.5f + 0.35f;

            break;

        case GizmoAxis::Y:
            axisDirection =
                rotateVector(
                    { 0, 1, 0 },
                    part.cframe.rotation
                );

            distance =
                part.size.y * 0.5f + 0.35f;

            break;

        case GizmoAxis::Z:
            axisDirection =
                rotateVector(
                    { 0, 0, 1 },
                    part.cframe.rotation
                );

            distance =
                part.size.z * 0.5f + 0.35f;

            break;

        default:
            return {
                GizmoAxis::None,
                1,
                part.cframe.position
            };
    }

    axisDirection =
        Vector3Scale(
            axisDirection,
            distance * sign
        );

    return {
        axis,
        sign,
        Vector3Add(
            part.cframe.position,
            axisDirection
        )
    };
}

vector<GizmoHandle> getGizmoHandles(const Part& part)
{
    Vector3 halfSize = {
        part.size.x * 0.5f,
        part.size.y * 0.5f,
        part.size.z * 0.5f
    };

    float offset = 0.25f;

    return {
        // Right
        {
            GizmoAxis::X,
            1,
            localToWorld(
                part.cframe,
                { halfSize.x + offset, 0, 0 }
            )
        },

        // Left
        {
            GizmoAxis::X,
            -1,
            localToWorld(
                part.cframe,
                { -halfSize.x - offset, 0, 0 }
            )
        },

        // Top
        {
            GizmoAxis::Y,
            1,
            localToWorld(
                part.cframe,
                { 0, halfSize.y + offset, 0 }
            )
        },

        // Bottom
        {
            GizmoAxis::Y,
            -1,
            localToWorld(
                part.cframe,
                { 0, -halfSize.y - offset, 0 }
            )
        },

        // Front
        {
            GizmoAxis::Z,
            1,
            localToWorld(
                part.cframe,
                { 0, 0, halfSize.z + offset }
            )
        },

        // Back
        {
            GizmoAxis::Z,
            -1,
            localToWorld(
                part.cframe,
                { 0, 0, -halfSize.z - offset }
            )
        }
    };
}

GizmoAxis getHoveredRotationAxis(Camera3D& camera,const Part& part)
{
    Vector2 mouse =
        GetMousePosition();

    Vector2 center =
        GetWorldToScreen(
            part.cframe.position,
            camera
        );

    float radiusWorld =
        max(
            max(
                part.size.x,
                part.size.y
            ),
            part.size.z
        ) * 0.5f + 1.0f;

    // Convert a nearby world point to screen space
    // to get an approximate screen radius.
    Vector3 radiusPoint =
        Vector3Add(
            part.cframe.position,
            { radiusWorld, 0, 0 }
        );

    Vector2 screenRadiusPoint =
        GetWorldToScreen(
            radiusPoint,
            camera
        );

    float screenRadius =
        Vector2Distance(
            center,
            screenRadiusPoint
        );

    float mouseRadius =
        Vector2Distance(
            center,
            mouse
        );

    // Allow some thickness around the ring.
    if (fabsf(mouseRadius - screenRadius) > 30.0f)
        return GizmoAxis::None;

    Vector2 direction =
        Vector2Subtract(
            mouse,
            center
        );

    if (Vector2Length(direction) < 1.0f)
        return GizmoAxis::None;

    direction =
        Vector2Normalize(direction);

    Vector3 worldX =
        rotateVector(
            { 1, 0, 0 },
            part.cframe.rotation
        );

    Vector3 worldY =
        rotateVector(
            { 0, 1, 0 },
            part.cframe.rotation
        );

    Vector3 worldZ =
        rotateVector(
            { 0, 0, 1 },
            part.cframe.rotation
        );

    Vector2 xScreen =
        Vector2Subtract(
            GetWorldToScreen(
                Vector3Add(
                    part.cframe.position,
                    Vector3Scale(
                        worldX,
                        radiusWorld
                    )
                ),
                camera
            ),
            center
        );

    Vector2 yScreen =
        Vector2Subtract(
            GetWorldToScreen(
                Vector3Add(
                    part.cframe.position,
                    Vector3Scale(
                        worldY,
                        radiusWorld
                    )
                ),
                camera
            ),
            center
        );

    Vector2 zScreen =
        Vector2Subtract(
            GetWorldToScreen(
                Vector3Add(
                    part.cframe.position,
                    Vector3Scale(
                        worldZ,
                        radiusWorld
                    )
                ),
                camera
            ),
            center
        );

    xScreen = Vector2Normalize(xScreen);
    yScreen = Vector2Normalize(yScreen);
    zScreen = Vector2Normalize(zScreen);

    float xDot =
        fabsf(
            Vector2DotProduct(
                direction,
                xScreen
            )
        );

    float yDot =
        fabsf(
            Vector2DotProduct(
                direction,
                yScreen
            )
        );

    float zDot =
        fabsf(
            Vector2DotProduct(
                direction,
                zScreen
            )
        );

    if (xDot >= yDot && xDot >= zDot)
        return GizmoAxis::X;

    if (yDot >= xDot && yDot >= zDot)
        return GizmoAxis::Y;

    return GizmoAxis::Z;
}

GizmoHandle getHoveredGizmo(Camera3D& camera,const Part& part)
{
    Vector3 pivot = getPartWorldPivot(part);
    GizmoHandle result = { GizmoAxis::None, 1, pivot };
    Vector2 mouse = GetMousePosition();
    float closestDistance = 28.0f;

    // Center sphere available in Move / Scale / Rotate
    Vector2 centerScreen = GetWorldToScreen(pivot, camera);
    if (Vector2Distance(mouse, centerScreen) < 14.0f)
    {
        result.axis = GizmoAxis::Center;
        result.sign = 1;
        result.position = pivot;
        return result;
    }

    if (currentGizmo == GizmoType::Move)
    {
        // Hit-test whole shaft (not only tip): screen-space distance to segment
        // Match DrawGizmoArrow constant length
        auto axisLen = [](float /*halfExtent*/) {
            return 2.4f;
        };
        float lens[3] = {
            axisLen(part.size.x * 0.5f),
            axisLen(part.size.y * 0.5f),
            axisLen(part.size.z * 0.5f)
        };
        GizmoAxis axes[3] = { GizmoAxis::X, GizmoAxis::Y, GizmoAxis::Z };
        Vector3 dirs[3] = {
            rotateVector({ 1, 0, 0 }, part.cframe.rotation),
            rotateVector({ 0, 1, 0 }, part.cframe.rotation),
            rotateVector({ 0, 0, 1 }, part.cframe.rotation)
        };

        // Generous pixel threshold; tip gets a bit more
        const float shaftHitPx = 22.0f;
        const float tipHitPx = 30.0f;

        for (int ai = 0; ai < 3; ++ai)
        {
            Vector3 axisDir = Vector3Normalize(dirs[ai]);
            float len = lens[ai];
            for (int sign : { -1, 1 })
            {
                Vector3 dir = Vector3Scale(axisDir, (float)sign);
                Vector3 tip = Vector3Add(pivot, Vector3Scale(dir, len));
                // Skip the very center (leave for center sphere) — start a bit out
                Vector3 shaftStart = Vector3Add(pivot, Vector3Scale(dir, 0.18f));

                Vector2 a = GetWorldToScreen(shaftStart, camera);
                Vector2 b = GetWorldToScreen(tip, camera);
                Vector2 ab = { b.x - a.x, b.y - a.y };
                float abLen2 = ab.x * ab.x + ab.y * ab.y;
                float t = 0.0f;
                if (abLen2 > 1e-4f)
                {
                    t = ((mouse.x - a.x) * ab.x + (mouse.y - a.y) * ab.y) / abLen2;
                    t = Clamp(t, 0.0f, 1.0f);
                }
                Vector2 closest = { a.x + ab.x * t, a.y + ab.y * t };
                float dist = Vector2Distance(mouse, closest);
                // Near tip → larger tolerance
                float threshold = (t > 0.72f) ? tipHitPx : shaftHitPx;
                if (dist < closestDistance && dist < threshold)
                {
                    closestDistance = dist;
                    result.axis = axes[ai];
                    result.sign = sign;
                    result.position = tip;
                }
            }
        }
        return result;
    }

    // Scale: 6 face handles
    GizmoAxis axes[3] = { GizmoAxis::X, GizmoAxis::Y, GizmoAxis::Z };
    for (GizmoAxis axis : axes)
    {
        for (int sign : { -1, 1 })
        {
            GizmoHandle handle = getGizmoHandle(part, axis, sign);
            Vector3 axisDir =
                axis == GizmoAxis::X ? rotateVector({ 1, 0, 0 }, part.cframe.rotation) :
                axis == GizmoAxis::Y ? rotateVector({ 0, 1, 0 }, part.cframe.rotation) :
                                       rotateVector({ 0, 0, 1 }, part.cframe.rotation);
            float dist =
                axis == GizmoAxis::X ? part.size.x * 0.5f + 0.35f :
                axis == GizmoAxis::Y ? part.size.y * 0.5f + 0.35f :
                                       part.size.z * 0.5f + 0.35f;
            handle.position = Vector3Add(pivot, Vector3Scale(axisDir, dist * static_cast<float>(sign)));
            handle.axis = axis;
            handle.sign = sign;
            float distance = Vector2Distance(mouse, GetWorldToScreen(handle.position, camera));
            if (distance < closestDistance)
            {
                closestDistance = distance;
                result = handle;
            }
        }
    }
    return result;
}


bool getRotationMouseAngle(Camera3D& camera,Vector3 center,Vector3 axis,float& angle)
{
    Vector2 mouse = GetMousePosition();
    Ray ray = GetMouseRay(mouse, camera);

    axis = Vector3Normalize(axis);

    // Intersect mouse ray with the rotation plane.
    float denominator =
        Vector3DotProduct(ray.direction, axis);

    if (fabsf(denominator) < 0.0001f)
        return false;

    Vector3 toCenter =
        Vector3Subtract(center, ray.position);

    float t =
        Vector3DotProduct(toCenter, axis)
        / denominator;

    if (t < 0.0f)
        return false;

    Vector3 hitPoint =
        Vector3Add(
            ray.position,
            Vector3Scale(ray.direction, t)
        );

    Vector3 radial =
        Vector3Subtract(hitPoint, center);

    // Remove any tiny component along the axis.
    radial =
        Vector3Subtract(
            radial,
            Vector3Scale(
                axis,
                Vector3DotProduct(radial, axis)
            )
        );

    if (Vector3Length(radial) < 0.0001f)
        return false;

    radial = Vector3Normalize(radial);

    Vector3 cameraForward =
        Vector3Normalize(
            Vector3Subtract(
                camera.target,
                camera.position
            )
        );

    Vector3 cameraRight =
        Vector3Normalize(
            Vector3CrossProduct(
                cameraForward,
                camera.up
            )
        );

    Vector3 reference =
        Vector3Subtract(
            cameraRight,
            Vector3Scale(
                axis,
                Vector3DotProduct(cameraRight, axis)
            )
        );

    if (Vector3Length(reference) < 0.0001f)
    {
        reference =
            Vector3Subtract(
                camera.up,
                Vector3Scale(
                    axis,
                    Vector3DotProduct(camera.up, axis)
                )
            );
    }

    reference = Vector3Normalize(reference);

    Vector3 tangent =
        Vector3Normalize(
            Vector3CrossProduct(axis, reference)
        );

    float x =
        Vector3DotProduct(radial, reference);

    float y =
        Vector3DotProduct(radial, tangent);

    angle = atan2f(y, x);

    return true;
}

Color getGizmoColor(GizmoAxis axis,GizmoAxis hoveredAxis)
{
    bool hovered = axis == hoveredAxis;

    switch (axis)
    {
        case GizmoAxis::X:
            return hovered ? MAROON : RED;

        case GizmoAxis::Y:
            return hovered ? DARKGREEN : GREEN;

        case GizmoAxis::Z:
            return hovered ? DARKBLUE : BLUE;

        default:
            return WHITE;
    }
}

void handleGizmoMode()
{
    if (IsKeyPressed(KEY_ONE))
    {
        selectToolActive = true;
        activeGizmoAxis = GizmoAxis::None;
        hoveredGizmoAxis = GizmoAxis::None;
    }

    if (IsKeyPressed(KEY_TWO))
    {
        currentGizmo = GizmoType::Move;
        selectToolActive = false;
    }

    if (IsKeyPressed(KEY_THREE))
    {
        currentGizmo = GizmoType::Scale;
        selectToolActive = false;
    }

    if (IsKeyPressed(KEY_FOUR))
    {
        currentGizmo = GizmoType::Rotate;
        selectToolActive = false;
    }
}

void handleGizmoInteraction(Camera3D& camera)
{
    if (selectToolActive)
        return;
    gizmoParts = getSelectedParts();

    if (gizmoParts.empty())
        return;

    // Proxy part: position at selection pivot (Model/Folder average or PrimaryPart)
    static Part gizmoProxyPart;
    gizmoProxyPart.cframe.position = getSelectionGizmoPivot();
    gizmoProxyPart.cframe.rotation = gizmoParts.front()->cframe.rotation;
    gizmoProxyPart.size = gizmoParts.front()->size;
    gizmoProxyPart.pivotOffset = { 0, 0, 0 };
    Part* part = &gizmoProxyPart;


    // ============================================================
    // HOVER
    // ============================================================

    if (!draggingGizmo)
    {
        if (currentGizmo == GizmoType::Rotate)
        {
            hoveredGizmoAxis =
                getHoveredRotationAxis(
                    camera,
                    *part
                );

            hoveredGizmoSign = 1;
        }
        else
        {
            GizmoHandle handle =
                getHoveredGizmo(
                    camera,
                    *part
                );

            hoveredGizmoAxis =
                handle.axis;

            hoveredGizmoSign =
                handle.sign;
        }
    }


    // ============================================================
    // START DRAG
    // ============================================================

    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
    {
        if (currentGizmo == GizmoType::Rotate)
        {
            // Prefer center sphere (free move) over rotation rings
            GizmoHandle centerCheck = getHoveredGizmo(camera, *part);
            if (centerCheck.axis == GizmoAxis::Center)
            {
                activeGizmoAxis = GizmoAxis::Center;
                activeGizmoSign = 1;
                draggingGizmo = true;
                gizmoStartMouse = GetMousePosition();
                gizmoDragValue = 0.0f;
                gizmoStartPosition = getPartWorldPivot(*part);
                gizmoStartSize = part->size;
                gizmoStartRotation = part->cframe.rotation;
                gizmoStartModelScale = selectedInstances.size() == 1 &&
                    selectedInstances.front() != nullptr &&
                    selectedInstances.front()->getType() == InstanceType::Model
                    ? static_cast<Model_Instance*>(selectedInstances.front())->scale : 1.0f;
                gizmoStartPositions.clear();
                gizmoStartSizes.clear();
                gizmoStartRotations.clear();
                for (Part* selectedPart : gizmoParts)
                {
                    gizmoStartPositions.push_back(selectedPart->cframe.position);
                    gizmoStartSizes.push_back(selectedPart->size);
                    gizmoStartRotations.push_back(selectedPart->cframe.rotation);
                }
            }
            else
            {
            GizmoAxis axis =
                getHoveredRotationAxis(
                    camera,
                    *part
                );

            if (axis != GizmoAxis::None)
            {
                activeGizmoAxis = axis;
                activeGizmoSign = 1;

                draggingGizmo = true;

                gizmoStartMouse =
                    GetMousePosition();

                gizmoDragValue = 0.0f;

                gizmoStartPosition =
                    getPartWorldPivot(*part);

                gizmoStartSize =
                    part->size;
                gizmoStartModelScale = selectedInstances.size() == 1 &&
                    selectedInstances.front() != nullptr &&
                    selectedInstances.front()->getType() == InstanceType::Model
                    ? static_cast<Model_Instance*>(selectedInstances.front())->scale : 1.0f;

                gizmoStartRotation =
                    part->cframe.rotation;

                gizmoCenterScale = IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL);
                gizmoResize = IsKeyDown(KEY_LEFT_ALT) || IsKeyDown(KEY_RIGHT_ALT);
                gizmoStartPositions.clear();
                gizmoStartSizes.clear();
                gizmoStartRotations.clear();

                for (Part* selectedPart : gizmoParts)
                {
                    gizmoStartPositions.push_back(selectedPart->cframe.position);
                    gizmoStartSizes.push_back(selectedPart->size);
                    gizmoStartRotations.push_back(selectedPart->cframe.rotation);
                }


                Vector3 rotationAxis;

                if (axis == GizmoAxis::X)
                    rotationAxis = rotateVector({ 1, 0, 0 }, gizmoStartRotation);
                else if (axis == GizmoAxis::Y)
                    rotationAxis = rotateVector({ 0, 1, 0 }, gizmoStartRotation);
                else
                    rotationAxis = rotateVector({ 0, 0, 1 }, gizmoStartRotation);

                if (!getRotationMouseAngle(
                    camera,
                    gizmoStartPosition,
                    rotationAxis,
                    gizmoStartAngle
                ))
                {
                    draggingGizmo = false;
                    activeGizmoAxis = GizmoAxis::None;
                    return;
                }
            }
            }
        }
        else
        {
            GizmoHandle handle =
                getHoveredGizmo(
                    camera,
                    *part
                );

            if (handle.axis != GizmoAxis::None)
            {
                activeGizmoAxis =
                    handle.axis;

                activeGizmoSign =
                    handle.sign;

                draggingGizmo = true;

                gizmoStartMouse =
                    GetMousePosition();

                gizmoDragValue = 0.0f;

                gizmoStartPosition =
                    getPartWorldPivot(*part);

                gizmoStartSize =
                    part->size;
                gizmoStartModelScale = selectedInstances.size() == 1 &&
                    selectedInstances.front() != nullptr &&
                    selectedInstances.front()->getType() == InstanceType::Model
                    ? static_cast<Model_Instance*>(selectedInstances.front())->scale : 1.0f;

                gizmoStartRotation =
                    part->cframe.rotation;

                gizmoCenterScale = IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL);
                gizmoResize = IsKeyDown(KEY_LEFT_ALT) || IsKeyDown(KEY_RIGHT_ALT);
                gizmoStartPositions.clear();
                gizmoStartSizes.clear();
                gizmoStartRotations.clear();

                for (Part* selectedPart : gizmoParts)
                {
                    gizmoStartPositions.push_back(selectedPart->cframe.position);
                    gizmoStartSizes.push_back(selectedPart->size);
                    gizmoStartRotations.push_back(selectedPart->cframe.rotation);
                }
            }
        }
    }


    // ============================================================
    // RELEASE
    // ============================================================

    bool releaseGizmo =
        IsMouseButtonReleased(MOUSE_BUTTON_LEFT);


    if (!draggingGizmo)
        return;


    // ============================================================
    // ROTATE
    // ============================================================

    if (currentGizmo == GizmoType::Rotate && activeGizmoAxis != GizmoAxis::Center)
    {
        Vector3 rotationAxis;

        if (activeGizmoAxis == GizmoAxis::X)
            rotationAxis = rotateVector({ 1, 0, 0 }, gizmoStartRotation);
        else if (activeGizmoAxis == GizmoAxis::Y)
            rotationAxis = rotateVector({ 0, 1, 0 }, gizmoStartRotation);
        else
            rotationAxis = rotateVector({ 0, 0, 1 }, gizmoStartRotation);

        float currentAngle = 0.0f;

        if (!getRotationMouseAngle(
                camera,
                gizmoStartPosition,
                rotationAxis,
                currentAngle
            ))
        {
            if (releaseGizmo)
                draggingGizmo = false;

            return;
        }

        float angleDelta =
            currentAngle -
            gizmoStartAngle;

        // Keep angle between -PI and PI.
        while (angleDelta > PI)
            angleDelta -= 2.0f * PI;

        while (angleDelta < -PI)
            angleDelta += 2.0f * PI;

        float degrees =
            angleDelta * RAD2DEG;

        gizmoDragValue = degrees;


        for (size_t i = 0; i < gizmoParts.size(); i++)
        {
            Vector3 localAxis;

            if (activeGizmoAxis == GizmoAxis::X)
                localAxis = { 1, 0, 0 };
            else if (activeGizmoAxis == GizmoAxis::Y)
                localAxis = { 0, 1, 0 };
            else
                localAxis = { 0, 0, 1 };

            gizmoParts[i]->cframe.rotation =
                rotateCFrameEuler(
                    gizmoStartRotations[i],
                    localAxis,
                    degrees
                );

            Vector3 offset =
                Vector3Subtract(
                    gizmoStartPositions[i],
                    gizmoStartPosition
                );

            gizmoParts[i]->cframe.position =
                Vector3Add(
                    gizmoStartPosition,
                    Vector3RotateByAxisAngle(
                        offset,
                        rotationAxis,
                        degrees * DEG2RAD
                    )
                );

        }

        if (releaseGizmo)
        {
            draggingGizmo = false;
            activeGizmoAxis = GizmoAxis::None;
            activeGizmoSign = 1;
        }

        return;
    }


    // ============================================================
    // MOVE / SCALE
    // ============================================================

    Vector2 mouse = GetMousePosition();
    Vector2 delta = Vector2Subtract(mouse, gizmoStartMouse);

    // Center drag (all gizmo modes) — free move on camera plane / surface snap.
    if (activeGizmoAxis == GizmoAxis::Center)
    {
        Ray ray = GetMouseRay(mouse, camera);
        Vector3 planeOrigin = gizmoStartPosition;
        Vector3 planeNormal = Vector3Normalize(Vector3Subtract(camera.position, planeOrigin));
        float denom = Vector3DotProduct(ray.direction, planeNormal);
        Vector3 hitPoint = planeOrigin;
        if (fabsf(denom) > 1e-5f)
        {
            float t = Vector3DotProduct(Vector3Subtract(planeOrigin, ray.position), planeNormal) / denom;
            if (t > 0.0f)
                hitPoint = Vector3Add(ray.position, Vector3Scale(ray.direction, t));
        }

        float closest = FLT_MAX;
        Vector3 snapPoint = hitPoint;
        bool snapped = false;
        function<void(Instance*)> walk = [&](Instance* inst)
        {
            if (!inst) return;
            if (inst->getType() == InstanceType::Part)
            {
                Part* other = static_cast<Part*>(inst);
                bool isSelected = false;
                for (Part* sp : gizmoParts)
                    if (sp == other) { isSelected = true; break; }
                if (isSelected)
                {
                    for (Instance* c : inst->children) walk(c);
                    return;
                }

                Vector3 half = Vector3Scale(other->size, 0.5f);
                BoundingBox box = {
                    Vector3Subtract(other->cframe.position, half),
                    Vector3Add(other->cframe.position, half)
                };
                RayCollision col = GetRayCollisionBox(ray, box);
                if (col.hit && col.distance < closest)
                {
                    closest = col.distance;
                    snapPoint = col.point;
                    snapped = true;
                }
            }
            for (Instance* c : inst->children)
                walk(c);
        };
        walk(&workspace);

        Vector3 targetPivot = snapped ? snapPoint : hitPoint;
        Vector3 moveDelta = Vector3Subtract(targetPivot, gizmoStartPosition);
        for (size_t i = 0; i < gizmoParts.size(); i++)
        {
            Vector3 startPivot = localToWorld(
                { gizmoStartPositions[i], gizmoStartRotations[i] },
                gizmoParts[i]->pivotOffset
            );
            setPartWorldPivot(*gizmoParts[i], Vector3Add(startPivot, moveDelta));
        }

        if (releaseGizmo)
        {
            draggingGizmo = false;
            activeGizmoAxis = GizmoAxis::None;
            activeGizmoSign = 1;
        }
        return;
    }

    Vector3 activeAxis = { 0, 0, 0 };
    switch (activeGizmoAxis)
    {
        case GizmoAxis::X:
            activeAxis = rotateVector({ 1, 0, 0 }, gizmoStartRotation);
            break;
        case GizmoAxis::Y:
            activeAxis = rotateVector({ 0, 1, 0 }, gizmoStartRotation);
            break;
        case GizmoAxis::Z:
            activeAxis = rotateVector({ 0, 0, 1 }, gizmoStartRotation);
            break;
        default:
            return;
    }

    float screenMovement = getCameraRelativeAxisDrag(camera, activeAxis, delta);
    float amount = screenMovement * getWorldUnitsPerScreenPixel(camera, gizmoStartPosition, activeAxis);

    // ============================================================
    // MOVE (axis)
    // ============================================================

    if (currentGizmo == GizmoType::Move)
    {
        Vector3 axis = activeAxis;
        for (size_t i = 0; i < gizmoParts.size(); i++)
        {
            gizmoParts[i]->cframe.position =
                Vector3Add(gizmoStartPositions[i], Vector3Scale(axis, amount));
        }
        gizmoDragValue = Vector3Distance(
            gizmoParts.front()->cframe.position,
            gizmoStartPositions.front()
        );
    }


    // ============================================================
    // SCALE
    // ============================================================

    else if (currentGizmo == GizmoType::Scale)
    {
        // Roblox-like scale:
        //   default     — grow/shrink from opposite face (position shifts half delta)
        //   Ctrl        — scale about center (both sides, position fixed on axis)
        //   Alt         — uniform scale (all axes by same factor)
        Vector3 scaleAxis =
            activeGizmoAxis == GizmoAxis::X ? rotateVector({ 1, 0, 0 }, gizmoStartRotation) :
            activeGizmoAxis == GizmoAxis::Y ? rotateVector({ 0, 1, 0 }, gizmoStartRotation) :
            activeGizmoAxis == GizmoAxis::Z ? rotateVector({ 0, 0, 1 }, gizmoStartRotation) :
            Vector3{ 0, 0, 0 };

        if (activeGizmoAxis == GizmoAxis::None || activeGizmoAxis == GizmoAxis::Center)
            return;

        if (selectedInstances.size() == 1 && selectedInstances.front() != nullptr &&
            selectedInstances.front()->getType() == InstanceType::Model)
        {
            float oldAxisSize =
                activeGizmoAxis == GizmoAxis::X ? gizmoStartSize.x :
                activeGizmoAxis == GizmoAxis::Y ? gizmoStartSize.y : gizmoStartSize.z;
            float newAxisSize = max(0.1f, oldAxisSize + amount * static_cast<float>(activeGizmoSign));
            float scaleFactor = newAxisSize / max(oldAxisSize, 0.001f);
            Model_Instance* model = static_cast<Model_Instance*>(selectedInstances.front());
            scaleModelTo(*model, static_cast<float>(gizmoStartModelScale) * scaleFactor, gizmoStartPosition);
            projectDirty = true;
            gizmoDragValue = scaleFactor;
            if (releaseGizmo)
            {
                draggingGizmo = false;
                activeGizmoAxis = GizmoAxis::None;
                activeGizmoSign = 1;
            }
            return;
        }

        for (size_t i = 0; i < gizmoParts.size(); i++)
        {
            Part* selectedPart = gizmoParts[i];
            Vector3 startSize = gizmoStartSizes[i];
            Vector3 startPos = gizmoStartPositions[i];
            selectedPart->size = startSize;
            selectedPart->cframe.position = startPos;

            float oldAxisSize =
                activeGizmoAxis == GizmoAxis::X ? startSize.x :
                activeGizmoAxis == GizmoAxis::Y ? startSize.y : startSize.z;

            float newAxisSize = max(0.1f, oldAxisSize + amount * static_cast<float>(activeGizmoSign));
            float sizeDelta = newAxisSize - oldAxisSize;
            float scaleFactor = newAxisSize / max(oldAxisSize, 0.001f);

            if (gizmoResize)
            {
                // Alt: uniform scale about center
                selectedPart->size.x = max(0.1f, startSize.x * scaleFactor);
                selectedPart->size.y = max(0.1f, startSize.y * scaleFactor);
                selectedPart->size.z = max(0.1f, startSize.z * scaleFactor);
                // position stays (center scale)
            }
            else if (gizmoCenterScale)
            {
                // Ctrl: single-axis scale about center
                if (activeGizmoAxis == GizmoAxis::X) selectedPart->size.x = newAxisSize;
                else if (activeGizmoAxis == GizmoAxis::Y) selectedPart->size.y = newAxisSize;
                else selectedPart->size.z = newAxisSize;
                // position unchanged — expands both faces
            }
            else
            {
                // Default: scale from opposite face (handle side moves, opposite stays)
                if (activeGizmoAxis == GizmoAxis::X) selectedPart->size.x = newAxisSize;
                else if (activeGizmoAxis == GizmoAxis::Y) selectedPart->size.y = newAxisSize;
                else selectedPart->size.z = newAxisSize;

                float shift = sizeDelta * 0.5f * static_cast<float>(activeGizmoSign);
                selectedPart->cframe.position =
                    Vector3Add(startPos, Vector3Scale(scaleAxis, shift));
            }
        }

        gizmoDragValue = amount;
    }

    if (releaseGizmo)
    {
        draggingGizmo = false;
        activeGizmoAxis = GizmoAxis::None;
        activeGizmoSign = 1;
    }
}

// ============================================================
// Load Resources
// ============================================================

RenderTexture2D LoadShadowMap(int width, int height)
{
    RenderTexture2D target = { 0 };

    target.id = rlLoadFramebuffer();

    if (target.id > 0)
    {
        rlEnableFramebuffer(target.id);

        // Color attachment
        target.texture.id =
            rlLoadTexture(
                0,
                width,
                height,
                PIXELFORMAT_UNCOMPRESSED_R8G8B8A8,
                1
            );

        target.texture.width = width;
        target.texture.height = height;
        target.texture.format =
            PIXELFORMAT_UNCOMPRESSED_R8G8B8A8;
        target.texture.mipmaps = 1;

        // IMPORTANT: actual depth texture
        target.depth.id =
            rlLoadTextureDepth(
                width,
                height,
                false
            );

        target.depth.width = width;
        target.depth.height = height;
        target.depth.format = PIXELFORMAT_UNCOMPRESSED_R32;
        target.depth.mipmaps = 1;

        rlTextureParameters(
            target.depth.id,
            RL_TEXTURE_MAG_FILTER,
            RL_TEXTURE_FILTER_LINEAR
        );

        rlTextureParameters(
            target.depth.id,
            RL_TEXTURE_MIN_FILTER,
            RL_TEXTURE_FILTER_LINEAR
        );

        rlTextureParameters(
            target.depth.id,
            RL_TEXTURE_WRAP_S,
            RL_TEXTURE_WRAP_CLAMP
        );

        rlTextureParameters(
            target.depth.id,
            RL_TEXTURE_WRAP_T,
            RL_TEXTURE_WRAP_CLAMP
        );

        rlFramebufferAttach(
            target.id,
            target.texture.id,
            RL_ATTACHMENT_COLOR_CHANNEL0,
            RL_ATTACHMENT_TEXTURE2D,
            0
        );

        rlFramebufferAttach(
            target.id,
            target.depth.id,
            RL_ATTACHMENT_DEPTH,
            RL_ATTACHMENT_TEXTURE2D,
            0
        );

        if (rlFramebufferComplete(target.id))
        {
            TraceLog(
                LOG_INFO,
                "Shadow framebuffer created successfully"
            );
        }

        rlDisableFramebuffer();
    }

    return target;
}


#endif // BT_GIZMO_H
