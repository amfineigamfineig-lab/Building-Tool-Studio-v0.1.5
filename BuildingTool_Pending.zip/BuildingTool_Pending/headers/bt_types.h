// bt_types.h — Instance hierarchy, services types, lighting structs
// Auto-split from buildingTool_.cpp (keep include order).
#pragma once
#ifndef BT_TYPES_H
#define BT_TYPES_H


// ============================================================
// CFrame
// ============================================================

struct CFrame
{
    Vector3 position;
    Vector3 rotation;
};


// ============================================================
// Instance
// ============================================================

struct Instance
{
    string name;
    string id;
    bool hidden = false;

    Instance* parent = nullptr;
    vector<Instance*> children;

    virtual InstanceType getType() const = 0;

    virtual ~Instance() = default;

};

#pragma region "Instance Tree Functions"
// ============================================================
// Part
// ============================================================

struct Part : Instance
{
    PartType type = PartType::Block;
    bool isMeshPart = false;
    string meshId;
    string textureId;
    CollisionFidelity collisionFidelity = CollisionFidelity::Default;
    bool anchored = true;  // default true (Roblox-style)

    Vector3 size = { 1.0f, 1.0f, 1.0f };

    Color color = RED;

    CFrame cframe = {
        { 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f }
    };

    // Local offset from part origin to pivot (Roblox-style PivotOffset)
    Vector3 pivotOffset = { 0.0f, 0.0f, 0.0f };

    // 0 = opaque, 1 = fully invisible
    float transparency = 0.0f;
    // 0 = matte, 1 = mirror-like specular (Part.Reflectance)
    float reflectance = 0.0f;
    bool castShadow = true;
    bool advancedPhysics = false;
    float density = 1.0f;
    float friction = 0.55f;

    // Basic physics (runtime only, when !anchored)
    Vector3 velocity = { 0.0f, 0.0f, 0.0f };
    Vector3 angularVelocity = { 0.0f, 0.0f, 0.0f }; // deg/s-ish euler rates
    bool canCollide = true;
    // Roblox TrussPart-like: always climbable by a Humanoid, regardless of
    // the small-gap squeeze rule used for ordinary walls.
    bool truss = false;
    // Locked: cannot pick in 3D viewport (explorer selection still allowed).
    bool locked = false;
    // Local Axes: per-part forward/up indicators (editor visualization)
    bool showLocalAxes = false;

    InstanceType getType() const override
    {
        return InstanceType::Part;
    }
};

enum class BT_CameraMode
{
    Default,
    Scriptable
};

struct HumanoidInstance : Instance
{
    float health = 100.0f;
    float maxHealth = 100.0f;
    float walkSpeed = 16.0f;
    float jumpPower = 50.0f;   // upward velocity impulse (studs/s)
    // Distance from ground to hip/root support so visual legs clear the floor
    // (R6 default ≈ 2 = full leg length). Prevents leg/torso collision issues
    // when animations are added later.
    float hipHeight = 3.0f;
    bool autoJump = false;
    Part* rootPart = nullptr;
    // Steepest ground slope (degrees from horizontal) the Humanoid can stand
    // on without sliding/falling. A part's slope is approximated from its
    // own orientation (see physic.h's updateBasicPhysics).
    float slopeAngle = 45.0f;
    // Runtime-only (not serialized): true when standing on solid ground
    bool grounded = false;
    // Runtime-only (not serialized): true while gripping a Truss part.
    bool climbing = false;
    // Maximum horizontal clearance from the Truss surface before climb state breaks.
    // Collision/penetration counts as attached.
    float climbGap = 0.6f;
    // Runtime-only (not serialized): outward direction away from the surface
    // currently being climbed, used to push the character back on jump.
    Vector3 climbNormal = { 0.0f, 0.0f, 0.0f };
    InstanceType getType() const override { return InstanceType::Humanoid; }
};

struct CameraInstance : Instance
{
    BT_CameraMode mode = BT_CameraMode::Default;
    Instance* target = nullptr;
    CFrame cframe = { { 0, 5, 12 }, { 0, 0, 0 } };
    InstanceType getType() const override { return InstanceType::Camera; }
};

// ============================================================
// 2D GUI (ScreenGui / GuiObject family)
// ============================================================

// Layer collectors (ScreenGui, SurfaceGui, BillboardGui)
struct LayerCollectorInstance : Instance
{
    bool enabled = true;
    int displayOrder = 0;
    bool resetOnSpawn = true;
    bool ignoreGuiInset = false;
    bool clipToDeviceSafeArea = true;
    bool safeAreaCompatibility = true;
    // SurfaceGui / BillboardGui
    Instance* adornee = nullptr;
    float maxDistance = 0.0f;       // 0 = infinite
    float sizeOffset = 0.0f;
    bool alwaysOnTop = false;
    float lightInfluence = 0.0f;    // 0..1 (SurfaceGui / BillboardGui)
    float pixelsPerStud = 50.0f;    // SurfaceGui
    string face = "Front";          // SurfaceGui Face (NormalId)
    float brightness = 1.0f;
    bool active = true;
    bool clipsDescendants = false;  // SurfaceGui
    Vector2 canvasSize = { 800.0f, 600.0f }; // SurfaceGui CanvasSize
    string sizingMode = "PixelsPerStud";     // PixelsPerStud | FixedSize
    float zOffset = 0.0f;           // SurfaceGui
    // BillboardGui offsets / distance limits
    Vector3 studsOffset = { 0, 0, 0 };
    Vector3 studsOffsetWorldSpace = { 0, 0, 0 };
    Vector3 extentsOffset = { 0, 0, 0 };
    Vector3 extentsOffsetWorldSpace = { 0, 0, 0 };
    float distanceLowerLimit = 0.0f;
    float distanceUpperLimit = 0.0f; // 0 = none
    UDim2Value billboardSize = { { 0.0f, 200.0f }, { 0.0f, 50.0f } }; // BillboardGui.Size
    InstanceType layerType = InstanceType::ScreenGui;
    InstanceType getType() const override { return layerType; }
};

// Shared GuiObject layout + look (Roblox GuiObject + text/image/button/scroll extras)
struct GuiObjectInstance : Instance
{
    InstanceType guiType = InstanceType::Frame;
    // Layout
    UDim2Value size = { { 0.0f, 200.0f }, { 0.0f, 50.0f } };
    UDim2Value position = { { 0.0f, 0.0f }, { 0.0f, 0.0f } };
    Vector2 anchorPoint = { 0.0f, 0.0f };
    string automaticSize = "None";      // None X Y XY
    string sizeConstraint = "RelativeXY";
    int layoutOrder = 0;
    float rotation = 0.0f;
    // Appearance
    Color backgroundColor = { 255, 255, 255, 255 };
    float backgroundTransparency = 0.0f;
    int borderSizePixel = 0;
    Color borderColor = { 27, 42, 53, 255 };
    string borderMode = "Outline";      // Outline Inset Middle
    bool visible = true;
    int zIndex = 1;
    bool clipsDescendants = false;
    float groupTransparency = 0.0f;
    // Interaction
    bool active = true;
    bool interactable = true;
    bool selectable = false;
    int selectionOrder = 0;
    bool autoButtonColor = true;
    bool modal = false;
    // Text (TextLabel / TextButton / TextBox)
    string text;
    int textSize = 14;
    Color textColor = { 0, 0, 0, 255 };
    float textTransparency = 0.0f;
    string textXAlignment = "Center";
    string textYAlignment = "Center";
    bool textScaled = false;
    bool textWrapped = false;
    bool richText = false;
    string font = "SourceSans";
    float lineHeight = 1.0f;
    int maxVisibleGraphemes = -1;
    Color textStrokeColor = { 0, 0, 0, 255 };
    float textStrokeTransparency = 1.0f;
    string textTruncate = "None";       // None AtEnd
    // TextBox-only
    string placeholderText;
    Color placeholderColor = { 178, 178, 178, 255 };
    bool clearTextOnFocus = true;
    bool multiLine = false;
    bool textEditable = true;
    // Image (ImageLabel / ImageButton)
    string image;
    float imageTransparency = 0.0f;
    Color imageColor = { 255, 255, 255, 255 };
    string scaleType = "Stretch";
    Vector2 imageRectOffset = { 0, 0 };
    Vector2 imageRectSize = { 0, 0 };
    float sliceScale = 1.0f;
    string resampleMode = "Default";
    // ImageButton hover/pressed variants
    string hoverImage;
    string pressedImage;
    // ScrollingFrame (CanvasSize is UDim2 in Roblox; store scale+offset)
    UDim2Value scrollCanvasSize = { { 0.0f, 0.0f }, { 0.0f, 0.0f } };
    Vector2 canvasPosition = { 0.0f, 0.0f };
    bool scrollingEnabled = true;
    float scrollBarThickness = 12.0f;
    Color scrollBarImageColor = { 0, 0, 0, 255 };
    float scrollBarImageTransparency = 0.0f;
    string scrollingDirection = "XY";   // X Y XY
    string elasticBehavior = "WhenNeeded";
    string automaticCanvasSize = "None"; // None X Y XY (Enum.AutomaticSize)
    string horizontalScrollBarInset = "None"; // None / ScrollBar / Always
    string verticalScrollBarInset = "None";
    // Frame style
    string frameStyle = "Custom";
    InstanceType getType() const override { return guiType; }
};

// UI modifiers (parented under GuiObjects)
struct UIModifierInstance : Instance
{
    InstanceType modType = InstanceType::UICorner;
    // UICorner
    UDimValue cornerRadius = { 0.0f, 8.0f };
    // UIStroke
    bool strokeEnabled = true;
    float strokeThickness = 1.0f;
    Color strokeColor = { 0, 0, 0, 255 };
    float strokeTransparency = 0.0f;
    string strokeApplyStrokeMode = "Contextual"; // Border / Contextual
    string lineJoinMode = "Round";               // Round Bevel Miter
    string strokeSizingMode = "FixedSize";
    // UIListLayout
    string fillDirection = "Vertical";
    string horizontalAlignment = "Left";
    string verticalAlignment = "Top";
    string sortOrder = "LayoutOrder";            // LayoutOrder Name
    UDimValue listPadding = { 0.0f, 0.0f };
    int paddingPx = 0; // legacy alias of listPadding.offset
    bool wraps = false;
    // UIPadding
    UDimValue paddingLeft, paddingRight, paddingTop, paddingBottom;
    // UIGridLayout
    UDim2Value cellSize = { { 0.0f, 100.0f }, { 0.0f, 100.0f } };
    UDim2Value cellPadding = { { 0.0f, 4.0f }, { 0.0f, 4.0f } };
    int fillDirectionMaxCells = 0;
    string startCorner = "TopLeft";
    // UIAspectRatioConstraint
    float aspectRatio = 1.0f;
    string aspectType = "FitWithinMaxSize";
    string dominantAxis = "Width";
    InstanceType getType() const override { return modType; }
};


// ============================================================
// Script
// ============================================================

struct Script : Instance
{
    ScriptType type = ScriptType::Script;
    // If false, this script is skipped when Play starts.
    bool enabled = true;
    // RunContext mirrors type for the property panel (Server/Client/Module).
    // Changing RunContext updates type and explorer icon.

    string source = "print(\"Hello world!\")";
    string compiledBytecode;

    InstanceType getType() const override
    {
        return InstanceType::Script;
    }

    // Convenience: RunContext string for properties / serialization
    string runContextName() const
    {
        switch (type)
        {
        case ScriptType::LocalScript: return "Client";
        case ScriptType::ModuleScript: return "Module";
        default: return "Server";
        }
    }

    void setRunContext(const string& ctx)
    {
        if (ctx == "Client" || ctx == "LocalScript")
            type = ScriptType::LocalScript;
        else if (ctx == "Module" || ctx == "ModuleScript")
            type = ScriptType::ModuleScript;
        else
            type = ScriptType::Script; // Server
    }
};


// ============================================================
// Model
// ============================================================

struct Model_Instance : Instance
{
    double scale = 1.0;
    // If set, model pivot follows PrimaryPart + this offset (local to primary).
    // If null, WorldPivot is the model bounding-box center (or origin).
    Part* primaryPart = nullptr;
    Vector3 pivotOffset = { 0.0f, 0.0f, 0.0f };

    InstanceType getType() const override
    {
        return InstanceType::Model;
    }
};


// ============================================================
// Folder
// ============================================================

struct Folder : Instance
{
    InstanceType getType() const override
    {
        return InstanceType::Folder;
    }
};

struct Service : Instance
{
    InstanceType getType() const override
    {
        return InstanceType::Service;
    }
};

struct PlayerInstance : Instance
{
    string userId = "LocalPlayer";
    Model_Instance* character = nullptr;
    CameraInstance* camera = nullptr;
    // PlayerGui is created at client runtime (clone of StarterGui contents)
    Folder* playerGui = nullptr;
    InstanceType getType() const override { return InstanceType::Player; }
};

struct BindableEventInstance : Instance
{
    InstanceType getType() const override { return InstanceType::BindableEvent; }
};

struct BindableFunctionInstance : Instance
{
    InstanceType getType() const override { return InstanceType::BindableFunction; }
};

struct RemoteEventInstance : Instance
{
    InstanceType getType() const override { return InstanceType::RemoteEvent; }
};

struct RemoteFunctionInstance : Instance
{
    InstanceType getType() const override { return InstanceType::RemoteFunction; }
};

struct BlurInstance : Instance
{
    float size = 0.0f;
    InstanceType getType() const override { return InstanceType::Blur; }
};

struct ColorCorrectionInstance : Instance
{
    float brightness = 0.0f;
    float contrast = 0.0f;
    float saturation = 0.0f;
    Color tintColor = WHITE;
    InstanceType getType() const override { return InstanceType::ColorCorrection; }
};

struct SunLightInstance : Instance
{
    Vector3 direction = { -0.5f, -1.0f, -0.5f };
    Color color = { 255, 190, 110, 255 };
    float intensity = 0.8f;
    InstanceType getType() const override { return InstanceType::SunLight; }
};

// Roblox PointLight / SpotLight / SurfaceLight
struct PointLightInstance : Instance
{
    Color color = { 255, 255, 255, 255 };
    float brightness = 1.0f;
    float range = 8.0f;
    bool shadows = false;
    bool enabled = true;
    InstanceType getType() const override { return InstanceType::PointLight; }
};
struct SpotLightInstance : Instance
{
    Color color = { 255, 255, 255, 255 };
    float brightness = 1.0f;
    float range = 16.0f;
    float angle = 90.0f; // degrees
    string face = "Front"; // NormalId
    bool shadows = false;
    bool enabled = true;
    InstanceType getType() const override { return InstanceType::SpotLight; }
};
struct SurfaceLightInstance : Instance
{
    Color color = { 255, 255, 255, 255 };
    float brightness = 1.0f;
    float range = 16.0f;
    float angle = 90.0f;
    string face = "Front";
    bool shadows = false;
    bool enabled = true;
    InstanceType getType() const override { return InstanceType::SurfaceLight; }
};

struct BloomInstance : Instance
{
    float intensity = 0.0f;
    float threshold = 1.0f;
    float size = 1.0f;
    InstanceType getType() const override { return InstanceType::Bloom; }
};

// Roblox-like Sound instance (SoundId points at an embedded assetId://N)
struct SoundInstance : Instance
{
    string soundId;          // e.g. "assetId://1"
    float volume = 0.5f;
    float playbackSpeed = 1.0f;
    bool looped = false;
    bool playing = false;
    float timePosition = 0.0f;
    float rollOffMaxDistance = 10000.0f;
    float rollOffMinDistance = 10.0f;

    InstanceType getType() const override
    {
        return InstanceType::Sound;
    }
};

// Roblox-like Texture instance (decal/texture on a face)
struct TextureInstance : Instance
{
    string texture;          // e.g. "assetId://2"
    float studsPerTileU = 2.0f;
    float studsPerTileV = 2.0f;
    float offsetStudsU = 0.0f;
    float offsetStudsV = 0.0f;
    float transparency = 0.0f;
    Color color3 = { 255, 255, 255, 255 };
    string face = "Top";     // Top/Bottom/Front/Back/Left/Right

    InstanceType getType() const override
    {
        return InstanceType::Texture;
    }
};

// Roblox-like WeldConstraint — rigidly joins Part0 and Part1
struct WeldConstraint : Instance
{
    Part* part0 = nullptr;
    Part* part1 = nullptr;
    bool enabled = true;
    // Fixed relative pose of Part1 in Part0 local space (captured once on enable/assign)
    Vector3 relativePosition = { 0, 0, 0 };
    Vector3 relativeRotation = { 0, 0, 0 };
    bool relativeCaptured = false;

    InstanceType getType() const override
    {
        return InstanceType::WeldConstraint;
    }
};

// Roblox-like Motor6D — joint with C0/C1 offsets and optional continuous rotation
struct Motor6DConstraint : Instance
{
    Part* part0 = nullptr;
    Part* part1 = nullptr;
    // Attachments in each part's local space (Roblox C0 / C1)
    CFrame c0 = {};
    CFrame c1 = {};
    // Animated offset (Roblox Motor6D.Transform). Identity at rest.
    // Walk / Animate scripts write this — same as Roblox Animate.
    CFrame transform = {};
    // Optional Motor Z-spin (Roblox DesiredAngle/CurrentAngle around C0 local Z)
    float desiredAngle = 0.0f;
    float maxVelocity = 0.0f; // rad/s (0 = snap)
    float currentAngle = 0.0f;
    bool enabled = true;

    InstanceType getType() const override
    {
        return InstanceType::Motor6D;
    }
};

// ============================================================
// SunLight
// ============================================================

struct SunLight
{
    Vector3 direction;
    Color color;
    float intensity;
    float ambient;
};

struct LightingSettings
{
    Color ambient = { 90, 110, 140, 255 };           // soft blue-tinted ambient
    Color outdoorAmbient = { 140, 170, 210, 255 };

    Color colorShiftBottom = { 0, 0, 0, 255 };
    Color colorShiftTop = { 0, 0, 0, 255 };

    // Roblox-like blue sky (used as ClearBackground / fog)
    Color fogColor = { 135, 206, 235, 255 };
    float fogStart = 0.0f;
    float fogEnd = 10000.0f;                         // far fog so sky stays blue

    float brightness = 1.0f;
    float exposureCompensation = 0.0f;

    float environmentDiffuseScale = 1.0f;
    float environmentSpecularScale = 1.0f;

    bool globalShadows = true;
    // Soft = PCF blur, Hard = crisp 1-tap, Sharp = contact-hardening (realistic)
    string shadowSoftness = "Soft";

    float clockTime = 9.0f;
    float geographicLatitude = 41.7f;

    // Screen-space post-processing blur. 0 = disabled.
    float blur = 0.0f;
};

#pragma endregion

#endif // BT_TYPES_H