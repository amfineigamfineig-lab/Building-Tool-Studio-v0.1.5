// bt_editor_chrome.h — Camera input, top bar, window bar, chrome
#pragma once
#ifndef BT_EDITOR_CHROME_H
#define BT_EDITOR_CHROME_H

bool isPointerOverScreenGui();

void setupMouseMovement(Camera3D& camera)
{
    float dt = GetFrameTime();
    bool viewportInputAllowed = !isPointerOverScreenGui();

    Vector3 forward = Vector3Normalize(Vector3Subtract(camera.target, camera.position));
    if (Vector3Length(forward) < 0.001f)
        forward = { 0.0f, 0.0f, -1.0f };

    // Rotate the view direction around the camera's current position.
    if (viewportInputAllowed && IsMouseButtonDown(MOUSE_BUTTON_RIGHT))
    {
        Vector2 mouseDelta = GetMouseDelta();
        float yaw = atan2f(forward.x, forward.z) - mouseDelta.x * 0.005f;
        float pitch = asinf(Clamp(forward.y, -1.0f, 1.0f)) - mouseDelta.y * 0.005f;
        pitch = Clamp(pitch, -1.5f, 1.5f);
        forward = {
            sinf(yaw) * cosf(pitch),
            sinf(pitch),
            cosf(yaw) * cosf(pitch)
        };
        camera.target = Vector3Add(camera.position, forward);
    }

    // ============================================================
    // MIDDLE MOUSE = PAN
    // ============================================================

    if (viewportInputAllowed && IsMouseButtonDown(MOUSE_BUTTON_MIDDLE))
    {
        Vector2 mouseDelta =
            GetMouseDelta();

        float distance = Vector3Distance(camera.position, camera.target);

        float panSpeed =
            0.01f * distance * max(0.1f, studioSettings.cameraSpeed);

        // Ignore vertical camera angle
        forward.y = 0.0f;

        if (Vector3Length(forward) > 0.001f)
        {
            forward =
                Vector3Normalize(forward);

            Vector3 right = {
                -forward.z,
                0.0f,
                 forward.x
            };

            Vector3 pan = { 0 };

            pan =
                Vector3Add(
                    pan,
                    Vector3Scale(
                        right,
                        -mouseDelta.x *
                        panSpeed
                    )
                );

            pan =
                Vector3Add(
                    pan,
                    Vector3Scale(
                        camera.up,
                        mouseDelta.y *
                        panSpeed
                    )
                );

            camera.position = Vector3Add(camera.position, pan);
            camera.target = Vector3Add(camera.target, pan);
        }
    }

    // ============================================================
    // SCROLL = ZOOM
    // ============================================================

    float wheel = isZoneFocused(FocusZone::Viewport) && viewportInputAllowed ? GetMouseWheelMove() : 0.0f;

    if (wheel != 0.0f)
    {
        float zoomSpeed = 2.0f * max(0.1f, studioSettings.cameraSpeed);
        forward = Vector3Normalize(Vector3Subtract(camera.target, camera.position));
        Vector3 zoom = Vector3Scale(forward, wheel * zoomSpeed);
        camera.position = Vector3Add(camera.position, zoom);
        camera.target = Vector3Add(camera.target, zoom);
    }

    // ============================================================
    // LOCAL CAMERA MOVEMENT
    // ============================================================

    forward = Vector3Normalize(Vector3Subtract(camera.target, camera.position));

    Vector3 right =
        Vector3Normalize(
            Vector3CrossProduct(
                forward,
                camera.up
            )
        );

    Vector3 movement = { 0 };

    bool cameraKeyMovementAllowed =
        !IsKeyDown(KEY_LEFT_CONTROL) && !IsKeyDown(KEY_RIGHT_CONTROL) &&
        !IsKeyDown(KEY_LEFT_ALT) && !IsKeyDown(KEY_RIGHT_ALT);
    if (cameraKeyMovementAllowed && IsKeyDown(KEY_W))
        movement =
            Vector3Add(movement, forward);

    if (cameraKeyMovementAllowed && IsKeyDown(KEY_S))
        movement =
            Vector3Subtract(movement, forward);

    if (cameraKeyMovementAllowed && IsKeyDown(KEY_D))
        movement =
            Vector3Add(movement, right);

    if (cameraKeyMovementAllowed && IsKeyDown(KEY_A))
        movement =
            Vector3Subtract(movement, right);

    if (cameraKeyMovementAllowed && IsKeyDown(KEY_E))
        movement.y += 1.0f;

    if (cameraKeyMovementAllowed && IsKeyDown(KEY_Q))
        movement.y -= 1.0f;

    if (Vector3Length(movement) > 0.001f)
    {
        movement =
            Vector3Normalize(movement);

        float speed = 5.0f * max(0.1f, studioSettings.cameraSpeed);

        if (IsKeyDown(KEY_LEFT_SHIFT))
            speed = 20.0f * max(0.1f, studioSettings.cameraSpeed);

        movement =
            Vector3Scale(
                movement,
                speed * dt
            );

        camera.position = Vector3Add(camera.position, movement);
        camera.target = Vector3Add(camera.target, movement);
    }
}

int getTopBarMenuWidth(TopBarItem* item)
{
    if (item == nullptr)
        return 150;

    int width = 160;
    for (TopBarItem* child : item->children)
    {
        if (child != nullptr)
            width = max(width, MeasureText(child->label.c_str(), 15) + 40);
    }
    return width;
}

void renderMenu(TopBarItem* item, int x, int y)
{
    const int itemHeight = 26;
    const int padding = 12;

    if (item == nullptr || item->children.empty())
        return;

    int width = getTopBarMenuWidth(item);
    int height = static_cast<int>(item->children.size()) * itemHeight;
    EditorThemeColors theme = getEditorThemeColors();

    DrawRectangleRounded({ (float)x, (float)y, (float)width, (float)height }, 0.02f, 8, theme.panel);
    DrawRectangleRoundedLines({ (float)x, (float)y, (float)width, (float)height }, 0.02f, 8, theme.border);

    Vector2 mouse = GetMousePosition();

    for (size_t i = 0; i < item->children.size(); ++i)
    {
        TopBarItem* child = item->children[i];
        if (child == nullptr)
            continue;

        int childY = y + static_cast<int>(i) * itemHeight;
        Rectangle rect = {
            static_cast<float>(x),
            static_cast<float>(childY),
            static_cast<float>(width),
            static_cast<float>(itemHeight)
        };

        bool hovered = CheckCollisionPointRec(mouse, rect);
        if (hovered)
            DrawRectangleRounded(rect, 0.08f, 6, theme.accent);

        DrawText(
            child->label.c_str(),
            x + padding,
            childY + 5,
            15,
            hovered ? WHITE : theme.text
        );

        if (child->label == "Action Bar" || child->label == "Ribbon Bar" || child->label == "Window Bar")
        {
            bool enabled = child->label == "Action Bar" ? studioSettings.showActionBar :
                (child->label == "Ribbon Bar" ? studioSettings.showRibbonBar : studioSettings.showWindowBar);
            DrawRectangle(x + width - 22, childY + 8, 10, 10, enabled ? theme.accent : theme.header);
            DrawRectangleLines(x + width - 22, childY + 8, 10, 10, theme.border);
        }

        if (!child->children.empty())
        {
            DrawText(">", x + width - 18, childY + 5, 15, (Color){ 180, 180, 180, 255 });
            if (hovered)
                renderMenu(child, x + width, childY);
        }
    }
}

bool handleTopBarMenuItemClick(
    TopBarItem* item,
    int x,
    int y,
    TopBarItem*& clickedItem)
{
    if (item == nullptr || item->children.empty())
        return false;

    const int itemHeight = 26;
    int width = getTopBarMenuWidth(item);
    Vector2 mouse = GetMousePosition();

    for (size_t i = 0; i < item->children.size(); ++i)
    {
        TopBarItem* child = item->children[i];
        if (child == nullptr)
            continue;

        int childY = y + static_cast<int>(i) * itemHeight;
        Rectangle rect = {
            static_cast<float>(x),
            static_cast<float>(childY),
            static_cast<float>(width),
            static_cast<float>(itemHeight)
        };

        if (!CheckCollisionPointRec(mouse, rect))
            continue;

        if (!child->children.empty())
        {
            if (handleTopBarMenuItemClick(
                    child, x + width, childY, clickedItem))
                return true;
        }

        clickedItem = child;
        return true;
    }

    return false;
}

void performTopBarMenuAction(TopBarItem* item)
{
    if (item == nullptr)
        return;

    if (item->label == "New")
        requestProjectAction(PendingProjectAction::New);
    else if (item->label == "Open")
        requestProjectAction(PendingProjectAction::Open);
    else if (item->label == "Save")
        saveProject(false);
    else if (item->label == "Save As")
        saveProject(true);
    else if (item->label == "Export")
        exportProjectExecutable();
    else if (item->label == "Import Asset")
        browseAndImportAsset();
    else if (item->label == "Studio Settings")
        studioSettingsOpen = true;
    else if (item->label == "Game Settings")
        gameSettingsOpen = true;
    else if (item->label == "Viewport")
        ensureWindowTab(WindowType::Viewport);
    else if (item->label == "Output")
        ensureWindowTab(WindowType::Output);
    else if (item->label == "Asset Manager")
        openLibraryWindow();
    else if (item->label == "Show Hidden Assets")
        showHiddenAssets = !showHiddenAssets;
    else if (item->label == "Action Bar")
    {
        studioSettings.showActionBar = !studioSettings.showActionBar;
        updateEditorChromeLayout();
        saveStudioSettings();
    }
    else if (item->label == "Window Bar")
    {
        studioSettings.showWindowBar = !studioSettings.showWindowBar;
        updateEditorChromeLayout();
        saveStudioSettings();
    }
    else if (item->label == "Ribbon Bar")
    {
        studioSettings.showRibbonBar = !studioSettings.showRibbonBar;
        updateEditorChromeLayout();
        saveStudioSettings();
    }
}

void drawActionIcon(int index, int x, int y, Color)
{
    if (explorerIcons == nullptr)
        return;
    // 0=Play(server) 1=PlayPlayer(client) 2=Stop 3=POV toggle (text drawn separately)
    if (index == 3)
        return;
    Texture2D icon = index == 0 ? explorerIcons->playIcon :
        index == 1 ? explorerIcons->playPlayerIcon : explorerIcons->stopIcon;
    if (icon.id != 0)
        drawEditorIcon(icon, (float)x, (float)y, 24.0f, 24.0f,
            getStudioMiscIconTint(index == 0 ? "Play" : (index == 1 ? "PlayClient" : "Stop")));
}

// Standard app menu bar height (File / View / Help)
// Compute top-level menu item x positions (text-sized, not fixed 90px boxes)
static int topBarItemX(const vector<TopBarItem*>& topBarItems, size_t index)
{
    int x = 8;
    for (size_t i = 0; i < index && i < topBarItems.size(); ++i)
    {
        TopBarItem* it = topBarItems[i];
        if (!it) continue;
        int tw = MeasureText(it->label.c_str(), 15);
        x += tw + 20;
    }
    return x;
}

static int topBarItemWidth(TopBarItem* item)
{
    if (!item) return 48;
    return MeasureText(item->label.c_str(), 15) + 16;
}

void renderActionBar()
{
    if (ACTION_BAR_HEIGHT <= 0)
        return;
    EditorThemeColors theme = getEditorThemeColors();
    const int barY = editorActionBarY();
    const int barHeight = ACTION_BAR_HEIGHT;
    const int barWidth = GetScreenWidth();
    DrawRectangle(0, barY, barWidth, barHeight, theme.header);
    Vector2 mouse = GetMousePosition();
    // 0 Play, 1 PlayPlayer, 2 Stop, 3 Server/Client POV switch
    for (int index = 0; index < 4; ++index)
    {
        Rectangle button = { 8.0f + index * 54.0f, (float)barY + 4.0f, 44.0f, 24.0f };
        bool hovered = CheckCollisionPointRec(mouse, button);
        Color fill = hovered ? theme.accentHover : theme.surface;
        if (index == 1 && runtimePlaying && runtimeClientMode)
            fill = (Color){ 30, 155, 105, 255 };
        if (index == 0 && runtimePlaying && !runtimeClientMode)
            fill = (Color){ 30, 155, 105, 255 };
        // POV button highlights based on preferred / active POV
        if (index == 3)
        {
            bool client = runtimePlaying ? runtimeClientMode : editorClientPOV;
            fill = client ? theme.accent : theme.surface;
            if (hovered) fill = theme.accentHover;
        }
        DrawRectangleRounded(button, 0.24f, 6, fill);
        DrawRectangleRoundedLines(button, 0.24f, 6, theme.border);
        if (index == 3)
        {
            bool client = runtimePlaying ? runtimeClientMode : editorClientPOV;
            const char* label = client ? "CL" : "SV";
            DrawText(label, (int)button.x + 10, (int)button.y + 4, 14, theme.text);
        }
        else
            drawActionIcon(index, (int)button.x + 7, (int)button.y, theme.text);
    }
}

struct RibbonButton
{
    const char* label;
    const char* fallbackIcon;
    const char* action;
    bool enabled = true;
};

Texture2D getRibbonButtonIcon(const RibbonButton& button)
{
    if (explorerIcons == nullptr)
        return { 0 };
    if (button.action == string("Select")) return explorerIcons->ribbonSelectIcon;
    if (button.action == string("Move")) return explorerIcons->ribbonMoveIcon;
    if (button.action == string("Rotate")) return explorerIcons->ribbonRotateIcon;
    if (button.action == string("Scale")) return explorerIcons->ribbonScaleIcon;
    if (button.action == string("Group")) return explorerIcons->ribbonGroupIcon;
    if (button.action == string("Ungroup")) return explorerIcons->ribbonUngroupIcon;
    if (button.action == string("Anchor")) return explorerIcons->ribbonAnchorIcon;
    if (button.action == string("Play")) return explorerIcons->playIcon;
    if (button.action == string("Play Client")) return explorerIcons->playPlayerIcon;
    if (button.action == string("Stop")) return explorerIcons->stopIcon;
    return { 0 };
}

vector<RibbonButton> getRibbonButtons(int tab)
{
    if (tab == 1)
        return { { "Group", "G", "Group" }, { "Ungroup", "U", "Ungroup" },
            { "Move", "M", "Move" }, { "Scale", "S", "Scale" },
            { "Rotate", "R", "Rotate" }, { "Anchor", "A", "Anchor" } };
    if (tab == 2)
        return { { "Play", ">", "Play" }, { "Play Client", "C", "Play Client" },
            { "Stop", "[]", "Stop" } };
    if (tab == 3)
        return { { "Action Bar", "A", "Action Bar" }, { "Ribbon Bar", "R", "Ribbon Bar" },
            { "Window Bar", "W", "Window Bar" },
            { "Explorer", "E", "Explorer" }, { "Properties", "P", "Properties" } };
    if (tab == 4)
        return { { "Asset Manager", "L", "Asset Manager" } };
    return { { "Select", "S", "Select" }, { "Move", "M", "Move" },
        { "Scale", "Z", "Scale" }, { "Rotate", "R", "Rotate" },
        { "Part", "+", "Part" }, { "Group", "G", "Group" },
        { "Ungroup", "U", "Ungroup" }, { "Anchor", "A", "Anchor" },
        { "Find", "F", "Find" }, { "Replace", "R", "Replace" } };
}

void performRibbonAction(const string& action)
{
    if (action == "Move") { currentGizmo = GizmoType::Move; selectToolActive = false; }
    else if (action == "Scale") { currentGizmo = GizmoType::Scale; selectToolActive = false; }
    else if (action == "Rotate") { currentGizmo = GizmoType::Rotate; selectToolActive = false; }
    else if (action == "Select") selectToolActive = true;
    else if (action == "Group") groupSelectedInstances(false);
    else if (action == "Ungroup") ungroupSelectedInstances();
    else if (action == "Anchor")
    {
        vector<Part*> parts = getSelectedParts();
        if (!parts.empty())
        {
            bool anchored = !parts.front()->anchored;
            for (Part* part : parts) part->anchored = anchored;
            projectDirty = true;
        }
    }
    else if (action == "Part")
    {
        pushProjectUndoCheckpoint();
        Part* part = new Part();
        part->name = "Part";
        part->cframe.position = { 0.0f, 0.5f, 0.0f };
        addInstanceToParent(&workspace, part);
        selectedInstances = { part };
        projectDirty = true;
    }
    else if (action == "Play") startRuntime(false);
    else if (action == "Play Client") startRuntime(true);
    else if (action == "Stop") stopRuntime();
    else if (action == "Action Bar")
    {
        studioSettings.showActionBar = !studioSettings.showActionBar;
        updateEditorChromeLayout();
        saveStudioSettings();
    }
    else if (action == "Window Bar")
    {
        studioSettings.showWindowBar = !studioSettings.showWindowBar;
        updateEditorChromeLayout();
        saveStudioSettings();
    }
    else if (action == "Ribbon Bar")
    {
        studioSettings.showRibbonBar = !studioSettings.showRibbonBar;
        updateEditorChromeLayout();
        saveStudioSettings();
    }
    else if (action == "Explorer") dockPanelToWindowBar(DockPanelKind::Explorer);
    else if (action == "Properties") dockPanelToWindowBar(DockPanelKind::Properties);
    else if (action == "Asset Manager") openLibraryWindow();
    else if (action == "Find" && activeScript != nullptr)
    {
        activeWindow = WindowType::Script;
        scriptFindOpen = true;
        scriptFindReplaceOpen = false;
        scriptFindFocusedField = 0;
    }
    else if (action == "Replace" && activeScript != nullptr)
    {
        activeWindow = WindowType::Script;
        scriptFindOpen = true;
        scriptFindReplaceOpen = true;
        scriptFindFocusedField = 0;
    }
}

bool handleRibbonBarClick()
{
    if (!IsMouseButtonPressed(MOUSE_BUTTON_LEFT) || welcomeScreenOpen || RIBBON_BAR_HEIGHT <= 0)
        return false;
    Vector2 mouse = GetMousePosition();
    int barY = editorRibbonBarY();
    if (mouse.y < barY || mouse.y >= barY + RIBBON_BAR_HEIGHT)
        return false;

    const char* tabs[] = { "Home", "Model", "Test", "View", "Plugins" };
    int tabX = 12;
    for (int index = 0; index < 5; ++index)
    {
        int width = MeasureText(tabs[index], 16) + 24;
        Rectangle tab = { (float)tabX, (float)barY + 3, (float)width, 27 };
        if (CheckCollisionPointRec(mouse, tab))
        {
            activeRibbonTab = index;
            return true;
        }
        tabX += width + 3;
    }

    if (mouse.y < barY + 32)
        return true;
    vector<RibbonButton> buttons = getRibbonButtons(activeRibbonTab);
    int x = 12;
    for (const RibbonButton& button : buttons)
    {
        Rectangle rect = { (float)x, (float)barY + 32, 76, 70 };
        if (CheckCollisionPointRec(mouse, rect))
        {
            if (button.enabled)
                performRibbonAction(button.action);
            return true;
        }
        x += 78;
    }
    return true;
}

void renderRibbonBar()
{
    if (welcomeScreenOpen || RIBBON_BAR_HEIGHT <= 0)
        return;
    EditorThemeColors theme = getEditorThemeColors();
    int barY = editorRibbonBarY();
    DrawRectangle(0, barY, GetScreenWidth(), RIBBON_BAR_HEIGHT, theme.panel);
    DrawLine(0, barY + RIBBON_BAR_HEIGHT - 1, GetScreenWidth(), barY + RIBBON_BAR_HEIGHT - 1, theme.border);

    const char* tabs[] = { "Home", "Model", "Test", "View", "Plugins" };
    int tabX = 12;
    for (int index = 0; index < 5; ++index)
    {
        int width = MeasureText(tabs[index], 16) + 24;
        Rectangle tab = { (float)tabX, (float)barY + 3, (float)width, 27 };
        if (index == activeRibbonTab)
        {
            DrawRectangleRounded(tab, 0.25f, 6, theme.surface);
            DrawRectangle(tabX, barY + 28, width, 2, theme.accent);
        }
        DrawText(tabs[index], tabX + 12, barY + 8, 16, theme.text);
        tabX += width + 3;
    }

    Vector2 mouse = GetMousePosition();
    vector<RibbonButton> buttons = getRibbonButtons(activeRibbonTab);
    int x = 12;
    for (const RibbonButton& button : buttons)
    {
        Rectangle rect = { (float)x, (float)barY + 32, 76, 70 };
        bool hover = button.enabled && CheckCollisionPointRec(mouse, rect);
        DrawRectangleRounded(rect, 0.14f, 6, hover ? theme.selected : theme.panel);
        Rectangle iconFrame = { (float)x + 22, (float)barY + 35, 32, 30 };
        DrawRectangleRounded(iconFrame, 0.22f, 6, button.enabled ? theme.surface : theme.header);
        DrawRectangleRoundedLines(iconFrame, 0.22f, 6, theme.border);
        Texture2D icon = getRibbonButtonIcon(button);
        if (icon.id != 0)
        {
            const char* tintKey = button.action;
            if (button.action == string("Play Client")) tintKey = "PlayClient";
            drawEditorIcon(icon, (float)x + 22, (float)barY + 35, 32.0f, 30.0f,
                getStudioRibbonIconTint(tintKey));
        }
        else
        {
            int iconWidth = MeasureText(button.fallbackIcon, 16);
            DrawText(button.fallbackIcon, x + 38 - iconWidth / 2, barY + 42, 16,
                button.enabled ? theme.text : theme.muted);
        }
        int labelWidth = MeasureText(button.label, 12);
        DrawText(button.label, x + max(2, (76 - labelWidth) / 2), barY + 75, 12,
            button.enabled ? theme.text : theme.muted);
        x += 78;
    }
}

void renderTopBar(vector<TopBarItem*>& topBarItems)
{
    const int barHeight = MENU_BAR_HEIGHT;
    Vector2 mouse = GetMousePosition();

    EditorThemeColors theme = getEditorThemeColors();
    DrawRectangle(0, 0, GetScreenWidth(), barHeight, theme.header);
    DrawRectangle(0, barHeight - 1, GetScreenWidth(), 1, theme.border);

    for (size_t i = 0; i < topBarItems.size(); ++i)
    {
        TopBarItem* item = topBarItems[i];
        if (item == nullptr)
            continue;

        int x = topBarItemX(topBarItems, i);
        int w = topBarItemWidth(item);
        Rectangle rect = { (float)x, 0.0f, (float)w, (float)barHeight };
        bool open = (openMenu == item);
        bool hovered = CheckCollisionPointRec(mouse, rect) || open;

        if (hovered)
            DrawRectangleRec(rect, theme.surface);

        DrawText(
            item->label.c_str(),
            x + 8,
            (barHeight - 15) / 2,
            15,
            theme.text
        );
    }

    // Action bar is editor-only (hidden on welcome screen)
    if (!welcomeScreenOpen)
    {
        renderActionBar();
        renderRibbonBar();
    }

    // Dropdown drawn last so it sits above everything in the bar stack
    if (openMenu != nullptr)
    {
        int menuX = 8;
        for (size_t i = 0; i < topBarItems.size(); ++i)
        {
            if (topBarItems[i] == openMenu)
            {
                menuX = topBarItemX(topBarItems, i);
                break;
            }
        }
        renderMenu(openMenu, menuX, barHeight);
    }
}

void openScriptWindow(Script* script)
{
    if (script == nullptr)
        return;

    if (find(openScripts.begin(), openScripts.end(), script) == openScripts.end())
    {
        openScripts.push_back(script);
        windowTabs.push_back({ WindowType::Script, script });
    }
    activeScript = script;
    activeWindow = WindowType::Script;
    scriptCursor = static_cast<int>(script->source.size());
    scriptSelectionStart = -1;
    scriptSelectionEnd = -1;
    scriptCaretResetTime = GetTime();
    focusedZone = FocusZone::ScriptEditor;
    openMenu = nullptr;
}

void closeScriptWindow(Script* script)
{
    auto it = find(openScripts.begin(), openScripts.end(), script);
    if (it == openScripts.end())
        return;

    int closedIndex = static_cast<int>(it - openScripts.begin());
    openScripts.erase(it);
    windowTabs.erase(
        remove_if(windowTabs.begin(), windowTabs.end(),
            [script](const WindowTab& tab)
            {
                return tab.type == WindowType::Script && tab.script == script;
            }),
        windowTabs.end()
    );
    if (activeScript == script)
    {
        if (openScripts.empty())
        {
            activeScript = nullptr;
            activeWindow = WindowType::Viewport;
        }
        else
        {
            activeScript = openScripts[min(closedIndex, static_cast<int>(openScripts.size()) - 1)];
            activeWindow = WindowType::Script;
            scriptCursor = static_cast<int>(activeScript->source.size());
        }
    }
}

void renderWindowBar()
{
    if (WINDOW_BAR_HEIGHT <= 0)
        return;
    EditorThemeColors theme = getEditorThemeColors();
    const int barY = editorWindowBarY();
    const int barHeight = WINDOW_BAR_HEIGHT;
    const int scrollBarHeight = 6;
    int visibleWidth = GetScreenWidth();
    int visibleLeft = 0;
    int contentWidth = getWindowBarContentWidth();
    float maxScroll = max(0, contentWidth - visibleWidth);
    windowBarScrollX = std::clamp(windowBarScrollX, 0.0f, static_cast<float>(maxScroll));

    DrawRectangle(visibleLeft, barY, visibleWidth, barHeight, theme.header);

    BeginScissorMode(visibleLeft, barY, visibleWidth, barHeight - scrollBarHeight);
    int tabX = 8 - static_cast<int>(windowBarScrollX);
    for (const WindowTab& tab : windowTabs)
    {
        int tabWidth = getWindowTabWidth(tab);
        bool active = tab.type == activeWindow &&
            (tab.type != WindowType::Script || tab.script == activeScript);
        Rectangle tabRect = { static_cast<float>(tabX), static_cast<float>(barY + 2), static_cast<float>(tabWidth), 24.0f };
        DrawRectangleRec(tabRect, active ? theme.selected : theme.surface);

        const char* label = tab.type == WindowType::Viewport ? "Viewport" :
            tab.type == WindowType::Welcome ? "Welcome" :
            tab.type == WindowType::Output ? "Output" :
            tab.type == WindowType::Library ? "Asset Manager" :
            tab.type == WindowType::ExplorerView ? "Explorer" :
            tab.type == WindowType::PropertiesView ? "Properties" :
            (tab.script != nullptr ? tab.script->name.c_str() : "Script");
        DrawText(label, tabX + 10, barY + 7, 16, theme.text);
        if (tab.type == WindowType::Script ||
            tab.type == WindowType::Library ||
            tab.type == WindowType::ExplorerView ||
            tab.type == WindowType::PropertiesView)
            DrawText("X", tabX + tabWidth - 25, barY + 6, 18, theme.muted);
        tabX += tabWidth;
    }
    EndScissorMode();

    if (maxScroll > 0.0f)
    {
        Rectangle track = { static_cast<float>(visibleLeft), static_cast<float>(barY + barHeight - scrollBarHeight), static_cast<float>(visibleWidth), static_cast<float>(scrollBarHeight) };
        float thumbWidth = scrollbarThumbSize(track.width, static_cast<float>(maxScroll));
        Rectangle thumb = { track.x + windowBarScrollX / maxScroll * (track.width - thumbWidth), track.y, thumbWidth, track.height };
        DrawRectangleRec(track, theme.canvas);
        DrawRectangleRec(thumb, theme.muted);
    }
}

void handleWindowBarClick()
{
    if (WINDOW_BAR_HEIGHT <= 0)
        return;
    Vector2 mouse = GetMousePosition();

    // Continue tab drag even if the cursor leaves the bar strip
    if (draggedWindowTab >= 0 && IsMouseButtonDown(MOUSE_BUTTON_LEFT))
    {
        if (fabsf(mouse.x - windowBarTabDragStart.x) > 5.0f ||
            fabsf(mouse.y - windowBarTabDragStart.y) > 5.0f)
            windowBarTabDragMoved = true;
    }

    if (draggedWindowTab >= 0 && IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
    {
        if (windowBarTabDragMoved)
        {
            int target = 0;
            int tabX = 8 - static_cast<int>(windowBarScrollX);
            for (int index = 0; index < static_cast<int>(windowTabs.size()); ++index)
            {
                int tabWidth = getWindowTabWidth(windowTabs[index]);
                if (mouse.x > tabX + tabWidth / 2)
                    target = index + 1;
                tabX += tabWidth;
            }
            target = min(target, static_cast<int>(windowTabs.size()) - 1);
            WindowTab moved = windowTabs[draggedWindowTab];
            windowTabs.erase(windowTabs.begin() + draggedWindowTab);
            if (target > draggedWindowTab)
                target--;
            target = std::clamp(target, 0, static_cast<int>(windowTabs.size()));
            windowTabs.insert(windowTabs.begin() + target, moved);
        }
        draggedWindowTab = -1;
        windowBarTabDragMoved = false;
        return;
    }

    if (mouse.y < (float)editorWindowBarY() || mouse.y >= (float)editorContentTopY())
        return;

    int contentWidth = getWindowBarContentWidth();
    int visibleLeft = 0;
    int visibleWidth = GetScreenWidth();
    float maxScroll = max(0, contentWidth - visibleWidth);
    int barY = editorWindowBarY();
    if (mouse.y >= barY + WINDOW_BAR_HEIGHT - 6)
    {
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && maxScroll > 0.0f)
            windowBarDraggingScroll = true;
        if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && windowBarDraggingScroll && maxScroll > 0.0f)
        {
            windowBarScrollX = std::clamp(
                ((mouse.x - visibleLeft) / max(static_cast<float>(visibleWidth), 1.0f)) * maxScroll,
                0.0f,
                maxScroll
            );
        }
        if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
            windowBarDraggingScroll = false;
        return;
    }

    float wheel = GetMouseWheelMove();
    if (wheel != 0.0f)
    {
        int tabX = 8 - static_cast<int>(windowBarScrollX);
        for (const WindowTab& tab : windowTabs)
        {
            int tabWidth = getWindowTabWidth(tab);
            Rectangle tabRect = { static_cast<float>(tabX), static_cast<float>(barY + 2),
                static_cast<float>(tabWidth), 24.0f };
            if (CheckCollisionPointRec(mouse, tabRect))
            {
                activeWindow = tab.type;
                activeScript = tab.script;
                focusActiveWindow();
                return;
            }
            tabX += tabWidth;
        }
    }

    if (isZoneFocused(FocusZone::Chrome) && wheel != 0.0f && maxScroll > 0.0f)
    {
        windowBarScrollX = std::clamp(
            windowBarScrollX - wheel * 120.0f,
            0.0f,
            maxScroll
        );
        return;
    }

    bool tabPressed = IsMouseButtonPressed(MOUSE_BUTTON_LEFT) ||
        IsMouseButtonPressed(MOUSE_BUTTON_RIGHT) ||
        IsMouseButtonPressed(MOUSE_BUTTON_MIDDLE);
    if (tabPressed && draggedWindowTab < 0)
    {
        int tabX = 8 - static_cast<int>(windowBarScrollX);
        for (int index = 0; index < static_cast<int>(windowTabs.size()); ++index)
        {
            WindowTab& tab = windowTabs[index];
            int tabWidth = getWindowTabWidth(tab);
            Rectangle tabRect = { static_cast<float>(tabX), static_cast<float>(barY + 2), static_cast<float>(tabWidth), 24.0f };
            if (CheckCollisionPointRec(mouse, tabRect))
            {
                bool leftPressed = IsMouseButtonPressed(MOUSE_BUTTON_LEFT);
                if (leftPressed && tab.type == WindowType::Script && mouse.x >= tabRect.x + tabRect.width - 32.0f)
                {
                    closeScriptWindow(tab.script);
                }
                else if (leftPressed && (tab.type == WindowType::ExplorerView || tab.type == WindowType::PropertiesView) &&
                         mouse.x >= tabRect.x + tabRect.width - 32.0f)
                {
                    DockPanelKind panel = tab.type == WindowType::ExplorerView
                        ? DockPanelKind::Explorer : DockPanelKind::Properties;
                    closeWindowTabType(tab.type);
                    dockPanelInto(panel, panel == DockPanelKind::Explorer ? rightDockSlot : leftDockSlot);
                }
                else if (leftPressed && tab.type == WindowType::Library && mouse.x >= tabRect.x + tabRect.width - 32.0f)
                {
                    closeWindowTabType(WindowType::Library);
                }
                else
                {
                    activeWindow = tab.type;
                    activeScript = tab.script;
                    focusActiveWindow();
                    if (activeScript != nullptr)
                        scriptCursor = static_cast<int>(activeScript->source.size());
                    if (leftPressed)
                    {
                        draggedWindowTab = index;
                        windowBarTabDragMoved = false;
                        windowBarTabDragStart = mouse;
                        windowBarTabDragOffset = { mouse.x - tabRect.x, mouse.y - tabRect.y };
                    }
                }
                return;
            }
            tabX += tabWidth;
        }
    }
}

void renderWindowBarTabDragOverlay()
{
    if (draggedWindowTab < 0 || !windowBarTabDragMoved)
        return;
    if (draggedWindowTab >= static_cast<int>(windowTabs.size()))
        return;

    WindowTab& tab = windowTabs[draggedWindowTab];
    int tabWidth = getWindowTabWidth(tab);
    Vector2 mouse = GetMousePosition();
    float fx = mouse.x - windowBarTabDragOffset.x;
    float fy = mouse.y - windowBarTabDragOffset.y;

    const char* label = tab.type == WindowType::Viewport ? "Viewport" :
        tab.type == WindowType::Output ? "Output" :
        tab.type == WindowType::Library ? "Asset Manager" :
        tab.type == WindowType::ExplorerView ? "Explorer" :
        tab.type == WindowType::PropertiesView ? "Properties" :
        (tab.script != nullptr ? tab.script->name.c_str() : "Script");

    DrawRectangle(static_cast<int>(fx), static_cast<int>(fy), tabWidth, 26, (Color){ 70, 90, 120, 230 });
    DrawRectangleLinesEx(
        (Rectangle){ fx, fy, (float)tabWidth, 26.0f },
        2.0f, (Color){ 0, 180, 255, 255 });
    DrawText(label, static_cast<int>(fx) + 10, static_cast<int>(fy) + 5, 16, RAYWHITE);

    // Drop insertion marker on the window bar
    int insertX = 8 - static_cast<int>(windowBarScrollX);
    int markerX = insertX;
    for (int index = 0; index < static_cast<int>(windowTabs.size()); ++index)
    {
        int w = getWindowTabWidth(windowTabs[index]);
        if (mouse.x > insertX + w / 2)
            markerX = insertX + w;
        insertX += w;
    }
    DrawRectangle(markerX - 1, editorWindowBarY() + 2, 3, 24, getEditorThemeColors().accent);
}

// ============================================================
// Explorer
// ============================================================

int getExplorerX()
{
    if (activeWindow == WindowType::ExplorerView)
        return leftSlotWidth();
    return isDockPanelOnLeft(DockPanelKind::Explorer) ? 0 : GetScreenWidth() - EXPLORER_WIDTH;
}

enum class PropertyKind
{
    String,
    Number,
    Boolean,
    Color,
    ReadOnly,
    SoundPreview,  // inline play/seek bar for Sound instances
    InstanceRef,   // pointer to another Instance (stored as path in project files)
    Enum,          // dropdown of predefined enum options (not free text)
    Packed,        // expandable header: shows compact {x,y,z} / UDim2 / Color3
    PackedField    // component row shown only when parent Packed is expanded
};

struct PropertyRow
{
    string name;
    PropertyKind kind;
    string value;
    vector<string> enumOptions; // only used when kind == Enum
    // Packed / PackedField
    string packId;              // group key e.g. "Position", "Size", "CFrame"
    string packCompact;         // display when collapsed e.g. "{0, 8, 0}"
    int packDepth = 0;          // 0 header, 1 field
};

// Which packed groups are expanded in the Properties panel (key = packId)
unordered_set<string> propertyPackedExpanded;

string colorToHex(Color color);

vector<PropertyRow> getPropertyRows(Instance* instance)
{
    if (instance == nullptr)
        return {};

    string className =
        instance->getType() == InstanceType::Part
            ? (static_cast<const Part*>(instance)->isMeshPart ? "MeshPart" : "Part") :
        instance->getType() == InstanceType::Script ? scriptTypeName(static_cast<const Script*>(instance)->type) :
        instance->getType() == InstanceType::Model ? "Model" :
        instance->getType() == InstanceType::Folder ? "Folder" :
        instance->getType() == InstanceType::Sound ? "Sound" :
        instance->getType() == InstanceType::Texture ? "Texture" :
        instance->getType() == InstanceType::WeldConstraint ? "WeldConstraint" :
        instance->getType() == InstanceType::Motor6D ? "Motor6D" :
        instance->getType() == InstanceType::Blur ? "Blur" :
        instance->getType() == InstanceType::ColorCorrection ? "ColorCorrection" :
        instance->getType() == InstanceType::SunLight ? "SunLight" :
        instance->getType() == InstanceType::Bloom ? "Bloom" :
        instance == &Lighting ? "Lighting" : "Service";

    vector<PropertyRow> rows = {
        { "Name", PropertyKind::String, instance->name },
        { "ClassName", PropertyKind::ReadOnly, className },
        { "Parent", instance->getType() == InstanceType::Service
                ? PropertyKind::ReadOnly : PropertyKind::InstanceRef,
            instance->parent != nullptr ? getInstancePath(instance->parent) : "" }
    };

    if (instance->getType() == InstanceType::Part)
    {
        Part* part = static_cast<Part*>(instance);
        auto addPackedV3 = [&](const string& id, const string& label, float x, float y, float z,
            const char* fx, const char* fy, const char* fz)
        {
            PropertyRow hdr;
            hdr.name = label;
            hdr.kind = PropertyKind::Packed;
            hdr.packId = id;
            hdr.packCompact = TextFormat("{%.3g, %.3g, %.3g}", x, y, z);
            hdr.value = hdr.packCompact;
            rows.push_back(hdr);
            if (propertyPackedExpanded.count(id))
            {
                rows.push_back({ fx, PropertyKind::PackedField, TextFormat("%.3f", x), {}, id, "", 1 });
                rows.push_back({ fy, PropertyKind::PackedField, TextFormat("%.3f", y), {}, id, "", 1 });
                rows.push_back({ fz, PropertyKind::PackedField, TextFormat("%.3f", z), {}, id, "", 1 });
            }
        };
        addPackedV3("Position", "Position", part->cframe.position.x, part->cframe.position.y, part->cframe.position.z,
            "Position X", "Position Y", "Position Z");
        addPackedV3("Orientation", "Orientation", part->cframe.rotation.x, part->cframe.rotation.y, part->cframe.rotation.z,
            "Orientation X", "Orientation Y", "Orientation Z");
        addPackedV3("Size", "Size", part->size.x, part->size.y, part->size.z,
            "Size X", "Size Y", "Size Z");
        rows.push_back({ "Color", PropertyKind::Color, colorToHex(part->color) });
        rows.push_back({ "Transparency", PropertyKind::Number, TextFormat("%.3f", part->transparency) });
        rows.push_back({ "Reflectance", PropertyKind::Number, TextFormat("%.3f", part->reflectance) });
        rows.push_back({ "Anchored", PropertyKind::Boolean, part->anchored ? "true" : "false" });
        rows.push_back({ "CanCollide", PropertyKind::Boolean, part->canCollide ? "true" : "false" });
        rows.push_back({ "CastShadow", PropertyKind::Boolean, part->castShadow ? "true" : "false" });
        rows.push_back({ "AdvancedPhysics", PropertyKind::Boolean, part->advancedPhysics ? "true" : "false" });
        if (part->advancedPhysics)
        {
            rows.push_back({ "Density", PropertyKind::Number, TextFormat("%.3f", part->density) });
            rows.push_back({ "Friction", PropertyKind::Number, TextFormat("%.3f", part->friction) });
        }
        rows.push_back({ "Truss", PropertyKind::Boolean, part->truss ? "true" : "false" });
        rows.push_back({ "Locked", PropertyKind::Boolean, part->locked ? "true" : "false" });
        rows.push_back({ "LocalAxes", PropertyKind::Boolean, part->showLocalAxes ? "true" : "false" });
        if (!part->isMeshPart)
        {
            PropertyRow partTypeRow;
            partTypeRow.name = "PartType";
            partTypeRow.kind = PropertyKind::Enum;
            partTypeRow.value = partTypeName(part->type);
            partTypeRow.enumOptions = { "Block", "Sphere", "Cylinder", "Cone", "Wedge", "CornerWedge" };
            rows.push_back(partTypeRow);
        }
        else
        {
            rows.push_back({ "MeshId", PropertyKind::String, part->meshId });
            rows.push_back({ "TextureId", PropertyKind::String, part->textureId });
            PropertyRow fidelityRow;
            fidelityRow.name = "CollisionFidelity";
            fidelityRow.kind = PropertyKind::Enum;
            fidelityRow.value = collisionFidelityName(part->collisionFidelity);
            fidelityRow.enumOptions = {
                "Default", "Hull", "Box", "PreciseConvexDecomposition", "Tunable"
            };
            rows.push_back(fidelityRow);
        }
        addPackedV3("PivotOffset", "PivotOffset", part->pivotOffset.x, part->pivotOffset.y, part->pivotOffset.z,
            "PivotOffset X", "PivotOffset Y", "PivotOffset Z");
    }
    else if (instance->getType() == InstanceType::Script)
    {
        Script* s = static_cast<Script*>(instance);
        rows.push_back({ "Enabled", PropertyKind::Boolean, s->enabled ? "true" : "false" });
        {
            PropertyRow rc;
            rc.name = "RunContext";
            rc.kind = PropertyKind::Enum;
            rc.value = s->runContextName();
            rc.enumOptions = { "Server", "Client", "Module" };
            rows.push_back(rc);
        }
    }
    else if (instance->getType() == InstanceType::Model)
    {
        Model_Instance* model = static_cast<Model_Instance*>(instance);
        Vector3 wp = getModelWorldPivot(*model);
        rows.push_back({ "Scale", PropertyKind::Number, TextFormat("%.3f", model->scale) });
        rows.push_back({ "PrimaryPart", PropertyKind::InstanceRef, model->primaryPart ? model->primaryPart->name : "" });
        rows.push_back({ "PivotOffset X", PropertyKind::Number, TextFormat("%.3f", model->pivotOffset.x) });
        rows.push_back({ "PivotOffset Y", PropertyKind::Number, TextFormat("%.3f", model->pivotOffset.y) });
        rows.push_back({ "PivotOffset Z", PropertyKind::Number, TextFormat("%.3f", model->pivotOffset.z) });
        rows.push_back({ "WorldPivot X", PropertyKind::ReadOnly, TextFormat("%.3f", wp.x) });
        rows.push_back({ "WorldPivot Y", PropertyKind::ReadOnly, TextFormat("%.3f", wp.y) });
        rows.push_back({ "WorldPivot Z", PropertyKind::ReadOnly, TextFormat("%.3f", wp.z) });
    }
    else if (instance->getType() == InstanceType::Sound)
    {
        SoundInstance* s = static_cast<SoundInstance*>(instance);
        rows.push_back({ "SoundId", PropertyKind::String, s->soundId });
        rows.push_back({ "Sample", PropertyKind::SoundPreview, "" });
        rows.push_back({ "Volume", PropertyKind::Number, TextFormat("%.3f", s->volume) });
        rows.push_back({ "PlaybackSpeed", PropertyKind::Number, TextFormat("%.3f", s->playbackSpeed) });
        rows.push_back({ "PlayingSpeed", PropertyKind::Number, TextFormat("%.3f", s->playbackSpeed) });
        rows.push_back({ "Looped", PropertyKind::Boolean, s->looped ? "true" : "false" });
        rows.push_back({ "Playing", PropertyKind::Boolean, s->playing ? "true" : "false" });
        rows.push_back({ "TimePosition", PropertyKind::Number, TextFormat("%.3f", s->timePosition) });
        rows.push_back({ "RollOffMaxDistance", PropertyKind::Number, TextFormat("%.3f", s->rollOffMaxDistance) });
        rows.push_back({ "RollOffMinDistance", PropertyKind::Number, TextFormat("%.3f", s->rollOffMinDistance) });
    }
    else if (instance->getType() == InstanceType::Humanoid)
    {
        HumanoidInstance* humanoid = static_cast<HumanoidInstance*>(instance);
        rows.push_back({ "Health", PropertyKind::Number, TextFormat("%.3f", humanoid->health) });
        rows.push_back({ "MaxHealth", PropertyKind::Number, TextFormat("%.3f", humanoid->maxHealth) });
        rows.push_back({ "WalkSpeed", PropertyKind::Number, TextFormat("%.3f", humanoid->walkSpeed) });
        rows.push_back({ "JumpPower", PropertyKind::Number, TextFormat("%.3f", humanoid->jumpPower) });
        rows.push_back({ "HipHeight", PropertyKind::Number, TextFormat("%.3f", humanoid->hipHeight) });
        rows.push_back({ "SlopeAngle", PropertyKind::Number, TextFormat("%.3f", humanoid->slopeAngle) });
        rows.push_back({ "RootPart", PropertyKind::InstanceRef, humanoid->rootPart ? humanoid->rootPart->name : "" });
    }
    else if (instance->getType() == InstanceType::Camera)
    {
        CameraInstance* cameraInstance = static_cast<CameraInstance*>(instance);
        {
            PropertyRow modeRow;
            modeRow.name = "Mode";
            modeRow.kind = PropertyKind::Enum;
            modeRow.value = cameraInstance->mode == BT_CameraMode::Default ? "Default" : "Scriptable";
            modeRow.enumOptions = { "Default", "Scriptable" };
            rows.push_back(modeRow);
        }
        rows.push_back({ "Target", PropertyKind::InstanceRef,
            cameraInstance->target ? cameraInstance->target->name : "" });
        rows.push_back({ "CFrame X", PropertyKind::Number, TextFormat("%.3f", cameraInstance->cframe.position.x) });
        rows.push_back({ "CFrame Y", PropertyKind::Number, TextFormat("%.3f", cameraInstance->cframe.position.y) });
        rows.push_back({ "CFrame Z", PropertyKind::Number, TextFormat("%.3f", cameraInstance->cframe.position.z) });
    }
    else if (instance->getType() == InstanceType::Texture)
    {
        TextureInstance* t = static_cast<TextureInstance*>(instance);
        rows.push_back({ "Texture", PropertyKind::String, t->texture });
        rows.push_back({ "StudsPerTileU", PropertyKind::Number, TextFormat("%.3f", t->studsPerTileU) });
        rows.push_back({ "StudsPerTileV", PropertyKind::Number, TextFormat("%.3f", t->studsPerTileV) });
        rows.push_back({ "OffsetStudsU", PropertyKind::Number, TextFormat("%.3f", t->offsetStudsU) });
        rows.push_back({ "OffsetStudsV", PropertyKind::Number, TextFormat("%.3f", t->offsetStudsV) });
        rows.push_back({ "Transparency", PropertyKind::Number, TextFormat("%.3f", t->transparency) });
        rows.push_back({ "Color3", PropertyKind::Color, colorToHex(t->color3) });
        {
            PropertyRow faceRow;
            faceRow.name = "Face";
            faceRow.kind = PropertyKind::Enum;
            faceRow.value = t->face;
            faceRow.enumOptions = { "Top", "Bottom", "Front", "Back", "Left", "Right" };
            rows.push_back(faceRow);
        }
    }
    else if (instance->getType() == InstanceType::WeldConstraint)
    {
        WeldConstraint* w = static_cast<WeldConstraint*>(instance);
        rows.push_back({ "Part0", PropertyKind::InstanceRef, w->part0 ? w->part0->name : "" });
        rows.push_back({ "Part1", PropertyKind::InstanceRef, w->part1 ? w->part1->name : "" });
        rows.push_back({ "Enabled", PropertyKind::Boolean, w->enabled ? "true" : "false" });
    }
    else if (instance->getType() == InstanceType::Motor6D)
    {
        Motor6DConstraint* m = static_cast<Motor6DConstraint*>(instance);
        rows.push_back({ "Part0", PropertyKind::InstanceRef, m->part0 ? m->part0->name : "" });
        rows.push_back({ "Part1", PropertyKind::InstanceRef, m->part1 ? m->part1->name : "" });
        rows.push_back({ "C0 Position X", PropertyKind::Number, TextFormat("%.3f", m->c0.position.x) });
        rows.push_back({ "C0 Position Y", PropertyKind::Number, TextFormat("%.3f", m->c0.position.y) });
        rows.push_back({ "C0 Position Z", PropertyKind::Number, TextFormat("%.3f", m->c0.position.z) });
        rows.push_back({ "C1 Position X", PropertyKind::Number, TextFormat("%.3f", m->c1.position.x) });
        rows.push_back({ "C1 Position Y", PropertyKind::Number, TextFormat("%.3f", m->c1.position.y) });
        rows.push_back({ "C1 Position Z", PropertyKind::Number, TextFormat("%.3f", m->c1.position.z) });
        rows.push_back({ "DesiredAngle", PropertyKind::Number, TextFormat("%.3f", m->desiredAngle) });
        rows.push_back({ "MaxVelocity", PropertyKind::Number, TextFormat("%.3f", m->maxVelocity) });
        rows.push_back({ "CurrentAngle", PropertyKind::ReadOnly, TextFormat("%.3f", m->currentAngle) });
        rows.push_back({ "Enabled", PropertyKind::Boolean, m->enabled ? "true" : "false" });
    }
    else if (instance->getType() == InstanceType::Blur)
    {
        rows.push_back({ "Size", PropertyKind::Number, TextFormat("%.3f", static_cast<BlurInstance*>(instance)->size) });
    }
    else if (instance->getType() == InstanceType::ColorCorrection)
    {
        auto* effect = static_cast<ColorCorrectionInstance*>(instance);
        rows.push_back({ "Brightness", PropertyKind::Number, TextFormat("%.3f", effect->brightness) });
        rows.push_back({ "Contrast", PropertyKind::Number, TextFormat("%.3f", effect->contrast) });
        rows.push_back({ "Saturation", PropertyKind::Number, TextFormat("%.3f", effect->saturation) });
        rows.push_back({ "TintColor", PropertyKind::Color, colorToHex(effect->tintColor) });
    }
    else if (instance->getType() == InstanceType::SunLight)
    {
        auto* effect = static_cast<SunLightInstance*>(instance);
        rows.push_back({ "Direction X", PropertyKind::Number, TextFormat("%.3f", effect->direction.x) });
        rows.push_back({ "Direction Y", PropertyKind::Number, TextFormat("%.3f", effect->direction.y) });
        rows.push_back({ "Direction Z", PropertyKind::Number, TextFormat("%.3f", effect->direction.z) });
        rows.push_back({ "Color", PropertyKind::Color, colorToHex(effect->color) });
        rows.push_back({ "Intensity", PropertyKind::Number, TextFormat("%.3f", effect->intensity) });
    }
    else if (instance->getType() == InstanceType::PointLight)
    {
        auto* L = static_cast<PointLightInstance*>(instance);
        rows.push_back({ "Enabled", PropertyKind::Boolean, L->enabled ? "true" : "false" });
        rows.push_back({ "Color", PropertyKind::Color, colorToHex(L->color) });
        rows.push_back({ "Brightness", PropertyKind::Number, TextFormat("%.3f", L->brightness) });
        rows.push_back({ "Range", PropertyKind::Number, TextFormat("%.3f", L->range) });
        rows.push_back({ "Shadows", PropertyKind::Boolean, L->shadows ? "true" : "false" });
    }
    else if (instance->getType() == InstanceType::SpotLight)
    {
        auto* L = static_cast<SpotLightInstance*>(instance);
        rows.push_back({ "Enabled", PropertyKind::Boolean, L->enabled ? "true" : "false" });
        rows.push_back({ "Color", PropertyKind::Color, colorToHex(L->color) });
        rows.push_back({ "Brightness", PropertyKind::Number, TextFormat("%.3f", L->brightness) });
        rows.push_back({ "Range", PropertyKind::Number, TextFormat("%.3f", L->range) });
        rows.push_back({ "Angle", PropertyKind::Number, TextFormat("%.3f", L->angle) });
        {
            PropertyRow faceRow; faceRow.name = "Face"; faceRow.kind = PropertyKind::Enum; faceRow.value = L->face;
            faceRow.enumOptions = { "Front", "Back", "Left", "Right", "Top", "Bottom" };
            rows.push_back(faceRow);
        }
        rows.push_back({ "Shadows", PropertyKind::Boolean, L->shadows ? "true" : "false" });
    }
    else if (instance->getType() == InstanceType::SurfaceLight)
    {
        auto* L = static_cast<SurfaceLightInstance*>(instance);
        rows.push_back({ "Enabled", PropertyKind::Boolean, L->enabled ? "true" : "false" });
        rows.push_back({ "Color", PropertyKind::Color, colorToHex(L->color) });
        rows.push_back({ "Brightness", PropertyKind::Number, TextFormat("%.3f", L->brightness) });
        rows.push_back({ "Range", PropertyKind::Number, TextFormat("%.3f", L->range) });
        rows.push_back({ "Angle", PropertyKind::Number, TextFormat("%.3f", L->angle) });
        {
            PropertyRow faceRow; faceRow.name = "Face"; faceRow.kind = PropertyKind::Enum; faceRow.value = L->face;
            faceRow.enumOptions = { "Front", "Back", "Left", "Right", "Top", "Bottom" };
            rows.push_back(faceRow);
        }
        rows.push_back({ "Shadows", PropertyKind::Boolean, L->shadows ? "true" : "false" });
    }
    else if (instance->getType() == InstanceType::Bloom)
    {
        auto* effect = static_cast<BloomInstance*>(instance);
        rows.push_back({ "Intensity", PropertyKind::Number, TextFormat("%.3f", effect->intensity) });
        rows.push_back({ "Threshold", PropertyKind::Number, TextFormat("%.3f", effect->threshold) });
        rows.push_back({ "Size", PropertyKind::Number, TextFormat("%.3f", effect->size) });
    }
    else if (instance == &Lighting)
    {
        rows.push_back({ "Ambient", PropertyKind::Color, colorToHex(lightingSettings.ambient) });
        rows.push_back({ "OutdoorAmbient", PropertyKind::Color, colorToHex(lightingSettings.outdoorAmbient) });
        rows.push_back({ "ColorShift_Top", PropertyKind::Color, colorToHex(lightingSettings.colorShiftTop) });
        rows.push_back({ "ColorShift_Bottom", PropertyKind::Color, colorToHex(lightingSettings.colorShiftBottom) });
        rows.push_back({ "FogColor", PropertyKind::Color, colorToHex(lightingSettings.fogColor) });
        rows.push_back({ "FogStart", PropertyKind::Number, TextFormat("%.3f", lightingSettings.fogStart) });
        rows.push_back({ "FogEnd", PropertyKind::Number, TextFormat("%.3f", lightingSettings.fogEnd) });
        rows.push_back({ "Brightness", PropertyKind::Number, TextFormat("%.3f", lightingSettings.brightness) });
        rows.push_back({ "ExposureCompensation", PropertyKind::Number, TextFormat("%.3f", lightingSettings.exposureCompensation) });
        rows.push_back({ "EnvironmentDiffuseScale", PropertyKind::Number, TextFormat("%.3f", lightingSettings.environmentDiffuseScale) });
        rows.push_back({ "EnvironmentSpecularScale", PropertyKind::Number, TextFormat("%.3f", lightingSettings.environmentSpecularScale) });
        rows.push_back({ "GlobalShadows", PropertyKind::Boolean, lightingSettings.globalShadows ? "true" : "false" });
        {
            PropertyRow soft;
            soft.name = "ShadowSoftness";
            soft.kind = PropertyKind::Enum;
            soft.value = lightingSettings.shadowSoftness;
            soft.enumOptions = { "Hard", "Soft", "Sharp" };
            rows.push_back(soft);
        }
        rows.push_back({ "ClockTime", PropertyKind::Number, TextFormat("%.3f", lightingSettings.clockTime) });
        rows.push_back({ "GeographicLatitude", PropertyKind::Number, TextFormat("%.3f", lightingSettings.geographicLatitude) });
        rows.push_back({ "Blur", PropertyKind::Number, TextFormat("%.3f", lightingSettings.blur) });
    }
    else if (instance->getType() == InstanceType::ScreenGui ||
             instance->getType() == InstanceType::SurfaceGui ||
             instance->getType() == InstanceType::BillboardGui)
    {
        auto* lc = static_cast<LayerCollectorInstance*>(instance);
        rows.push_back({ "Enabled", PropertyKind::Boolean, lc->enabled ? "true" : "false" });
        rows.push_back({ "Active", PropertyKind::Boolean, lc->active ? "true" : "false" });
        rows.push_back({ "DisplayOrder", PropertyKind::Number, TextFormat("%d", lc->displayOrder) });
        rows.push_back({ "ResetOnSpawn", PropertyKind::Boolean, lc->resetOnSpawn ? "true" : "false" });
        rows.push_back({ "IgnoreGuiInset", PropertyKind::Boolean, lc->ignoreGuiInset ? "true" : "false" });
        rows.push_back({ "ClipToDeviceSafeArea", PropertyKind::Boolean, lc->clipToDeviceSafeArea ? "true" : "false" });
        rows.push_back({ "AlwaysOnTop", PropertyKind::Boolean, lc->alwaysOnTop ? "true" : "false" });
        rows.push_back({ "MaxDistance", PropertyKind::Number, TextFormat("%.3f", lc->maxDistance) });
        rows.push_back({ "PixelsPerStud", PropertyKind::Number, TextFormat("%.3f", lc->pixelsPerStud) });
        rows.push_back({ "Brightness", PropertyKind::Number, TextFormat("%.3f", lc->brightness) });
        rows.push_back({ "LightInfluence", PropertyKind::Number, TextFormat("%.3f", lc->lightInfluence) });
        rows.push_back({ "ClipsDescendants", PropertyKind::Boolean, lc->clipsDescendants ? "true" : "false" });
        rows.push_back({ "CanvasSize X", PropertyKind::Number, TextFormat("%.3f", lc->canvasSize.x) });
        rows.push_back({ "CanvasSize Y", PropertyKind::Number, TextFormat("%.3f", lc->canvasSize.y) });
        {
            PropertyRow sm; sm.name = "SizingMode"; sm.kind = PropertyKind::Enum; sm.value = lc->sizingMode;
            sm.enumOptions = { "PixelsPerStud", "FixedSize" }; rows.push_back(sm);
        }
        rows.push_back({ "ZOffset", PropertyKind::Number, TextFormat("%.3f", lc->zOffset) });
        rows.push_back({ "StudsOffset X", PropertyKind::Number, TextFormat("%.3f", lc->studsOffset.x) });
        rows.push_back({ "StudsOffset Y", PropertyKind::Number, TextFormat("%.3f", lc->studsOffset.y) });
        rows.push_back({ "StudsOffset Z", PropertyKind::Number, TextFormat("%.3f", lc->studsOffset.z) });
        rows.push_back({ "DistanceLowerLimit", PropertyKind::Number, TextFormat("%.3f", lc->distanceLowerLimit) });
        rows.push_back({ "DistanceUpperLimit", PropertyKind::Number, TextFormat("%.3f", lc->distanceUpperLimit) });
        rows.push_back({ "Billboard Size X Scale", PropertyKind::Number, TextFormat("%.3f", lc->billboardSize.x.scale) });
        rows.push_back({ "Billboard Size X Offset", PropertyKind::Number, TextFormat("%.3f", lc->billboardSize.x.offset) });
        rows.push_back({ "Billboard Size Y Scale", PropertyKind::Number, TextFormat("%.3f", lc->billboardSize.y.scale) });
        rows.push_back({ "Billboard Size Y Offset", PropertyKind::Number, TextFormat("%.3f", lc->billboardSize.y.offset) });
        {
            PropertyRow faceRow;
            faceRow.name = "Face";
            faceRow.kind = PropertyKind::Enum;
            faceRow.value = lc->face;
            faceRow.enumOptions = { "Front", "Back", "Top", "Bottom", "Left", "Right" };
            rows.push_back(faceRow);
        }
        rows.push_back({ "Adornee", PropertyKind::InstanceRef, lc->adornee ? lc->adornee->name : "" });
    }
    else if (instance->getType() == InstanceType::Frame ||
             instance->getType() == InstanceType::ScrollingFrame ||
             instance->getType() == InstanceType::TextLabel ||
             instance->getType() == InstanceType::ImageLabel ||
             instance->getType() == InstanceType::TextButton ||
             instance->getType() == InstanceType::ImageButton ||
             instance->getType() == InstanceType::TextBox)
    {
        auto* g = static_cast<GuiObjectInstance*>(instance);
        rows.push_back({ "Visible", PropertyKind::Boolean, g->visible ? "true" : "false" });
        rows.push_back({ "Active", PropertyKind::Boolean, g->active ? "true" : "false" });
        rows.push_back({ "Interactable", PropertyKind::Boolean, g->interactable ? "true" : "false" });
        rows.push_back({ "ClipsDescendants", PropertyKind::Boolean, g->clipsDescendants ? "true" : "false" });
        auto addPackedUDim2 = [&](const string& id, const string& label, const UDim2Value& u,
            const char* xs, const char* xo, const char* ys, const char* yo)
        {
            PropertyRow hdr;
            hdr.name = label;
            hdr.kind = PropertyKind::Packed;
            hdr.packId = id;
            hdr.packCompact = TextFormat("{%.3g, %.3g},{%.3g, %.3g}", u.x.scale, u.x.offset, u.y.scale, u.y.offset);
            hdr.value = hdr.packCompact;
            rows.push_back(hdr);
            if (propertyPackedExpanded.count(id))
            {
                rows.push_back({ xs, PropertyKind::PackedField, TextFormat("%.3f", u.x.scale), {}, id, "", 1 });
                rows.push_back({ xo, PropertyKind::PackedField, TextFormat("%.3f", u.x.offset), {}, id, "", 1 });
                rows.push_back({ ys, PropertyKind::PackedField, TextFormat("%.3f", u.y.scale), {}, id, "", 1 });
                rows.push_back({ yo, PropertyKind::PackedField, TextFormat("%.3f", u.y.offset), {}, id, "", 1 });
            }
        };
        addPackedUDim2("GuiSize", "Size", g->size, "Size X Scale", "Size X Offset", "Size Y Scale", "Size Y Offset");
        addPackedUDim2("GuiPosition", "Position", g->position, "Position X Scale", "Position X Offset", "Position Y Scale", "Position Y Offset");
        {
            PropertyRow hdr;
            hdr.name = "AnchorPoint";
            hdr.kind = PropertyKind::Packed;
            hdr.packId = "AnchorPoint";
            hdr.packCompact = TextFormat("{%.3g, %.3g}", g->anchorPoint.x, g->anchorPoint.y);
            hdr.value = hdr.packCompact;
            rows.push_back(hdr);
            if (propertyPackedExpanded.count("AnchorPoint"))
            {
                rows.push_back({ "AnchorPoint X", PropertyKind::PackedField, TextFormat("%.3f", g->anchorPoint.x), {}, "AnchorPoint", "", 1 });
                rows.push_back({ "AnchorPoint Y", PropertyKind::PackedField, TextFormat("%.3f", g->anchorPoint.y), {}, "AnchorPoint", "", 1 });
            }
        }
        rows.push_back({ "ZIndex", PropertyKind::Number, TextFormat("%d", g->zIndex) });
        rows.push_back({ "LayoutOrder", PropertyKind::Number, TextFormat("%d", g->layoutOrder) });
        rows.push_back({ "Rotation", PropertyKind::Number, TextFormat("%.3f", g->rotation) });
        rows.push_back({ "BackgroundColor3", PropertyKind::Color, colorToHex(g->backgroundColor) });
        rows.push_back({ "BackgroundTransparency", PropertyKind::Number, TextFormat("%.3f", g->backgroundTransparency) });
        rows.push_back({ "BorderColor3", PropertyKind::Color, colorToHex(g->borderColor) });
        rows.push_back({ "BorderSizePixel", PropertyKind::Number, TextFormat("%d", g->borderSizePixel) });
        {
            PropertyRow bm; bm.name = "BorderMode"; bm.kind = PropertyKind::Enum; bm.value = g->borderMode;
            bm.enumOptions = { "Outline", "Inset", "Middle" }; rows.push_back(bm);
        }
        {
            PropertyRow as; as.name = "AutomaticSize"; as.kind = PropertyKind::Enum; as.value = g->automaticSize;
            as.enumOptions = { "None", "X", "Y", "XY" }; rows.push_back(as);
        }
        auto t = instance->getType();
        if (t == InstanceType::TextLabel || t == InstanceType::TextButton || t == InstanceType::TextBox)
        {
            rows.push_back({ "Text", PropertyKind::String, g->text });
            rows.push_back({ "TextSize", PropertyKind::Number, TextFormat("%d", g->textSize) });
            rows.push_back({ "TextColor3", PropertyKind::Color, colorToHex(g->textColor) });
            rows.push_back({ "TextTransparency", PropertyKind::Number, TextFormat("%.3f", g->textTransparency) });
            rows.push_back({ "TextStrokeColor3", PropertyKind::Color, colorToHex(g->textStrokeColor) });
            rows.push_back({ "TextStrokeTransparency", PropertyKind::Number, TextFormat("%.3f", g->textStrokeTransparency) });
            {
                PropertyRow fontRow; fontRow.name = "Font"; fontRow.kind = PropertyKind::Enum; fontRow.value = g->font;
                fontRow.enumOptions = getAvailableFontNames();
                rows.push_back(fontRow);
            }
            rows.push_back({ "RichText", PropertyKind::Boolean, g->richText ? "true" : "false" });
            rows.push_back({ "TextScaled", PropertyKind::Boolean, g->textScaled ? "true" : "false" });
            rows.push_back({ "TextWrapped", PropertyKind::Boolean, g->textWrapped ? "true" : "false" });
            rows.push_back({ "LineHeight", PropertyKind::Number, TextFormat("%.3f", g->lineHeight) });
            rows.push_back({ "MaxVisibleGraphemes", PropertyKind::Number, TextFormat("%d", g->maxVisibleGraphemes) });
            {
                PropertyRow xa; xa.name = "TextXAlignment"; xa.kind = PropertyKind::Enum; xa.value = g->textXAlignment;
                xa.enumOptions = { "Left", "Center", "Right" }; rows.push_back(xa);
            }
            {
                PropertyRow ya; ya.name = "TextYAlignment"; ya.kind = PropertyKind::Enum; ya.value = g->textYAlignment;
                ya.enumOptions = { "Top", "Center", "Bottom" }; rows.push_back(ya);
            }
            {
                PropertyRow tt; tt.name = "TextTruncate"; tt.kind = PropertyKind::Enum; tt.value = g->textTruncate;
                tt.enumOptions = { "None", "AtEnd" }; rows.push_back(tt);
            }
        }
        if (t == InstanceType::TextBox)
        {
            rows.push_back({ "PlaceholderText", PropertyKind::String, g->placeholderText });
            rows.push_back({ "PlaceholderColor3", PropertyKind::Color, colorToHex(g->placeholderColor) });
            rows.push_back({ "ClearTextOnFocus", PropertyKind::Boolean, g->clearTextOnFocus ? "true" : "false" });
            rows.push_back({ "MultiLine", PropertyKind::Boolean, g->multiLine ? "true" : "false" });
            rows.push_back({ "TextEditable", PropertyKind::Boolean, g->textEditable ? "true" : "false" });
        }
        if (t == InstanceType::ImageLabel || t == InstanceType::ImageButton)
        {
            rows.push_back({ "Image", PropertyKind::String, g->image });
            rows.push_back({ "ImageColor3", PropertyKind::Color, colorToHex(g->imageColor) });
            rows.push_back({ "ImageTransparency", PropertyKind::Number, TextFormat("%.3f", g->imageTransparency) });
            {
                PropertyRow st; st.name = "ScaleType"; st.kind = PropertyKind::Enum; st.value = g->scaleType;
                st.enumOptions = { "Stretch", "Slice", "Tile", "Fit", "Crop" }; rows.push_back(st);
            }
            rows.push_back({ "ImageRectOffset X", PropertyKind::Number, TextFormat("%.3f", g->imageRectOffset.x) });
            rows.push_back({ "ImageRectOffset Y", PropertyKind::Number, TextFormat("%.3f", g->imageRectOffset.y) });
            rows.push_back({ "ImageRectSize X", PropertyKind::Number, TextFormat("%.3f", g->imageRectSize.x) });
            rows.push_back({ "ImageRectSize Y", PropertyKind::Number, TextFormat("%.3f", g->imageRectSize.y) });
            rows.push_back({ "SliceScale", PropertyKind::Number, TextFormat("%.3f", g->sliceScale) });
        }
        if (t == InstanceType::ImageButton)
        {
            rows.push_back({ "HoverImage", PropertyKind::String, g->hoverImage });
            rows.push_back({ "PressedImage", PropertyKind::String, g->pressedImage });
        }
        if (t == InstanceType::TextButton || t == InstanceType::ImageButton)
        {
            rows.push_back({ "AutoButtonColor", PropertyKind::Boolean, g->autoButtonColor ? "true" : "false" });
            rows.push_back({ "Modal", PropertyKind::Boolean, g->modal ? "true" : "false" });
            rows.push_back({ "Selectable", PropertyKind::Boolean, g->selectable ? "true" : "false" });
            rows.push_back({ "SelectionOrder", PropertyKind::Number, TextFormat("%d", g->selectionOrder) });
        }
        if (t == InstanceType::ScrollingFrame)
        {
            rows.push_back({ "ScrollingEnabled", PropertyKind::Boolean, g->scrollingEnabled ? "true" : "false" });
            rows.push_back({ "CanvasSize X Scale", PropertyKind::Number, TextFormat("%.3f", g->scrollCanvasSize.x.scale) });
            rows.push_back({ "CanvasSize X Offset", PropertyKind::Number, TextFormat("%.3f", g->scrollCanvasSize.x.offset) });
            rows.push_back({ "CanvasSize Y Scale", PropertyKind::Number, TextFormat("%.3f", g->scrollCanvasSize.y.scale) });
            rows.push_back({ "CanvasSize Y Offset", PropertyKind::Number, TextFormat("%.3f", g->scrollCanvasSize.y.offset) });
            rows.push_back({ "CanvasPosition X", PropertyKind::Number, TextFormat("%.3f", g->canvasPosition.x) });
            rows.push_back({ "CanvasPosition Y", PropertyKind::Number, TextFormat("%.3f", g->canvasPosition.y) });
            rows.push_back({ "ScrollBarThickness", PropertyKind::Number, TextFormat("%.3f", g->scrollBarThickness) });
            rows.push_back({ "ScrollBarImageColor3", PropertyKind::Color, colorToHex(g->scrollBarImageColor) });
            rows.push_back({ "ScrollBarImageTransparency", PropertyKind::Number, TextFormat("%.3f", g->scrollBarImageTransparency) });
            {
                PropertyRow ac; ac.name = "AutomaticCanvasSize"; ac.kind = PropertyKind::Enum; ac.value = g->automaticCanvasSize;
                ac.enumOptions = { "None", "X", "Y", "XY" }; rows.push_back(ac);
            }
            {
                PropertyRow sd; sd.name = "ScrollingDirection"; sd.kind = PropertyKind::Enum; sd.value = g->scrollingDirection;
                sd.enumOptions = { "X", "Y", "XY" }; rows.push_back(sd);
            }
            {
                PropertyRow eb; eb.name = "ElasticBehavior"; eb.kind = PropertyKind::Enum; eb.value = g->elasticBehavior;
                eb.enumOptions = { "WhenNeeded", "Always", "Never" }; rows.push_back(eb);
            }
            {
                PropertyRow hi; hi.name = "HorizontalScrollBarInset"; hi.kind = PropertyKind::Enum; hi.value = g->horizontalScrollBarInset;
                hi.enumOptions = { "None", "ScrollBar", "Always" }; rows.push_back(hi);
            }
            {
                PropertyRow vi; vi.name = "VerticalScrollBarInset"; vi.kind = PropertyKind::Enum; vi.value = g->verticalScrollBarInset;
                vi.enumOptions = { "None", "ScrollBar", "Always" }; rows.push_back(vi);
            }
        }
        rows.push_back({ "GroupTransparency", PropertyKind::Number, TextFormat("%.3f", g->groupTransparency) });
        {
            PropertyRow sc; sc.name = "SizeConstraint"; sc.kind = PropertyKind::Enum; sc.value = g->sizeConstraint;
            sc.enumOptions = { "RelativeXY", "RelativeXX", "RelativeYY" }; rows.push_back(sc);
        }
    }
    else if (instance->getType() == InstanceType::UICorner ||
             instance->getType() == InstanceType::UIStroke ||
             instance->getType() == InstanceType::UIListLayout ||
             instance->getType() == InstanceType::UIPadding ||
             instance->getType() == InstanceType::UIGridLayout ||
             instance->getType() == InstanceType::UIAspectRatioConstraint)
    {
        auto* m = static_cast<UIModifierInstance*>(instance);
        auto t = instance->getType();
        if (t == InstanceType::UICorner)
        {
            rows.push_back({ "CornerRadius Scale", PropertyKind::Number, TextFormat("%.3f", m->cornerRadius.scale) });
            rows.push_back({ "CornerRadius Offset", PropertyKind::Number, TextFormat("%.3f", m->cornerRadius.offset) });
        }
        if (t == InstanceType::UIStroke)
        {
            rows.push_back({ "Enabled", PropertyKind::Boolean, m->strokeEnabled ? "true" : "false" });
            rows.push_back({ "Thickness", PropertyKind::Number, TextFormat("%.3f", m->strokeThickness) });
            rows.push_back({ "Color", PropertyKind::Color, colorToHex(m->strokeColor) });
            rows.push_back({ "Transparency", PropertyKind::Number, TextFormat("%.3f", m->strokeTransparency) });
            {
                PropertyRow am; am.name = "ApplyStrokeMode"; am.kind = PropertyKind::Enum; am.value = m->strokeApplyStrokeMode;
                am.enumOptions = { "Contextual", "Border" }; rows.push_back(am);
            }
            {
                PropertyRow lj; lj.name = "LineJoinMode"; lj.kind = PropertyKind::Enum; lj.value = m->lineJoinMode;
                lj.enumOptions = { "Round", "Bevel", "Miter" }; rows.push_back(lj);
            }
        }
        if (t == InstanceType::UIListLayout)
        {
            {
                PropertyRow fd; fd.name = "FillDirection"; fd.kind = PropertyKind::Enum; fd.value = m->fillDirection;
                fd.enumOptions = { "Vertical", "Horizontal" }; rows.push_back(fd);
            }
            {
                PropertyRow ha; ha.name = "HorizontalAlignment"; ha.kind = PropertyKind::Enum; ha.value = m->horizontalAlignment;
                ha.enumOptions = { "Left", "Center", "Right" }; rows.push_back(ha);
            }
            {
                PropertyRow va; va.name = "VerticalAlignment"; va.kind = PropertyKind::Enum; va.value = m->verticalAlignment;
                va.enumOptions = { "Top", "Center", "Bottom" }; rows.push_back(va);
            }
            {
                PropertyRow so; so.name = "SortOrder"; so.kind = PropertyKind::Enum; so.value = m->sortOrder;
                so.enumOptions = { "LayoutOrder", "Name" }; rows.push_back(so);
            }
            rows.push_back({ "Padding Offset", PropertyKind::Number, TextFormat("%.3f", m->listPadding.offset) });
            rows.push_back({ "Wraps", PropertyKind::Boolean, m->wraps ? "true" : "false" });
        }
        if (t == InstanceType::UIPadding)
        {
            rows.push_back({ "PaddingLeft Offset", PropertyKind::Number, TextFormat("%.3f", m->paddingLeft.offset) });
            rows.push_back({ "PaddingRight Offset", PropertyKind::Number, TextFormat("%.3f", m->paddingRight.offset) });
            rows.push_back({ "PaddingTop Offset", PropertyKind::Number, TextFormat("%.3f", m->paddingTop.offset) });
            rows.push_back({ "PaddingBottom Offset", PropertyKind::Number, TextFormat("%.3f", m->paddingBottom.offset) });
        }
        if (t == InstanceType::UIGridLayout)
        {
            rows.push_back({ "CellSize X Offset", PropertyKind::Number, TextFormat("%.3f", m->cellSize.x.offset) });
            rows.push_back({ "CellSize Y Offset", PropertyKind::Number, TextFormat("%.3f", m->cellSize.y.offset) });
            rows.push_back({ "CellPadding X Offset", PropertyKind::Number, TextFormat("%.3f", m->cellPadding.x.offset) });
            rows.push_back({ "CellPadding Y Offset", PropertyKind::Number, TextFormat("%.3f", m->cellPadding.y.offset) });
            rows.push_back({ "FillDirectionMaxCells", PropertyKind::Number, TextFormat("%d", m->fillDirectionMaxCells) });
        }
        if (t == InstanceType::UIAspectRatioConstraint)
        {
            rows.push_back({ "AspectRatio", PropertyKind::Number, TextFormat("%.3f", m->aspectRatio) });
            {
                PropertyRow at; at.name = "AspectType"; at.kind = PropertyKind::Enum; at.value = m->aspectType;
                at.enumOptions = { "FitWithinMaxSize", "ScaleWithParentSize" }; rows.push_back(at);
            }
            {
                PropertyRow da; da.name = "DominantAxis"; da.kind = PropertyKind::Enum; da.value = m->dominantAxis;
                da.enumOptions = { "Width", "Height" }; rows.push_back(da);
            }
        }
    }

    for (PropertyRow& row : rows)
    {
        if (row.kind != PropertyKind::Number &&
            row.kind != PropertyKind::PackedField &&
            row.kind != PropertyKind::ReadOnly)
            continue;
        char* end = nullptr;
        float value = strtof(row.value.c_str(), &end);
        if (end != row.value.c_str() && *end == '\0' && isfinite(value))
            row.value = cleanNumber(value);
    }
    return rows;
}

string colorToHex(Color color)
{
    return TextFormat("#%02X%02X%02X", color.r, color.g, color.b);
}

Color hexToColor(const string& value, Color fallback)
{
    if (value.size() != 7 || value[0] != '#')
        return fallback;
    char* end = nullptr;
    long number = strtol(value.c_str() + 1, &end, 16);
    if (end == value.c_str() + 7)
        return { static_cast<unsigned char>((number >> 16) & 255), static_cast<unsigned char>((number >> 8) & 255),
            static_cast<unsigned char>(number & 255), 255 };
    return fallback;
}

bool assignPointerProperty(Instance* target)
{
    if (pointerPickOwner == nullptr || target == nullptr || pointerPickProperty.empty())
        return false;

    if (pointerPickProperty == "Parent")
    {
        if (!reparentInstance(pointerPickOwner, target))
            return false;
    }
    else if (pointerPickProperty == "PrimaryPart")
    {
        if (pointerPickOwner->getType() != InstanceType::Model ||
            target->getType() != InstanceType::Part ||
            !isInstanceInBranch(pointerPickOwner, target))
            return false;
        static_cast<Model_Instance*>(pointerPickOwner)->primaryPart = static_cast<Part*>(target);
    }
    else if (pointerPickProperty == "Part0" || pointerPickProperty == "Part1")
    {
        if (target->getType() != InstanceType::Part)
            return false;
        Part* selectedPart = static_cast<Part*>(target);
        if (pointerPickOwner->getType() == InstanceType::WeldConstraint)
        {
            WeldConstraint* weld = static_cast<WeldConstraint*>(pointerPickOwner);
            if (pointerPickProperty == "Part0") weld->part0 = selectedPart;
            else weld->part1 = selectedPart;
            weld->relativeCaptured = false;
            if (weld->part0 && weld->part1) captureWeldRelative(weld);
        }
        else if (pointerPickOwner->getType() == InstanceType::Motor6D)
        {
            Motor6DConstraint* motor = static_cast<Motor6DConstraint*>(pointerPickOwner);
            if (pointerPickProperty == "Part0") motor->part0 = selectedPart;
            else
            {
                motor->part1 = selectedPart;
                // Store Motor6D under Part1 children.
                if (motor->part1 != nullptr && motor->parent != motor->part1)
                {
                    removeInstanceFromParent(motor);
                    addInstanceToParent(motor->part1, motor);
                }
            }
        }
        else return false;
    }
    else if (pointerPickProperty == "RootPart" && pointerPickOwner->getType() == InstanceType::Humanoid)
    {
        if (target->getType() != InstanceType::Part) return false;
        static_cast<HumanoidInstance*>(pointerPickOwner)->rootPart = static_cast<Part*>(target);
    }
    else if (pointerPickProperty == "Target" && pointerPickOwner->getType() == InstanceType::Camera)
    {
        if (target->getType() != InstanceType::Humanoid) return false;
        static_cast<CameraInstance*>(pointerPickOwner)->target = target;
    }
    else if (pointerPickProperty == "Adornee" &&
             (pointerPickOwner->getType() == InstanceType::ScreenGui ||
              pointerPickOwner->getType() == InstanceType::SurfaceGui ||
              pointerPickOwner->getType() == InstanceType::BillboardGui))
    {
        static_cast<LayerCollectorInstance*>(pointerPickOwner)->adornee = target;
    }
    else return false;

    pointerPickOwner = nullptr;
    pointerPickProperty.clear();
    activePropertyRow = -1;
    projectDirty = true;
    return true;
}

Instance* getPointerPropertyTarget(Instance* owner, const string& property)
{
    if (owner == nullptr)
        return nullptr;
    if (property == "Parent")
        return owner->parent;
    if (property == "PrimaryPart" && owner->getType() == InstanceType::Model)
        return static_cast<Model_Instance*>(owner)->primaryPart;
    if ((property == "Part0" || property == "Part1") &&
        owner->getType() == InstanceType::WeldConstraint)
    {
        auto* weld = static_cast<WeldConstraint*>(owner);
        return property == "Part0" ? weld->part0 : weld->part1;
    }
    if ((property == "Part0" || property == "Part1") &&
        owner->getType() == InstanceType::Motor6D)
    {
        auto* motor = static_cast<Motor6DConstraint*>(owner);
        return property == "Part0" ? motor->part0 : motor->part1;
    }
    if (property == "RootPart" && owner->getType() == InstanceType::Humanoid)
        return static_cast<HumanoidInstance*>(owner)->rootPart;
    if (property == "Target" && owner->getType() == InstanceType::Camera)
        return static_cast<CameraInstance*>(owner)->target;
    if (property == "Adornee" &&
        (owner->getType() == InstanceType::ScreenGui ||
         owner->getType() == InstanceType::SurfaceGui ||
         owner->getType() == InstanceType::BillboardGui))
        return static_cast<LayerCollectorInstance*>(owner)->adornee;
    return nullptr;
}

bool clearPointerProperty(Instance* owner, const string& property)
{
    if (property == "Parent")
        return false;
    if (getPointerPropertyTarget(owner, property) == nullptr)
        return false;
    if (property == "PrimaryPart")
        static_cast<Model_Instance*>(owner)->primaryPart = nullptr;
    else if (property == "Part0" || property == "Part1")
    {
        if (owner->getType() == InstanceType::WeldConstraint)
        {
            auto* weld = static_cast<WeldConstraint*>(owner);
            if (property == "Part0") weld->part0 = nullptr;
            else weld->part1 = nullptr;
            weld->relativeCaptured = false;
        }
        else
        {
            auto* motor = static_cast<Motor6DConstraint*>(owner);
            if (property == "Part0") motor->part0 = nullptr;
            else motor->part1 = nullptr;
        }
    }
    else if (property == "RootPart")
        static_cast<HumanoidInstance*>(owner)->rootPart = nullptr;
    else if (property == "Target")
        static_cast<CameraInstance*>(owner)->target = nullptr;
    else if (property == "Adornee")
        static_cast<LayerCollectorInstance*>(owner)->adornee = nullptr;
    return true;
}

bool canPickPointerProperty(const Instance* owner, const string& property)
{
    if (owner == nullptr)
        return false;
    return (property == "Parent" && owner->getType() != InstanceType::Service) ||
        (property == "PrimaryPart" && owner->getType() == InstanceType::Model) ||
        ((property == "Part0" || property == "Part1") &&
            (owner->getType() == InstanceType::WeldConstraint || owner->getType() == InstanceType::Motor6D)) ||
        (property == "RootPart" && owner->getType() == InstanceType::Humanoid) ||
        (property == "Target" && owner->getType() == InstanceType::Camera) ||
        (property == "Adornee" &&
            (owner->getType() == InstanceType::ScreenGui ||
             owner->getType() == InstanceType::SurfaceGui ||
             owner->getType() == InstanceType::BillboardGui));
}


// Multi-select property merge: intersection of property names/kinds.
// Same value across selection → show it; mixed → empty string.
vector<PropertyRow> getMergedPropertyRows(const vector<Instance*>& instances)
{
    vector<PropertyRow> merged;
    if (instances.empty()) return merged;
    vector<Instance*> live;
    for (Instance* inst : instances)
        if (inst) live.push_back(inst);
    if (live.empty()) return merged;
    if (live.size() == 1)
        return getPropertyRows(live.front());

    vector<vector<PropertyRow>> all;
    for (Instance* inst : live)
        all.push_back(getPropertyRows(inst));

    for (const PropertyRow& base : all.front())
    {
        if (base.kind == PropertyKind::SoundPreview)
            continue;
        bool onAll = true;
        bool sameValue = true;
        string sharedValue = base.value;
        string sharedCompact = base.packCompact;
        for (size_t i = 1; i < all.size(); ++i)
        {
            const PropertyRow* match = nullptr;
            for (const PropertyRow& r : all[i])
            {
                if (r.name == base.name && r.kind == base.kind)
                {
                    match = &r;
                    break;
                }
            }
            if (!match) { onAll = false; break; }
            if (match->value != sharedValue) sameValue = false;
            if (match->packCompact != sharedCompact) sharedCompact.clear();
        }
        if (!onAll) continue;
        PropertyRow row = base;
        if (!sameValue) row.value = "";
        if (sharedCompact.empty() && base.kind == PropertyKind::Packed)
            row.packCompact = "";
        merged.push_back(row);
    }
    return merged;
}

void applyPropertyText(Instance* instance, int rowIndex, const string& text)
{
    if (instance == nullptr || rowIndex < 0)
        return;

    vector<PropertyRow> rows = getPropertyRows(instance);
    if (rowIndex >= static_cast<int>(rows.size()))
        return;

    const string& property = rows[rowIndex].name;
    if (rows[rowIndex].kind == PropertyKind::Number ||
        rows[rowIndex].kind == PropertyKind::PackedField)
    {
        char* end = nullptr;
        float value = strtof(text.c_str(), &end);
        if (end == text.c_str() || *end != '\0' || !isfinite(value))
            return;
        static const vector<string> integerProperties = {
            "DisplayOrder", "ZIndex", "LayoutOrder", "SelectionOrder",
            "BorderSizePixel", "TextSize", "MaxVisibleGraphemes",
            "FillDirectionMaxCells"
        };
        if (find(integerProperties.begin(), integerProperties.end(), property) != integerProperties.end() &&
            (floor(value) != value ||
             static_cast<double>(value) < numeric_limits<int>::min() ||
             static_cast<double>(value) > numeric_limits<int>::max()))
            return;
    }

    if (property == "Name")
    {
        instance->name = text;
        return;
    }

    if (instance->getType() == InstanceType::Script)
    {
        Script* s = static_cast<Script*>(instance);
        if (property == "Enabled")
        {
            s->enabled = (text == "true" || text == "True" || text == "1");
            return;
        }
        if (property == "RunContext")
        {
            s->setRunContext(text);
            return;
        }
    }

    if (instance->getType() == InstanceType::PointLight)
    {
        auto* light = static_cast<PointLightInstance*>(instance);
        if (property == "Enabled") light->enabled = text == "true" || text == "True" || text == "1";
        else if (property == "Shadows") light->shadows = text == "true" || text == "True" || text == "1";
        else if (property == "Color") light->color = hexToColor(text, light->color);
        else if (property == "Brightness" || property == "Range")
        {
            float value = strtof(text.c_str(), nullptr);
            if (property == "Brightness") light->brightness = std::clamp(value, 0.0f, 200.0f);
            else light->range = std::clamp(value, 0.0f, 200.0f);
        }
        return;
    }
    if (instance->getType() == InstanceType::SpotLight)
    {
        auto* light = static_cast<SpotLightInstance*>(instance);
        if (property == "Enabled") light->enabled = text == "true" || text == "True" || text == "1";
        else if (property == "Shadows") light->shadows = text == "true" || text == "True" || text == "1";
        else if (property == "Color") light->color = hexToColor(text, light->color);
        else if (property == "Face") light->face = text;
        else if (property == "Brightness" || property == "Range" || property == "Angle")
        {
            float value = strtof(text.c_str(), nullptr);
            if (property == "Brightness") light->brightness = std::clamp(value, 0.0f, 200.0f);
            else if (property == "Range") light->range = std::clamp(value, 0.0f, 200.0f);
            else light->angle = std::clamp(value, 0.0f, 180.0f);
        }
        return;
    }
    if (instance->getType() == InstanceType::SurfaceLight)
    {
        auto* light = static_cast<SurfaceLightInstance*>(instance);
        if (property == "Enabled") light->enabled = text == "true" || text == "True" || text == "1";
        else if (property == "Shadows") light->shadows = text == "true" || text == "True" || text == "1";
        else if (property == "Color") light->color = hexToColor(text, light->color);
        else if (property == "Face") light->face = text;
        else if (property == "Brightness" || property == "Range" || property == "Angle")
        {
            float value = strtof(text.c_str(), nullptr);
            if (property == "Brightness") light->brightness = std::clamp(value, 0.0f, 200.0f);
            else if (property == "Range") light->range = std::clamp(value, 0.0f, 200.0f);
            else light->angle = std::clamp(value, 0.0f, 180.0f);
        }
        return;
    }

    if (instance->getType() == InstanceType::ScreenGui ||
        instance->getType() == InstanceType::SurfaceGui ||
        instance->getType() == InstanceType::BillboardGui)
    {
        auto* lc = static_cast<LayerCollectorInstance*>(instance);
        auto isTrue = [&](const string& t) { return t == "true" || t == "True" || t == "1"; };
        if (property == "Enabled") { lc->enabled = isTrue(text); return; }
        if (property == "Active") { lc->active = isTrue(text); return; }
        if (property == "ResetOnSpawn") { lc->resetOnSpawn = isTrue(text); return; }
        if (property == "IgnoreGuiInset") { lc->ignoreGuiInset = isTrue(text); return; }
        if (property == "ClipToDeviceSafeArea") { lc->clipToDeviceSafeArea = isTrue(text); return; }
        if (property == "AlwaysOnTop") { lc->alwaysOnTop = isTrue(text); return; }
        if (property == "ClipsDescendants") { lc->clipsDescendants = isTrue(text); return; }
        if (property == "Face") { lc->face = text; return; }
        if (property == "SizingMode") { lc->sizingMode = text; return; }
        char* end = nullptr;
        float v = strtof(text.c_str(), &end);
        if (end != text.c_str())
        {
            if (property == "DisplayOrder") { lc->displayOrder = (int)v; return; }
            if (property == "MaxDistance") { lc->maxDistance = v; return; }
            if (property == "PixelsPerStud") { lc->pixelsPerStud = v; return; }
            if (property == "Brightness") { lc->brightness = v; return; }
            if (property == "LightInfluence") { lc->lightInfluence = std::clamp(v, 0.0f, 1.0f); return; }
            if (property == "CanvasSize X") { lc->canvasSize.x = v; return; }
            if (property == "CanvasSize Y") { lc->canvasSize.y = v; return; }
            if (property == "ZOffset") { lc->zOffset = v; return; }
            if (property == "StudsOffset X") { lc->studsOffset.x = v; return; }
            if (property == "StudsOffset Y") { lc->studsOffset.y = v; return; }
            if (property == "StudsOffset Z") { lc->studsOffset.z = v; return; }
            if (property == "DistanceLowerLimit") { lc->distanceLowerLimit = v; return; }
            if (property == "DistanceUpperLimit") { lc->distanceUpperLimit = v; return; }
            if (property == "Billboard Size X Scale") { lc->billboardSize.x.scale = v; return; }
            if (property == "Billboard Size X Offset") { lc->billboardSize.x.offset = v; return; }
            if (property == "Billboard Size Y Scale") { lc->billboardSize.y.scale = v; return; }
            if (property == "Billboard Size Y Offset") { lc->billboardSize.y.offset = v; return; }
        }
        return;
    }

    if (instance->getType() == InstanceType::Frame ||
        instance->getType() == InstanceType::ScrollingFrame ||
        instance->getType() == InstanceType::TextLabel ||
        instance->getType() == InstanceType::ImageLabel ||
        instance->getType() == InstanceType::TextButton ||
        instance->getType() == InstanceType::ImageButton ||
        instance->getType() == InstanceType::TextBox)
    {
        auto* g = static_cast<GuiObjectInstance*>(instance);
        auto isTrue = [&](const string& t) { return t == "true" || t == "True" || t == "1"; };
        if (property == "Visible") { g->visible = isTrue(text); return; }
        if (property == "Active") { g->active = isTrue(text); return; }
        if (property == "Interactable") { g->interactable = isTrue(text); return; }
        if (property == "ClipsDescendants") { g->clipsDescendants = isTrue(text); return; }
        if (property == "RichText") { g->richText = isTrue(text); return; }
        if (property == "TextScaled") { g->textScaled = isTrue(text); return; }
        if (property == "TextWrapped") { g->textWrapped = isTrue(text); return; }
        if (property == "ClearTextOnFocus") { g->clearTextOnFocus = isTrue(text); return; }
        if (property == "MultiLine") { g->multiLine = isTrue(text); return; }
        if (property == "TextEditable") { g->textEditable = isTrue(text); return; }
        if (property == "AutoButtonColor") { g->autoButtonColor = isTrue(text); return; }
        if (property == "Modal") { g->modal = isTrue(text); return; }
        if (property == "ScrollingEnabled") { g->scrollingEnabled = isTrue(text); return; }
        if (property == "Selectable") { g->selectable = isTrue(text); return; }
        if (property == "Text") { g->text = text; return; }
        if (property == "PlaceholderText") { g->placeholderText = text; return; }
        if (property == "Font") { g->font = text; return; }
        if (property == "Image") { g->image = text; return; }
        if (property == "HoverImage") { g->hoverImage = text; return; }
        if (property == "PressedImage") { g->pressedImage = text; return; }
        if (property == "TextXAlignment") { g->textXAlignment = text; return; }
        if (property == "TextYAlignment") { g->textYAlignment = text; return; }
        if (property == "TextTruncate") { g->textTruncate = text; return; }
        if (property == "BorderMode") { g->borderMode = text; return; }
        if (property == "AutomaticSize") { g->automaticSize = text; return; }
        if (property == "SizeConstraint") { g->sizeConstraint = text; return; }
        if (property == "ScaleType") { g->scaleType = text; return; }
        if (property == "ScrollingDirection") { g->scrollingDirection = text; return; }
        if (property == "ElasticBehavior") { g->elasticBehavior = text; return; }
        if (property == "AutomaticCanvasSize") { g->automaticCanvasSize = text; return; }
        if (property == "HorizontalScrollBarInset") { g->horizontalScrollBarInset = text; return; }
        if (property == "VerticalScrollBarInset") { g->verticalScrollBarInset = text; return; }
        if (property == "BackgroundColor3") { g->backgroundColor = hexToColor(text, g->backgroundColor); return; }
        if (property == "BorderColor3") { g->borderColor = hexToColor(text, g->borderColor); return; }
        if (property == "TextColor3") { g->textColor = hexToColor(text, g->textColor); return; }
        if (property == "TextStrokeColor3") { g->textStrokeColor = hexToColor(text, g->textStrokeColor); return; }
        if (property == "PlaceholderColor3") { g->placeholderColor = hexToColor(text, g->placeholderColor); return; }
        if (property == "ImageColor3") { g->imageColor = hexToColor(text, g->imageColor); return; }
        if (property == "ScrollBarImageColor3") { g->scrollBarImageColor = hexToColor(text, g->scrollBarImageColor); return; }
        char* end = nullptr;
        float v = strtof(text.c_str(), &end);
        if (end != text.c_str())
        {
            if (property == "Size X Scale") { g->size.x.scale = v; return; }
            if (property == "Size X Offset") { g->size.x.offset = v; return; }
            if (property == "Size Y Scale") { g->size.y.scale = v; return; }
            if (property == "Size Y Offset") { g->size.y.offset = v; return; }
            if (property == "Position X Scale") { g->position.x.scale = v; return; }
            if (property == "Position X Offset") { g->position.x.offset = v; return; }
            if (property == "Position Y Scale") { g->position.y.scale = v; return; }
            if (property == "Position Y Offset") { g->position.y.offset = v; return; }
            if (property == "AnchorPoint X") { g->anchorPoint.x = v; return; }
            if (property == "AnchorPoint Y") { g->anchorPoint.y = v; return; }
            if (property == "ZIndex") { g->zIndex = (int)v; return; }
            if (property == "LayoutOrder") { g->layoutOrder = (int)v; return; }
            if (property == "SelectionOrder") { g->selectionOrder = (int)v; return; }
            if (property == "Rotation") { g->rotation = v; return; }
            if (property == "BackgroundTransparency") { g->backgroundTransparency = std::clamp(v, 0.0f, 1.0f); return; }
            if (property == "GroupTransparency") { g->groupTransparency = std::clamp(v, 0.0f, 1.0f); return; }
            if (property == "BorderSizePixel") { g->borderSizePixel = (int)v; return; }
            if (property == "TextSize") { g->textSize = max(1, (int)v); return; }
            if (property == "TextTransparency") { g->textTransparency = std::clamp(v, 0.0f, 1.0f); return; }
            if (property == "TextStrokeTransparency") { g->textStrokeTransparency = std::clamp(v, 0.0f, 1.0f); return; }
            if (property == "LineHeight") { g->lineHeight = v; return; }
            if (property == "MaxVisibleGraphemes") { g->maxVisibleGraphemes = (int)v; return; }
            if (property == "ImageTransparency") { g->imageTransparency = std::clamp(v, 0.0f, 1.0f); return; }
            if (property == "SliceScale") { g->sliceScale = v; return; }
            if (property == "ImageRectOffset X") { g->imageRectOffset.x = v; return; }
            if (property == "ImageRectOffset Y") { g->imageRectOffset.y = v; return; }
            if (property == "ImageRectSize X") { g->imageRectSize.x = v; return; }
            if (property == "ImageRectSize Y") { g->imageRectSize.y = v; return; }
            if (property == "CanvasSize X Scale") { g->scrollCanvasSize.x.scale = v; return; }
            if (property == "CanvasSize X Offset") { g->scrollCanvasSize.x.offset = v; return; }
            if (property == "CanvasSize Y Scale") { g->scrollCanvasSize.y.scale = v; return; }
            if (property == "CanvasSize Y Offset") { g->scrollCanvasSize.y.offset = v; return; }
            if (property == "CanvasPosition X") { g->canvasPosition.x = v; return; }
            if (property == "CanvasPosition Y") { g->canvasPosition.y = v; return; }
            if (property == "ScrollBarThickness") { g->scrollBarThickness = v; return; }
            if (property == "ScrollBarImageTransparency") { g->scrollBarImageTransparency = std::clamp(v, 0.0f, 1.0f); return; }
        }
        return;
    }

    if (instance->getType() == InstanceType::UICorner ||
        instance->getType() == InstanceType::UIStroke ||
        instance->getType() == InstanceType::UIListLayout ||
        instance->getType() == InstanceType::UIPadding ||
        instance->getType() == InstanceType::UIGridLayout ||
        instance->getType() == InstanceType::UIAspectRatioConstraint)
    {
        auto* m = static_cast<UIModifierInstance*>(instance);
        auto isTrue = [&](const string& t) { return t == "true" || t == "True" || t == "1"; };
        if (property == "Enabled") { m->strokeEnabled = isTrue(text); return; }
        if (property == "Wraps") { m->wraps = isTrue(text); return; }
        if (property == "ApplyStrokeMode") { m->strokeApplyStrokeMode = text; return; }
        if (property == "LineJoinMode") { m->lineJoinMode = text; return; }
        if (property == "FillDirection") { m->fillDirection = text; return; }
        if (property == "HorizontalAlignment") { m->horizontalAlignment = text; return; }
        if (property == "VerticalAlignment") { m->verticalAlignment = text; return; }
        if (property == "SortOrder") { m->sortOrder = text; return; }
        if (property == "AspectType") { m->aspectType = text; return; }
        if (property == "DominantAxis") { m->dominantAxis = text; return; }
        if (property == "Color") { m->strokeColor = hexToColor(text, m->strokeColor); return; }
        char* end = nullptr;
        float v = strtof(text.c_str(), &end);
        if (end != text.c_str())
        {
            if (property == "CornerRadius Scale") { m->cornerRadius.scale = v; return; }
            if (property == "CornerRadius Offset") { m->cornerRadius.offset = v; return; }
            if (property == "Thickness") { m->strokeThickness = v; return; }
            if (property == "Transparency") { m->strokeTransparency = std::clamp(v, 0.0f, 1.0f); return; }
            if (property == "Padding Offset") { m->listPadding.offset = v; m->paddingPx = (int)v; return; }
            if (property == "PaddingLeft Offset") { m->paddingLeft.offset = v; return; }
            if (property == "PaddingRight Offset") { m->paddingRight.offset = v; return; }
            if (property == "PaddingTop Offset") { m->paddingTop.offset = v; return; }
            if (property == "PaddingBottom Offset") { m->paddingBottom.offset = v; return; }
            if (property == "CellSize X Offset") { m->cellSize.x.offset = v; return; }
            if (property == "CellSize Y Offset") { m->cellSize.y.offset = v; return; }
            if (property == "CellPadding X Offset") { m->cellPadding.x.offset = v; return; }
            if (property == "CellPadding Y Offset") { m->cellPadding.y.offset = v; return; }
            if (property == "FillDirectionMaxCells") { m->fillDirectionMaxCells = (int)v; return; }
            if (property == "AspectRatio") { m->aspectRatio = max(0.01f, v); return; }
        }
        return;
    }

    if (instance->getType() == InstanceType::Part)
    {
        Part* part = static_cast<Part*>(instance);

        if (property == "Color")
        {
            part->color = hexToColor(text, part->color);
            return;
        }
        if (property == "PartType")
        {
            part->type = parsePartType(text);
            return;
        }
        if (property == "MeshId")
        {
            if (part->isMeshPart) part->meshId = normalizeAssetId(text);
            return;
        }
        if (property == "TextureId")
        {
            if (part->isMeshPart) part->textureId = normalizeAssetId(text);
            return;
        }
        if (property == "CollisionFidelity")
        {
            if (part->isMeshPart) part->collisionFidelity = parseCollisionFidelity(text);
            return;
        }
        if (property == "Anchored") { part->anchored = (text == "true" || text == "True"); return; }
        if (property == "CanCollide") { part->canCollide = (text == "true" || text == "True"); return; }
        if (property == "CastShadow") { part->castShadow = (text == "true" || text == "True"); return; }
        if (property == "AdvancedPhysics") { part->advancedPhysics = (text == "true" || text == "True"); return; }
        if (property == "Truss") { part->truss = (text == "true" || text == "True"); return; }
        if (property == "Locked") { part->locked = (text == "true" || text == "True"); return; }
        if (property == "LocalAxes") { part->showLocalAxes = (text == "true" || text == "True"); return; }

        char* end = nullptr;
        float value = strtof(text.c_str(), &end);
        if (end == text.c_str() || *end != '\0')
            return;

        if (property == "Density") part->density = std::clamp(value, 0.01f, 100.0f);
        else if (property == "Friction") part->friction = std::clamp(value, 0.0f, 1.0f);
        else if (property == "Position X") part->cframe.position.x = value;
        else if (property == "Position Y") part->cframe.position.y = value;
        else if (property == "Position Z") part->cframe.position.z = value;
        else if (property == "Orientation X") part->cframe.rotation.x = value;
        else if (property == "Orientation Y") part->cframe.rotation.y = value;
        else if (property == "Orientation Z") part->cframe.rotation.z = value;
        else if (property == "Size X") part->size.x = max(0.1f, value);
        else if (property == "Size Y") part->size.y = max(0.1f, value);
        else if (property == "Size Z") part->size.z = max(0.1f, value);
        else if (property == "Transparency") part->transparency = std::clamp(value, 0.0f, 1.0f);
        else if (property == "Reflectance") part->reflectance = std::clamp(value, 0.0f, 1.0f);
        else if (property == "PivotOffset X") part->pivotOffset.x = value;
        else if (property == "PivotOffset Y") part->pivotOffset.y = value;
        else if (property == "PivotOffset Z") part->pivotOffset.z = value;
        return;
    }

    if (instance->getType() == InstanceType::Model)
    {
        Model_Instance* model = static_cast<Model_Instance*>(instance);
        if (property == "Scale")
        {
            char* end = nullptr;
            float value = strtof(text.c_str(), &end);
            if (end != text.c_str() && *end == '\0' && isfinite(value) && value > 0.0f)
                scaleModelTo(*model, value);
            return;
        }
        if (property == "PrimaryPart")
        {
            model->primaryPart = nullptr;
            if (!text.empty())
            {
                function<void(Instance*)> walk = [&](Instance* inst)
                {
                    if (!inst || model->primaryPart) return;
                    if (inst->getType() == InstanceType::Part && inst->name == text)
                        model->primaryPart = static_cast<Part*>(inst);
                    for (Instance* child : inst->children)
                        walk(child);
                };
                walk(model);
            }
            return;
        }
        char* end = nullptr;
        float value = strtof(text.c_str(), &end);
        if (end == text.c_str() || *end != '\0')
            return;
        if (property == "PivotOffset X") model->pivotOffset.x = value;
        else if (property == "PivotOffset Y") model->pivotOffset.y = value;
        else if (property == "PivotOffset Z") model->pivotOffset.z = value;
        return;
    }

    if (instance->getType() == InstanceType::Sound)
    {
        SoundInstance* s = static_cast<SoundInstance*>(instance);
        if (property == "SoundId") { s->soundId = normalizeAssetId(text); return; }
        if (property == "Looped") { s->looped = (text == "true" || text == "True"); return; }
        if (property == "Playing") { s->playing = (text == "true" || text == "True"); return; }
        char* end = nullptr;
        float value = strtof(text.c_str(), &end);
        if (end == text.c_str() || *end != '\0') return;
        if (property == "Volume") s->volume = std::clamp(value, 0.0f, 10.0f);
        else if (property == "PlaybackSpeed" || property == "PlayingSpeed")
            s->playbackSpeed = max(0.01f, value);
        else if (property == "TimePosition") s->timePosition = max(0.0f, value);
        else if (property == "RollOffMaxDistance") s->rollOffMaxDistance = max(0.0f, value);
        else if (property == "RollOffMinDistance") s->rollOffMinDistance = max(0.0f, value);
        return;
    }

    if (instance->getType() == InstanceType::Humanoid)
    {
        HumanoidInstance* humanoid = static_cast<HumanoidInstance*>(instance);
        if (property == "RootPart")
        {
            humanoid->rootPart = nullptr;
            function<void(Instance*)> walk = [&](Instance* current)
            {
                if (!current || humanoid->rootPart) return;
                if (current->getType() == InstanceType::Part && current->name == text)
                    humanoid->rootPart = static_cast<Part*>(current);
                for (Instance* child : current->children) walk(child);
            };
            walk(instance->parent);
            return;
        }
        char* end = nullptr;
        float value = strtof(text.c_str(), &end);
        if (end == text.c_str() || *end != '\0') return;
        if (property == "Health") humanoid->health = std::clamp(value, 0.0f, humanoid->maxHealth);
        else if (property == "MaxHealth") humanoid->maxHealth = max(1.0f, value);
        else if (property == "WalkSpeed") humanoid->walkSpeed = max(0.0f, value);
        else if (property == "JumpPower") humanoid->jumpPower = max(0.0f, value);
        else if (property == "HipHeight") humanoid->hipHeight = max(0.0f, value);
        else if (property == "SlopeAngle") humanoid->slopeAngle = std::clamp(value, 0.0f, 89.0f);
        return;
    }

    if (instance->getType() == InstanceType::Camera)
    {
        CameraInstance* cameraInstance = static_cast<CameraInstance*>(instance);
        if (property == "Mode")
        {
            cameraInstance->mode = text == "Scriptable" ? BT_CameraMode::Scriptable : BT_CameraMode::Default;
            return;
        }
        char* end = nullptr;
        float value = strtof(text.c_str(), &end);
        if (end == text.c_str() || *end != '\0') return;
        if (property == "CFrame X") cameraInstance->cframe.position.x = value;
        else if (property == "CFrame Y") cameraInstance->cframe.position.y = value;
        else if (property == "CFrame Z") cameraInstance->cframe.position.z = value;
        return;
    }

    if (instance->getType() == InstanceType::Texture)
    {
        TextureInstance* t = static_cast<TextureInstance*>(instance);
        if (property == "Texture") { t->texture = normalizeAssetId(text); return; }
        if (property == "Face") { t->face = text; return; }
        if (property == "Color3") { t->color3 = hexToColor(text, t->color3); return; }
        char* end = nullptr;
        float value = strtof(text.c_str(), &end);
        if (end == text.c_str() || *end != '\0') return;
        if (property == "StudsPerTileU") t->studsPerTileU = max(0.01f, value);
        else if (property == "StudsPerTileV") t->studsPerTileV = max(0.01f, value);
        else if (property == "OffsetStudsU") t->offsetStudsU = value;
        else if (property == "OffsetStudsV") t->offsetStudsV = value;
        else if (property == "Transparency") t->transparency = std::clamp(value, 0.0f, 1.0f);
        return;
    }

    if (instance->getType() == InstanceType::Blur)
    {
        char* end = nullptr;
        float value = strtof(text.c_str(), &end);
        if (end != text.c_str() && *end == '\0' && rows[rowIndex].name == "Size")
        {
            static_cast<BlurInstance*>(instance)->size = max(0.0f, value);
            lightingSettings.blur = static_cast<BlurInstance*>(instance)->size;
        }
        return;
    }

    if (instance->getType() == InstanceType::ColorCorrection)
    {
        auto* effect = static_cast<ColorCorrectionInstance*>(instance);
        if (rows[rowIndex].name == "TintColor") { effect->tintColor = hexToColor(text, effect->tintColor); return; }
        char* end = nullptr;
        float value = strtof(text.c_str(), &end);
        if (end == text.c_str() || *end != '\0') return;
        if (rows[rowIndex].name == "Brightness") effect->brightness = value;
        else if (rows[rowIndex].name == "Contrast") effect->contrast = value;
        else if (rows[rowIndex].name == "Saturation") effect->saturation = value;
        return;
    }

    if (instance->getType() == InstanceType::SunLight)
    {
        auto* effect = static_cast<SunLightInstance*>(instance);
        if (rows[rowIndex].name == "Color") { effect->color = hexToColor(text, effect->color); return; }
        char* end = nullptr;
        float value = strtof(text.c_str(), &end);
        if (end == text.c_str() || *end != '\0') return;
        if (rows[rowIndex].name == "Direction X") effect->direction.x = value;
        else if (rows[rowIndex].name == "Direction Y") effect->direction.y = value;
        else if (rows[rowIndex].name == "Direction Z") effect->direction.z = value;
        else if (rows[rowIndex].name == "Intensity") effect->intensity = max(0.0f, value);
        sun.direction = Vector3Normalize(effect->direction);
        sun.intensity = effect->intensity;
        return;
    }

    if (instance->getType() == InstanceType::Bloom)
    {
        auto* effect = static_cast<BloomInstance*>(instance);
        char* end = nullptr;
        float value = strtof(text.c_str(), &end);
        if (end == text.c_str() || *end != '\0') return;
        if (rows[rowIndex].name == "Intensity") effect->intensity = max(0.0f, value);
        else if (rows[rowIndex].name == "Threshold") effect->threshold = max(0.0f, value);
        else if (rows[rowIndex].name == "Size") effect->size = max(0.0f, value);
        return;
    }

    if (instance->getType() == InstanceType::WeldConstraint ||
        instance->getType() == InstanceType::Motor6D)
    {
        auto findPartNamed = [&](const string& name) -> Part*
        {
            if (name.empty()) return nullptr;
            Part* found = nullptr;
            function<void(Instance*)> walk = [&](Instance* n)
            {
                if (!n || found) return;
                if (n->getType() == InstanceType::Part && n->name == name)
                    found = static_cast<Part*>(n);
                for (Instance* c : n->children) walk(c);
            };
            walk(&workspace);
            return found;
        };

        if (instance->getType() == InstanceType::WeldConstraint)
        {
            WeldConstraint* w = static_cast<WeldConstraint*>(instance);
            if (property == "Part0")
            {
                w->part0 = findPartNamed(text);
                w->relativeCaptured = false;
                if (w->part0 && w->part1) captureWeldRelative(w);
                return;
            }
            if (property == "Part1")
            {
                w->part1 = findPartNamed(text);
                w->relativeCaptured = false;
                if (w->part0 && w->part1) captureWeldRelative(w);
                return;
            }
            if (property == "Enabled")
            {
                bool on = (text == "true" || text == "True");
                w->enabled = on;
                if (on && w->part0 && w->part1) captureWeldRelative(w);
                return;
            }
        }
        else
        {
            Motor6DConstraint* m = static_cast<Motor6DConstraint*>(instance);
            if (property == "Part0") { m->part0 = findPartNamed(text); return; }
            if (property == "Part1")
            {
                m->part1 = findPartNamed(text);
                // Motor6D is stored as a child of Part1 (Roblox-style / tool convention).
                if (m->part1 != nullptr && m->parent != m->part1)
                {
                    removeInstanceFromParent(m);
                    addInstanceToParent(m->part1, m);
                }
                return;
            }
            if (property == "Enabled") { m->enabled = (text == "true" || text == "True"); return; }
            char* end = nullptr;
            float value = strtof(text.c_str(), &end);
            if (end == text.c_str() || *end != '\0') return;
            if (property == "DesiredAngle") m->desiredAngle = value;
            else if (property == "MaxVelocity") m->maxVelocity = max(0.0f, value);
            else if (property == "C0 Position X") m->c0.position.x = value;
            else if (property == "C0 Position Y") m->c0.position.y = value;
            else if (property == "C0 Position Z") m->c0.position.z = value;
            else if (property == "C1 Position X") m->c1.position.x = value;
            else if (property == "C1 Position Y") m->c1.position.y = value;
            else if (property == "C1 Position Z") m->c1.position.z = value;
        }
        return;
    }

    if (instance == &Lighting)
    {
        if (property == "Ambient")
            lightingSettings.ambient = hexToColor(text, lightingSettings.ambient);
        else if (property == "OutdoorAmbient")
            lightingSettings.outdoorAmbient = hexToColor(text, lightingSettings.outdoorAmbient);
        else if (property == "ColorShift_Top")
            lightingSettings.colorShiftTop = hexToColor(text, lightingSettings.colorShiftTop);
        else if (property == "ColorShift_Bottom")
            lightingSettings.colorShiftBottom = hexToColor(text, lightingSettings.colorShiftBottom);
        else if (property == "FogColor")
            lightingSettings.fogColor = hexToColor(text, lightingSettings.fogColor);
        else if (property == "GlobalShadows")
            lightingSettings.globalShadows = (text == "true" || text == "True");
        else if (property == "ShadowSoftness")
        {
            if (text == "Hard" || text == "Soft" || text == "Sharp")
                lightingSettings.shadowSoftness = text;
        }
        else
        {
            char* end = nullptr;
            float value = strtof(text.c_str(), &end);
            if (end == text.c_str() || *end != '\0')
                return;

            if (property == "FogStart")
                lightingSettings.fogStart = max(0.0f, value);
            else if (property == "FogEnd")
                lightingSettings.fogEnd = max(lightingSettings.fogStart + 0.001f, value);
            else if (property == "Brightness")
                lightingSettings.brightness = max(0.0f, value);
            else if (property == "ExposureCompensation")
                lightingSettings.exposureCompensation = value;
            else if (property == "EnvironmentDiffuseScale")
                lightingSettings.environmentDiffuseScale = max(0.0f, value);
            else if (property == "EnvironmentSpecularScale")
                lightingSettings.environmentSpecularScale = max(0.0f, value);
            else if (property == "ClockTime")
                lightingSettings.clockTime = fmodf(max(0.0f, value), 24.0f);
            else if (property == "GeographicLatitude")
                lightingSettings.geographicLatitude = Clamp(value, -90.0f, 90.0f);
            else if (property == "Blur")
                lightingSettings.blur = Clamp(value, 0.0f, 8.0f);
        }
    }
}


void applyPropertyTextToSelection(int rowIndex, const string& text)
{
    if (selectedInstances.empty() || rowIndex < 0) return;
    vector<PropertyRow> merged = getMergedPropertyRows(selectedInstances);
    if (rowIndex >= (int)merged.size()) return;
    const string propName = merged[rowIndex].name;
    const PropertyKind propKind = merged[rowIndex].kind;
    for (Instance* inst : selectedInstances)
    {
        if (!inst) continue;
        vector<PropertyRow> rows = getPropertyRows(inst);
        for (int i = 0; i < (int)rows.size(); ++i)
        {
            if (rows[i].name == propName && rows[i].kind == propKind)
            {
                applyPropertyText(inst, i, text);
                break;
            }
        }
    }
    projectDirty = true;
}


#endif // BT_EDITOR_CHROME_H