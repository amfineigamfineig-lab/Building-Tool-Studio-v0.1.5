// bt_engine.h — umbrella for editor engine branches (include order matters)
#pragma once
#ifndef BT_ENGINE_H
#define BT_ENGINE_H

#include "bt_gizmo.h"
#include "bt_render3d.h"
#include "bt_editor_chrome.h"
#include "bt_panels.h"
#include "bt_script_runtime.h"

#endif // BT_ENGINE_H