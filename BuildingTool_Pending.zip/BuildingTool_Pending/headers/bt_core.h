// bt_core.h — Instance tree ops, project serialize, settings, autosave, dialogs
// Auto-split from buildingTool_.cpp (keep include order).
#pragma once
#ifndef BT_CORE_H
#define BT_CORE_H

// ============================================================
// Instance Tree Functions
// ============================================================

void addInstanceToParent(Instance* parent, Instance* child)
{
    if (parent == nullptr || child == nullptr)
        return;

    parent->children.push_back(child);
    child->parent = parent;
}


void removeInstanceFromParent(Instance* child)
{
    if (child == nullptr || child->parent == nullptr)
        return;

    Instance* parent = child->parent;

    for (auto it = parent->children.begin();
         it != parent->children.end();
         ++it)
    {
        if (*it == child)
        {
            parent->children.erase(it);
            break;
        }
    }

    child->parent = nullptr;
}

bool isInstanceInBranch(const Instance* branch,const Instance* instance)
{
    if (branch == nullptr || instance == nullptr)
        return false;

    if (branch == instance)
        return true;

    for (const Instance* child : branch->children)
    {
        if (isInstanceInBranch(child, instance))
            return true;
    }

    return false;
}

bool reparentInstance(Instance* child,Instance* newParent)
{
    if (child == nullptr || newParent == nullptr ||
        child == newParent || isInstanceInBranch(child, newParent) ||
        child->getType() == InstanceType::Service)
    {
        return false;
    }

    removeInstanceFromParent(child);
    addInstanceToParent(newParent, child);
    return true;
}

Service workspace = Service();
Service Lighting = Service();
Service ReplicatedStorage = Service();
Service ServerStorage = Service();
Service Players = Service();
Service ServerScriptService = Service();
Service StarterGui = Service();
Service StarterPlayer = Service();
Service StarterPack = Service();
// System-owned assets (CharacterRig, etc.). Hidden from Explorer unless
// View → Show Hidden Assets is on. Not part of the user's project tree.
Service CoreStorage = Service();
Script* characterRigModule = nullptr;

void ensureCharacterRigModule()
{
    if (characterRigModule != nullptr)
        return;

    characterRigModule = new Script();
    characterRigModule->name = "CharacterRig";
    characterRigModule->type = ScriptType::ModuleScript;
    characterRigModule->hidden = true;
    characterRigModule->source =
        "local rig = {\n"
        "    Parts = {'Torso', 'Head', 'Left Arm', 'Right Arm', 'Left Leg', 'Right Leg'},\n"
        "    Motor6Ds = {'Neck', 'Left Shoulder', 'Right Shoulder', 'Left Hip', 'Right Hip'}\n"
        "}\n"
        "return rig\n";
    addInstanceToParent(&CoreStorage, characterRigModule);
}

Instance* hoveredInstance = nullptr;
vector<Instance*> selectedInstances;
bool showHiddenAssets = false;
bool viewportSelectionBoxActive = false;
bool viewportSelectionBoxAdditive = false;
Vector2 viewportSelectionBoxStart = { 0, 0 };
Vector2 viewportSelectionBoxEnd = { 0, 0 };

vector<Instance*> explorerClipboard;

enum class ExplorerEditType
{
    Duplicate,
    Remove,
    Group,
    Ungroup
};

struct ExplorerEdit
{
    ExplorerEditType type;
    vector<Instance*> instances;
    vector<Instance*> parents;
    vector<size_t> indices;
    Instance* container = nullptr;
};

vector<ExplorerEdit> explorerUndo;
vector<ExplorerEdit> explorerRedo;

// Global project undo/redo (full project JSON snapshots). Script editor keeps its own stack.
vector<string> projectUndoStack;
vector<string> projectRedoStack;
const int kMaxProjectUndo = 50;
bool projectUndoRestoring = false;

// Implemented after serializeProjectJSON / applyProjectJSON
void pushProjectUndoCheckpoint();
void undoProjectChange();
void redoProjectChange();

Instance* renamingInstance = nullptr;
string renameText;
bool renameSelectAll = false;
int renameCursor = 0;
double lastExplorerClickTime = -1.0;
Instance* lastExplorerClicked = nullptr;
int explorerClickCount = 0;

float explorerScrollX = 0.0f;
float explorerScrollY = 0.0f;
// Expand/collapse hit targets filled during render_children (screen-space)
struct ExplorerExpandHit { Instance* instance; Rectangle rect; };
vector<ExplorerExpandHit> explorerExpandHits;
bool explorerDragging = false;
Vector2 explorerDragStartMouse = { 0, 0 };
Instance* explorerDraggedInstance = nullptr;
Instance* explorerDropTarget = nullptr;
vector<Instance*> explorerDraggedInstances;
bool explorerDraggingScrollX = false;
bool explorerDraggingScrollY = false;
vector<Instance*> collapsedExplorerInstances;

// Used by Shift-click to determine the selection range.
Instance* selectionAnchor = nullptr;

Instance* cloneInstance(const Instance* source)
{
    if (source == nullptr)
        return nullptr;

    Instance* copy = nullptr;
    switch (source->getType())
    {
        case InstanceType::Part: copy = new Part(*static_cast<const Part*>(source)); break;
        case InstanceType::Script: copy = new Script(*static_cast<const Script*>(source)); break;
        case InstanceType::Model: copy = new Model_Instance(*static_cast<const Model_Instance*>(source)); break;
        case InstanceType::Folder: copy = new Folder(*static_cast<const Folder*>(source)); break;
        case InstanceType::Service: copy = new Service(*static_cast<const Service*>(source)); break;
        case InstanceType::Sound: copy = new SoundInstance(*static_cast<const SoundInstance*>(source)); break;
        case InstanceType::Texture: copy = new TextureInstance(*static_cast<const TextureInstance*>(source)); break;
        case InstanceType::WeldConstraint: copy = new WeldConstraint(*static_cast<const WeldConstraint*>(source)); break;
        case InstanceType::Motor6D: copy = new Motor6DConstraint(*static_cast<const Motor6DConstraint*>(source)); break;
        case InstanceType::Blur: copy = new BlurInstance(*static_cast<const BlurInstance*>(source)); break;
        case InstanceType::ColorCorrection: copy = new ColorCorrectionInstance(*static_cast<const ColorCorrectionInstance*>(source)); break;
        case InstanceType::SunLight: copy = new SunLightInstance(*static_cast<const SunLightInstance*>(source)); break;
        case InstanceType::PointLight: copy = new PointLightInstance(*static_cast<const PointLightInstance*>(source)); break;
        case InstanceType::SpotLight: copy = new SpotLightInstance(*static_cast<const SpotLightInstance*>(source)); break;
        case InstanceType::SurfaceLight: copy = new SurfaceLightInstance(*static_cast<const SurfaceLightInstance*>(source)); break;
        case InstanceType::Bloom: copy = new BloomInstance(*static_cast<const BloomInstance*>(source)); break;
        case InstanceType::Player: copy = new PlayerInstance(*static_cast<const PlayerInstance*>(source)); break;
        case InstanceType::BindableEvent: copy = new BindableEventInstance(*static_cast<const BindableEventInstance*>(source)); break;
        case InstanceType::BindableFunction: copy = new BindableFunctionInstance(*static_cast<const BindableFunctionInstance*>(source)); break;
        case InstanceType::RemoteEvent: copy = new RemoteEventInstance(*static_cast<const RemoteEventInstance*>(source)); break;
        case InstanceType::RemoteFunction: copy = new RemoteFunctionInstance(*static_cast<const RemoteFunctionInstance*>(source)); break;
        case InstanceType::Humanoid: copy = new HumanoidInstance(*static_cast<const HumanoidInstance*>(source)); break;
        case InstanceType::Camera: copy = new CameraInstance(*static_cast<const CameraInstance*>(source)); break;
        case InstanceType::ScreenGui:
        case InstanceType::SurfaceGui:
        case InstanceType::BillboardGui:
            copy = new LayerCollectorInstance(*static_cast<const LayerCollectorInstance*>(source));
            break;
        case InstanceType::Frame:
        case InstanceType::ScrollingFrame:
        case InstanceType::TextLabel:
        case InstanceType::ImageLabel:
        case InstanceType::TextButton:
        case InstanceType::ImageButton:
        case InstanceType::TextBox:
            copy = new GuiObjectInstance(*static_cast<const GuiObjectInstance*>(source));
            break;
        case InstanceType::UICorner:
        case InstanceType::UIListLayout:
        case InstanceType::UIStroke:
        case InstanceType::UIPadding:
        case InstanceType::UIGridLayout:
        case InstanceType::UIAspectRatioConstraint:
            copy = new UIModifierInstance(*static_cast<const UIModifierInstance*>(source));
            break;
    }
    if (copy == nullptr)
        return nullptr;

    copy->parent = nullptr;
    copy->children.clear();
    for (const Instance* child : source->children)
    {
        Instance* childCopy = cloneInstance(child);
        if (childCopy != nullptr)
            addInstanceToParent(copy, childCopy);
    }
    return copy;
}

void destroyInstanceTree(Instance* instance)
{
    if (instance == nullptr)
        return;
    // Copy pointer list first — recursive delete must not iterate a live vector
    // of nodes that are being freed.
    vector<Instance*> kids = instance->children;
    instance->children.clear();
    for (Instance* child : kids)
    {
        if (child != nullptr)
            child->parent = nullptr;
        destroyInstanceTree(child);
    }
    delete instance;
}

void insertInstanceAt(Instance* parent, Instance* child, size_t index)
{
    if (parent == nullptr || child == nullptr)
        return;
    child->parent = parent;
    index = min(index, parent->children.size());
    parent->children.insert(parent->children.begin() + index, child);
}

vector<Instance*> getSelectedRoots()
{
    vector<Instance*> roots;
    for (Instance* instance : selectedInstances)
    {
        if (instance == nullptr || instance->getType() == InstanceType::Service)
            continue;
        bool descendantSelected = false;
        for (Instance* other : selectedInstances)
        {
            if (other != nullptr && other != instance && isInstanceInBranch(other, instance))
            {
                descendantSelected = true;
                break;
            }
        }
        if (!descendantSelected)
            roots.push_back(instance);
    }
    return roots;
}

void pushExplorerEdit(ExplorerEdit edit)
{
    explorerUndo.push_back(edit);
    explorerRedo.clear();
}

void detachEditInstances(const ExplorerEdit& edit)
{
    for (Instance* instance : edit.instances)
        removeInstanceFromParent(instance);
}

void attachEditInstances(const ExplorerEdit& edit)
{
    for (size_t i = 0; i < edit.instances.size(); ++i)
        insertInstanceAt(edit.parents[i], edit.instances[i], edit.indices[i]);
}

void undoExplorerEdit()
{
    if (explorerUndo.empty())
        return;
    ExplorerEdit edit = explorerUndo.back();
    explorerUndo.pop_back();
    if (edit.type == ExplorerEditType::Group)
    {
        detachEditInstances(edit);
        removeInstanceFromParent(edit.container);
        selectedInstances = edit.instances;
    }
    else if (edit.type == ExplorerEditType::Ungroup)
    {
        detachEditInstances(edit);
        insertInstanceAt(edit.parents.front(), edit.container, edit.indices.front());
        for (Instance* instance : edit.instances)
            addInstanceToParent(edit.container, instance);
        selectedInstances = { edit.container };
    }
    else if (edit.type == ExplorerEditType::Remove)
    {
        attachEditInstances(edit);
        selectedInstances = edit.instances;
    }
    else
    {
        detachEditInstances(edit);
        selectedInstances.clear();
    }
    explorerRedo.push_back(edit);
}

void redoExplorerEdit()
{
    if (explorerRedo.empty())
        return;
    ExplorerEdit edit = explorerRedo.back();
    explorerRedo.pop_back();
    if (edit.type == ExplorerEditType::Group)
    {
        removeInstanceFromParent(edit.container);
        for (Instance* instance : edit.instances)
            removeInstanceFromParent(instance);
        for (Instance* instance : edit.instances)
            addInstanceToParent(edit.container, instance);
        addInstanceToParent(edit.parents.front(), edit.container);
        selectedInstances = { edit.container };
    }
    else if (edit.type == ExplorerEditType::Ungroup)
    {
        removeInstanceFromParent(edit.container);
        for (Instance* instance : edit.instances)
            addInstanceToParent(edit.parents.front(), instance);
        selectedInstances = edit.instances;
    }
    else if (edit.type == ExplorerEditType::Remove)
    {
        detachEditInstances(edit);
        selectedInstances.clear();
    }
    else
    {
        attachEditInstances(edit);
        selectedInstances = edit.instances;
    }
    explorerUndo.push_back(edit);
}

Instance* getExplorerPasteTarget(bool selectedTarget)
{
    if (!selectedTarget || selectedInstances.size() != 1)
        return &workspace;

    Instance* target = selectedInstances.front();
    return target != nullptr && target->getType() != InstanceType::Service ? target : &workspace;
}

void copySelectedInstances()
{
    for (Instance* instance : explorerClipboard)
        destroyInstanceTree(instance);
    explorerClipboard.clear();
    for (Instance* instance : getSelectedRoots())
        explorerClipboard.push_back(cloneInstance(instance));
}

void pasteInstances(Instance* targetParent)
{
    if (explorerClipboard.empty() || targetParent == nullptr)
        return;

    ExplorerEdit edit = { ExplorerEditType::Duplicate };
    for (Instance* clipboardInstance : explorerClipboard)
    {
        Instance* copy = cloneInstance(clipboardInstance);
        if (copy == nullptr)
            continue;
        addInstanceToParent(targetParent, copy);
        edit.instances.push_back(copy);
        edit.parents.push_back(targetParent);
        edit.indices.push_back(targetParent->children.size() - 1);
    }
    if (!edit.instances.empty())
    {
        selectedInstances = edit.instances;
        pushExplorerEdit(edit);
    }
}

void duplicateSelectedInstances()
{
    vector<Instance*> roots = getSelectedRoots();
    if (roots.empty())
        return;

    ExplorerEdit edit = { ExplorerEditType::Duplicate };
    for (Instance* instance : roots)
    {
        Instance* copy = cloneInstance(instance);
        if (copy == nullptr || instance->parent == nullptr)
            continue;
        size_t index = find(instance->parent->children.begin(), instance->parent->children.end(), instance) - instance->parent->children.begin();
        insertInstanceAt(instance->parent, copy, index + 1);
        edit.instances.push_back(copy);
        edit.parents.push_back(instance->parent);
        edit.indices.push_back(index + 1);
    }
    if (!edit.instances.empty())
    {
        selectedInstances = edit.instances;
        pushExplorerEdit(edit);
    }
}

void deleteSelectedInstances(bool copyToClipboard)
{
    vector<Instance*> roots = getSelectedRoots();
    if (roots.empty())
        return;

    if (copyToClipboard)
        copySelectedInstances();

    ExplorerEdit edit = { ExplorerEditType::Remove };
    for (Instance* instance : roots)
    {
        if (instance->parent == nullptr)
            continue;
        size_t index = find(instance->parent->children.begin(), instance->parent->children.end(), instance) - instance->parent->children.begin();
        edit.instances.push_back(instance);
        edit.parents.push_back(instance->parent);
        edit.indices.push_back(index);
        removeInstanceFromParent(instance);
    }
    if (!edit.instances.empty())
    {
        selectedInstances.clear();
        pushExplorerEdit(edit);
    }
}

void groupSelectedInstances(bool asFolder)
{
    vector<Instance*> roots = getSelectedRoots();
    if (roots.empty())
        return;

    map<Instance*, int> parentCounts;
    for (Instance* instance : roots)
        if (instance->parent != nullptr)
            parentCounts[instance->parent]++;

    Instance* targetParent = &workspace;
    int mostSelected = 0;
    for (const auto& entry : parentCounts)
    {
        if (entry.second > mostSelected)
        {
            targetParent = entry.first;
            mostSelected = entry.second;
        }
    }

    Instance* container = asFolder
        ? static_cast<Instance*>(new Folder())
        : static_cast<Instance*>(new Model_Instance());
    container->name = asFolder ? "Folder" : "Model";
    addInstanceToParent(targetParent, container);

    ExplorerEdit edit = { ExplorerEditType::Group };
    edit.container = container;
    for (Instance* instance : roots)
    {
        if (instance == targetParent)
            continue;
        size_t index = find(instance->parent->children.begin(), instance->parent->children.end(), instance) - instance->parent->children.begin();
        edit.instances.push_back(instance);
        edit.parents.push_back(instance->parent);
        edit.indices.push_back(index);
        removeInstanceFromParent(instance);
        addInstanceToParent(container, instance);
    }

    if (edit.instances.empty())
    {
        removeInstanceFromParent(container);
        destroyInstanceTree(container);
        return;
    }

    selectedInstances = { container };
    pushExplorerEdit(edit);
}

void ungroupSelectedInstances()
{
    vector<Instance*> roots = getSelectedRoots();
    for (Instance* container : roots)
    {
        if (container->parent == nullptr ||
            (container->getType() != InstanceType::Model && container->getType() != InstanceType::Folder))
            continue;

        Instance* parent = container->parent;
        size_t containerIndex = find(parent->children.begin(), parent->children.end(), container) - parent->children.begin();
        ExplorerEdit edit = { ExplorerEditType::Ungroup };
        edit.container = container;
        edit.parents.push_back(parent);
        edit.indices.push_back(containerIndex);
        vector<Instance*> children = container->children;
        for (Instance* child : children)
        {
            edit.instances.push_back(child);
            edit.parents.push_back(parent);
            edit.indices.push_back(containerIndex++);
            removeInstanceFromParent(child);
            addInstanceToParent(parent, child);
        }
        removeInstanceFromParent(container);
        selectedInstances = edit.instances;
        pushExplorerEdit(edit);
    }
}

void handleExplorerShortcuts()
{
    if (renamingInstance != nullptr ||
        (!isZoneFocused(FocusZone::Explorer) && !isZoneFocused(FocusZone::Viewport)))
        return;

    bool ctrl = IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL);
    bool shift = IsKeyDown(KEY_LEFT_SHIFT) || IsKeyDown(KEY_RIGHT_SHIFT);
    bool alt = IsKeyDown(KEY_LEFT_ALT) || IsKeyDown(KEY_RIGHT_ALT);
    if (alt && IsKeyPressed(KEY_G))
        return;
    if (IsKeyPressed(KEY_DELETE) || IsKeyPressed(KEY_BACKSPACE))
    {
        deleteSelectedInstances(false);
        return;
    }
    if (!ctrl)
        return;

    if (IsKeyPressed(KEY_C))
        copySelectedInstances();
    else if (IsKeyPressed(KEY_X))
        deleteSelectedInstances(true);
    else if (IsKeyPressed(KEY_V))
        pasteInstances(getExplorerPasteTarget(shift));
    else if (IsKeyPressed(KEY_D))
        duplicateSelectedInstances();
    else if (IsKeyPressed(KEY_G) && alt)
        groupSelectedInstances(true);
    else if (IsKeyPressed(KEY_G))
        groupSelectedInstances(false);
    else if (IsKeyPressed(KEY_U))
        ungroupSelectedInstances();
    else if (IsKeyPressed(KEY_Z) && !shift)
        undoProjectChange(); // full project (tree, props, assets, …)
    else if (IsKeyPressed(KEY_Y) || (IsKeyPressed(KEY_Z) && shift))
        redoProjectChange();
}

vector<Instance*> existingInstances = { &workspace };
Folder game = Folder();

SunLight sun = {
    { -0.5f, -1.0f, -0.5f },
    { 255, 190, 110, 255 },
    0.8f,
    0.35f
};

BlurInstance blurEffect;
ColorCorrectionInstance colorCorrectionEffect;
SunLightInstance sunLightEffect;
BloomInstance bloomEffect;

void ensureLightingEffectInstances()
{
    blurEffect.name = "Blur";
    colorCorrectionEffect.name = "ColorCorrection";
    sunLightEffect.name = "SunLight";
    bloomEffect.name = "Bloom";
    if (blurEffect.parent == nullptr) addInstanceToParent(&Lighting, &blurEffect);
    if (colorCorrectionEffect.parent == nullptr) addInstanceToParent(&Lighting, &colorCorrectionEffect);
    if (sunLightEffect.parent == nullptr) addInstanceToParent(&Lighting, &sunLightEffect);
    if (bloomEffect.parent == nullptr) addInstanceToParent(&Lighting, &bloomEffect);
}

LightingSettings lightingSettings;


// ============================================================
// Project Save / Load
// ============================================================

void addInstanceToParent(Instance* parent, Instance* child);
void destroyInstanceTree(Instance* instance);

// Small self-contained JSON value/parser. Project files are stored as JSON
// first and then passed through HLX/Zstd by Compress.h.
struct JsonValue
{
    enum class Type { Null, Bool, Number, String, Object, Array };
    Type type = Type::Null;
    bool boolean = false;
    double number = 0.0;
    string text;
    map<string, JsonValue> object;
    vector<JsonValue> array;

    static JsonValue makeObject() { JsonValue v; v.type = Type::Object; return v; }
    static JsonValue makeArray() { JsonValue v; v.type = Type::Array; return v; }
    static JsonValue makeString(const string& s) { JsonValue v; v.type = Type::String; v.text = s; return v; }
    static JsonValue makeNumber(double n) { JsonValue v; v.type = Type::Number; v.number = n; return v; }
    static JsonValue makeBool(bool b) { JsonValue v; v.type = Type::Bool; v.boolean = b; return v; }

    const JsonValue* get(const string& key) const
    {
        auto it = object.find(key);
        return it == object.end() ? nullptr : &it->second;
    }
};

class JsonParser
{
    const string& source;
    size_t pos = 0;

    void skipWhitespace()
    {
        while (pos < source.size() && isspace(static_cast<unsigned char>(source[pos]))) ++pos;
    }

    bool consume(char c)
    {
        skipWhitespace();
        if (pos >= source.size() || source[pos] != c) return false;
        ++pos;
        return true;
    }

    bool parseStringValue(string& out)
    {
        skipWhitespace();
        if (pos >= source.size() || source[pos] != '"') return false;
        ++pos;
        out.clear();
        while (pos < source.size())
        {
            char c = source[pos++];
            if (c == '"') return true;
            if (c != '\\') { out += c; continue; }
            if (pos >= source.size()) return false;
            char e = source[pos++];
            switch (e)
            {
                case '"': out += '"'; break;
                case '\\': out += '\\'; break;
                case '/': out += '/'; break;
                case 'b': out += '\b'; break;
                case 'f': out += '\f'; break;
                case 'n': out += '\n'; break;
                case 'r': out += '\r'; break;
                case 't': out += '\t'; break;
                case 'u':
                    // Project text is emitted as UTF-8 by the editor. For the
                    // rare \u escape, consume it and preserve it as '?' rather
                    // than corrupting the parser.
                    if (pos + 4 > source.size()) return false;
                    pos += 4; out += '?'; break;
                default: return false;
            }
        }
        return false;
    }

    bool parseNumberValue(double& out)
    {
        skipWhitespace();
        size_t start = pos;
        if (pos < source.size() && (source[pos] == '-' || source[pos] == '+')) ++pos;
        while (pos < source.size() && isdigit(static_cast<unsigned char>(source[pos]))) ++pos;
        if (pos < source.size() && source[pos] == '.') { ++pos; while (pos < source.size() && isdigit(static_cast<unsigned char>(source[pos]))) ++pos; }
        if (pos < source.size() && (source[pos] == 'e' || source[pos] == 'E'))
        {
            ++pos;
            if (pos < source.size() && (source[pos] == '-' || source[pos] == '+')) ++pos;
            while (pos < source.size() && isdigit(static_cast<unsigned char>(source[pos]))) ++pos;
        }
        if (start == pos) return false;
        try { out = stod(source.substr(start, pos - start)); } catch (...) { return false; }
        return true;
    }

    bool parseValue(JsonValue& out)
    {
        skipWhitespace();
        if (pos >= source.size()) return false;
        if (source[pos] == '"') { string v; if (!parseStringValue(v)) return false; out = JsonValue::makeString(v); return true; }
        if (source[pos] == '{') return parseObject(out);
        if (source[pos] == '[') return parseArray(out);
        if (source.compare(pos, 4, "true") == 0) { pos += 4; out = JsonValue::makeBool(true); return true; }
        if (source.compare(pos, 5, "false") == 0) { pos += 5; out = JsonValue::makeBool(false); return true; }
        if (source.compare(pos, 4, "null") == 0) { pos += 4; out = JsonValue(); return true; }
        double n = 0.0; if (parseNumberValue(n)) { out = JsonValue::makeNumber(n); return true; }
        return false;
    }

    bool parseObject(JsonValue& out)
    {
        if (!consume('{')) return false;
        out = JsonValue::makeObject();
        skipWhitespace();
        if (consume('}')) return true;
        while (pos < source.size())
        {
            string key;
            if (!parseStringValue(key) || !consume(':')) return false;
            JsonValue value;
            if (!parseValue(value)) return false;
            out.object[key] = value;
            skipWhitespace();
            if (consume('}')) return true;
            if (!consume(',')) return false;
        }
        return false;
    }

    bool parseArray(JsonValue& out)
    {
        if (!consume('[')) return false;
        out = JsonValue::makeArray();
        skipWhitespace();
        if (consume(']')) return true;
        while (pos < source.size())
        {
            JsonValue value;
            if (!parseValue(value)) return false;
            out.array.push_back(value);
            skipWhitespace();
            if (consume(']')) return true;
            if (!consume(',')) return false;
        }
        return false;
    }

public:
    explicit JsonParser(const string& s) : source(s) {}
    bool parse(JsonValue& out)
    {
        if (!parseValue(out)) return false;
        skipWhitespace();
        return pos == source.size();
    }
};

string jsonEscape(const string& value)
{
    ostringstream out;
    for (unsigned char c : value)
    {
        switch (c)
        {
            case '"': out << "\\\""; break;
            case '\\': out << "\\\\"; break;
            case '\b': out << "\\b"; break;
            case '\f': out << "\\f"; break;
            case '\n': out << "\\n"; break;
            case '\r': out << "\\r"; break;
            case '\t': out << "\\t"; break;
            default:
                if (c < 32) out << "?";
                else out << static_cast<char>(c);
        }
    }
    return out.str();
}

string jsonString(const string& value) { return "\"" + jsonEscape(value) + "\""; }
string jsonNumber(double value)
{
    ostringstream out;
    out << setprecision(9) << value;
    return out.str();
}
string jsonBool(bool value) { return value ? "true" : "false"; }

string instanceTypeName(InstanceType type)
{
    switch (type)
    {
        case InstanceType::Part: return "Part";
        case InstanceType::Script: return "Script";
        case InstanceType::Model: return "Model";
        case InstanceType::Folder: return "Folder";
        case InstanceType::Service: return "Service";
        case InstanceType::Sound: return "Sound";
        case InstanceType::Texture: return "Texture";
        case InstanceType::WeldConstraint: return "WeldConstraint";
        case InstanceType::Motor6D: return "Motor6D";
        case InstanceType::Blur: return "Blur";
        case InstanceType::ColorCorrection: return "ColorCorrection";
        case InstanceType::SunLight: return "SunLight";
    case InstanceType::PointLight: return "PointLight";
    case InstanceType::SpotLight: return "SpotLight";
    case InstanceType::SurfaceLight: return "SurfaceLight";
        case InstanceType::Bloom: return "Bloom";
        case InstanceType::Player: return "Player";
        case InstanceType::BindableEvent: return "BindableEvent";
        case InstanceType::BindableFunction: return "BindableFunction";
        case InstanceType::RemoteEvent: return "RemoteEvent";
        case InstanceType::RemoteFunction: return "RemoteFunction";
        case InstanceType::Humanoid: return "Humanoid";
        case InstanceType::Camera: return "Camera";
        case InstanceType::ScreenGui: return "ScreenGui";
        case InstanceType::SurfaceGui: return "SurfaceGui";
        case InstanceType::BillboardGui: return "BillboardGui";
        case InstanceType::Frame: return "Frame";
        case InstanceType::ScrollingFrame: return "ScrollingFrame";
        case InstanceType::TextLabel: return "TextLabel";
        case InstanceType::ImageLabel: return "ImageLabel";
        case InstanceType::TextButton: return "TextButton";
        case InstanceType::ImageButton: return "ImageButton";
        case InstanceType::TextBox: return "TextBox";
        case InstanceType::UICorner: return "UICorner";
        case InstanceType::UIListLayout: return "UIListLayout";
        case InstanceType::UIStroke: return "UIStroke";
        case InstanceType::UIPadding: return "UIPadding";
        case InstanceType::UIGridLayout: return "UIGridLayout";
        case InstanceType::UIAspectRatioConstraint: return "UIAspectRatioConstraint";
    }
    return "Folder";
}

string partTypeName(PartType type)
{
    switch (type)
    {
        case PartType::Block: return "Block";
        case PartType::Wedge: return "Wedge";
        case PartType::CornerWedge: return "CornerWedge";
        case PartType::Cylinder: return "Cylinder";
        case PartType::Sphere: return "Sphere";
        case PartType::Cone: return "Cone";
    }
    return "Block";
}

string collisionFidelityName(CollisionFidelity fidelity)
{
    switch (fidelity)
    {
        case CollisionFidelity::Default: return "Default";
        case CollisionFidelity::Hull: return "Hull";
        case CollisionFidelity::Box: return "Box";
        case CollisionFidelity::PreciseConvexDecomposition: return "PreciseConvexDecomposition";
        case CollisionFidelity::Tunable: return "Tunable";
    }
    return "Default";
}

CollisionFidelity parseCollisionFidelity(const string& value)
{
    if (value == "Hull" || value == "1") return CollisionFidelity::Hull;
    if (value == "Box" || value == "2") return CollisionFidelity::Box;
    if (value == "PreciseConvexDecomposition" || value == "3")
        return CollisionFidelity::PreciseConvexDecomposition;
    if (value == "Tunable" || value == "4") return CollisionFidelity::Tunable;
    return CollisionFidelity::Default;
}

PartType parsePartType(const string& s)
{
    if (s == "Wedge") return PartType::Wedge;
    if (s == "CornerWedge") return PartType::CornerWedge;
    if (s == "Cylinder") return PartType::Cylinder;
    if (s == "Sphere") return PartType::Sphere;
    if (s == "Cone") return PartType::Cone;
    return PartType::Block;
}

string scriptTypeName(ScriptType type)
{
    switch (type)
    {
        case ScriptType::LocalScript: return "LocalScript";
        case ScriptType::ModuleScript: return "ModuleScript";
        case ScriptType::Script: return "Script";
    }
    return "Script";
}

ScriptType parseScriptType(const string& s)
{
    if (s == "LocalScript") return ScriptType::LocalScript;
    if (s == "ModuleScript") return ScriptType::ModuleScript;
    return ScriptType::Script;
}

string vec3JSON(const Vector3& v)
{
    return "[" + jsonNumber(v.x) + "," + jsonNumber(v.y) + "," + jsonNumber(v.z) + "]";
}

string colorJSON(const Color& c)
{
    return "[" + to_string(c.r) + "," + to_string(c.g) + "," + to_string(c.b) + "," + to_string(c.a) + "]";
}

float jsonFloat(const JsonValue* v, float fallback = 0.0f)
{
    return v && v->type == JsonValue::Type::Number ? static_cast<float>(v->number) : fallback;
}

bool jsonBoolValue(const JsonValue* v, bool fallback = false)
{
    return v && v->type == JsonValue::Type::Bool ? v->boolean : fallback;
}

string jsonStringValue(const JsonValue* v, const string& fallback = "")
{
    return v && v->type == JsonValue::Type::String ? v->text : fallback;
}

Vector3 jsonVec3(const JsonValue* v, Vector3 fallback = { 0, 0, 0 })
{
    if (!v || v->type != JsonValue::Type::Array || v->array.size() < 3) return fallback;
    return { jsonFloat(&v->array[0], fallback.x), jsonFloat(&v->array[1], fallback.y), jsonFloat(&v->array[2], fallback.z) };
}

Color jsonColor(const JsonValue* v, Color fallback = WHITE)
{
    if (!v || v->type != JsonValue::Type::Array || v->array.size() < 4) return fallback;
    return { static_cast<unsigned char>(clamp(jsonFloat(&v->array[0], fallback.r), 0.0f, 255.0f)),
             static_cast<unsigned char>(clamp(jsonFloat(&v->array[1], fallback.g), 0.0f, 255.0f)),
             static_cast<unsigned char>(clamp(jsonFloat(&v->array[2], fallback.b), 0.0f, 255.0f)),
             static_cast<unsigned char>(clamp(jsonFloat(&v->array[3], fallback.a), 0.0f, 255.0f)) };
}

string projectFilePath;
string projectName = "Untitled";
string projectId = "unsaved"; // short stable id used in autosave filenames
bool newProjectTypeDialogOpen = false;
bool newProjectTypeDialogWaitForMouseRelease = false;
string compileScriptBytecodeForExport(const Script* script, bool& success);
string lastSavedProjectJSON;
string lastObservedProjectJSON;
double lastProjectObservation = 0.0;
double lastAutoSaveTime = 0.0;

string sanitizeFileToken(const string& s)
{
    string out;
    out.reserve(s.size());
    for (char c : s)
    {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
            (c >= '0' && c <= '9') || c == '-' || c == '_')
            out.push_back(c);
        else if (c == ' ' || c == '.')
            out.push_back('_');
    }
    if (out.empty()) out = "Untitled";
    if (out.size() > 48) out = out.substr(0, 48);
    return out;
}

string makeProjectIdFromPath(const string& path)
{
    if (path.empty()) return "unsaved";
    // FNV-1a 32-bit → 8 hex chars
    unsigned int h = 2166136261u;
    for (unsigned char c : path)
    {
        h ^= c;
        h *= 16777619u;
    }
    char buf[16];
    snprintf(buf, sizeof(buf), "%08x", h);
    return string(buf);
}

string getAutosavesDir()
{
    filesystem::path p = filesystem::path(GetWorkingDirectory()) / "autosaves";
    error_code ec;
    filesystem::create_directories(p, ec);
    return p.string();
}

bool projectSaveDialogOpen = false;
// After the user Cancels a close-with-unsaved prompt, ignore further
// WindowShouldClose() until a new rising edge (prevents dialog spam / freeze).
bool windowCloseConsumed = false;
bool windowClosePrev = false;

// Startup/welcome screen. The editor itself is hidden until the user
// creates or opens a project, similar to a game-editor start page.
bool welcomeScreenOpen = true;

static string windowTypeTitleLabel(WindowType t)
{
    switch (t)
    {
    case WindowType::Viewport: return "Viewport";
    case WindowType::Output: return "Output";
    case WindowType::Library: return "Asset Manager";
    case WindowType::ExplorerView: return "Explorer";
    case WindowType::PropertiesView: return "Properties";
    case WindowType::Script: return "Script";
    case WindowType::Welcome: return "Welcome";
    default: return "Viewport";
    }
}

void updateApplicationWindowTitle()
{
    string title;
    if (welcomeScreenOpen || activeWindow == WindowType::Welcome)
    {
        title = "BuildingTool " + BUILDING_TOOL_VERSION + " - Welcome";
    }
    else
    {
        string win = windowTypeTitleLabel(activeWindow);
        if (activeWindow == WindowType::Script && activeScript != nullptr && !activeScript->name.empty())
            win = activeScript->name;
        title = "BuildingTool " + BUILDING_TOOL_VERSION + " - " + projectName + " - " + win;
        if (projectDirty)
            title += "*";
    }
    SetWindowTitle(title.c_str());
}
vector<string> recentProjects;
const char* RECENT_PROJECTS_FILE_NAME = "recent_projects.json";
bool projectSaveDialogWasCloseRequest = false;
enum class PendingProjectAction { None, New, Open, Exit };
PendingProjectAction pendingProjectAction = PendingProjectAction::None;

void destroyDynamicChildren(Instance* parent)
{
    if (!parent) return;
    for (Instance* child : parent->children)
    {
        destroyInstanceTree(child);
    }
    parent->children.clear();
}

void resetEditorProjectTree()
{
    pendingInstanceRefs.clear();

    selectedInstances.clear();
    explorerClipboard.clear();
    explorerUndo.clear();
    explorerRedo.clear();
    gizmoParts.clear();
    gizmoStartPositions.clear();
    gizmoStartSizes.clear();
    gizmoStartRotations.clear();
    draggingGizmo = false;
    hoveredGizmoAxis = GizmoAxis::None;
    activeGizmoAxis = GizmoAxis::None;
    hoveredGizmoSign = 1;
    activeGizmoSign = 1;
    openScripts.clear();
    windowTabs = { { WindowType::Viewport, nullptr }, { WindowType::Output, nullptr } };
    insertMenuOpen = false;
    insertMenuHover = -1;
    clearProjectAssets();
    libraryScrollY = 0;
    libraryHoverIndex = -1;
    activeWindow = WindowType::Viewport;
    activeScript = nullptr;
    hoveredInstance = nullptr;
    propertyColorPickerOpen = false;
    activePropertyRow = -1;
    propertyEditText.clear();
    propertyEditCursor = 0;
    collapsedExplorerInstances.clear();
    // Do not delete the fixed Service objects; only delete dynamic non-service
    // top-level instances and the children owned by services.
    for (Instance* child : game.children)
    {
        if (child != nullptr && child->getType() != InstanceType::Service)
            destroyInstanceTree(child);
    }
    game.children.clear();
    // Service objects remain alive; their children are project-owned and are cleared too.
    destroyDynamicChildren(&workspace);
    for (Instance* child : Lighting.children)
    {
        if (child != &blurEffect && child != &colorCorrectionEffect &&
            child != &sunLightEffect && child != &bloomEffect)
            destroyInstanceTree(child);
    }
    Lighting.children.clear();
    blurEffect.parent = nullptr;
    colorCorrectionEffect.parent = nullptr;
    sunLightEffect.parent = nullptr;
    bloomEffect.parent = nullptr;
    for (Instance* child : ReplicatedStorage.children)
        destroyInstanceTree(child);
    ReplicatedStorage.children.clear();
    for (Instance* child : CoreStorage.children)
    {
        if (child != characterRigModule)
            destroyInstanceTree(child);
    }
    CoreStorage.children.clear();
    if (characterRigModule != nullptr)
        addInstanceToParent(&CoreStorage, characterRigModule);
    destroyDynamicChildren(&ServerStorage);
    destroyDynamicChildren(&Players);
    destroyDynamicChildren(&ServerScriptService);
    destroyDynamicChildren(&StarterGui);
    destroyDynamicChildren(&StarterPlayer);
    destroyDynamicChildren(&StarterPack);
    game.children.clear();
    addInstanceToParent(&game, &workspace);
    addInstanceToParent(&game, &Players);
    addInstanceToParent(&game, &Lighting);
    addInstanceToParent(&game, &ReplicatedStorage);
    addInstanceToParent(&game, &ServerScriptService);
    addInstanceToParent(&game, &ServerStorage);
    StarterGui.name = "StarterGui";
    StarterPlayer.name = "StarterPlayer";
    StarterPack.name = "StarterPack";
    addInstanceToParent(&game, &StarterGui);
    addInstanceToParent(&game, &StarterPlayer);
    addInstanceToParent(&game, &StarterPack);
    CoreStorage.name = "CoreStorage";
    CoreStorage.hidden = true; // system service — hidden unless Show Hidden Assets
    addInstanceToParent(&game, &CoreStorage);
    if (characterRigModule != nullptr)
        addInstanceToParent(&CoreStorage, characterRigModule);
    ensureLightingEffectInstances();
    ensureCharacterRigModule();
}

string serializeInstanceJSON(const Instance* instance)
{
    if (!instance) return "null";
    ostringstream out;
    string className = instance->getType() == InstanceType::Part &&
        static_cast<const Part*>(instance)->isMeshPart
        ? "MeshPart" : instanceTypeName(instance->getType());
    out << "{\"class\":" << jsonString(className)
        << ",\"name\":" << jsonString(instance->name)
        << ",\"id\":" << jsonString(instance->id)
        << ",\"hidden\":" << jsonBool(instance->hidden);

    if (instance->getType() == InstanceType::Part)
    {
        const Part* p = static_cast<const Part*>(instance);
        out << ",\"partType\":" << jsonString(partTypeName(p->type))
            << ",\"anchored\":" << jsonBool(p->anchored)
            << ",\"size\":" << vec3JSON(p->size)
            << ",\"color\":" << colorJSON(p->color)
            << ",\"position\":" << vec3JSON(p->cframe.position)
            << ",\"rotation\":" << vec3JSON(p->cframe.rotation)
            << ",\"pivotOffset\":" << vec3JSON(p->pivotOffset)
            << ",\"transparency\":" << jsonNumber(p->transparency)
            << ",\"reflectance\":" << jsonNumber(p->reflectance)
            << ",\"castShadow\":" << jsonBool(p->castShadow)
            << ",\"canCollide\":" << jsonBool(p->canCollide)
            << ",\"truss\":" << jsonBool(p->truss)
            << ",\"locked\":" << jsonBool(p->locked)
            << ",\"advancedPhysics\":" << jsonBool(p->advancedPhysics)
            << ",\"density\":" << jsonNumber(p->density)
            << ",\"friction\":" << jsonNumber(p->friction);
        if (p->isMeshPart)
            out << ",\"meshId\":" << jsonString(p->meshId)
                << ",\"textureId\":" << jsonString(p->textureId)
                << ",\"collisionFidelity\":" << jsonString(collisionFidelityName(p->collisionFidelity));
    }
    else if (instance->getType() == InstanceType::Script)
    {
        const Script* s = static_cast<const Script*>(instance);
        out << ",\"scriptType\":" << jsonString(scriptTypeName(s->type))
            << ",\"runContext\":" << jsonString(s->runContextName())
            << ",\"enabled\":" << jsonBool(s->enabled);
        if (serializeProjectForRuntime)
        {
            bool compiled = false;
            string bytecode = compileScriptBytecodeForExport(s, compiled);
            if (!compiled)
                projectSerializationFailed = true;
            out << ",\"bytecode\":" << jsonString(bytecode);
        }
        else if (projectStorageMultiFile)
        {
            string sourceFile = "Scripts/script_" +
                to_string(projectSerializationScriptIndex++) + ".lua";
            out << ",\"sourceFile\":" << jsonString(sourceFile);
        }
        else
            out << ",\"source\":" << jsonString(s->source);
    }
    else if (instance->getType() == InstanceType::Model)
    {
        const Model_Instance* m = static_cast<const Model_Instance*>(instance);
        out << ",\"scale\":" << jsonNumber(m->scale)
            << ",\"pivotOffset\":" << vec3JSON(m->pivotOffset);
    }
    else if (instance->getType() == InstanceType::Sound)
    {
        const SoundInstance* s = static_cast<const SoundInstance*>(instance);
        out << ",\"soundId\":" << jsonString(s->soundId)
            << ",\"volume\":" << jsonNumber(s->volume)
            << ",\"playbackSpeed\":" << jsonNumber(s->playbackSpeed)
            << ",\"looped\":" << jsonBool(s->looped)
            << ",\"playing\":" << jsonBool(s->playing)
            << ",\"timePosition\":" << jsonNumber(s->timePosition)
            << ",\"rollOffMaxDistance\":" << jsonNumber(s->rollOffMaxDistance)
            << ",\"rollOffMinDistance\":" << jsonNumber(s->rollOffMinDistance);
    }
    else if (instance->getType() == InstanceType::Texture)
    {
        const TextureInstance* t = static_cast<const TextureInstance*>(instance);
        out << ",\"texture\":" << jsonString(t->texture)
            << ",\"studsPerTileU\":" << jsonNumber(t->studsPerTileU)
            << ",\"studsPerTileV\":" << jsonNumber(t->studsPerTileV)
            << ",\"offsetStudsU\":" << jsonNumber(t->offsetStudsU)
            << ",\"offsetStudsV\":" << jsonNumber(t->offsetStudsV)
            << ",\"transparency\":" << jsonNumber(t->transparency)
            << ",\"color3\":" << colorJSON(t->color3)
            << ",\"face\":" << jsonString(t->face);
    }



    else if (instance->getType() == InstanceType::PointLight)
    {
        const auto* L = static_cast<const PointLightInstance*>(instance);
        out << ",\"color\":" << colorJSON(L->color)
            << ",\"brightness\":" << jsonNumber(L->brightness)
            << ",\"range\":" << jsonNumber(L->range)
            << ",\"shadows\":" << jsonBool(L->shadows)
            << ",\"enabled\":" << jsonBool(L->enabled);
    }
    else if (instance->getType() == InstanceType::SpotLight)
    {
        const auto* L = static_cast<const SpotLightInstance*>(instance);
        out << ",\"color\":" << colorJSON(L->color)
            << ",\"brightness\":" << jsonNumber(L->brightness)
            << ",\"range\":" << jsonNumber(L->range)
            << ",\"angle\":" << jsonNumber(L->angle)
            << ",\"face\":" << jsonString(L->face)
            << ",\"shadows\":" << jsonBool(L->shadows)
            << ",\"enabled\":" << jsonBool(L->enabled);
    }
    else if (instance->getType() == InstanceType::SurfaceLight)
    {
        const auto* L = static_cast<const SurfaceLightInstance*>(instance);
        out << ",\"color\":" << colorJSON(L->color)
            << ",\"brightness\":" << jsonNumber(L->brightness)
            << ",\"range\":" << jsonNumber(L->range)
            << ",\"angle\":" << jsonNumber(L->angle)
            << ",\"face\":" << jsonString(L->face)
            << ",\"shadows\":" << jsonBool(L->shadows)
            << ",\"enabled\":" << jsonBool(L->enabled);
    }

    if (instance->getType() == InstanceType::Model)
    {
        const Model_Instance* m = static_cast<const Model_Instance*>(instance);
        if (m->primaryPart != nullptr)
            out << ",\"primaryPart\":" << jsonString(getInstancePath(m->primaryPart));
    }
    else if (instance->getType() == InstanceType::Humanoid)
    {
        const HumanoidInstance* h = static_cast<const HumanoidInstance*>(instance);
        out << ",\"health\":" << jsonNumber(h->health)
            << ",\"maxHealth\":" << jsonNumber(h->maxHealth)
            << ",\"walkSpeed\":" << jsonNumber(h->walkSpeed)
            << ",\"jumpPower\":" << jsonNumber(h->jumpPower)
            << ",\"hipHeight\":" << jsonNumber(h->hipHeight)
            << ",\"slopeAngle\":" << jsonNumber(h->slopeAngle);
        if (h->rootPart != nullptr)
            out << ",\"rootPart\":" << jsonString(getInstancePath(h->rootPart));
    }
    else if (instance->getType() == InstanceType::WeldConstraint)
    {
        const WeldConstraint* w = static_cast<const WeldConstraint*>(instance);
        out << ",\"enabled\":" << jsonBool(w->enabled);
        if (w->part0) out << ",\"part0\":" << jsonString(getInstancePath(w->part0));
        if (w->part1) out << ",\"part1\":" << jsonString(getInstancePath(w->part1));
    }
    else if (instance->getType() == InstanceType::Motor6D)
    {
        const Motor6DConstraint* m = static_cast<const Motor6DConstraint*>(instance);
        out << ",\"enabled\":" << jsonBool(m->enabled)
            << ",\"desiredAngle\":" << jsonNumber(m->desiredAngle)
            << ",\"maxVelocity\":" << jsonNumber(m->maxVelocity)
            << ",\"c0\":" << vec3JSON(m->c0.position)
            << ",\"c1\":" << vec3JSON(m->c1.position);
        if (m->part0) out << ",\"part0\":" << jsonString(getInstancePath(m->part0));
        if (m->part1) out << ",\"part1\":" << jsonString(getInstancePath(m->part1));
    }
    else if (instance->getType() == InstanceType::Camera)
    {
        const CameraInstance* c = static_cast<const CameraInstance*>(instance);
        out << ",\"position\":" << vec3JSON(c->cframe.position)
            << ",\"rotation\":" << vec3JSON(c->cframe.rotation);
        if (c->target) out << ",\"target\":" << jsonString(getInstancePath(c->target));
    }
    else if (instance->getType() == InstanceType::ScreenGui ||
             instance->getType() == InstanceType::SurfaceGui ||
             instance->getType() == InstanceType::BillboardGui)
    {
        const LayerCollectorInstance* lc = static_cast<const LayerCollectorInstance*>(instance);
        out << ",\"enabled\":" << jsonBool(lc->enabled)
            << ",\"displayOrder\":" << jsonNumber((double)lc->displayOrder)
            << ",\"resetOnSpawn\":" << jsonBool(lc->resetOnSpawn)
            << ",\"ignoreGuiInset\":" << jsonBool(lc->ignoreGuiInset)
            << ",\"clipToDeviceSafeArea\":" << jsonBool(lc->clipToDeviceSafeArea)
            << ",\"alwaysOnTop\":" << jsonBool(lc->alwaysOnTop)
            << ",\"maxDistance\":" << jsonNumber(lc->maxDistance)
            << ",\"lightInfluence\":" << jsonNumber(lc->lightInfluence)
            << ",\"pixelsPerStud\":" << jsonNumber(lc->pixelsPerStud)
            << ",\"face\":" << jsonString(lc->face)
            << ",\"brightness\":" << jsonNumber(lc->brightness)
            << ",\"active\":" << jsonBool(lc->active)
            << ",\"clipsDescendants\":" << jsonBool(lc->clipsDescendants)
            << ",\"canvasSizeX\":" << jsonNumber(lc->canvasSize.x)
            << ",\"canvasSizeY\":" << jsonNumber(lc->canvasSize.y)
            << ",\"sizingMode\":" << jsonString(lc->sizingMode)
            << ",\"zOffset\":" << jsonNumber(lc->zOffset)
            << ",\"studsOffsetX\":" << jsonNumber(lc->studsOffset.x)
            << ",\"studsOffsetY\":" << jsonNumber(lc->studsOffset.y)
            << ",\"studsOffsetZ\":" << jsonNumber(lc->studsOffset.z)
            << ",\"distanceLowerLimit\":" << jsonNumber(lc->distanceLowerLimit)
            << ",\"distanceUpperLimit\":" << jsonNumber(lc->distanceUpperLimit)
            << ",\"bbSizeSX\":" << jsonNumber(lc->billboardSize.x.scale)
            << ",\"bbSizeOX\":" << jsonNumber(lc->billboardSize.x.offset)
            << ",\"bbSizeSY\":" << jsonNumber(lc->billboardSize.y.scale)
            << ",\"bbSizeOY\":" << jsonNumber(lc->billboardSize.y.offset);
        if (lc->adornee) out << ",\"adornee\":" << jsonString(getInstancePath(lc->adornee));
    }
    else if (instance->getType() == InstanceType::Frame ||
             instance->getType() == InstanceType::ScrollingFrame ||
             instance->getType() == InstanceType::TextLabel ||
             instance->getType() == InstanceType::ImageLabel ||
             instance->getType() == InstanceType::TextButton ||
             instance->getType() == InstanceType::ImageButton ||
             instance->getType() == InstanceType::TextBox)
    {
        const GuiObjectInstance* g = static_cast<const GuiObjectInstance*>(instance);
        out << ",\"sizeSX\":" << jsonNumber(g->size.x.scale) << ",\"sizeOX\":" << jsonNumber(g->size.x.offset)
            << ",\"sizeSY\":" << jsonNumber(g->size.y.scale) << ",\"sizeOY\":" << jsonNumber(g->size.y.offset)
            << ",\"posSX\":" << jsonNumber(g->position.x.scale) << ",\"posOX\":" << jsonNumber(g->position.x.offset)
            << ",\"posSY\":" << jsonNumber(g->position.y.scale) << ",\"posOY\":" << jsonNumber(g->position.y.offset)
            << ",\"anchorX\":" << jsonNumber(g->anchorPoint.x) << ",\"anchorY\":" << jsonNumber(g->anchorPoint.y)
            << ",\"automaticSize\":" << jsonString(g->automaticSize)
            << ",\"sizeConstraint\":" << jsonString(g->sizeConstraint)
            << ",\"layoutOrder\":" << jsonNumber((double)g->layoutOrder)
            << ",\"rotation\":" << jsonNumber(g->rotation)
            << ",\"bgColor\":" << colorJSON(g->backgroundColor)
            << ",\"bgTransparency\":" << jsonNumber(g->backgroundTransparency)
            << ",\"borderSize\":" << jsonNumber((double)g->borderSizePixel)
            << ",\"borderColor\":" << colorJSON(g->borderColor)
            << ",\"borderMode\":" << jsonString(g->borderMode)
            << ",\"visible\":" << jsonBool(g->visible)
            << ",\"zIndex\":" << jsonNumber((double)g->zIndex)
            << ",\"clipsDescendants\":" << jsonBool(g->clipsDescendants)
            << ",\"groupTransparency\":" << jsonNumber(g->groupTransparency)
            << ",\"active\":" << jsonBool(g->active)
            << ",\"interactable\":" << jsonBool(g->interactable)
            << ",\"selectable\":" << jsonBool(g->selectable)
            << ",\"selectionOrder\":" << jsonNumber((double)g->selectionOrder)
            << ",\"autoButtonColor\":" << jsonBool(g->autoButtonColor)
            << ",\"modal\":" << jsonBool(g->modal)
            << ",\"text\":" << jsonString(g->text)
            << ",\"textSize\":" << jsonNumber((double)g->textSize)
            << ",\"textColor\":" << colorJSON(g->textColor)
            << ",\"textTransparency\":" << jsonNumber(g->textTransparency)
            << ",\"textXAlignment\":" << jsonString(g->textXAlignment)
            << ",\"textYAlignment\":" << jsonString(g->textYAlignment)
            << ",\"textScaled\":" << jsonBool(g->textScaled)
            << ",\"textWrapped\":" << jsonBool(g->textWrapped)
            << ",\"richText\":" << jsonBool(g->richText)
            << ",\"font\":" << jsonString(g->font)
            << ",\"lineHeight\":" << jsonNumber(g->lineHeight)
            << ",\"maxVisibleGraphemes\":" << jsonNumber((double)g->maxVisibleGraphemes)
            << ",\"textStrokeColor\":" << colorJSON(g->textStrokeColor)
            << ",\"textStrokeTransparency\":" << jsonNumber(g->textStrokeTransparency)
            << ",\"textTruncate\":" << jsonString(g->textTruncate)
            << ",\"placeholderText\":" << jsonString(g->placeholderText)
            << ",\"placeholderColor\":" << colorJSON(g->placeholderColor)
            << ",\"clearTextOnFocus\":" << jsonBool(g->clearTextOnFocus)
            << ",\"multiLine\":" << jsonBool(g->multiLine)
            << ",\"textEditable\":" << jsonBool(g->textEditable)
            << ",\"image\":" << jsonString(g->image)
            << ",\"imageTransparency\":" << jsonNumber(g->imageTransparency)
            << ",\"imageColor\":" << colorJSON(g->imageColor)
            << ",\"scaleType\":" << jsonString(g->scaleType)
            << ",\"imageRectOffsetX\":" << jsonNumber(g->imageRectOffset.x)
            << ",\"imageRectOffsetY\":" << jsonNumber(g->imageRectOffset.y)
            << ",\"imageRectSizeX\":" << jsonNumber(g->imageRectSize.x)
            << ",\"imageRectSizeY\":" << jsonNumber(g->imageRectSize.y)
            << ",\"sliceScale\":" << jsonNumber(g->sliceScale)
            << ",\"hoverImage\":" << jsonString(g->hoverImage)
            << ",\"pressedImage\":" << jsonString(g->pressedImage)
            << ",\"scrollCanvasSX\":" << jsonNumber(g->scrollCanvasSize.x.scale)
            << ",\"scrollCanvasOX\":" << jsonNumber(g->scrollCanvasSize.x.offset)
            << ",\"scrollCanvasSY\":" << jsonNumber(g->scrollCanvasSize.y.scale)
            << ",\"scrollCanvasOY\":" << jsonNumber(g->scrollCanvasSize.y.offset)
            << ",\"canvasPosX\":" << jsonNumber(g->canvasPosition.x)
            << ",\"canvasPosY\":" << jsonNumber(g->canvasPosition.y)
            << ",\"scrollingEnabled\":" << jsonBool(g->scrollingEnabled)
            << ",\"scrollBarThickness\":" << jsonNumber(g->scrollBarThickness)
            << ",\"scrollBarImageColor\":" << colorJSON(g->scrollBarImageColor)
            << ",\"scrollBarImageTransparency\":" << jsonNumber(g->scrollBarImageTransparency)
            << ",\"scrollingDirection\":" << jsonString(g->scrollingDirection)
            << ",\"elasticBehavior\":" << jsonString(g->elasticBehavior)
            << ",\"automaticCanvasSize\":" << jsonString(g->automaticCanvasSize)
            << ",\"horizontalScrollBarInset\":" << jsonString(g->horizontalScrollBarInset)
            << ",\"verticalScrollBarInset\":" << jsonString(g->verticalScrollBarInset);
    }
    else if (instance->getType() == InstanceType::UICorner ||
             instance->getType() == InstanceType::UIStroke ||
             instance->getType() == InstanceType::UIListLayout ||
             instance->getType() == InstanceType::UIPadding ||
             instance->getType() == InstanceType::UIGridLayout ||
             instance->getType() == InstanceType::UIAspectRatioConstraint)
    {
        const UIModifierInstance* m = static_cast<const UIModifierInstance*>(instance);
        out << ",\"cornerRadiusS\":" << jsonNumber(m->cornerRadius.scale)
            << ",\"cornerRadiusO\":" << jsonNumber(m->cornerRadius.offset)
            << ",\"strokeEnabled\":" << jsonBool(m->strokeEnabled)
            << ",\"strokeThickness\":" << jsonNumber(m->strokeThickness)
            << ",\"strokeColor\":" << colorJSON(m->strokeColor)
            << ",\"strokeTransparency\":" << jsonNumber(m->strokeTransparency)
            << ",\"strokeApplyStrokeMode\":" << jsonString(m->strokeApplyStrokeMode)
            << ",\"lineJoinMode\":" << jsonString(m->lineJoinMode)
            << ",\"fillDirection\":" << jsonString(m->fillDirection)
            << ",\"horizontalAlignment\":" << jsonString(m->horizontalAlignment)
            << ",\"verticalAlignment\":" << jsonString(m->verticalAlignment)
            << ",\"sortOrder\":" << jsonString(m->sortOrder)
            << ",\"listPaddingO\":" << jsonNumber(m->listPadding.offset)
            << ",\"paddingPx\":" << jsonNumber((double)m->paddingPx)
            << ",\"wraps\":" << jsonBool(m->wraps)
            << ",\"paddingLeftO\":" << jsonNumber(m->paddingLeft.offset)
            << ",\"paddingRightO\":" << jsonNumber(m->paddingRight.offset)
            << ",\"paddingTopO\":" << jsonNumber(m->paddingTop.offset)
            << ",\"paddingBottomO\":" << jsonNumber(m->paddingBottom.offset)
            << ",\"cellSizeOX\":" << jsonNumber(m->cellSize.x.offset)
            << ",\"cellSizeOY\":" << jsonNumber(m->cellSize.y.offset)
            << ",\"cellPaddingOX\":" << jsonNumber(m->cellPadding.x.offset)
            << ",\"cellPaddingOY\":" << jsonNumber(m->cellPadding.y.offset)
            << ",\"fillDirectionMaxCells\":" << jsonNumber((double)m->fillDirectionMaxCells)
            << ",\"aspectRatio\":" << jsonNumber(m->aspectRatio)
            << ",\"aspectType\":" << jsonString(m->aspectType)
            << ",\"dominantAxis\":" << jsonString(m->dominantAxis);
    }

    out << ",\"children\":[";
    bool firstChild = true;
    for (const Instance* child : instance->children)
    {
        if (child == characterRigModule)
            continue;
        if (!firstChild) out << ',';
        firstChild = false;
        out << serializeInstanceJSON(child);
    }
    out << "]}";
    return out.str();
}

string serializeProjectJSON()
{
    projectSerializationScriptIndex = 0;
    projectSerializationAssetIndex = 0;
    if (serializeProjectForRuntime)
        projectSerializationFailed = false;
    ostringstream out;
    out << "{\"format\":\"BuildingToolProject\",\"version\":\"1.0\",\"name\":"
        << jsonString(projectName) << ",\"sun\":{\"direction\":" << vec3JSON(sun.direction)
        << ",\"color\":" << colorJSON(sun.color)
        << ",\"intensity\":" << jsonNumber(sun.intensity)
        << ",\"ambient\":" << jsonNumber(sun.ambient) << "}"
        << ",\"lighting\":{\"ambient\":" << colorJSON(lightingSettings.ambient)
        << ",\"outdoorAmbient\":" << colorJSON(lightingSettings.outdoorAmbient)
        << ",\"colorShiftBottom\":" << colorJSON(lightingSettings.colorShiftBottom)
        << ",\"colorShiftTop\":" << colorJSON(lightingSettings.colorShiftTop)
        << ",\"fogColor\":" << colorJSON(lightingSettings.fogColor)
        << ",\"fogStart\":" << jsonNumber(lightingSettings.fogStart)
        << ",\"fogEnd\":" << jsonNumber(lightingSettings.fogEnd)
        << ",\"brightness\":" << jsonNumber(lightingSettings.brightness)
        << ",\"exposureCompensation\":" << jsonNumber(lightingSettings.exposureCompensation)
        << ",\"environmentDiffuseScale\":" << jsonNumber(lightingSettings.environmentDiffuseScale)
        << ",\"environmentSpecularScale\":" << jsonNumber(lightingSettings.environmentSpecularScale)
        << ",\"globalShadows\":" << jsonBool(lightingSettings.globalShadows)
        << ",\"shadowSoftness\":" << jsonString(lightingSettings.shadowSoftness)
        << ",\"clockTime\":" << jsonNumber(lightingSettings.clockTime)
        << ",\"geographicLatitude\":" << jsonNumber(lightingSettings.geographicLatitude)
        << ",\"blur\":" << jsonNumber(lightingSettings.blur) << "}"
        << ",\"gameSettings\":{\"graphicsQuality\":" << gameSettings.graphicsQuality << "}"
        << ",\"children\":[";
    for (size_t i = 0; i < game.children.size(); ++i)
    {
        if (i) out << ',';
        out << serializeInstanceJSON(game.children[i]);
    }
    out << "],\"assets\":[";
    for (size_t i = 0; i < projectAssets.size(); ++i)
    {
        if (i) out << ',';
        const ProjectAsset& a = projectAssets[i];
        out << "{\"id\":" << jsonString(a.id)
            << ",\"name\":" << jsonString(a.name)
            << ",\"type\":" << jsonString(assetTypeName(a.type))
            << ",\"fileType\":" << jsonString(a.fileType)
            << ",\"compressed\":" << jsonBool(a.compressed);
        if (projectStorageMultiFile && !serializeProjectForRuntime)
            out << ",\"file\":" << jsonString("Assets/asset_" +
                to_string(projectSerializationAssetIndex++) + "." + sanitizeFileToken(a.fileType));
        else
            out << ",\"data\":" << jsonString(base64Encode(a.data));
        out << "}";
    }
    out << "]}";
    return out.str();
}

string serializeProjectStateJSON()
{
    bool previousMultiFile = projectStorageMultiFile;
    bool previousRuntimeMode = serializeProjectForRuntime;
    projectStorageMultiFile = false;
    serializeProjectForRuntime = false;
    string snapshot = serializeProjectJSON();
    projectStorageMultiFile = previousMultiFile;
    serializeProjectForRuntime = previousRuntimeMode;
    return snapshot;
}

void loadCustomEditorThemes()
{
    customEditorThemes.clear();
    vector<filesystem::path> themeDirectories = { filesystem::current_path() / "themes" };
    char modulePath[MAX_PATH] = {};
    DWORD modulePathLength = GetModuleFileNameA(nullptr, modulePath, MAX_PATH);
    if (modulePathLength > 0 && modulePathLength < MAX_PATH)
    {
        filesystem::path executableDirectory = filesystem::path(modulePath).parent_path();
        themeDirectories.push_back(executableDirectory / "themes");
        themeDirectories.push_back(executableDirectory / "assets" / "themes");
    }

    sort(themeDirectories.begin(), themeDirectories.end());
    themeDirectories.erase(unique(themeDirectories.begin(), themeDirectories.end()), themeDirectories.end());
    unordered_set<string> loadedThemeNames;
    int loadedCount = 0;
    for (const filesystem::path& directory : themeDirectories)
    {
        error_code directoryError;
        if (!filesystem::is_directory(directory, directoryError) || directoryError)
            continue;

        filesystem::directory_iterator entry(directory, directoryError);
        filesystem::directory_iterator end;
        while (!directoryError && entry != end)
        {
            filesystem::directory_entry file = *entry;
            entry.increment(directoryError);
            error_code fileError;
            if (!file.is_regular_file(fileError) || fileError || file.path().extension() != ".json")
                continue;

            ifstream input(file.path(), ios::binary);
            if (!input)
                continue;
            string content((istreambuf_iterator<char>(input)), istreambuf_iterator<char>());
            JsonParser parser(content);
            JsonValue root;
            if (!parser.parse(root) || root.type != JsonValue::Type::Object)
                continue;

            CustomEditorTheme theme;
            theme.name = jsonStringValue(root.get("name"), file.path().stem().string());
            if (theme.name.empty() || theme.name == "Dark" || theme.name == "Light" ||
                theme.name == "Gray" || theme.name == "Orange" || !loadedThemeNames.insert(theme.name).second)
                continue;

            const JsonValue* ui = root.get("ui");
            const JsonValue* script = root.get("script");
            const JsonValue* legacyScript = root.get("theme");
            if (ui != nullptr)
            {
                theme.ui.canvas = jsonColor(ui->get("canvas"), theme.ui.canvas);
                theme.ui.panel = jsonColor(ui->get("panel"), theme.ui.panel);
                theme.ui.header = jsonColor(ui->get("header"), theme.ui.header);
                theme.ui.surface = jsonColor(ui->get("surface"), theme.ui.surface);
                theme.ui.border = jsonColor(ui->get("border"), theme.ui.border);
                theme.ui.text = jsonColor(ui->get("text"), theme.ui.text);
                theme.ui.muted = jsonColor(ui->get("muted"), theme.ui.muted);
                theme.ui.accent = jsonColor(ui->get("accent"), theme.ui.accent);
                theme.ui.accentHover = jsonColor(ui->get("accentHover"), theme.ui.accentHover);
                theme.ui.selected = jsonColor(ui->get("selected"), theme.ui.selected);
                const JsonValue* gradientStart = ui->get("gradientStart");
                const JsonValue* gradientEnd = ui->get("gradientEnd");
                if (gradientStart != nullptr && gradientEnd != nullptr)
                {
                    theme.ui.gradientStart = jsonColor(gradientStart, theme.ui.gradientStart);
                    theme.ui.gradientEnd = jsonColor(gradientEnd, theme.ui.gradientEnd);
                    theme.ui.hasGradient = true;
                    theme.ui.gradientStops = { { 0.0f, theme.ui.gradientStart }, { 1.0f, theme.ui.gradientEnd } };
                }
                const JsonValue* gradient = ui->get("gradient");
                if (gradient != nullptr && gradient->type == JsonValue::Type::Array)
                {
                    vector<ThemeGradientStop> stops;
                    for (const JsonValue& stopValue : gradient->array)
                    {
                        if (stopValue.type != JsonValue::Type::Object)
                            continue;
                        ThemeGradientStop stop;
                        stop.time = std::clamp((float)jsonFloat(stopValue.get("time"), -1.0f), 0.0f, 1.0f);
                        const JsonValue* stopColor = stopValue.get("color");
                        if (stopColor == nullptr)
                            continue;
                        stop.color = jsonColor(stopColor, theme.ui.canvas);
                        stops.push_back(stop);
                    }
                    sort(stops.begin(), stops.end(), [](const ThemeGradientStop& a, const ThemeGradientStop& b)
                    {
                        return a.time < b.time;
                    });
                    if (stops.size() >= 2)
                    {
                        theme.ui.gradientStops = std::move(stops);
                        theme.ui.gradientStart = theme.ui.gradientStops.front().color;
                        theme.ui.gradientEnd = theme.ui.gradientStops.back().color;
                        theme.ui.hasGradient = true;
                    }
                }
            }
            const JsonValue* icons = root.get("icons");
            if (icons != nullptr && icons->type == JsonValue::Type::Object)
            {
                const JsonValue* set = icons->get("set");
                const JsonValue* instances = icons->get("instances");
                const JsonValue* single = icons->get("single");
                const JsonValue* misc = icons->get("misc");
                const JsonValue* ribbons = icons->get("ribbons");
                auto loadColorMap = [&](const JsonValue* map, unordered_map<string, Color>& destination)
                {
                    if (map == nullptr || map->type != JsonValue::Type::Object)
                        return;
                    for (const auto& entry : map->object)
                        if (entry.second.type == JsonValue::Type::Array)
                            destination[entry.first] = jsonColor(&entry.second, theme.ui.accent);
                };
                loadColorMap(set, theme.iconSetColors);
                loadColorMap(instances, theme.iconInstanceColors);
                loadColorMap(single, theme.iconInstanceColors);
                loadColorMap(misc, theme.iconMiscColors);
                auto loadRibbonColors = [&](const JsonValue* map)
                {
                    if (map == nullptr || map->type != JsonValue::Type::Object)
                        return;
                    for (const auto& entry : map->object)
                    {
                        if (entry.second.type == JsonValue::Type::Array)
                            theme.ribbonColors[entry.first] = jsonColor(&entry.second, theme.ui.accent);
                        else if (entry.second.type == JsonValue::Type::Object)
                            loadColorMap(&entry.second, theme.ribbonColors);
                    }
                };
                loadRibbonColors(ribbons);
            }
            const JsonValue* ribbonSettings = root.get("ribbons");
            if (ribbonSettings != nullptr && ribbonSettings->type == JsonValue::Type::Object)
            {
                for (const auto& entry : ribbonSettings->object)
                {
                    if (entry.second.type == JsonValue::Type::Array)
                        theme.ribbonColors[entry.first] = jsonColor(&entry.second, theme.ui.accent);
                    else if (entry.second.type == JsonValue::Type::Object)
                        for (const auto& action : entry.second.object)
                            if (action.second.type == JsonValue::Type::Array)
                                theme.ribbonColors[action.first] = jsonColor(&action.second, theme.ui.accent);
                }
            }
            if (script == nullptr)
                script = legacyScript;
            if (script != nullptr)
            {
                theme.scriptBackground = jsonColor(script->get("background"), theme.scriptBackground);
                theme.scriptGutter = jsonColor(script->get("gutter"), theme.scriptGutter);
                theme.scriptText = jsonColor(script->get("text"), theme.scriptText);
                theme.scriptComment = jsonColor(script->get("comment"), theme.scriptComment);
                theme.scriptString = jsonColor(script->get("string"), theme.scriptString);
                theme.scriptKeyword = jsonColor(script->get("keyword"), theme.scriptKeyword);
                theme.scriptLiteral = jsonColor(script->get("literal"), theme.scriptLiteral);
                theme.scriptFunction = jsonColor(script->get("function"), theme.scriptFunction);
                theme.scriptNumber = jsonColor(script->get("number"), theme.scriptNumber);
                theme.scriptBuiltin = jsonColor(script->get("builtin"), theme.scriptBuiltin);
                theme.scriptOperator = jsonColor(script->get("operator"), theme.scriptOperator);
                theme.scriptType = jsonColor(script->get("type"), theme.scriptType);
                theme.scriptSelection = jsonColor(script->get("selection"), theme.scriptSelection);
                theme.scriptFindHighlight = jsonColor(script->get("findHighlight"), theme.scriptFindHighlight);
            }
            customEditorThemes.push_back(theme);
            loadedCount++;
        }
    }
    addOutputLog(TextFormat("[Themes] Loaded %d custom theme(s)", loadedCount));
}

string getStudioSettingsPath()
{
    return makeTempFilePath("studio_settings.json");
}

void saveStudioSettings()
{
    ensureDefaultProjectFonts();
    ostringstream out;
    out << "{\n";
    out << "  \"showGrid\":" << (studioSettings.showGrid ? "true" : "false") << ",\n";
    out << "  \"showActionBar\":" << (studioSettings.showActionBar ? "true" : "false") << ",\n";
    out << "  \"showRibbonBar\":" << (studioSettings.showRibbonBar ? "true" : "false") << ",\n";
    out << "  \"showWindowBar\":" << (studioSettings.showWindowBar ? "true" : "false") << ",\n";
    out << "  \"theme\":" << jsonString(studioSettings.theme) << ",\n";
    out << "  \"vsync\":" << (studioSettings.vsync ? "true" : "false") << ",\n";
    out << "  \"autoSave\":" << (studioSettings.autoSave ? "true" : "false") << ",\n";
    out << "  \"autoSaveMinutes\":" << studioSettings.autoSaveMinutes << ",\n";
    out << "  \"autoSaveCap\":" << studioSettings.autoSaveCap << ",\n";
    out << "  \"iconTint\":" << colorJSON(studioSettings.iconTint) << ",\n";
    out << "  \"iconColorMode\":" << jsonString(studioSettings.iconColorMode) << ",\n";
    out << "  \"colorSlots\":[";
    for (size_t index = 0; index < studioSettings.colorSlots.size(); ++index)
    {
        if (index > 0) out << ",";
        out << colorJSON(studioSettings.colorSlots[index]);
    }
    out << "],\n";
    out << "  \"colorSlotUsed\":[";
    for (size_t index = 0; index < studioSettings.colorSlotUsed.size(); ++index)
    {
        if (index > 0) out << ",";
        out << (studioSettings.colorSlotUsed[index] ? "true" : "false");
    }
    out << "],\n";
    out << "  \"iconGroupColors\":{\n";
    bool firstIconGroup = true;
    for (const auto& group : studioSettings.iconGroupColors)
    {
        if (!firstIconGroup) out << ",\n";
        firstIconGroup = false;
        out << "    " << jsonString(group.first) << ":" << colorJSON(group.second);
    }
    out << "\n  },\n";
    out << "  \"iconIndividualColors\":{\n";
    bool firstIndividualIcon = true;
    for (const auto& icon : iconIndividualColors)
    {
        if (!firstIndividualIcon) out << ",\n";
        firstIndividualIcon = false;
        out << "    " << jsonString(icon.first) << ":" << colorJSON(icon.second);
    }
    out << "\n  },\n";
    out << "  \"targetFps\":" << studioSettings.targetFps << ",\n";
    out << "  \"cameraSpeed\":" << studioSettings.cameraSpeed << ",\n";
    out << "  \"selectedFont\":" << jsonString(studioSelectedFont) << ",\n";
    out << "  \"fonts\":[\n";
    bool first = true;
    for (const auto& e : projectFonts)
    {
        if (!first) out << ",\n";
        first = false;
        out << "    {\"name\":" << jsonString(e.name)
            << ",\"path\":" << jsonString(e.path)
            << ",\"isSystem\":" << (e.isSystem ? "true" : "false")
            << ",\"isImported\":" << ((!e.isSystem && !e.path.empty()) ? "true" : "false")
            << "}";
    }
    out << "\n  ]\n}\n";
    ofstream f(getStudioSettingsPath(), ios::binary);
    if (f) { f << out.str(); f.close(); }
}

void loadStudioSettings()
{
    loadCustomEditorThemes();
    ifstream f(getStudioSettingsPath(), ios::binary);
    if (!f)
    {
        applyStudioScriptTheme();
        updateEditorChromeLayout();
        return;
    }
    string content((istreambuf_iterator<char>(f)), istreambuf_iterator<char>());
    f.close();
    if (content.empty())
    {
        applyStudioScriptTheme();
        updateEditorChromeLayout();
        return;
    }
    JsonParser parser(content);
    JsonValue root;
    if (!parser.parse(root) || root.type != JsonValue::Type::Object)
    {
        applyStudioScriptTheme();
        updateEditorChromeLayout();
        return;
    }
    studioSettings.showGrid = jsonBoolValue(root.get("showGrid"), studioSettings.showGrid);
    studioSettings.showActionBar = jsonBoolValue(root.get("showActionBar"), studioSettings.showActionBar);
    studioSettings.showRibbonBar = jsonBoolValue(root.get("showRibbonBar"), studioSettings.showRibbonBar);
    studioSettings.showWindowBar = jsonBoolValue(root.get("showWindowBar"), studioSettings.showWindowBar);
    studioSettings.theme = jsonStringValue(root.get("theme"), studioSettings.theme);
    bool knownTheme = studioSettings.theme == "Dark" || studioSettings.theme == "Light" ||
        studioSettings.theme == "Gray" || studioSettings.theme == "Orange";
    for (const CustomEditorTheme& theme : customEditorThemes)
        knownTheme = knownTheme || studioSettings.theme == theme.name;
    if (!knownTheme)
        studioSettings.theme = "Dark";
    studioSettings.vsync = jsonBoolValue(root.get("vsync"), studioSettings.vsync);
    studioSettings.autoSave = jsonBoolValue(root.get("autoSave"), studioSettings.autoSave);
    studioSettings.autoSaveMinutes = max(1, (int)jsonFloat(root.get("autoSaveMinutes"), (float)studioSettings.autoSaveMinutes));
    studioSettings.autoSaveCap = max(1, min(20, (int)jsonFloat(root.get("autoSaveCap"), (float)studioSettings.autoSaveCap)));
    studioSettings.iconTint = jsonColor(root.get("iconTint"), studioSettings.iconTint);
    studioSettings.iconColorMode = jsonStringValue(root.get("iconColorMode"), studioSettings.iconColorMode);
    if (studioSettings.iconColorMode != "Mono" && studioSettings.iconColorMode != "Colorful" &&
        studioSettings.iconColorMode != "Theme" && studioSettings.iconColorMode != "Advanced")
        studioSettings.iconColorMode = "Mono";
    if (const JsonValue* colorSlots = root.get("colorSlots"))
    {
        if (colorSlots->type == JsonValue::Type::Array)
            for (size_t index = 0; index < min(studioSettings.colorSlots.size(), colorSlots->array.size()); ++index)
                studioSettings.colorSlots[index] = jsonColor(&colorSlots->array[index], studioSettings.colorSlots[index]);
    }
    if (const JsonValue* colorSlotUsed = root.get("colorSlotUsed"))
    {
        if (colorSlotUsed->type == JsonValue::Type::Array)
            for (size_t index = 0; index < min(studioSettings.colorSlotUsed.size(), colorSlotUsed->array.size()); ++index)
                studioSettings.colorSlotUsed[index] = jsonBoolValue(&colorSlotUsed->array[index], false);
    }
    if (const JsonValue* iconGroups = root.get("iconGroupColors"))
        for (const auto& group : studioSettings.iconGroupColors)
            studioSettings.iconGroupColors[group.first] = jsonColor(iconGroups->get(group.first), group.second);
    if (const JsonValue* iconColors = root.get("iconIndividualColors"))
    {
        for (const auto& entry : iconColors->object)
            iconIndividualColors[entry.first] = jsonColor(&entry.second, WHITE);
    }
    studioSettings.targetFps = (int)jsonFloat(root.get("targetFps"), (float)studioSettings.targetFps);
    studioSettings.cameraSpeed = jsonFloat(root.get("cameraSpeed"), studioSettings.cameraSpeed);
    studioSelectedFont = jsonStringValue(root.get("selectedFont"), studioSelectedFont);
    ensureDefaultProjectFonts();
    const JsonValue* fonts = root.get("fonts");
    if (fonts && fonts->type == JsonValue::Type::Array)
    {
        for (const JsonValue& fe : fonts->array)
        {
            if (fe.type != JsonValue::Type::Object) continue;
            string name = jsonStringValue(fe.get("name"));
            string fpath = jsonStringValue(fe.get("path"));
            bool isSys = jsonBoolValue(fe.get("isSystem"), false);
            if (name.empty()) continue;
            bool exists = false;
            for (const auto& e : projectFonts)
                if (e.name == name) { exists = true; break; }
            if (exists) continue;
            ProjectFontEntry e;
            e.name = name;
            e.path = fpath;
            e.isSystem = isSys;
            if (!fpath.empty() && !isSys && filesystem::exists(fpath))
            {
                e.font = LoadFontEx(fpath.c_str(), 32, 0, 250);
                e.loaded = e.font.glyphCount > 0;
            }
            projectFonts.push_back(e);
        }
    }
    Font* font = resolveProjectFont(studioSelectedFont);
    if (font && font->glyphCount > 0)
    {
        applicationFont = *font;
        applicationFontLoaded = true;
    }
    // Apply general settings immediately after load
    SetTargetFPS(max(30, studioSettings.targetFps));
    if (studioSettings.vsync) SetWindowState(FLAG_VSYNC_HINT);
    else ClearWindowState(FLAG_VSYNC_HINT);
    applyStudioScriptTheme();
    updateEditorChromeLayout();
}


bool readProjectSourceFile(const string& relativePath, string& data)
{
    filesystem::path relative(relativePath);
    if (relative.empty() || relative.is_absolute())
        return false;
    for (const filesystem::path& component : relative)
        if (component == "..")
            return false;
    if (projectSourceRoot.empty())
        return false;
    ifstream file(projectSourceRoot / relative, ios::binary);
    if (!file)
        return false;
    data.assign((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());
    return !file.bad();
}

Instance* deserializeInstanceJSON(const JsonValue& value)
{
    if (value.type != JsonValue::Type::Object) return nullptr;
    string className = jsonStringValue(value.get("class"));
    Instance* instance = nullptr;
    if (className == "Part" || className == "MeshPart") instance = new Part();
    else if (className == "Script") instance = new Script();
    else if (className == "Model") instance = new Model_Instance();
    else if (className == "Folder") instance = new Folder();
    else if (className == "Sound") instance = new SoundInstance();
    else if (className == "Texture") instance = new TextureInstance();
    else if (className == "WeldConstraint") instance = new WeldConstraint();
    else if (className == "Motor6D") instance = new Motor6DConstraint();
    else if (className == "BindableEvent") instance = new BindableEventInstance();
    else if (className == "BindableFunction") instance = new BindableFunctionInstance();
    else if (className == "RemoteEvent") instance = new RemoteEventInstance();
    else if (className == "RemoteFunction") instance = new RemoteFunctionInstance();
    else if (className == "Humanoid") instance = new HumanoidInstance();
    else if (className == "Camera") instance = new CameraInstance();
    else if (className == "PointLight") instance = new PointLightInstance();
    else if (className == "SpotLight") instance = new SpotLightInstance();
    else if (className == "SurfaceLight") instance = new SurfaceLightInstance();
    else if (className == "ScreenGui" || className == "SurfaceGui" || className == "BillboardGui")
    {
        auto* lc = new LayerCollectorInstance();
        if (className == "SurfaceGui") lc->layerType = InstanceType::SurfaceGui;
        else if (className == "BillboardGui") lc->layerType = InstanceType::BillboardGui;
        else lc->layerType = InstanceType::ScreenGui;
        instance = lc;
    }
    else if (className == "Frame" || className == "ScrollingFrame" || className == "TextLabel" ||
             className == "ImageLabel" || className == "TextButton" || className == "ImageButton" ||
             className == "TextBox")
    {
        auto* g = new GuiObjectInstance();
        if (className == "ScrollingFrame") g->guiType = InstanceType::ScrollingFrame;
        else if (className == "TextLabel") { g->guiType = InstanceType::TextLabel; g->text = "Label"; g->backgroundTransparency = 1.0f; }
        else if (className == "ImageLabel") { g->guiType = InstanceType::ImageLabel; g->backgroundTransparency = 1.0f; }
        else if (className == "TextButton") { g->guiType = InstanceType::TextButton; g->text = "Button"; }
        else if (className == "ImageButton") { g->guiType = InstanceType::ImageButton; g->backgroundTransparency = 1.0f; }
        else if (className == "TextBox") { g->guiType = InstanceType::TextBox; g->text = ""; g->placeholderText = "Text here"; }
        else g->guiType = InstanceType::Frame;
        instance = g;
    }
    else if (className == "UICorner" || className == "UIListLayout" || className == "UIStroke" ||
             className == "UIPadding" || className == "UIGridLayout" || className == "UIAspectRatioConstraint")
    {
        auto* m = new UIModifierInstance();
        if (className == "UIListLayout") m->modType = InstanceType::UIListLayout;
        else if (className == "UIStroke") m->modType = InstanceType::UIStroke;
        else if (className == "UIPadding") m->modType = InstanceType::UIPadding;
        else if (className == "UIGridLayout") m->modType = InstanceType::UIGridLayout;
        else if (className == "UIAspectRatioConstraint") m->modType = InstanceType::UIAspectRatioConstraint;
        else m->modType = InstanceType::UICorner;
        instance = m;
    }
    else return nullptr; // Services are owned by the editor and are restored separately.

    instance->name = jsonStringValue(value.get("name"), "Instance");
    instance->id = jsonStringValue(value.get("id"));
    instance->hidden = jsonBoolValue(value.get("hidden"), false);
    if (instance->getType() == InstanceType::Part)
    {
        Part* p = static_cast<Part*>(instance);
        p->isMeshPart = className == "MeshPart";
        p->type = parsePartType(jsonStringValue(value.get("partType")));
        p->anchored = jsonBoolValue(value.get("anchored"), true);
        p->size = jsonVec3(value.get("size"), p->size);
        p->color = jsonColor(value.get("color"), p->color);
        p->cframe.position = jsonVec3(value.get("position"), p->cframe.position);
        p->cframe.rotation = jsonVec3(value.get("rotation"), p->cframe.rotation);
        p->pivotOffset = jsonVec3(value.get("pivotOffset"), p->pivotOffset);
        p->transparency = jsonFloat(value.get("transparency"), 0.0f);
        p->reflectance = jsonFloat(value.get("reflectance"), 0.0f);
        p->castShadow = jsonBoolValue(value.get("castShadow"), true);
        p->canCollide = jsonBoolValue(value.get("canCollide"), true);
        p->truss = jsonBoolValue(value.get("truss"), false);
        p->locked = jsonBoolValue(value.get("locked"), false);
        p->advancedPhysics = jsonBoolValue(value.get("advancedPhysics"), false);
        p->density = std::clamp(jsonFloat(value.get("density"), p->density), 0.01f, 100.0f);
        p->friction = std::clamp(jsonFloat(value.get("friction"), p->friction), 0.0f, 1.0f);
        if (p->isMeshPart)
        {
            p->meshId = jsonStringValue(value.get("meshId"));
            p->textureId = jsonStringValue(value.get("textureId"));
            p->collisionFidelity = parseCollisionFidelity(
                jsonStringValue(value.get("collisionFidelity"), "Default"));
        }
    }
    else if (instance->getType() == InstanceType::PointLight)
    {
        auto* L = static_cast<PointLightInstance*>(instance);
        L->color = jsonColor(value.get("color"), L->color);
        L->brightness = std::clamp(jsonFloat(value.get("brightness"), L->brightness), 0.0f, 200.0f);
        L->range = std::clamp(jsonFloat(value.get("range"), L->range), 0.0f, 200.0f);
        L->shadows = jsonBoolValue(value.get("shadows"), L->shadows);
        L->enabled = jsonBoolValue(value.get("enabled"), L->enabled);
    }
    else if (instance->getType() == InstanceType::SpotLight)
    {
        auto* L = static_cast<SpotLightInstance*>(instance);
        L->color = jsonColor(value.get("color"), L->color);
        L->brightness = std::clamp(jsonFloat(value.get("brightness"), L->brightness), 0.0f, 200.0f);
        L->range = std::clamp(jsonFloat(value.get("range"), L->range), 0.0f, 200.0f);
        L->angle = std::clamp(jsonFloat(value.get("angle"), L->angle), 0.0f, 180.0f);
        L->face = jsonStringValue(value.get("face"), L->face);
        L->shadows = jsonBoolValue(value.get("shadows"), L->shadows);
        L->enabled = jsonBoolValue(value.get("enabled"), L->enabled);
    }
    else if (instance->getType() == InstanceType::SurfaceLight)
    {
        auto* L = static_cast<SurfaceLightInstance*>(instance);
        L->color = jsonColor(value.get("color"), L->color);
        L->brightness = std::clamp(jsonFloat(value.get("brightness"), L->brightness), 0.0f, 200.0f);
        L->range = std::clamp(jsonFloat(value.get("range"), L->range), 0.0f, 200.0f);
        L->angle = std::clamp(jsonFloat(value.get("angle"), L->angle), 0.0f, 180.0f);
        L->face = jsonStringValue(value.get("face"), L->face);
        L->shadows = jsonBoolValue(value.get("shadows"), L->shadows);
        L->enabled = jsonBoolValue(value.get("enabled"), L->enabled);
    }
    else if (instance->getType() == InstanceType::Script)
    {
        Script* s = static_cast<Script*>(instance);
        s->type = parseScriptType(jsonStringValue(value.get("scriptType")));
        // Prefer explicit runContext if present (Server/Client/Module)
        string rc = jsonStringValue(value.get("runContext"));
        if (!rc.empty())
            s->setRunContext(rc);
        s->enabled = jsonBoolValue(value.get("enabled"), true);
        s->source = jsonStringValue(value.get("source"), "");
        s->compiledBytecode = jsonStringValue(value.get("bytecode"));
        string sourceFile = jsonStringValue(value.get("sourceFile"));
        if (!sourceFile.empty() && !readProjectSourceFile(sourceFile, s->source))
            addOutputLog("[Error] Could not load script source: " + sourceFile);
    }
    else if (instance->getType() == InstanceType::Model)
    {
        Model_Instance* m = static_cast<Model_Instance*>(instance);
        m->scale = jsonFloat(value.get("scale"), 1.0f);
        m->pivotOffset = jsonVec3(value.get("pivotOffset"), m->pivotOffset);
        string pp = jsonStringValue(value.get("primaryPart"));
        if (!pp.empty())
            pendingInstanceRefs.push_back({ instance, "PrimaryPart", pp });
    }
    else if (instance->getType() == InstanceType::Humanoid)
    {
        HumanoidInstance* h = static_cast<HumanoidInstance*>(instance);
        h->health = jsonFloat(value.get("health"), 100.0f);
        h->maxHealth = jsonFloat(value.get("maxHealth"), 100.0f);
        h->walkSpeed = jsonFloat(value.get("walkSpeed"), 16.0f);
        h->jumpPower = jsonFloat(value.get("jumpPower"), 50.0f);
        h->hipHeight = jsonFloat(value.get("hipHeight"), 3.0f);
        h->slopeAngle = jsonFloat(value.get("slopeAngle"), 45.0f);
        string rp = jsonStringValue(value.get("rootPart"));
        if (!rp.empty())
            pendingInstanceRefs.push_back({ instance, "RootPart", rp });
    }
    else if (instance->getType() == InstanceType::WeldConstraint)
    {
        WeldConstraint* w = static_cast<WeldConstraint*>(instance);
        w->enabled = jsonBoolValue(value.get("enabled"), true);
        string p0 = jsonStringValue(value.get("part0"));
        string p1 = jsonStringValue(value.get("part1"));
        if (!p0.empty()) pendingInstanceRefs.push_back({ instance, "Part0", p0 });
        if (!p1.empty()) pendingInstanceRefs.push_back({ instance, "Part1", p1 });
    }
    else if (instance->getType() == InstanceType::Motor6D)
    {
        Motor6DConstraint* m = static_cast<Motor6DConstraint*>(instance);
        m->enabled = jsonBoolValue(value.get("enabled"), true);
        m->desiredAngle = jsonFloat(value.get("desiredAngle"), 0.0f);
        m->maxVelocity = jsonFloat(value.get("maxVelocity"), 0.0f);
        m->c0.position = jsonVec3(value.get("c0"), m->c0.position);
        m->c1.position = jsonVec3(value.get("c1"), m->c1.position);
        m->c0.rotation = jsonVec3(value.get("c0rot"), m->c0.rotation);
        m->c1.rotation = jsonVec3(value.get("c1rot"), m->c1.rotation);
        string p0 = jsonStringValue(value.get("part0"));
        string p1 = jsonStringValue(value.get("part1"));
        if (!p0.empty()) pendingInstanceRefs.push_back({ instance, "Part0", p0 });
        if (!p1.empty()) pendingInstanceRefs.push_back({ instance, "Part1", p1 });
    }
    else if (instance->getType() == InstanceType::Camera)
    {
        CameraInstance* c = static_cast<CameraInstance*>(instance);
        c->cframe.position = jsonVec3(value.get("position"), c->cframe.position);
        c->cframe.rotation = jsonVec3(value.get("rotation"), c->cframe.rotation);
        string tg = jsonStringValue(value.get("target"));
        if (!tg.empty()) pendingInstanceRefs.push_back({ instance, "Target", tg });
    }
    else if (instance->getType() == InstanceType::ScreenGui ||
             instance->getType() == InstanceType::SurfaceGui ||
             instance->getType() == InstanceType::BillboardGui)
    {
        LayerCollectorInstance* lc = static_cast<LayerCollectorInstance*>(instance);
        lc->enabled = jsonBoolValue(value.get("enabled"), true);
        lc->displayOrder = (int)jsonFloat(value.get("displayOrder"), 0.0f);
        lc->resetOnSpawn = jsonBoolValue(value.get("resetOnSpawn"), true);
        lc->ignoreGuiInset = jsonBoolValue(value.get("ignoreGuiInset"), false);
        lc->clipToDeviceSafeArea = jsonBoolValue(value.get("clipToDeviceSafeArea"), true);
        lc->alwaysOnTop = jsonBoolValue(value.get("alwaysOnTop"), false);
        lc->maxDistance = jsonFloat(value.get("maxDistance"), 0.0f);
        lc->lightInfluence = jsonFloat(value.get("lightInfluence"), 0.0f);
        lc->pixelsPerStud = jsonFloat(value.get("pixelsPerStud"), 50.0f);
        lc->face = jsonStringValue(value.get("face"), lc->face);
        lc->brightness = jsonFloat(value.get("brightness"), 1.0f);
        lc->active = jsonBoolValue(value.get("active"), true);
        lc->clipsDescendants = jsonBoolValue(value.get("clipsDescendants"), false);
        lc->canvasSize.x = jsonFloat(value.get("canvasSizeX"), lc->canvasSize.x);
        lc->canvasSize.y = jsonFloat(value.get("canvasSizeY"), lc->canvasSize.y);
        lc->sizingMode = jsonStringValue(value.get("sizingMode"), lc->sizingMode);
        lc->zOffset = jsonFloat(value.get("zOffset"), 0.0f);
        lc->studsOffset.x = jsonFloat(value.get("studsOffsetX"), 0.0f);
        lc->studsOffset.y = jsonFloat(value.get("studsOffsetY"), 0.0f);
        lc->studsOffset.z = jsonFloat(value.get("studsOffsetZ"), 0.0f);
        lc->distanceLowerLimit = jsonFloat(value.get("distanceLowerLimit"), 0.0f);
        lc->distanceUpperLimit = jsonFloat(value.get("distanceUpperLimit"), 0.0f);
        lc->billboardSize.x.scale = jsonFloat(value.get("bbSizeSX"), lc->billboardSize.x.scale);
        lc->billboardSize.x.offset = jsonFloat(value.get("bbSizeOX"), lc->billboardSize.x.offset);
        lc->billboardSize.y.scale = jsonFloat(value.get("bbSizeSY"), lc->billboardSize.y.scale);
        lc->billboardSize.y.offset = jsonFloat(value.get("bbSizeOY"), lc->billboardSize.y.offset);
        string ad = jsonStringValue(value.get("adornee"));
        if (!ad.empty()) pendingInstanceRefs.push_back({ instance, "Adornee", ad });
    }
    else if (instance->getType() == InstanceType::Frame ||
             instance->getType() == InstanceType::ScrollingFrame ||
             instance->getType() == InstanceType::TextLabel ||
             instance->getType() == InstanceType::ImageLabel ||
             instance->getType() == InstanceType::TextButton ||
             instance->getType() == InstanceType::ImageButton ||
             instance->getType() == InstanceType::TextBox)
    {
        GuiObjectInstance* g = static_cast<GuiObjectInstance*>(instance);
        g->size.x.scale = jsonFloat(value.get("sizeSX"), g->size.x.scale);
        g->size.x.offset = jsonFloat(value.get("sizeOX"), g->size.x.offset);
        g->size.y.scale = jsonFloat(value.get("sizeSY"), g->size.y.scale);
        g->size.y.offset = jsonFloat(value.get("sizeOY"), g->size.y.offset);
        g->position.x.scale = jsonFloat(value.get("posSX"), g->position.x.scale);
        g->position.x.offset = jsonFloat(value.get("posOX"), g->position.x.offset);
        g->position.y.scale = jsonFloat(value.get("posSY"), g->position.y.scale);
        g->position.y.offset = jsonFloat(value.get("posOY"), g->position.y.offset);
        g->anchorPoint.x = jsonFloat(value.get("anchorX"), 0.0f);
        g->anchorPoint.y = jsonFloat(value.get("anchorY"), 0.0f);
        g->automaticSize = jsonStringValue(value.get("automaticSize"), g->automaticSize);
        g->sizeConstraint = jsonStringValue(value.get("sizeConstraint"), g->sizeConstraint);
        g->layoutOrder = (int)jsonFloat(value.get("layoutOrder"), (float)g->layoutOrder);
        g->rotation = jsonFloat(value.get("rotation"), 0.0f);
        g->backgroundColor = jsonColor(value.get("bgColor"), g->backgroundColor);
        g->backgroundTransparency = jsonFloat(value.get("bgTransparency"), 0.0f);
        g->borderSizePixel = (int)jsonFloat(value.get("borderSize"), 0.0f);
        g->borderColor = jsonColor(value.get("borderColor"), g->borderColor);
        g->borderMode = jsonStringValue(value.get("borderMode"), g->borderMode);
        g->visible = jsonBoolValue(value.get("visible"), true);
        g->zIndex = (int)jsonFloat(value.get("zIndex"), 1.0f);
        g->clipsDescendants = jsonBoolValue(value.get("clipsDescendants"), false);
        g->groupTransparency = jsonFloat(value.get("groupTransparency"), 0.0f);
        g->active = jsonBoolValue(value.get("active"), true);
        g->interactable = jsonBoolValue(value.get("interactable"), true);
        g->selectable = jsonBoolValue(value.get("selectable"), false);
        g->selectionOrder = (int)jsonFloat(value.get("selectionOrder"), 0.0f);
        g->autoButtonColor = jsonBoolValue(value.get("autoButtonColor"), true);
        g->modal = jsonBoolValue(value.get("modal"), false);
        g->text = jsonStringValue(value.get("text"), g->text);
        g->textSize = (int)jsonFloat(value.get("textSize"), (float)g->textSize);
        g->textColor = jsonColor(value.get("textColor"), g->textColor);
        g->textTransparency = jsonFloat(value.get("textTransparency"), 0.0f);
        g->textXAlignment = jsonStringValue(value.get("textXAlignment"), g->textXAlignment);
        g->textYAlignment = jsonStringValue(value.get("textYAlignment"), g->textYAlignment);
        g->textScaled = jsonBoolValue(value.get("textScaled"), false);
        g->textWrapped = jsonBoolValue(value.get("textWrapped"), false);
        g->richText = jsonBoolValue(value.get("richText"), false);
        g->font = jsonStringValue(value.get("font"), g->font);
        g->lineHeight = jsonFloat(value.get("lineHeight"), 1.0f);
        g->maxVisibleGraphemes = (int)jsonFloat(value.get("maxVisibleGraphemes"), -1.0f);
        g->textStrokeColor = jsonColor(value.get("textStrokeColor"), g->textStrokeColor);
        g->textStrokeTransparency = jsonFloat(value.get("textStrokeTransparency"), 1.0f);
        g->textTruncate = jsonStringValue(value.get("textTruncate"), g->textTruncate);
        g->placeholderText = jsonStringValue(value.get("placeholderText"), g->placeholderText);
        g->placeholderColor = jsonColor(value.get("placeholderColor"), g->placeholderColor);
        g->clearTextOnFocus = jsonBoolValue(value.get("clearTextOnFocus"), true);
        g->multiLine = jsonBoolValue(value.get("multiLine"), false);
        g->textEditable = jsonBoolValue(value.get("textEditable"), true);
        g->image = jsonStringValue(value.get("image"), g->image);
        g->imageTransparency = jsonFloat(value.get("imageTransparency"), 0.0f);
        g->imageColor = jsonColor(value.get("imageColor"), g->imageColor);
        g->scaleType = jsonStringValue(value.get("scaleType"), g->scaleType);
        g->imageRectOffset.x = jsonFloat(value.get("imageRectOffsetX"), 0.0f);
        g->imageRectOffset.y = jsonFloat(value.get("imageRectOffsetY"), 0.0f);
        g->imageRectSize.x = jsonFloat(value.get("imageRectSizeX"), 0.0f);
        g->imageRectSize.y = jsonFloat(value.get("imageRectSizeY"), 0.0f);
        g->sliceScale = jsonFloat(value.get("sliceScale"), 1.0f);
        g->hoverImage = jsonStringValue(value.get("hoverImage"), g->hoverImage);
        g->pressedImage = jsonStringValue(value.get("pressedImage"), g->pressedImage);
        g->scrollCanvasSize.x.scale = jsonFloat(value.get("scrollCanvasSX"), 0.0f);
        g->scrollCanvasSize.x.offset = jsonFloat(value.get("scrollCanvasOX"), 0.0f);
        g->scrollCanvasSize.y.scale = jsonFloat(value.get("scrollCanvasSY"), 0.0f);
        g->scrollCanvasSize.y.offset = jsonFloat(value.get("scrollCanvasOY"), 0.0f);
        g->canvasPosition.x = jsonFloat(value.get("canvasPosX"), 0.0f);
        g->canvasPosition.y = jsonFloat(value.get("canvasPosY"), 0.0f);
        g->scrollingEnabled = jsonBoolValue(value.get("scrollingEnabled"), true);
        g->scrollBarThickness = jsonFloat(value.get("scrollBarThickness"), 12.0f);
        g->scrollBarImageColor = jsonColor(value.get("scrollBarImageColor"), g->scrollBarImageColor);
        g->scrollBarImageTransparency = jsonFloat(value.get("scrollBarImageTransparency"), 0.0f);
        g->scrollingDirection = jsonStringValue(value.get("scrollingDirection"), g->scrollingDirection);
        g->elasticBehavior = jsonStringValue(value.get("elasticBehavior"), g->elasticBehavior);
        g->automaticCanvasSize = jsonStringValue(value.get("automaticCanvasSize"), g->automaticCanvasSize);
        g->horizontalScrollBarInset = jsonStringValue(value.get("horizontalScrollBarInset"), g->horizontalScrollBarInset);
        g->verticalScrollBarInset = jsonStringValue(value.get("verticalScrollBarInset"), g->verticalScrollBarInset);
    }
    else if (instance->getType() == InstanceType::UICorner ||
             instance->getType() == InstanceType::UIStroke ||
             instance->getType() == InstanceType::UIListLayout ||
             instance->getType() == InstanceType::UIPadding ||
             instance->getType() == InstanceType::UIGridLayout ||
             instance->getType() == InstanceType::UIAspectRatioConstraint)
    {
        UIModifierInstance* m = static_cast<UIModifierInstance*>(instance);
        m->cornerRadius.scale = jsonFloat(value.get("cornerRadiusS"), m->cornerRadius.scale);
        m->cornerRadius.offset = jsonFloat(value.get("cornerRadiusO"), m->cornerRadius.offset);
        m->strokeEnabled = jsonBoolValue(value.get("strokeEnabled"), true);
        m->strokeThickness = jsonFloat(value.get("strokeThickness"), m->strokeThickness);
        m->strokeColor = jsonColor(value.get("strokeColor"), m->strokeColor);
        m->strokeTransparency = jsonFloat(value.get("strokeTransparency"), 0.0f);
        m->strokeApplyStrokeMode = jsonStringValue(value.get("strokeApplyStrokeMode"), m->strokeApplyStrokeMode);
        m->lineJoinMode = jsonStringValue(value.get("lineJoinMode"), m->lineJoinMode);
        m->fillDirection = jsonStringValue(value.get("fillDirection"), m->fillDirection);
        m->horizontalAlignment = jsonStringValue(value.get("horizontalAlignment"), m->horizontalAlignment);
        m->verticalAlignment = jsonStringValue(value.get("verticalAlignment"), m->verticalAlignment);
        m->sortOrder = jsonStringValue(value.get("sortOrder"), m->sortOrder);
        m->listPadding.offset = jsonFloat(value.get("listPaddingO"), m->listPadding.offset);
        m->paddingPx = (int)jsonFloat(value.get("paddingPx"), (float)m->paddingPx);
        m->wraps = jsonBoolValue(value.get("wraps"), false);
        m->paddingLeft.offset = jsonFloat(value.get("paddingLeftO"), m->paddingLeft.offset);
        m->paddingRight.offset = jsonFloat(value.get("paddingRightO"), m->paddingRight.offset);
        m->paddingTop.offset = jsonFloat(value.get("paddingTopO"), m->paddingTop.offset);
        m->paddingBottom.offset = jsonFloat(value.get("paddingBottomO"), m->paddingBottom.offset);
        m->cellSize.x.offset = jsonFloat(value.get("cellSizeOX"), m->cellSize.x.offset);
        m->cellSize.y.offset = jsonFloat(value.get("cellSizeOY"), m->cellSize.y.offset);
        m->cellPadding.x.offset = jsonFloat(value.get("cellPaddingOX"), m->cellPadding.x.offset);
        m->cellPadding.y.offset = jsonFloat(value.get("cellPaddingOY"), m->cellPadding.y.offset);
        m->fillDirectionMaxCells = (int)jsonFloat(value.get("fillDirectionMaxCells"), 0.0f);
        m->aspectRatio = jsonFloat(value.get("aspectRatio"), m->aspectRatio);
        m->aspectType = jsonStringValue(value.get("aspectType"), m->aspectType);
        m->dominantAxis = jsonStringValue(value.get("dominantAxis"), m->dominantAxis);
    }
    else if (instance->getType() == InstanceType::Sound)
    {
        SoundInstance* s = static_cast<SoundInstance*>(instance);
        s->soundId = jsonStringValue(value.get("soundId"));
        s->volume = jsonFloat(value.get("volume"), 0.5f);
        s->playbackSpeed = jsonFloat(value.get("playbackSpeed"), 1.0f);
        s->looped = jsonBoolValue(value.get("looped"), false);
        s->playing = jsonBoolValue(value.get("playing"), false);
        s->timePosition = jsonFloat(value.get("timePosition"), 0.0f);
        s->rollOffMaxDistance = jsonFloat(value.get("rollOffMaxDistance"), 10000.0f);
        s->rollOffMinDistance = jsonFloat(value.get("rollOffMinDistance"), 10.0f);
    }
    else if (instance->getType() == InstanceType::Texture)
    {
        TextureInstance* t = static_cast<TextureInstance*>(instance);
        t->texture = jsonStringValue(value.get("texture"));
        t->studsPerTileU = jsonFloat(value.get("studsPerTileU"), 2.0f);
        t->studsPerTileV = jsonFloat(value.get("studsPerTileV"), 2.0f);
        t->offsetStudsU = jsonFloat(value.get("offsetStudsU"), 0.0f);
        t->offsetStudsV = jsonFloat(value.get("offsetStudsV"), 0.0f);
        t->transparency = jsonFloat(value.get("transparency"), 0.0f);
        t->color3 = jsonColor(value.get("color3"), t->color3);
        t->face = jsonStringValue(value.get("face"), "Top");
    }

    const JsonValue* children = value.get("children");
    if (children && children->type == JsonValue::Type::Array)
        for (const JsonValue& child : children->array)
            if (Instance* childInstance = deserializeInstanceJSON(child))
                addInstanceToParent(instance, childInstance);
    return instance;
}

bool applyProjectJSON(const string& json)
{
    JsonValue root;
    JsonParser parser(json);
    if (!parser.parse(root) || root.type != JsonValue::Type::Object)
        return false;
    if (jsonStringValue(root.get("format")) != "BuildingToolProject")
        return false;

    resetEditorProjectTree();
    projectName = jsonStringValue(root.get("name"), "Untitled");

    const JsonValue* sunValue = root.get("sun");
    if (sunValue && sunValue->type == JsonValue::Type::Object)
    {
        sun.direction = jsonVec3(sunValue->get("direction"), sun.direction);
        sun.color = jsonColor(sunValue->get("color"), sun.color);
        sun.intensity = jsonFloat(sunValue->get("intensity"), sun.intensity);
        sun.ambient = jsonFloat(sunValue->get("ambient"), sun.ambient);
    }

    const JsonValue* light = root.get("lighting");
    if (light && light->type == JsonValue::Type::Object)
    {
        lightingSettings.ambient = jsonColor(light->get("ambient"), lightingSettings.ambient);
        lightingSettings.outdoorAmbient = jsonColor(light->get("outdoorAmbient"), lightingSettings.outdoorAmbient);
        lightingSettings.colorShiftBottom = jsonColor(light->get("colorShiftBottom"), lightingSettings.colorShiftBottom);
        lightingSettings.colorShiftTop = jsonColor(light->get("colorShiftTop"), lightingSettings.colorShiftTop);
        lightingSettings.fogColor = jsonColor(light->get("fogColor"), lightingSettings.fogColor);
        lightingSettings.fogStart = jsonFloat(light->get("fogStart"), lightingSettings.fogStart);
        lightingSettings.fogEnd = jsonFloat(light->get("fogEnd"), lightingSettings.fogEnd);
        lightingSettings.brightness = jsonFloat(light->get("brightness"), lightingSettings.brightness);
        lightingSettings.exposureCompensation = jsonFloat(light->get("exposureCompensation"), lightingSettings.exposureCompensation);
        lightingSettings.environmentDiffuseScale = jsonFloat(light->get("environmentDiffuseScale"), lightingSettings.environmentDiffuseScale);
        lightingSettings.environmentSpecularScale = jsonFloat(light->get("environmentSpecularScale"), lightingSettings.environmentSpecularScale);
        lightingSettings.globalShadows = jsonBoolValue(light->get("globalShadows"), lightingSettings.globalShadows);
        {
            string soft = jsonStringValue(light->get("shadowSoftness"), lightingSettings.shadowSoftness);
            if (soft == "Hard" || soft == "Soft" || soft == "Sharp")
                lightingSettings.shadowSoftness = soft;
        }
        lightingSettings.clockTime = jsonFloat(light->get("clockTime"), lightingSettings.clockTime);
        lightingSettings.geographicLatitude = jsonFloat(light->get("geographicLatitude"), lightingSettings.geographicLatitude);
        lightingSettings.blur = jsonFloat(light->get("blur"), lightingSettings.blur);
    }

    const JsonValue* gs = root.get("gameSettings");
    if (gs && gs->type == JsonValue::Type::Object)
    {
        gameSettings.graphicsQuality = max(1, min(6,
            (int)jsonFloat(gs->get("graphicsQuality"), (float)gameSettings.graphicsQuality)));
    }

    const JsonValue* children = root.get("children");
    if (children && children->type == JsonValue::Type::Array)
    {
        for (const JsonValue& value : children->array)
        {
            if (value.type != JsonValue::Type::Object) continue;
            string className = jsonStringValue(value.get("class"));
            if (className == "Service")
            {
                string serviceName = jsonStringValue(value.get("name"));
                Instance* service = nullptr;
                if (serviceName == "Workspace") service = &workspace;
                else if (serviceName == "Players") service = &Players;
                else if (serviceName == "Lighting") service = &Lighting;
                else if (serviceName == "ReplicatedStorage") service = &ReplicatedStorage;
                else if (serviceName == "ServerScriptService") service = &ServerScriptService;
                else if (serviceName == "ServerStorage") service = &ServerStorage;
                else if (serviceName == "StarterGui") service = &StarterGui;
                else if (serviceName == "StarterPlayer") service = &StarterPlayer;
                else if (serviceName == "StarterPack") service = &StarterPack;
                if (!service) continue;
                service->name = serviceName;
                service->id = jsonStringValue(value.get("id"));
                const JsonValue* serviceChildren = value.get("children");
                if (serviceChildren && serviceChildren->type == JsonValue::Type::Array)
                    for (const JsonValue& serviceChild : serviceChildren->array)
                        if (Instance* child = deserializeInstanceJSON(serviceChild))
                            addInstanceToParent(service, child);
                continue;
            }

            if (Instance* child = deserializeInstanceJSON(value))
                addInstanceToParent(&workspace, child);
        }
    }
    // Embedded project assets (images / sounds)
    clearProjectAssets();
    const JsonValue* assetsValue = root.get("assets");
    if (assetsValue && assetsValue->type == JsonValue::Type::Array)
    {
        int maxId = 0;
        for (const JsonValue& value : assetsValue->array)
        {
            if (value.type != JsonValue::Type::Object)
                continue;
            ProjectAsset asset;
            asset.id = jsonStringValue(value.get("id"));
            asset.name = jsonStringValue(value.get("name"), "Asset");
            asset.type = parseAssetType(jsonStringValue(value.get("type")));
            asset.fileType = jsonStringValue(value.get("fileType"),
                asset.type == ProjectAssetType::Sound ? "wav" :
                asset.type == ProjectAssetType::Mesh ? "obj" : "png");
            asset.compressed = jsonBoolValue(value.get("compressed"), false);
            string assetFile = jsonStringValue(value.get("file"));
            if (!assetFile.empty())
            {
                string bytes;
                if (readProjectSourceFile(assetFile, bytes))
                    asset.data.assign(bytes.begin(), bytes.end());
                else
                    addOutputLog("[Error] Could not load project asset: " + assetFile);
            }
            else
                asset.data = base64Decode(jsonStringValue(value.get("data")));
            if (asset.id.empty())
                asset.id = generateAssetId();
            // Keep counter ahead of any loaded numeric suffix (assetId://N or legacy asset_N)
            string idNum;
            if (asset.id.rfind("assetId://", 0) == 0)
                idNum = asset.id.substr(10);
            else if (asset.id.rfind("asset_", 0) == 0)
                idNum = asset.id.substr(6);
            if (!idNum.empty())
            {
                try
                {
                    int n = stoi(idNum);
                    if (n > maxId) maxId = n;
                }
                catch (...) {}
            }
            projectAssets.push_back(std::move(asset));
        }
        if (maxId >= nextAssetIdCounter)
            nextAssetIdCounter = maxId + 1;
    }

    // Re-parent any service-owned objects from a newer file format if present.
    // Current files store the complete top-level tree under game.children.
    sun.direction = Vector3Normalize(sun.direction);
        resolvePendingInstanceRefs();
    // Collapse Explorer after project tree is built.
    collapseAllExplorerChildren();
    return true;
}

void pushProjectUndoCheckpoint()
{
    if (projectUndoRestoring || welcomeScreenOpen)
        return;
    string snap = serializeProjectStateJSON();
    if (!projectUndoStack.empty() && projectUndoStack.back() == snap)
        return;
    projectUndoStack.push_back(std::move(snap));
    if ((int)projectUndoStack.size() > kMaxProjectUndo)
        projectUndoStack.erase(projectUndoStack.begin());
    projectRedoStack.clear();
}

void undoProjectChange()
{
    if (projectUndoStack.size() < 2)
        return;
    projectRedoStack.push_back(projectUndoStack.back());
    projectUndoStack.pop_back();
    projectUndoRestoring = true;
    applyProjectJSON(projectUndoStack.back());
    projectUndoRestoring = false;
    lastObservedProjectJSON = projectUndoStack.back();
    projectDirty = (lastObservedProjectJSON != lastSavedProjectJSON);
    updateApplicationWindowTitle();
}

void redoProjectChange()
{
    if (projectRedoStack.empty())
        return;
    string snap = projectRedoStack.back();
    projectRedoStack.pop_back();
    projectUndoStack.push_back(snap);
    projectUndoRestoring = true;
    applyProjectJSON(snap);
    projectUndoRestoring = false;
    lastObservedProjectJSON = snap;
    projectDirty = (lastObservedProjectJSON != lastSavedProjectJSON);
    updateApplicationWindowTitle();
}

// Collect existing autosave version numbers for this project id+name
static vector<int> listAutosaveVersions(const string& id, const string& name)
{
    vector<int> versions;
    string dir = getAutosavesDir();
    string prefix = id + "-" + name + "-autosave-";
    error_code ec;
    if (!filesystem::exists(dir, ec)) return versions;
    for (const auto& entry : filesystem::directory_iterator(dir, ec))
    {
        if (ec) break;
        if (!entry.is_regular_file()) continue;
        string fn = entry.path().filename().string();
        if (fn.rfind(prefix, 0) != 0) continue;
        // strip prefix and optional .hlx
        string rest = fn.substr(prefix.size());
        if (rest.size() > 4 && rest.substr(rest.size() - 4) == ".hlx")
            rest = rest.substr(0, rest.size() - 4);
        try
        {
            int v = stoi(rest);
            if (v > 0) versions.push_back(v);
        }
        catch (...) {}
    }
    sort(versions.begin(), versions.end());
    return versions;
}

// Next path: [id]-[Name]-autosave-[version].hlx under ./autosaves
// When at cap, delete oldest and push forward.
string getNextAutoSavePath()
{
    string id = projectId.empty() ? "unsaved" : projectId;
    string name = sanitizeFileToken(projectName);
    int cap = max(1, studioSettings.autoSaveCap);
    vector<int> versions = listAutosaveVersions(id, name);
    int nextVer = versions.empty() ? 1 : (versions.back() + 1);

    // If we already have `cap` files, drop the oldest until we have room for one more
    while ((int)versions.size() >= cap)
    {
        int oldest = versions.front();
        versions.erase(versions.begin());
        string oldPath = (filesystem::path(getAutosavesDir()) /
            (id + "-" + name + "-autosave-" + to_string(oldest) + ".hlx")).string();
        error_code ec;
        filesystem::remove(oldPath, ec);
    }

    string path = (filesystem::path(getAutosavesDir()) /
        (id + "-" + name + "-autosave-" + to_string(nextVer) + ".hlx")).string();
    return path;
}

string getRecentProjectsPath()
{
    // System storage next to settings: ./temp/recent_projects.json
    return makeTempFilePath(RECENT_PROJECTS_FILE_NAME);
}

string getLegacyRecentProjectsPath()
{
    return (filesystem::path(GetWorkingDirectory()) / ".buildingtool_recent.txt").string();
}

static void pushRecentPath(const string& path)
{
    if (path.empty() || path.size() > 1024)
        return;
    bool bad = false;
    for (unsigned char c : path)
    {
        if (c < 32 && c != '\t')
        {
            bad = true;
            break;
        }
    }
    if (bad)
        return;
    if (find(recentProjects.begin(), recentProjects.end(), path) != recentProjects.end())
        return;
    // Prefer existing files, but keep missing paths so the card still shows
    // (open attempt will prune them).
    recentProjects.push_back(path);
}

void saveRecentProjects(); // forward decl (migration may write JSON during load)

void loadRecentProjects()
{
    recentProjects.clear();
    try
    {
        string recentPath = getRecentProjectsPath();
        error_code ec;
        if (filesystem::exists(recentPath, ec) && !ec)
        {
            auto fileSize = filesystem::file_size(recentPath, ec);
            if (ec || fileSize > 256 * 1024)
            {
                addOutputLog("[Recent] recent_projects.json is invalid or too large — ignoring.");
            }
            else
            {
                ifstream file(recentPath, ios::binary);
                if (file)
                {
                    string content((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());
                    file.close();
                    JsonParser parser(content);
                    JsonValue root;
                    if (parser.parse(root) && root.type == JsonValue::Type::Object)
                    {
                        const JsonValue* arr = root.get("projects");
                        if (arr && arr->type == JsonValue::Type::Array)
                        {
                            for (const JsonValue& v : arr->array)
                            {
                                string path = jsonStringValue(&v);
                                pushRecentPath(path);
                                if (recentProjects.size() >= 12)
                                    break;
                            }
                        }
                    }
                }
            }
        }

        // Migrate legacy line-based list once if JSON was empty
        if (recentProjects.empty())
        {
            string legacy = getLegacyRecentProjectsPath();
            if (filesystem::exists(legacy, ec) && !ec)
            {
                ifstream file(legacy);
                string path;
                while (file && getline(file, path))
                {
                    while (!path.empty() && (path.back() == '\r' || path.back() == ' ' || path.back() == '\t'))
                        path.pop_back();
                    size_t start = 0;
                    while (start < path.size() && (path[start] == ' ' || path[start] == '\t'))
                        start++;
                    if (start > 0)
                        path = path.substr(start);
                    pushRecentPath(path);
                    if (recentProjects.size() >= 12)
                        break;
                }
                if (!recentProjects.empty())
                    saveRecentProjects(); // write JSON and keep going
            }
        }
    }
    catch (...)
    {
        recentProjects.clear();
        try { addOutputLog("[Recent] Failed to read recent projects — starting empty."); }
        catch (...) {}
    }
}

void saveRecentProjects()
{
    try
    {
        ostringstream out;
        out << "{\n  \"projects\": [\n";
        bool first = true;
        for (const string& path : recentProjects)
        {
            if (path.empty() || path.size() > 1024)
                continue;
            if (!first)
                out << ",\n";
            first = false;
            out << "    " << jsonString(path);
        }
        out << "\n  ]\n}\n";
        ofstream file(getRecentProjectsPath(), ios::binary | ios::trunc);
        if (file)
        {
            file << out.str();
            file.close();
        }
    }
    catch (...)
    {
        // Never crash on recent-list write failures
    }
}

void addRecentProject(const string& path)
{
    if (path.empty()) return;
    recentProjects.erase(remove(recentProjects.begin(), recentProjects.end(), path), recentProjects.end());
    recentProjects.insert(recentProjects.begin(), path);
    if (recentProjects.size() > 12)
        recentProjects.resize(12);
    saveRecentProjects();
}

void resetProjectSettings()
{
    sun.direction = Vector3Normalize({ -0.5f, -1.0f, -0.5f });
    sun.color = { 255, 190, 110, 255 };
    sun.intensity = 0.8f;
    sun.ambient = 0.35f;
    lightingSettings = LightingSettings();
}

void createNewProject(bool multiFile)
{
    if (runtimePlaying)
        stopRuntime();

    resetEditorProjectTree();
    resetProjectSettings();
    projectFilePath.clear();
    projectSourceRoot.clear();
    projectStorageMultiFile = multiFile;
    projectId = "unsaved";
    gameSettings.graphicsQuality = 4;
    projectName = "Untitled";
    lastSavedProjectJSON = serializeProjectStateJSON();
    lastObservedProjectJSON = lastSavedProjectJSON;
    projectUndoStack.clear();
    projectRedoStack.clear();
    projectUndoStack.push_back(lastSavedProjectJSON);
    projectDirty = false;
    lastAutoSaveTime = GetTime();
    activeWindow = WindowType::Viewport;
    focusedZone = FocusZone::Viewport;
    activeScript = nullptr;
    welcomeScreenOpen = false;
    openMenu = nullptr;
    updateApplicationWindowTitle();

    // Roblox-style starter scene: large baseplate + blue sky (from LightingSettings)
    Part* baseplate = new Part();
    baseplate->name = "Baseplate";
    baseplate->type = PartType::Block;
    baseplate->size = { 2048.0f, 1.0f, 2048.0f };
    baseplate->cframe.position = { 0.0f, -0.5f, 0.0f };
    baseplate->color = { 99, 95, 98, 255 };   // classic gray baseplate-ish
    baseplate->anchored = true;
    baseplate->canCollide = true;
    addInstanceToParent(&workspace, baseplate);

    // Starter part: unanchored so Play immediately shows physics (falls onto baseplate)
    Part* starter = new Part();
    starter->name = "Part";
    starter->type = PartType::Block;
    starter->size = { 4.0f, 1.0f, 2.0f };
    starter->cframe.position = { 0.0f, 8.0f, 0.0f };
    starter->color = { 163, 162, 165, 255 };
    starter->anchored = false;
    starter->canCollide = true;
    starter->velocity = { 0.0f, 0.0f, 0.0f };
    addInstanceToParent(&workspace, starter);

    selectedInstances.clear();
    selectedInstances.push_back(starter);
    // New project: keep Explorer children collapsed.
    collapseAllExplorerChildren();
}

void beginNewProject()
{
    newProjectTypeDialogOpen = true;
    newProjectTypeDialogWaitForMouseRelease = IsMouseButtonDown(MOUSE_BUTTON_LEFT);
}

void renderNewProjectTypeDialog()
{
    if (!newProjectTypeDialogOpen)
        return;
    int width = 480;
    int height = 190;
    int x = (GetScreenWidth() - width) / 2;
    int y = (GetScreenHeight() - height) / 2;
    Vector2 mouse = GetMousePosition();
    DrawRectangle(0, 0, GetScreenWidth(), GetScreenHeight(), Fade(BLACK, 0.55f));
    DrawRectangleRounded({ (float)x, (float)y, (float)width, (float)height }, 0.04f, 8,
        getEditorThemeColors().panel);
    DrawText("Choose project format", x + 20, y + 18, 20, getEditorThemeColors().text);
    DrawText("Single file is easy to share; project folders keep scripts separate.",
        x + 20, y + 54, 14, getEditorThemeColors().muted);
    Rectangle single = { (float)x + 20, (float)y + 108, 205, 42 };
    Rectangle folder = { (float)x + 245, (float)y + 108, 215, 42 };
    DrawRectangleRounded(single, 0.18f, 6,
        CheckCollisionPointRec(mouse, single) ? getEditorThemeColors().accentHover : getEditorThemeColors().surface);
    DrawRectangleRounded(folder, 0.18f, 6,
        CheckCollisionPointRec(mouse, folder) ? getEditorThemeColors().accentHover : getEditorThemeColors().surface);
    DrawText("Single .hlx file", (int)single.x + 38, (int)single.y + 13, 15, getEditorThemeColors().text);
    DrawText("Project folder", (int)folder.x + 51, (int)folder.y + 13, 15, getEditorThemeColors().text);
    if (newProjectTypeDialogWaitForMouseRelease)
    {
        if (!IsMouseButtonDown(MOUSE_BUTTON_LEFT))
            newProjectTypeDialogWaitForMouseRelease = false;
        return;
    }
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
    {
        if (CheckCollisionPointRec(mouse, single))
        {
            newProjectTypeDialogOpen = false;
            createNewProject(false);
        }
        else if (CheckCollisionPointRec(mouse, folder))
        {
            newProjectTypeDialogOpen = false;
            createNewProject(true);
        }
        else if (!CheckCollisionPointRec(mouse, { (float)x, (float)y, (float)width, (float)height }))
            newProjectTypeDialogOpen = false;
    }
    if (IsKeyPressed(KEY_ESCAPE))
        newProjectTypeDialogOpen = false;
}

bool chooseOpenProjectFile(string& path)
{
    char buffer[MAX_PATH] = {};
    OPENFILENAMEA dialog = {};
    dialog.lStructSize = sizeof(dialog);
    dialog.hwndOwner   = (HWND)GetWindowHandle();
    dialog.lpstrFile   = buffer;
    dialog.nMaxFile    = MAX_PATH;
    dialog.lpstrFilter = "Building Tool Projects (*.hlx;*.btproj)\0*.hlx;*.btproj\0All Files (*.*)\0*.*\0";
    dialog.nFilterIndex = 1;
    dialog.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
    if (!GetOpenFileNameA(&dialog)) return false;
    path = buffer;
    return true;
}

bool chooseSaveProjectFile(string& path)
{
    char buffer[MAX_PATH] = {};
    if (!projectFilePath.empty())
        strncpy_s(buffer, projectFilePath.c_str(), _TRUNCATE);
    else
        strncpy_s(buffer, (projectName + (projectStorageMultiFile ? ".btproj" : ".hlx")).c_str(), _TRUNCATE);

    OPENFILENAMEA dialog = {};
    dialog.lStructSize = sizeof(dialog);
    dialog.hwndOwner   = (HWND)GetWindowHandle();
    dialog.lpstrFile   = buffer;
    dialog.nMaxFile    = MAX_PATH;
    dialog.lpstrFilter = projectStorageMultiFile
        ? "Building Tool Project Folder Manifest (*.btproj)\0*.btproj\0All Files (*.*)\0*.*\0"
        : "Building Tool Project (*.hlx)\0*.hlx\0All Files (*.*)\0*.*\0";
    dialog.nFilterIndex = 1;
    dialog.lpstrDefExt = projectStorageMultiFile ? "btproj" : "hlx";
    dialog.Flags = OFN_EXPLORER | OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
    if (!GetSaveFileNameA(&dialog)) return false;
    path = buffer;
    return true;
}

bool saveProjectToPath(const string& path, bool autoSave = false)
{
    if (path.empty()) return false;
    filesystem::path outputPath(path);
    if (!autoSave && projectStorageMultiFile && outputPath.extension() == ".btproj" &&
        outputPath.parent_path().filename() != outputPath.stem())
    {
        filesystem::path folder = outputPath.parent_path() / outputPath.stem();
        outputPath = folder / (outputPath.stem().string() + ".btproj");
    }
    string finalPath = outputPath.string();
    bool previousMultiFile = projectStorageMultiFile;
    if (autoSave)
        projectStorageMultiFile = false;
    if (!autoSave && projectStorageMultiFile)
    {
        error_code ec;
        filesystem::path root = outputPath.parent_path();
        filesystem::create_directories(root / "Scripts", ec);
        if (ec)
        {
            projectStorageMultiFile = previousMultiFile;
            addOutputLog("[Error] Could not create project Scripts folder: " + ec.message());
            return false;
        }
        filesystem::create_directories(root / "Assets", ec);
        if (ec)
        {
            projectStorageMultiFile = previousMultiFile;
            addOutputLog("[Error] Could not create project Assets folder: " + ec.message());
            return false;
        }
        int scriptIndex = 0;
        bool writeScriptsOk = true;
        function<void(const Instance*)> writeScripts = [&](const Instance* instance)
        {
            if (instance == nullptr || instance == characterRigModule)
                return;
            if (instance->getType() == InstanceType::Script)
            {
                const Script* script = static_cast<const Script*>(instance);
                filesystem::path scriptPath = root / "Scripts" /
                    ("script_" + to_string(scriptIndex++) + ".lua");
                ofstream sourceFile(scriptPath, ios::binary | ios::trunc);
                if (!sourceFile || !(sourceFile << script->source))
                    writeScriptsOk = false;
            }
            for (const Instance* child : instance->children)
                writeScripts(child);
        };
        for (const Instance* child : game.children)
            writeScripts(child);
        for (size_t index = 0; index < projectAssets.size(); ++index)
        {
            const ProjectAsset& asset = projectAssets[index];
            string extension = sanitizeFileToken(asset.fileType);
            filesystem::path assetPath = root / "Assets" /
                ("asset_" + to_string(index) + "." + extension);
            ofstream assetFile(assetPath, ios::binary | ios::trunc);
            if (!assetFile || (!asset.data.empty() &&
                !assetFile.write(reinterpret_cast<const char*>(asset.data.data()),
                    static_cast<streamsize>(asset.data.size()))))
                writeScriptsOk = false;
        }
        if (!writeScriptsOk)
        {
            projectStorageMultiFile = previousMultiFile;
            addOutputLog("[Error] Could not write one or more project source or asset files.");
            return false;
        }
        projectSourceRoot = root;
    }
    string previousProjectName = projectName;
    if (!autoSave)
    {
        string stem = outputPath.stem().string();
        if (!stem.empty())
            projectName = stem;
    }
    string json = serializeProjectJSON();
    projectStorageMultiFile = previousMultiFile;
    HLXResult result = HLX::SaveJSON(finalPath, json, HLX_ZSTD);
    if (result != HLX_OK)
    {
        projectName = previousProjectName;
        updateApplicationWindowTitle();
        addOutputLog("[Error] Could not save project: " + finalPath);
        return false;
    }
    if (!autoSave)
    {
        projectFilePath = finalPath;
        projectId = makeProjectIdFromPath(finalPath);
        updateApplicationWindowTitle();
        lastSavedProjectJSON = serializeProjectStateJSON();
        lastObservedProjectJSON = lastSavedProjectJSON;
        projectDirty = false;
        lastAutoSaveTime = GetTime();
        addRecentProject(finalPath);
    }
    else
    {
        lastAutoSaveTime = GetTime();
    }
    return true;
}

bool saveProject(bool saveAs = false)
{
    string path = projectFilePath;
    if (saveAs || path.empty())
        if (!chooseSaveProjectFile(path)) return false;
    return saveProjectToPath(path, false);
}

bool loadProjectFromPath(const string& path)
{
    if (path.empty())
        return false;

    // The project tree is about to be replaced. Stop Luau first so its
    // snapshots and coroutine state cannot reference deleted instances.
    if (runtimePlaying)
        stopRuntime();

    bool previousMultiFileMode = projectStorageMultiFile;
    filesystem::path previousSourceRoot = projectSourceRoot;
    filesystem::path sourcePath(path);
    projectStorageMultiFile = sourcePath.extension() == ".btproj";
    projectSourceRoot = projectStorageMultiFile ? sourcePath.parent_path() : filesystem::path();
    string json;
    HLXResult result = HLX::LoadJSON(path, json);
    if (result != HLX_OK || !applyProjectJSON(json))
    {
        projectStorageMultiFile = previousMultiFileMode;
        projectSourceRoot = previousSourceRoot;
        addOutputLog("[Error] Could not load project: " + path);
        return false;
    }
    projectFilePath = path;
    projectId = makeProjectIdFromPath(path);
    updateApplicationWindowTitle();
    lastSavedProjectJSON = serializeProjectStateJSON();
    lastObservedProjectJSON = lastSavedProjectJSON;
    projectUndoStack.clear();
    projectRedoStack.clear();
    projectUndoStack.push_back(lastSavedProjectJSON);
    projectDirty = false;
    lastAutoSaveTime = GetTime();
    addRecentProject(path);
    welcomeScreenOpen = false;
    activeWindow = WindowType::Viewport;
    focusedZone = FocusZone::Viewport;
    // On load: collapse all Explorer children so the tree starts closed.
    collapseAllExplorerChildren();
    return true;
}

bool loadProject()
{
    string path;
    if (!chooseOpenProjectFile(path)) return false;
    return loadProjectFromPath(path);
}

bool chooseExportExecutablePath(string& path)
{
    char buffer[MAX_PATH] = {};
    strncpy_s(buffer, (projectName + ".exe").c_str(), _TRUNCATE);
    OPENFILENAMEA dialog = {};
    dialog.lStructSize = sizeof(dialog);
    dialog.hwndOwner = (HWND)GetWindowHandle();
    dialog.lpstrFile = buffer;
    dialog.nMaxFile = MAX_PATH;
    dialog.lpstrFilter = "Windows Executable (*.exe)\0*.exe\0All Files (*.*)\0*.*\0";
    dialog.lpstrDefExt = "exe";
    dialog.Flags = OFN_EXPLORER | OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
    if (!GetSaveFileNameA(&dialog))
        return false;
    path = buffer;
    return true;
}

bool exportProjectExecutable()
{
    string outputPath;
    if (!chooseExportExecutablePath(outputPath))
        return false;
    bool previousRuntimeSerialization = serializeProjectForRuntime;
    serializeProjectForRuntime = true;
    string projectData = serializeProjectJSON();
    serializeProjectForRuntime = previousRuntimeSerialization;
    if (projectSerializationFailed)
    {
        addOutputLog("[Error] Export cancelled because one or more scripts could not be compiled.");
        return false;
    }

    filesystem::path selectedPath(outputPath);
    filesystem::path executablePath = selectedPath;
    filesystem::path packageDirectory;
    if (projectStorageMultiFile)
    {
        packageDirectory = selectedPath.parent_path() /
            (selectedPath.stem().string() + "_Export");
        executablePath = packageDirectory / selectedPath.filename();
    }

    char modulePath[MAX_PATH] = {};
    DWORD modulePathLength = GetModuleFileNameA(nullptr, modulePath, MAX_PATH);
    if (modulePathLength == 0 || modulePathLength >= MAX_PATH)
    {
        addOutputLog("[Error] Could not locate the Building Tool executable for export.");
        return false;
    }
    string runtimeBundle = projectData;
    runtimeBundle.push_back('\0');
    const char* shaderFiles[] = {
        "part_depth.vs", "part_depth.fs", "shadow_depth.vs",
        "shadow_depth.fs", "postprocess.vs", "postprocess.fs"
    };
    filesystem::path shaderDirectory = filesystem::path(modulePath).parent_path() / "shaders";
    for (const char* shaderName : shaderFiles)
    {
        ifstream shader(shaderDirectory / shaderName, ios::binary);
        if (!shader)
        {
            addOutputLog("[Error] Export requires runtime shader: " + string(shaderName));
            return false;
        }
        string shaderData((istreambuf_iterator<char>(shader)), istreambuf_iterator<char>());
        runtimeBundle.append(shaderName);
        runtimeBundle.push_back('\0');
        uint64_t shaderSize = static_cast<uint64_t>(shaderData.size());
        runtimeBundle.append(reinterpret_cast<const char*>(&shaderSize), sizeof(shaderSize));
        runtimeBundle.append(shaderData);
    }
    error_code ec;
    if (!packageDirectory.empty())
        filesystem::create_directories(packageDirectory, ec);
    if (ec)
    {
        addOutputLog("[Error] Could not create export folder: " + ec.message());
        return false;
    }
    filesystem::copy_file(modulePath, executablePath,
        filesystem::copy_options::overwrite_existing, ec);
    if (ec)
    {
        addOutputLog("[Error] Could not copy executable: " + ec.message());
        return false;
    }
    {
        ofstream executable(executablePath, ios::binary | ios::app);
        const char marker[8] = { 'B', 'T', 'G', 'A', 'M', 'E', '0', '1' };
        uint64_t payloadSize = static_cast<uint64_t>(runtimeBundle.size());
        if (!executable ||
            !executable.write(runtimeBundle.data(), static_cast<streamsize>(runtimeBundle.size())) ||
            !executable.write(reinterpret_cast<const char*>(&payloadSize), sizeof(payloadSize)) ||
            !executable.write(marker, sizeof(marker)))
        {
            addOutputLog("[Error] Could not write the standalone project payload.");
            return false;
        }
    }

    if (!packageDirectory.empty())
    {
        filesystem::path assetDirectory = packageDirectory / "Assets";
        filesystem::create_directories(assetDirectory, ec);
        if (ec)
        {
            addOutputLog("[Error] Could not create exported Assets folder: " + ec.message());
            return false;
        }
        for (size_t index = 0; index < projectAssets.size(); ++index)
        {
            const ProjectAsset& asset = projectAssets[index];
            string extension = sanitizeFileToken(asset.fileType);
            filesystem::path assetPath = assetDirectory /
                ("asset_" + to_string(index) + "." + extension);
            ofstream assetFile(assetPath, ios::binary | ios::trunc);
            if (!assetFile || (!asset.data.empty() &&
                !assetFile.write(reinterpret_cast<const char*>(asset.data.data()),
                    static_cast<streamsize>(asset.data.size()))))
            {
                addOutputLog("[Error] Could not write exported asset: " + assetPath.string());
                return false;
            }
        }
    }
    addOutputLog("[Export] Standalone runtime written to: " + executablePath.string());
    return true;
}

void continuePendingProjectAction(bool saved)
{
    PendingProjectAction action = pendingProjectAction;
    pendingProjectAction = PendingProjectAction::None;
    projectSaveDialogOpen = false;

    if (!saved && action == PendingProjectAction::Exit)
    {
        forceExit = true;
        return;
    }
    if (action == PendingProjectAction::New) { beginNewProject(); return; }
    if (action == PendingProjectAction::Open) { loadProject(); return; }
    if (action == PendingProjectAction::Exit)
    {
        forceExit = true;
        return;
    }
}

void requestProjectAction(PendingProjectAction action)
{
    if (action == PendingProjectAction::Exit)
    {
        if (projectDirty)
        {
            pendingProjectAction = action;
            projectSaveDialogOpen = true;
            projectSaveDialogWasCloseRequest = true;
        }
        else
            forceExit = true;
        return;
    }

    if (projectDirty)
    {
        pendingProjectAction = action;
        projectSaveDialogOpen = true;
        projectSaveDialogWasCloseRequest = false;
        return;
    }

    if (runtimePlaying)
        stopRuntime();

    if (action == PendingProjectAction::New)
        beginNewProject();
    else if (action == PendingProjectAction::Open)
        loadProject();
}

void updateProjectSaveSystem()
{
    // Avoid serialize / autosave work on the welcome screen (prevents idle crashes
    // and pointless disk I/O while no project is open).
    if (welcomeScreenOpen)
        return;

    // Observe the actual serialized state so every editor mutation, including
    // future properties added elsewhere, automatically participates in dirty tracking.
    double now = GetTime();
    if (now - lastProjectObservation >= 0.25)
    {
        string cur = serializeProjectStateJSON();
        if (!projectUndoRestoring && !lastObservedProjectJSON.empty() &&
            cur != lastObservedProjectJSON)
        {
            // Record the previous full project state so Undo can restore it
            if (projectUndoStack.empty() || projectUndoStack.back() != lastObservedProjectJSON)
                projectUndoStack.push_back(lastObservedProjectJSON);
            while ((int)projectUndoStack.size() > kMaxProjectUndo)
                projectUndoStack.erase(projectUndoStack.begin());
            projectRedoStack.clear();
        }
        lastObservedProjectJSON = cur;
        projectDirty = (lastObservedProjectJSON != lastSavedProjectJSON);
        updateApplicationWindowTitle();
        lastProjectObservation = now;
    }

    if (studioSettings.autoSave && projectDirty)
    {
        double cooldownSec = max(1, studioSettings.autoSaveMinutes) * 60.0;
        if (now - lastAutoSaveTime >= cooldownSec)
        {
            string path = getNextAutoSavePath();
            if (saveProjectToPath(path, true))
                addOutputLog("[Info] Auto-saved: " + path);
        }
    }
}



void renderGameSettingsDialog()
{
    if (!gameSettingsOpen) return;
    EditorThemeColors theme = getEditorThemeColors();
    int w = 520, h = 340;
    if (floatingGamePos.x < 0)
        floatingGamePos = { (float)((GetScreenWidth() - w) / 2), (float)((GetScreenHeight() - h) / 2) };
    int x = (int)floatingGamePos.x;
    int y = (int)floatingGamePos.y;
    Vector2 mouse = GetMousePosition();
    Rectangle titleBar = { (float)x, (float)y, (float)w, 42.0f };
    Rectangle closeButton = { (float)x + w - 42, (float)y + 8, 26, 26 };
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, titleBar) &&
        !CheckCollisionPointRec(mouse, closeButton) &&
        !CheckCollisionPointRec(mouse, { (float)x + w - 120, (float)y + h - 48, 90, 32 }))
    {
        // drag starts only on title (close handled later)
        floatingGameDrag = true;
        floatingDragOffset = { mouse.x - floatingGamePos.x, mouse.y - floatingGamePos.y };
    }
    if (floatingGameDrag)
    {
        if (IsMouseButtonDown(MOUSE_BUTTON_LEFT))
        {
            floatingGamePos.x = mouse.x - floatingDragOffset.x;
            floatingGamePos.y = mouse.y - floatingDragOffset.y;
            floatingGamePos.x = Clamp(floatingGamePos.x, 0, (float)GetScreenWidth() - w);
            floatingGamePos.y = Clamp(floatingGamePos.y, (float)MENU_BAR_HEIGHT, (float)GetScreenHeight() - h);
            x = (int)floatingGamePos.x;
            y = (int)floatingGamePos.y;
        }
        else
            floatingGameDrag = false;
    }
    // No screen dim — floating panel over live editor
    DrawRectangleRounded({ (float)x, (float)y, (float)w, (float)h }, 0.025f, 8, theme.panel);
    DrawRectangleRoundedLines({ (float)x, (float)y, (float)w, (float)h }, 0.025f, 8, theme.border);
    DrawRectangleRounded({ (float)x + 1, (float)y + 1, (float)w - 2, 42 }, 0.12f, 8, theme.header);
    DrawText("Game Settings", x + 18, y + 10, 20, theme.text);
    DrawRectangleRounded(closeButton, 0.2f, 6,
        CheckCollisionPointRec(mouse, closeButton) ? theme.accentHover : theme.surface);
    DrawText("x", (int)closeButton.x + 9, (int)closeButton.y + 5, 15, theme.text);
    DrawText("Saved with the project (not system settings)", x + 18, y + 48, 13, theme.muted);

    // mouse already sampled
    int rowY = y + 90;
    DrawText("Graphics quality", x + 28, rowY, 16, theme.text);
    rowY += 28;

    // Quality buttons 1–6
    const char* labels[] = {
        "1 Low", "2", "3", "4 Med", "5", "6 Ultra"
    };
    for (int i = 1; i <= 6; ++i)
    {
        Rectangle btn = { (float)(x + 28 + (i - 1) * 76), (float)rowY, 70, 32 };
        bool on = (gameSettings.graphicsQuality == i);
        bool hover = CheckCollisionPointRec(mouse, btn);
        Color fill = on ? theme.accent
                : (hover ? theme.accentHover : theme.surface);
        DrawRectangleRounded(btn, 0.18f, 6, fill);
        const char* lab = labels[i - 1];
        int tw = MeasureText(lab, 14);
        DrawText(lab, (int)btn.x + (70 - tw) / 2, (int)btn.y + 8, 14, theme.text);
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && hover)
        {
            gameSettings.graphicsQuality = i;
            projectDirty = true;
        }
    }
    rowY += 48;

    GraphicsQualityCaps caps = getGraphicsQualityCaps(gameSettings.graphicsQuality);
    DrawText(TextFormat("Level %d effects:", gameSettings.graphicsQuality), x + 28, rowY, 15, (Color){ 180, 190, 205, 255 });
    rowY += 24;
    int taps = caps.shadowsEnabled ? (2 * caps.shadowFilterSize + 1) * (2 * caps.shadowFilterSize + 1) : 0;
    DrawText(TextFormat("  Local lights: up to %d", caps.maxLights), x + 28, rowY, 14, (Color){ 160, 170, 185, 255 });
    rowY += 20;
    if (!caps.shadowsEnabled)
        DrawText("  Shadow samples: Off", x + 28, rowY, 14, (Color){ 160, 170, 185, 255 });
    else
        DrawText(TextFormat("  Shadow density: %d taps (same width, finer points)",
            max(1, taps)),
            x + 28, rowY, 14, (Color){ 160, 170, 185, 255 });
    rowY += 20;
    DrawText("  Style still from Lighting.ShadowSoftness (Hard/Soft/Sharp)", x + 28, rowY, 13, (Color){ 130, 140, 155, 255 });
    rowY += 20;
    DrawText(TextFormat("  Specular: %.0f%%  Reflectance: %.0f%%",
        caps.specularScale * 100.0f, caps.reflectanceScale * 100.0f), x + 28, rowY, 14, (Color){ 160, 170, 185, 255 });
    rowY += 20;
    DrawText(TextFormat("  Post-process: %s", caps.postProcess ? "On" : "Off"), x + 28, rowY, 14, (Color){ 160, 170, 185, 255 });

    Rectangle closeRect = { (float)x + w - 120, (float)y + h - 48, 90, 32 };
    DrawRectangleRounded(closeRect, 0.18f, 6,
        CheckCollisionPointRec(mouse, closeRect) ? theme.accentHover : theme.surface);
    DrawText("Close", (int)closeRect.x + 22, (int)closeRect.y + 7, 16, theme.text);
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, closeRect))
        gameSettingsOpen = false;
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, closeButton))
        gameSettingsOpen = false;
    if (IsKeyPressed(KEY_ESCAPE))
        gameSettingsOpen = false;
}

struct AdvancedEditorIcon
{
    string key;
    string name;
    string group;
    string path;
    Texture2D texture = { 0 };
};

vector<AdvancedEditorIcon>& getAdvancedEditorIcons()
{
    static vector<AdvancedEditorIcon> icons;
    if (!icons.empty())
        return icons;
    error_code scanError;
    filesystem::path root = filesystem::current_path() / "assets" / "icons";
    if (!filesystem::is_directory(root, scanError) || scanError)
        return icons;
    filesystem::recursive_directory_iterator entry(root, scanError), end;
    while (!scanError && entry != end)
    {
        filesystem::directory_entry file = *entry;
        entry.increment(scanError);
        error_code fileError;
        if (!file.is_regular_file(fileError) || fileError ||
            file.path().extension() != ".png")
            continue;
        string group = file.path().parent_path().filename().string();
        string name = file.path().stem().string();
        icons.push_back({ group + "/" + name, name, group, file.path().string(), { 0 } });
    }
    sort(icons.begin(), icons.end(), [](const AdvancedEditorIcon& a, const AdvancedEditorIcon& b)
    {
        return a.key < b.key;
    });
    return icons;
}

void drawPropertyColorPickerOverlay()
{
    if (!propertyColorPickerOpen)
        return;

    const int pickerWidth = 340;
    const int pickerHeight = 470;
    if (floatingPropertyColorPos.x < 0 || floatingPropertyColorPos.y < 0)
        floatingPropertyColorPos = {
            max(0.0f, (GetScreenWidth() - pickerWidth) * 0.5f),
            max(0.0f, (GetScreenHeight() - pickerHeight) * 0.5f)
        };
    int x = std::clamp(static_cast<int>(floatingPropertyColorPos.x), 0,
        max(0, GetScreenWidth() - pickerWidth));
    int y = std::clamp(static_cast<int>(floatingPropertyColorPos.y), 0,
        max(0, GetScreenHeight() - pickerHeight));
    floatingPropertyColorPos = { (float)x, (float)y };
    propertyColorPickerBounds = { (float)x, (float)y, (float)pickerWidth, (float)pickerHeight };

    EditorThemeColors theme = getEditorThemeColors();
    DrawRectangleRounded(propertyColorPickerBounds, 0.035f, 8, theme.panel);
    DrawRectangleRoundedLines(propertyColorPickerBounds, 0.035f, 8, theme.border);
    DrawRectangleRounded({ (float)x + 1, (float)y + 1, (float)pickerWidth - 2, 38 },
        0.12f, 8, theme.header);
    DrawText("Color", x + 14, y + 10, 17, theme.text);
    Rectangle close = { (float)x + pickerWidth - 34, (float)y + 6, 24, 24 };
    Vector2 mouse = GetMousePosition();
    DrawRectangleRounded(close, 0.2f, 6,
        CheckCollisionPointRec(mouse, close) ? theme.accentHover : theme.surface);
    DrawText("x", (int)close.x + 8, (int)close.y + 4, 15, theme.text);

    const Color basicColors[] = {
        WHITE, BLACK, RED, ORANGE, YELLOW, GREEN, BLUE, PURPLE,
        PINK, MAGENTA, (Color){ 0, 220, 220, 255 }, (Color){ 145, 155, 170, 255 }
    };
    DrawText("Basic colors", x + 14, y + 48, 14, theme.text);
    for (int index = 0; index < 12; ++index)
    {
        Rectangle swatch = { (float)x + 14 + (index % 6) * 46,
            (float)y + 70 + (index / 6) * 28, 36, 22 };
        DrawRectangleRounded(swatch, 0.2f, 6, basicColors[index]);
        DrawRectangleRoundedLines(swatch, 0.2f, 6, theme.border);
    }

    DrawText("Saved colors", x + 14, y + 128, 14, theme.text);
    Rectangle saveSlot = { (float)x + 170, (float)y + 124, 156, 24 };
    DrawRectangleRounded(saveSlot, 0.18f, 6,
        CheckCollisionPointRec(mouse, saveSlot) ? theme.accentHover : theme.surface);
    DrawRectangleRoundedLines(saveSlot, 0.18f, 6, theme.border);
    DrawText("Save to selected slot", (int)saveSlot.x + 9, (int)saveSlot.y + 6, 12, theme.text);
    for (int index = 0; index < 12; ++index)
    {
        Rectangle slot = { (float)x + 14 + (index % 6) * 46,
            (float)y + 150 + (index / 6) * 26, 36, 20 };
        DrawRectangleRounded(slot, 0.18f, 6, studioSettings.colorSlotUsed[index]
            ? studioSettings.colorSlots[index] : theme.surface);
        DrawRectangleRoundedLines(slot, 0.18f, 6,
            propertyColorSavedSlotSelection == index ? theme.accentHover : theme.border);
        DrawText(TextFormat("%d", index + 1), (int)slot.x + 14, (int)slot.y + 4, 10, theme.text);
    }

    DrawText("Color spectrum", x + 14, y + 204, 14, theme.text);
    const int spectrumWidth = 260;
    const int spectrumHeight = 100;
    for (int row = 0; row < spectrumHeight; ++row)
    {
        float value = 1.0f - static_cast<float>(row) / (spectrumHeight - 1);
        for (int column = 0; column < spectrumWidth; ++column)
        {
            float saturation = static_cast<float>(column) / (spectrumWidth - 1);
            DrawRectangle(x + 14 + column, y + 222 + row, 1, 1,
                ColorFromHSV(propertyPickerHue, saturation, value));
        }
        DrawRectangle(x + 286, y + 222 + row, 22, 1,
            ColorFromHSV(static_cast<float>(row) / (spectrumHeight - 1) * 360.0f, 1.0f, 1.0f));
    }
    DrawCircleLines(x + 14 + (int)(propertyPickerSaturation * (spectrumWidth - 1)),
        y + 222 + (int)((1.0f - propertyPickerValue) * (spectrumHeight - 1)), 5, WHITE);
    DrawRectangleLines(x + 14, y + 222, spectrumWidth, spectrumHeight, theme.border);
    int hueMarkerY = y + 222 + (int)(propertyPickerHue / 360.0f * (spectrumHeight - 1));
    DrawRectangleLines(x + 284, hueMarkerY - 2, 26, 4, WHITE);
    DrawRectangleLines(x + 286, y + 222, 22, spectrumHeight, theme.border);
    DrawText("Current color", x + 14, y + 332, 14, theme.muted);
    DrawRectangleRounded({ (float)x + 14, (float)y + 354, 54, 28 }, 0.18f, 6, propertyPickerColor);
    DrawText(TextFormat("#%02X%02X%02X", propertyPickerColor.r, propertyPickerColor.g,
        propertyPickerColor.b), x + 78, y + 360, 14, theme.text);
    DrawText("RGB", x + 14, y + 403, 13, theme.muted);
    Rectangle rgbField = { (float)x + 52, (float)y + 394, 188, 30 };
    DrawRectangleRounded(rgbField, 0.16f, 6, propertyColorRgbEditing ? theme.selected : theme.surface);
    DrawRectangleRoundedLines(rgbField, 0.16f, 6,
        propertyColorRgbEditing ? theme.accent : theme.border);
    DrawText(propertyColorRgbText.c_str(), (int)rgbField.x + 9, (int)rgbField.y + 8, 14, theme.text);
    if (propertyColorRgbEditing && fmod(GetTime() - propertyCaretResetTime, 1.0) < 0.5)
    {
        int cursor = std::clamp(propertyColorRgbCursor, 0,
            static_cast<int>(propertyColorRgbText.size()));
        string beforeCursor = propertyColorRgbText.substr(0, static_cast<size_t>(cursor));
        int caretX = static_cast<int>(rgbField.x) + 9 + MeasureText(beforeCursor.c_str(), 14);
        DrawRectangle(caretX, static_cast<int>(rgbField.y) + 6, 2, 18, theme.accentHover);
    }
    Rectangle copy = { (float)x + 250, (float)y + 394, 76, 30 };
    DrawRectangleRounded(copy, 0.18f, 6,
        CheckCollisionPointRec(mouse, copy) ? theme.accentHover : theme.surface);
    DrawText("Copy RGB", (int)copy.x + 8, (int)copy.y + 8, 12, theme.text);
    DrawText("Select a saved slot, then save to replace it.", x + 14, y + 438, 11, theme.muted);
}

void renderStudioSettingsDialog()
{
    if (!studioSettingsOpen) return;
    static int hoveredThemeIndex = -1;
    static double themeHoverStarted = 0.0;
    ensureDefaultProjectFonts();
    int w = 720, h = 520;
    if (floatingStudioPos.x < 0)
        floatingStudioPos = { (float)((GetScreenWidth() - w) / 2), (float)((GetScreenHeight() - h) / 2) };
    int x = (int)floatingStudioPos.x;
    int y = (int)floatingStudioPos.y;
    EditorThemeColors settingsTheme = getEditorThemeColors();
    Vector2 mouseDrag = GetMousePosition();
    Rectangle titleBar = { (float)x, (float)y, (float)w, 42.0f };
    Rectangle titleClose = { (float)x + w - 42, (float)y + 8, 26, 26 };
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouseDrag, titleBar) &&
        !CheckCollisionPointRec(mouseDrag, titleClose))
    {
        floatingStudioDrag = true;
        floatingDragOffset = { mouseDrag.x - floatingStudioPos.x, mouseDrag.y - floatingStudioPos.y };
    }
    if (floatingStudioDrag)
    {
        if (IsMouseButtonDown(MOUSE_BUTTON_LEFT))
        {
            floatingStudioPos.x = mouseDrag.x - floatingDragOffset.x;
            floatingStudioPos.y = mouseDrag.y - floatingDragOffset.y;
            floatingStudioPos.x = Clamp(floatingStudioPos.x, 0, (float)GetScreenWidth() - w);
            floatingStudioPos.y = Clamp(floatingStudioPos.y, (float)MENU_BAR_HEIGHT, (float)GetScreenHeight() - h);
            x = (int)floatingStudioPos.x;
            y = (int)floatingStudioPos.y;
        }
        else
            floatingStudioDrag = false;
    }
    drawThemeBackground({ (float)x, (float)y, (float)w, (float)h }, settingsTheme, settingsTheme.panel);
    DrawRectangleRoundedLines({ (float)x, (float)y, (float)w, (float)h }, 0.025f, 8, settingsTheme.border);
    DrawRectangleRounded({ (float)x + 1, (float)y + 1, (float)w - 2, 42 }, 0.12f, 8, settingsTheme.header);
    DrawText("Studio Settings", x + 18, y + 10, 20, settingsTheme.text);
    DrawRectangleRounded(titleClose, 0.2f, 6,
        CheckCollisionPointRec(mouseDrag, titleClose) ? settingsTheme.accentHover : settingsTheme.surface);
    DrawText("x", (int)titleClose.x + 9, (int)titleClose.y + 5, 15, settingsTheme.text);

    // Tabs: General | Appearance | Advanced
    Rectangle tabGen = { (float)x + 16, (float)y + 50, 110, 28 };
    Rectangle tabAppearance = { (float)x + 132, (float)y + 50, 110, 28 };
    Rectangle tabAdv = { (float)x + 248, (float)y + 50, 110, 28 };
    Vector2 mouse = GetMousePosition();
    if (propertyColorPickerOpen && propertyPickerExternalTarget != nullptr)
        mouse = { -1000.0f, -1000.0f };
    DrawRectangleRounded(tabGen, 0.18f, 6, studioSettingsTab == 0 ? settingsTheme.accent : settingsTheme.surface);
    DrawRectangleRounded(tabAppearance, 0.18f, 6, studioSettingsTab == 1 ? settingsTheme.accent : settingsTheme.surface);
    DrawRectangleRounded(tabAdv, 0.18f, 6, studioSettingsTab == 2 ? settingsTheme.accent : settingsTheme.surface);
    DrawText("General", (int)tabGen.x + 28, (int)tabGen.y + 6, 15, settingsTheme.text);
    DrawText("Appearance", (int)tabAppearance.x + 12, (int)tabAppearance.y + 6, 15, settingsTheme.text);
    DrawText("Advanced", (int)tabAdv.x + 22, (int)tabAdv.y + 6, 15, settingsTheme.text);
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
    {
        if (CheckCollisionPointRec(mouse, tabGen)) studioSettingsTab = 0;
        if (CheckCollisionPointRec(mouse, tabAppearance)) studioSettingsTab = 1;
        if (CheckCollisionPointRec(mouse, tabAdv)) studioSettingsTab = 2;
    }

    Vector2 settingsScreenMouse = propertyColorPickerOpen && propertyPickerExternalTarget != nullptr
        ? Vector2{ -1000.0f, -1000.0f } : GetMousePosition();
    Rectangle settingsContent = { (float)x + 8, (float)y + 84, (float)w - 24, (float)h - 144 };
    if (CheckCollisionPointRec(settingsScreenMouse, settingsContent) && !showAdvancedIconColors)
        studioSettingsScrollY = std::clamp(studioSettingsScrollY - GetMouseWheelMove() * 42.0f,
            0.0f, studioSettingsMaxScrollY);
    Rectangle settingsScrollTrack = { (float)x + w - 12, settingsContent.y, 5, settingsContent.height };
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) &&
        CheckCollisionPointRec(settingsScreenMouse, settingsScrollTrack) && studioSettingsMaxScrollY > 0.0f)
        studioSettingsScrollbarDragging = true;
    if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && studioSettingsScrollbarDragging &&
        studioSettingsMaxScrollY > 0.0f)
    {
        float thumbHeight = max(22.0f, settingsScrollTrack.height * settingsScrollTrack.height /
            (settingsScrollTrack.height + studioSettingsMaxScrollY));
        studioSettingsScrollY = scrollbarScrollFromMouse(settingsScreenMouse.y, settingsScrollTrack.y,
            settingsScrollTrack.height, thumbHeight, studioSettingsMaxScrollY);
    }
    if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
        studioSettingsScrollbarDragging = false;

    Vector2 unscrolledMouse = mouse;
    if (CheckCollisionPointRec(settingsScreenMouse, settingsContent))
        mouse.y += studioSettingsScrollY;
    else
        mouse = { -1000.0f, -1000.0f };
    rlPushMatrix();
    rlTranslatef(0.0f, -studioSettingsScrollY, 0.0f);
    BeginScissorMode((int)settingsContent.x, (int)settingsContent.y,
        (int)settingsContent.width, (int)settingsContent.height);
    int settingsContentBottom = y + 92;
    int rowY = y + 92;
    auto drawToggle = [&](const char* label, bool& value)
    {
        DrawText(label, x + 28, rowY + 4, 16, settingsTheme.text);
        Rectangle box = { (float)x + w - 70, (float)rowY, 40, 24 };
        Color fill = value ? settingsTheme.accent : settingsTheme.surface;
        if (CheckCollisionPointRec(mouse, box))
            fill = value ? settingsTheme.accentHover : settingsTheme.border;
        DrawRectangleRounded(box, 0.18f, 6, fill);
        DrawText(value ? "ON" : "OFF", (int)box.x + (value ? 8 : 6), (int)box.y + 4, 14, settingsTheme.text);
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, box))
            value = !value;
        rowY += 36;
    };

    Vector2 advancedIconMouse = mouse;
    if (studioSettingsTab == 0)
    {
        drawToggle("Show grid", studioSettings.showGrid);
        drawToggle("VSync", studioSettings.vsync);
        drawToggle("Auto-save", studioSettings.autoSave);

        DrawText(TextFormat("Autosave cooldown: %d min", studioSettings.autoSaveMinutes), x + 28, rowY + 4, 16, (Color){ 210, 216, 226, 255 });
        Rectangle asDown = { (float)x + w - 110, (float)rowY, 28, 24 };
        Rectangle asUp = { (float)x + w - 70, (float)rowY, 28, 24 };
        DrawRectangleRounded(asDown, 0.18f, 6, CheckCollisionPointRec(mouse, asDown) ? (Color){ 90, 98, 112, 255 } : (Color){ 70, 76, 88, 255 });
        DrawRectangleRounded(asUp, 0.18f, 6, CheckCollisionPointRec(mouse, asUp) ? (Color){ 90, 98, 112, 255 } : (Color){ 70, 76, 88, 255 });
        DrawText("-", (int)asDown.x + 10, (int)asDown.y + 3, 18, WHITE);
        DrawText("+", (int)asUp.x + 8, (int)asUp.y + 3, 18, WHITE);
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
        {
            if (CheckCollisionPointRec(mouse, asDown))
                studioSettings.autoSaveMinutes = max(1, studioSettings.autoSaveMinutes - 1);
            if (CheckCollisionPointRec(mouse, asUp))
                studioSettings.autoSaveMinutes = min(60, studioSettings.autoSaveMinutes + 1);
        }
        rowY += 36;

        DrawText(TextFormat("Autosave cap: %d versions", studioSettings.autoSaveCap), x + 28, rowY + 4, 16, (Color){ 210, 216, 226, 255 });
        Rectangle capDown = { (float)x + w - 110, (float)rowY, 28, 24 };
        Rectangle capUp = { (float)x + w - 70, (float)rowY, 28, 24 };
        DrawRectangleRec(capDown, CheckCollisionPointRec(mouse, capDown) ? (Color){ 90, 98, 112, 255 } : (Color){ 70, 76, 88, 255 });
        DrawRectangleRec(capUp, CheckCollisionPointRec(mouse, capUp) ? (Color){ 90, 98, 112, 255 } : (Color){ 70, 76, 88, 255 });
        DrawText("-", (int)capDown.x + 10, (int)capDown.y + 3, 18, WHITE);
        DrawText("+", (int)capUp.x + 8, (int)capUp.y + 3, 18, WHITE);
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
        {
            if (CheckCollisionPointRec(mouse, capDown))
                studioSettings.autoSaveCap = max(1, studioSettings.autoSaveCap - 1);
            if (CheckCollisionPointRec(mouse, capUp))
                studioSettings.autoSaveCap = min(20, studioSettings.autoSaveCap + 1);
        }
        rowY += 40;

        DrawText(TextFormat("Target FPS: %d", studioSettings.targetFps), x + 28, rowY + 4, 16, (Color){ 210, 216, 226, 255 });
        Rectangle fpsDown = { (float)x + w - 110, (float)rowY, 28, 24 };
        Rectangle fpsUp = { (float)x + w - 70, (float)rowY, 28, 24 };
        DrawRectangleRec(fpsDown, CheckCollisionPointRec(mouse, fpsDown) ? (Color){ 90, 98, 112, 255 } : (Color){ 70, 76, 88, 255 });
        DrawRectangleRec(fpsUp, CheckCollisionPointRec(mouse, fpsUp) ? (Color){ 90, 98, 112, 255 } : (Color){ 70, 76, 88, 255 });
        DrawText("-", (int)fpsDown.x + 10, (int)fpsDown.y + 3, 18, WHITE);
        DrawText("+", (int)fpsUp.x + 8, (int)fpsUp.y + 3, 18, WHITE);
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
        {
            if (CheckCollisionPointRec(mouse, fpsDown))
                studioSettings.targetFps = max(30, studioSettings.targetFps - 30);
            if (CheckCollisionPointRec(mouse, fpsUp))
                studioSettings.targetFps = min(240, studioSettings.targetFps + 30);
        }
        rowY += 40;

        DrawText(TextFormat("Camera speed: %.1fx", studioSettings.cameraSpeed), x + 28, rowY + 4, 16, (Color){ 210, 216, 226, 255 });
        Rectangle spdDown = { (float)x + w - 110, (float)rowY, 28, 24 };
        Rectangle spdUp = { (float)x + w - 70, (float)rowY, 28, 24 };
        DrawRectangleRounded(spdDown, 0.18f, 6, CheckCollisionPointRec(mouse, spdDown) ? (Color){ 90, 98, 112, 255 } : (Color){ 70, 76, 88, 255 });
        DrawRectangleRounded(spdUp, 0.18f, 6, CheckCollisionPointRec(mouse, spdUp) ? (Color){ 90, 98, 112, 255 } : (Color){ 70, 76, 88, 255 });
        DrawText("-", (int)spdDown.x + 10, (int)spdDown.y + 3, 18, WHITE);
        DrawText("+", (int)spdUp.x + 8, (int)spdUp.y + 3, 18, WHITE);
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
        {
            if (CheckCollisionPointRec(mouse, spdDown))
                studioSettings.cameraSpeed = max(0.25f, studioSettings.cameraSpeed - 0.25f);
            if (CheckCollisionPointRec(mouse, spdUp))
                studioSettings.cameraSpeed = min(4.0f, studioSettings.cameraSpeed + 0.25f);
        }
        rowY += 48;
        DrawText(("Version: " + BUILDING_TOOL_VERSION).c_str(), x + 28, rowY, 14, (Color){ 140, 150, 165, 255 });
        DrawText("Autosaves → ./autosaves/", x + 28, rowY + 20, 13, (Color){ 120, 130, 145, 255 });
        settingsContentBottom = rowY + 44;
    }
    else if (studioSettingsTab == 1)
    {
        DrawText("Interface theme", x + 28, rowY + 4, 17, settingsTheme.text);
        vector<string> themes = { "Dark", "Light", "Gray", "Orange" };
        for (const CustomEditorTheme& theme : customEditorThemes)
            themes.push_back(theme.name);
        int visibleThemes = static_cast<int>(themes.size());
        int currentHoveredTheme = -1;
        string tooltipThemeName;
        for (int index = 0; index < visibleThemes; ++index)
        {
            int column = index % 4;
            int row = index / 4;
            Rectangle option = { (float)x + 28 + column * 162, (float)rowY + 40 + row * 60, 150, 52 };
            bool selected = studioSettings.theme == themes[index];
            Color swatch = settingsTheme.accent;
            for (const CustomEditorTheme& custom : customEditorThemes)
                if (custom.name == themes[index]) swatch = custom.ui.accent;
            if (themes[index] == "Light") swatch = { 45, 112, 180, 255 };
            else if (themes[index] == "Gray") swatch = { 100, 145, 174, 255 };
            else if (themes[index] == "Orange") swatch = { 222, 119, 42, 255 };
            DrawRectangleRounded(option, 0.12f, 8, selected ? settingsTheme.selected : settingsTheme.surface);
            DrawRectangleRoundedLines(option, 0.12f, 8,
                selected ? settingsTheme.accentHover : settingsTheme.border);
            DrawRectangle((int)option.x + 10, (int)option.y + 10, 32, 32, swatch);
            string themeLabel = themes[index];
            while (themeLabel.size() > 3 && MeasureText((themeLabel + "...").c_str(), 15) > 88)
                themeLabel.pop_back();
            if (themeLabel != themes[index])
                themeLabel += "...";
            DrawText(themeLabel.c_str(), (int)option.x + 52, (int)option.y + 18, 15, settingsTheme.text);
            if (CheckCollisionPointRec(mouse, option))
            {
                currentHoveredTheme = index;
                tooltipThemeName = themes[index];
            }
            if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, option))
            {
                studioSettings.theme = themes[index];
                applyStudioScriptTheme();
                saveStudioSettings();
            }
        }
        if (currentHoveredTheme != hoveredThemeIndex)
        {
            hoveredThemeIndex = currentHoveredTheme;
            themeHoverStarted = GetTime();
        }
        if (currentHoveredTheme >= 0 && GetTime() - themeHoverStarted >= 1.0)
        {
            int tooltipWidth = MeasureText(tooltipThemeName.c_str(), 14) + 16;
            int tooltipX = std::clamp((int)mouse.x + 14, 4, GetScreenWidth() - tooltipWidth - 4);
            int tooltipY = (int)mouse.y + 18;
            if (tooltipY + 26 > GetScreenHeight())
                tooltipY = (int)mouse.y - 32;
            DrawRectangle(tooltipX, tooltipY, tooltipWidth, 26, settingsTheme.surface);
            DrawRectangleLines(tooltipX, tooltipY, tooltipWidth, 26, settingsTheme.border);
            DrawText(tooltipThemeName.c_str(), tooltipX + 8, tooltipY + 6, 14, settingsTheme.text);
        }
        int reloadY = rowY + 40 + ((visibleThemes + 3) / 4) * 60;
        Rectangle reload = { (float)x + 28, (float)reloadY, 130, 28 };
        DrawRectangleRounded(reload, 0.18f, 6, CheckCollisionPointRec(mouse, reload) ? settingsTheme.accentHover : settingsTheme.surface);
        DrawRectangleRoundedLines(reload, 0.18f, 6, settingsTheme.border);
        DrawText("Reload themes", (int)reload.x + 14, (int)reload.y + 7, 14, settingsTheme.text);
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, reload))
        {
            loadCustomEditorThemes();
            bool themeExists = studioSettings.theme == "Dark" || studioSettings.theme == "Light" ||
                studioSettings.theme == "Gray" || studioSettings.theme == "Orange";
            for (const CustomEditorTheme& theme : customEditorThemes)
                themeExists = themeExists || theme.name == studioSettings.theme;
            if (!themeExists) studioSettings.theme = "Dark";
            applyStudioScriptTheme();
            saveStudioSettings();
        }
        DrawText("Custom themes load from themes/*.json", x + 174, reloadY + 7, 14, settingsTheme.muted);
        settingsContentBottom = reloadY + 36;
    }
    else
    {
        // Icon tint mode and its color controls
        DrawText("Icon colors", x + 28, rowY, 16, settingsTheme.text);
        rowY += 24;
        Rectangle monoMode = { (float)x + 28, (float)rowY, 82, 26 };
        Rectangle themeMode = { (float)x + 114, (float)rowY, 82, 26 };
        Rectangle colorfulMode = { (float)x + 200, (float)rowY, 92, 26 };
        Rectangle advancedMode = { (float)x + 296, (float)rowY, 92, 26 };
        auto modeButton = [&](Rectangle rect, const char* label, bool selected)
        {
            DrawRectangleRounded(rect, 0.18f, 6, selected ? settingsTheme.accent : settingsTheme.surface);
            DrawRectangleRoundedLines(rect, 0.18f, 6, settingsTheme.border);
            DrawText(label, (int)rect.x + 12, (int)rect.y + 6, 13, settingsTheme.text);
        };
        modeButton(monoMode, "Mono", studioSettings.iconColorMode == "Mono");
        modeButton(themeMode, "Theme", studioSettings.iconColorMode == "Theme");
        modeButton(colorfulMode, "Colorful", studioSettings.iconColorMode == "Colorful");
        modeButton(advancedMode, "Advanced", studioSettings.iconColorMode == "Advanced");
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, monoMode))
            studioSettings.iconColorMode = "Mono";
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, themeMode))
            studioSettings.iconColorMode = "Theme";
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, colorfulMode))
            studioSettings.iconColorMode = "Colorful";
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, advancedMode))
            studioSettings.iconColorMode = "Advanced";
        rowY += 32;
        Rectangle advancedIconsButton = { (float)x + 396, (float)y + 116, 136, 26 };
        DrawRectangleRounded(advancedIconsButton, 0.18f, 6,
            CheckCollisionPointRec(mouse, advancedIconsButton) ? settingsTheme.accentHover : settingsTheme.surface);
        DrawRectangleRoundedLines(advancedIconsButton, 0.18f, 6, settingsTheme.border);
        DrawText(showAdvancedIconColors ? "Hide icon options" : "Advanced icons",
            (int)advancedIconsButton.x + 10, (int)advancedIconsButton.y + 6, 12, settingsTheme.text);
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) &&
            CheckCollisionPointRec(mouse, advancedIconsButton))
        {
            showAdvancedIconColors = !showAdvancedIconColors;
            advancedIconSearchFocused = false;
            advancedIconScrollY = 0.0f;
        }
        advancedIconMouse = mouse;
        if (showAdvancedIconColors)
            mouse = { -1000.0f, -1000.0f };

        auto tintSlider = [&](const char* label, unsigned char& channel, int channelX)
        {
            DrawText(TextFormat("%s %d", label, (int)channel), channelX, rowY, 14, settingsTheme.muted);
            Rectangle track = { (float)channelX, (float)rowY + 18, 160, 10 };
            DrawRectangleRec(track, settingsTheme.surface);
            float t = channel / 255.0f;
            DrawRectangle((int)(track.x + t * (track.width - 8)), (int)track.y - 2, 8, 14, WHITE);
            if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) &&
                CheckCollisionPointRec(mouse, { track.x - 4, track.y - 6, track.width + 8, track.height + 12 }))
            {
                float nt = Clamp((mouse.x - track.x) / track.width, 0.0f, 1.0f);
                channel = (unsigned char)(nt * 255.0f + 0.5f);
            }
        };
        if (studioSettings.iconColorMode == "Colorful")
        {
            const char* groups[] = { "Geometry", "Scripts", "Containers", "UI", "Assets", "Services" };
            for (int index = 0; index < 6; ++index)
            {
                int column = index % 3;
                int line = index / 3;
                Rectangle groupRect = { (float)x + 28 + column * 140, (float)rowY + line * 28, 132, 24 };
                bool selected = selectedIconColorGroup == groups[index];
                DrawRectangleRounded(groupRect, 0.18f, 6, selected ? settingsTheme.selected : settingsTheme.surface);
                DrawRectangleRoundedLines(groupRect, 0.18f, 6, selected ? settingsTheme.accent : settingsTheme.border);
                DrawRectangle((int)groupRect.x + 5, (int)groupRect.y + 5, 14, 14,
                    getStudioIconTint(groups[index]));
                DrawText(groups[index], (int)groupRect.x + 25, (int)groupRect.y + 5, 12, settingsTheme.text);
                if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, groupRect))
                    selectedIconColorGroup = groups[index];
            }
            rowY += 60;
            DrawText((selectedIconColorGroup + " color").c_str(), x + 28, rowY + 2, 13, settingsTheme.muted);
            Color& activeColor = studioSettings.iconGroupColors[selectedIconColorGroup];
            Rectangle editIconColor = { (float)x + 28, (float)rowY + 22, 108, 26 };
            DrawRectangleRounded(editIconColor, 0.18f, 6,
                CheckCollisionPointRec(mouse, editIconColor) ? settingsTheme.accentHover : settingsTheme.surface);
            DrawRectangleRoundedLines(editIconColor, 0.18f, 6, settingsTheme.border);
            DrawText("Edit color...", (int)editIconColor.x + 10, (int)editIconColor.y + 6, 12, settingsTheme.text);
            if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, editIconColor))
            {
                iconIndividualColorKey.clear();
                Vector3 hsv = ColorToHSV(activeColor);
                iconGroupPickerHue = hsv.x;
                iconGroupPickerSaturation = hsv.y;
                iconGroupPickerValue = hsv.z;
                propertyPickerExternalTarget = &activeColor;
                propertyPickerColor = activeColor;
                propertyColorRgbText = TextFormat("%d, %d, %d", activeColor.r, activeColor.g, activeColor.b);
                propertyColorRgbEditing = false;
                propertyColorRgbSelectAll = false;
                activePropertyRow = -1;
                floatingPropertyColorPos = { -1.0f, -1.0f };
                propertyColorPickerOpen = true;
                iconGroupColorPickerOpen = false;
            }
            rowY += 52;
        }
        else if (studioSettings.iconColorMode == "Mono")
        {
            tintSlider("R", studioSettings.iconTint.r, x + 28);
            tintSlider("G", studioSettings.iconTint.g, x + 210);
            tintSlider("B", studioSettings.iconTint.b, x + 392);
            rowY += 40;
        }
        // Preview strip of common icons
        DrawText("Icon set preview", x + 28, rowY, 14, settingsTheme.muted);
        rowY += 22;
        if (explorerIcons && !showAdvancedIconColors)
        {
            Texture2D previews[] = {
                explorerIcons->partIcon, explorerIcons->modelIcon, explorerIcons->folderIcon,
                explorerIcons->scriptIcon, explorerIcons->localScriptIcon, explorerIcons->moduleScriptIcon,
                explorerIcons->soundIcon, explorerIcons->textureIcon, explorerIcons->humanoidIcon,
                explorerIcons->cameraIcon, explorerIcons->guiIcon, explorerIcons->lightingIcon
            };
            float px = (float)x + 28;
            const char* previewGroups[] = { "Geometry", "Geometry", "Containers", "Scripts", "Scripts", "Scripts",
                "Assets", "Assets", "Services", "Services", "UI", "Services" };
            const char* previewKeys[] = { "Part", "Model", "Folder", "Script", "LocalScript", "ModuleScript",
                "Sound", "Texture", "Humanoid", "Camera", "ScreenGui", "Lighting" };
            for (size_t index = 0; index < sizeof(previews) / sizeof(previews[0]); ++index)
            {
                Texture2D ic = previews[index];
                if (ic.id == 0) continue;
                DrawRectangle((int)px - 2, rowY - 2, 28, 28, settingsTheme.surface);
                drawEditorIcon(ic, px, (float)rowY, 24.0f, 24.0f,
                    getStudioInstanceIconTint(previewKeys[index], previewGroups[index]));
                px += 32;
                if (px > x + w - 40) break;
            }
        }
        rowY += 40;

        // Advanced: Font browser
        DrawText("Fonts", x + 28, rowY, 16, (Color){ 210, 216, 226, 255 });
        DrawText(("Selected: " + studioSelectedFont).c_str(), x + 100, rowY, 14, (Color){ 160, 180, 210, 255 });
        rowY += 28;

        Rectangle importBtn = { (float)x + 28, (float)rowY, 140, 28 };
        DrawRectangleRec(importBtn, CheckCollisionPointRec(mouse, importBtn) ? (Color){ 70, 130, 90, 255 } : (Color){ 50, 100, 70, 255 });
        DrawText("Import Font…", (int)importBtn.x + 22, (int)importBtn.y + 6, 14, WHITE);
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, importBtn))
        {
#ifdef _WIN32
            char buffer[MAX_PATH] = {};
            OPENFILENAMEA dialog = {};
            dialog.lStructSize = sizeof(dialog);
            dialog.lpstrFile = buffer;
            dialog.nMaxFile = MAX_PATH;
            dialog.lpstrFilter = "Font Files\0*.ttf;*.otf;*.ttc\0All Files\0*.*\0";
            dialog.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
            if (GetOpenFileNameA(&dialog))
            {
                if (importFontFromPath(buffer))
                {
                    projectDirty = true;
                    addOutputLog(string("[Font] Imported: ") + buffer);
                }
                else
                    addOutputLog(string("[Font] Failed to load: ") + buffer);
            }
#endif
        }
        Rectangle useBtn = { (float)x + 180, (float)rowY, 160, 28 };
        DrawRectangleRec(useBtn, CheckCollisionPointRec(mouse, useBtn) ? (Color){ 70, 110, 160, 255 } : (Color){ 55, 85, 130, 255 });
        DrawText("Use Selected Font", (int)useBtn.x + 16, (int)useBtn.y + 6, 14, WHITE);
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, useBtn))
        {
            if (fontBrowserSelected >= 0 && fontBrowserSelected < (int)projectFonts.size())
            {
                studioSelectedFont = projectFonts[fontBrowserSelected].name;
                // Apply as application font when loaded
                Font* f = resolveProjectFont(studioSelectedFont);
                if (f && f->glyphCount > 0)
                {
                    applicationFont = *f;
                    applicationFontLoaded = true;
                }
                addOutputLog("[Font] Using: " + studioSelectedFont);
            }
        }
        rowY += 40;

        // Search
        DrawText("Search", x + 28, rowY, 14, (Color){ 160, 170, 185, 255 });
        Rectangle searchBox = { (float)x + 90, (float)rowY - 4, 200, 24 };
        DrawRectangleRec(searchBox, (Color){ 45, 50, 60, 255 });
        DrawRectangleLinesEx(searchBox, 1, (Color){ 90, 100, 115, 255 });
        DrawText(fontBrowserSearch.empty() ? "type to filter…" : fontBrowserSearch.c_str(),
            (int)searchBox.x + 8, (int)searchBox.y + 4, 14,
            fontBrowserSearch.empty() ? (Color){ 120, 130, 145, 255 } : RAYWHITE);
        int cp = showAdvancedIconColors ? 0 : GetCharPressed();
        while (cp > 0)
        {
            if (cp >= 32 && cp < 127 && fontBrowserSearch.size() < 40)
                fontBrowserSearch.push_back((char)cp);
            cp = GetCharPressed();
        }
        if (!showAdvancedIconColors && IsKeyPressed(KEY_BACKSPACE) && !fontBrowserSearch.empty())
            fontBrowserSearch.pop_back();

        rowY += 32;
        int listX = x + 20;
        int listY = rowY;
        int listW = 280;
        int listH = h - (listY - y) - 60;
        if (listH < 80) listH = 80;
        int prevW = w - listW - 50;
        int prevX = listX + listW + 16;
        DrawRectangle(listX, listY, listW, listH, (Color){ 28, 32, 40, 255 });
        DrawRectangle(prevX, listY, prevW, listH, (Color){ 28, 32, 40, 255 });

        vector<int> indices;
        string q = fontBrowserSearch;
        for (char& c : q) c = (char)tolower((unsigned char)c);
        for (int i = 0; i < (int)projectFonts.size(); ++i)
        {
            string n = projectFonts[i].name;
            for (char& c : n) c = (char)tolower((unsigned char)c);
            if (q.empty() || n.find(q) != string::npos)
                indices.push_back(i);
        }
        int rowHf = 28;
        float maxScr = max(0.0f, (float)(indices.size() * rowHf - listH));
        if (CheckCollisionPointRec(mouse, { (float)listX, (float)listY, (float)listW, (float)listH }))
            fontBrowserScrollY = std::clamp(fontBrowserScrollY - GetMouseWheelMove() * 36.0f, 0.0f, maxScr);
        fontBrowserScrollY = std::clamp(fontBrowserScrollY, 0.0f, maxScr);

        BeginScissorMode(listX, listY - (int)studioSettingsScrollY, listW, listH);
        for (int k = 0; k < (int)indices.size(); ++k)
        {
            int i = indices[k];
            float ry = (float)listY + k * rowHf - fontBrowserScrollY;
            Rectangle row = { (float)listX + 4, ry, (float)listW - 8, (float)(rowHf - 2) };
            bool sel = (fontBrowserSelected == i);
            bool hov = CheckCollisionPointRec(mouse, row);
            DrawRectangleRec(row, sel ? (Color){ 50, 90, 140, 255 } : (hov ? (Color){ 45, 55, 70, 255 } : (Color){ 34, 38, 48, 255 }));
            DrawText(projectFonts[i].name.c_str(), (int)row.x + 8, (int)row.y + 5, 14, RAYWHITE);
            if (!showAdvancedIconColors && IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && hov)
                fontBrowserSelected = i;
        }
        EndScissorMode();
        BeginScissorMode((int)settingsContent.x, (int)settingsContent.y,
            (int)settingsContent.width, (int)settingsContent.height);

        // Preview clipped inside right panel
        BeginScissorMode(prevX, listY - (int)studioSettingsScrollY, prevW, listH);
        if (fontBrowserSelected >= 0 && fontBrowserSelected < (int)projectFonts.size())
        {
            const auto& e = projectFonts[fontBrowserSelected];
            DrawText(e.name.c_str(), prevX + 12, listY + 12, 18, WHITE);
            DrawText(e.isSystem ? "System font (PC)" : (e.path.empty() ? "Built-in" : "Imported (embedded)"),
                prevX + 12, listY + 38, 13, (Color){ 140, 150, 165, 255 });
            Font* f = resolveProjectFont(e.name);
            Font use = f ? *f : GetFontDefault();
            const char* sample = "The quick brown fox jumps over the lazy dog";
            const char* sample2 = "ABCDEFG 0123456789";
            DrawTextEx(use, sample, { (float)prevX + 12, (float)listY + 72 }, 20.0f, 0.0f, RAYWHITE);
            DrawTextEx(use, sample2, { (float)prevX + 12, (float)listY + 108 }, 24.0f, 0.0f, (Color){ 200, 210, 230, 255 });
            DrawTextEx(use, "Gui text preview Aa Bb Cc", { (float)prevX + 12, (float)listY + 150 }, 16.0f, 0.0f, (Color){ 180, 200, 255, 255 });
        }
        EndScissorMode();
        BeginScissorMode((int)settingsContent.x, (int)settingsContent.y,
            (int)settingsContent.width, (int)settingsContent.height);
    }

    if (showAdvancedIconColors && studioSettingsTab == 2)
    {
        mouse = advancedIconMouse;
        Rectangle iconPanel = { (float)x + 16, (float)y + 150, (float)w - 32, (float)h - 214 };
        Rectangle searchBox = { iconPanel.x + 12, iconPanel.y + 10, iconPanel.width - 76, 28 };
        DrawRectangleRounded(iconPanel, 0.025f, 8, settingsTheme.panel);
        DrawRectangleRoundedLines(iconPanel, 0.025f, 8, settingsTheme.border);
        Rectangle closeIconList = { iconPanel.x + iconPanel.width - 46, iconPanel.y + 10, 28, 28 };
        DrawRectangleRounded(closeIconList, 0.2f, 6,
            CheckCollisionPointRec(mouse, closeIconList) ? settingsTheme.accentHover : settingsTheme.surface);
        DrawText("x", (int)closeIconList.x + 10, (int)closeIconList.y + 6, 14, settingsTheme.text);
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) &&
            CheckCollisionPointRec(mouse, closeIconList))
        {
            showAdvancedIconColors = false;
            advancedIconSearchFocused = false;
        }
        DrawRectangleRounded(searchBox, 0.16f, 6,
            advancedIconSearchFocused ? settingsTheme.selected : settingsTheme.surface);
        DrawRectangleRoundedLines(searchBox, 0.16f, 6,
            advancedIconSearchFocused ? settingsTheme.accent : settingsTheme.border);
        DrawText(advancedIconSearch.empty() ? "Search all icons..." : advancedIconSearch.c_str(),
            (int)searchBox.x + 9, (int)searchBox.y + 7, 14,
            advancedIconSearch.empty() ? settingsTheme.muted : settingsTheme.text);
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
            advancedIconSearchFocused = CheckCollisionPointRec(mouse, searchBox);
        if (advancedIconSearchFocused)
        {
            bool ctrl = IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL);
            int iconSearchCodepoint = GetCharPressed();
            while (iconSearchCodepoint > 0)
            {
                if (!ctrl && iconSearchCodepoint >= 32 && iconSearchCodepoint < 127 &&
                    advancedIconSearch.size() < 64)
                    advancedIconSearch.push_back((char)iconSearchCodepoint);
                iconSearchCodepoint = GetCharPressed();
            }
            if (IsKeyPressed(KEY_BACKSPACE) && !advancedIconSearch.empty())
                advancedIconSearch.pop_back();
            if (IsKeyPressed(KEY_ESCAPE))
                advancedIconSearchFocused = false;
        }

        vector<AdvancedEditorIcon>& icons = getAdvancedEditorIcons();
        vector<int> filtered;
        string query = advancedIconSearch;
        for (char& character : query)
            character = static_cast<char>(tolower(static_cast<unsigned char>(character)));
        for (int index = 0; index < static_cast<int>(icons.size()); ++index)
        {
            string searchText = icons[index].key;
            for (char& character : searchText)
                character = static_cast<char>(tolower(static_cast<unsigned char>(character)));
            if (query.empty() || searchText.find(query) != string::npos)
                filtered.push_back(index);
        }
        Rectangle listBounds = { iconPanel.x + 12, iconPanel.y + 48, iconPanel.width - 32, iconPanel.height - 60 };
        int columns = 3;
        float tileWidth = (listBounds.width - 16.0f) / columns;
        const float tileHeight = 40.0f;
        float contentHeight = static_cast<float>((filtered.size() + columns - 1) / columns) * tileHeight;
        float maxScroll = max(0.0f, contentHeight - listBounds.height);
        if (CheckCollisionPointRec(mouse, listBounds))
            advancedIconScrollY = std::clamp(advancedIconScrollY - GetMouseWheelMove() * 38.0f, 0.0f, maxScroll);
        else
            advancedIconScrollY = std::clamp(advancedIconScrollY, 0.0f, maxScroll);
        float thumbHeight = maxScroll > 0.0f
            ? std::clamp(listBounds.height * listBounds.height / (listBounds.height + maxScroll),
                min(20.0f, listBounds.height), listBounds.height)
            : listBounds.height;
        float trackX = listBounds.x + listBounds.width - 6.0f;
        Rectangle scrollTrack = { trackX, listBounds.y, 5.0f, listBounds.height };
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) &&
            CheckCollisionPointRec(mouse, scrollTrack) && maxScroll > 0.0f)
            advancedIconScrollbarDragging = true;
        if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
            advancedIconScrollbarDragging = false;
        if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && advancedIconScrollbarDragging &&
            maxScroll > 0.0f)
        {
            float thumbTravel = listBounds.height - thumbHeight;
            if (thumbTravel > 0.0f)
            {
                float position = std::clamp(mouse.y - listBounds.y - thumbHeight * 0.5f,
                    0.0f, thumbTravel);
                advancedIconScrollY = position / thumbTravel * maxScroll;
            }
        }
        BeginScissorMode((int)listBounds.x, (int)listBounds.y,
            (int)listBounds.width, (int)listBounds.height);
        for (int visible = 0; visible < static_cast<int>(filtered.size()); ++visible)
        {
            AdvancedEditorIcon& icon = icons[filtered[visible]];
            if (icon.texture.id == 0)
                icon.texture = LoadTexture(icon.path.c_str());
            int column = visible % columns;
            int row = visible / columns;
            Rectangle tile = { listBounds.x + column * tileWidth,
                listBounds.y + row * tileHeight - advancedIconScrollY, tileWidth - 6, tileHeight - 5 };
            bool hovered = CheckCollisionPointRec(mouse, tile);
            string overrideKey = icon.group == "Instance"
                ? "Instance/" + getAdvancedInstanceIconKey(icon.name)
                : "Misc/" + getAdvancedMiscIconKey(icon.name);
            auto iconColor = iconIndividualColors.find(overrideKey);
            Color tint = iconColor != iconIndividualColors.end()
                ? iconColor->second
                : (icon.group == "Instance"
                    ? getStudioInstanceIconTint(icon.name, "Services")
                    : getStudioMiscIconTint(icon.name));
            DrawRectangleRounded(tile, 0.14f, 6,
                overrideKey == iconIndividualColorKey ? settingsTheme.selected :
                (hovered ? settingsTheme.surface : settingsTheme.canvas));
            if (icon.texture.id != 0)
                drawEditorIcon(icon.texture, tile.x + 8, tile.y + 7, 24.0f, 24.0f, tint);
            DrawText(icon.name.c_str(), (int)tile.x + 40, (int)tile.y + 13, 12, settingsTheme.text);
            if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && hovered && !advancedIconScrollbarDragging)
            {
                iconIndividualColorKey = overrideKey;
                Color initialColor = iconColor != iconIndividualColors.end()
                    ? iconColor->second : tint;
                studioSettings.iconColorMode = "Advanced";
                Vector3 hsv = ColorToHSV(initialColor);
                iconGroupPickerHue = hsv.x;
                iconGroupPickerSaturation = hsv.y;
                iconGroupPickerValue = hsv.z;
                iconIndividualColors[overrideKey] = initialColor;
                propertyPickerExternalTarget = &iconIndividualColors[overrideKey];
                propertyPickerColor = initialColor;
                propertyColorRgbText = TextFormat("%d, %d, %d", initialColor.r, initialColor.g, initialColor.b);
                propertyColorRgbEditing = false;
                propertyColorRgbSelectAll = false;
                activePropertyRow = -1;
                floatingPropertyColorPos = { -1.0f, -1.0f };
                propertyColorPickerOpen = true;
                iconGroupColorPickerOpen = false;
                saveStudioSettings();
            }
        }
        EndScissorMode();
        BeginScissorMode((int)settingsContent.x, (int)settingsContent.y,
            (int)settingsContent.width, (int)settingsContent.height);
        if (maxScroll > 0.0f)
        {
            float thumbY = listBounds.y + advancedIconScrollY / maxScroll * (listBounds.height - thumbHeight);
            DrawRectangleRounded(scrollTrack, 0.5f, 6, settingsTheme.canvas);
            DrawRectangleRounded({ trackX, thumbY, 5, thumbHeight }, 0.5f, 6, settingsTheme.muted);
        }
    }

    settingsContentBottom = max(settingsContentBottom, rowY + 36);
    if (studioSettingsTab == 2)
        settingsContentBottom = max(settingsContentBottom, y + h - 60);
    EndScissorMode();
    rlPopMatrix();
    studioSettingsMaxScrollY = max(0.0f,
        (float)settingsContentBottom - (settingsContent.y + settingsContent.height));
    studioSettingsScrollY = std::clamp(studioSettingsScrollY, 0.0f, studioSettingsMaxScrollY);
    if (studioSettingsMaxScrollY > 0.0f)
    {
        float thumbHeight = max(22.0f, settingsScrollTrack.height * settingsScrollTrack.height /
            (settingsScrollTrack.height + studioSettingsMaxScrollY));
        float thumbY = settingsScrollTrack.y + studioSettingsScrollY / studioSettingsMaxScrollY *
            (settingsScrollTrack.height - thumbHeight);
        DrawRectangleRounded(settingsScrollTrack, 0.5f, 6, settingsTheme.canvas);
        DrawRectangleRounded({ settingsScrollTrack.x, thumbY, settingsScrollTrack.width, thumbHeight },
            0.5f, 6, settingsTheme.muted);
    }
    mouse = unscrolledMouse;

    Rectangle closeRect = { (float)x + w - 120, (float)y + h - 48, 90, 32 };
    DrawRectangleRounded(closeRect, 0.18f, 6,
        CheckCollisionPointRec(mouse, closeRect) ? (Color){ 90, 98, 112, 255 } : (Color){ 70, 76, 88, 255 });
    DrawText("Close", (int)closeRect.x + 22, (int)closeRect.y + 7, 16, WHITE);
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, closeRect))
    {
        saveStudioSettings();
        studioSettingsOpen = false;
    }
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, titleClose))
    {
        saveStudioSettings();
        studioSettingsOpen = false;
    }
    if (IsKeyPressed(KEY_ESCAPE))
    {
        saveStudioSettings();
        studioSettingsOpen = false;
    }

    SetTargetFPS(studioSettings.targetFps);
    if (studioSettings.vsync) SetWindowState(FLAG_VSYNC_HINT);
    else ClearWindowState(FLAG_VSYNC_HINT);
    if (propertyColorPickerOpen && propertyPickerExternalTarget != nullptr)
        drawPropertyColorPickerOverlay();
}

void renderProjectSaveDialog()
{
    if (!projectSaveDialogOpen) return;
    int w = 560, h = 190;
    int x = (GetScreenWidth() - w) / 2;
    int y = (GetScreenHeight() - h) / 2;
    DrawRectangle(0, 0, GetScreenWidth(), GetScreenHeight(), Fade(BLACK, 0.45f));
    DrawRectangleRounded({ (float)x, (float)y, (float)w, (float)h }, 0.025f, 8, RAYWHITE);
    DrawRectangleRounded({ (float)x + 1, (float)y + 1, (float)w - 2, 42 }, 0.12f, 8, (Color){ 55, 62, 74, 255 });
    DrawText("Unsaved Project", x + 18, y + 10, 20, WHITE);
    DrawText("This project has unsaved changes. Save before continuing?", x + 20, y + 62, 18, DARKGRAY);
    DrawText(projectName.c_str(), x + 20, y + 91, 16, GRAY);

    Rectangle saveRect = { (float)x + 190, (float)y + 135, 105, 34 };
    Rectangle discardRect = { (float)x + 305, (float)y + 135, 105, 34 };
    Rectangle cancelRect = { (float)x + 420, (float)y + 135, 105, 34 };
    Vector2 mouse = GetMousePosition();
    DrawRectangleRounded(saveRect, 0.18f, 6, CheckCollisionPointRec(mouse, saveRect) ? DARKGRAY : GRAY);
    DrawRectangleRounded(discardRect, 0.18f, 6, CheckCollisionPointRec(mouse, discardRect) ? DARKGRAY : GRAY);
    DrawRectangleRounded(cancelRect, 0.18f, 6, CheckCollisionPointRec(mouse, cancelRect) ? DARKGRAY : GRAY);
    DrawText("Save", (int)saveRect.x + 28, (int)saveRect.y + 8, 16, WHITE);
    DrawText("Don't Save", (int)discardRect.x + 8, (int)discardRect.y + 8, 16, WHITE);
    DrawText("Cancel", (int)cancelRect.x + 24, (int)cancelRect.y + 8, 16, WHITE);

    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
    {
        if (CheckCollisionPointRec(mouse, saveRect))
        {
            if (saveProject()) continuePendingProjectAction(true);
        }
        else if (CheckCollisionPointRec(mouse, discardRect))
            continuePendingProjectAction(false);
        else if (CheckCollisionPointRec(mouse, cancelRect))
        {
            projectSaveDialogOpen = false;
            pendingProjectAction = PendingProjectAction::None;
            // Keep the window open after Cancel even if OS close flag is still set.
            windowCloseConsumed = true;
            projectSaveDialogWasCloseRequest = false;
        }
    }
}

// ============================================================
// Math Functions
// ============================================================

Vector3 getModelWorldPivot(const Model_Instance& model);
Vector3 getPartWorldPivot(const Part& part);

// Collect every Part under an instance tree (used for Model/Folder gizmo moves).
void collectDescendantParts(Instance* root, vector<Part*>& parts)
{
    if (root == nullptr)
        return;
    if (root->getType() == InstanceType::Part)
        parts.push_back(static_cast<Part*>(root));
    for (Instance* child : root->children)
        collectDescendantParts(child, parts);
}

vector<Part*> getSelectedParts()
{
    vector<Part*> parts;

    for (Instance* instance : selectedInstances)
    {
        if (instance == nullptr)
            continue;
        if (instance->getType() == InstanceType::Part)
            parts.push_back(static_cast<Part*>(instance));
        else if (instance->getType() == InstanceType::Model ||
                 instance->getType() == InstanceType::Folder)
            collectDescendantParts(instance, parts);
    }

    // De-dupe if a part is both selected and a descendant of a selected model
    sort(parts.begin(), parts.end());
    parts.erase(unique(parts.begin(), parts.end()), parts.end());
    return parts;
}

// Pivot used for gizmo when selection is Model / Folder / multi-part:
// PrimaryPart path for Model, otherwise average of all descendant part positions.
Vector3 getSelectionGizmoPivot()
{
    if (selectedInstances.size() == 1 && selectedInstances.front() != nullptr)
    {
        Instance* inst = selectedInstances.front();
        if (inst->getType() == InstanceType::Model)
            return getModelWorldPivot(*static_cast<Model_Instance*>(inst));
        if (inst->getType() == InstanceType::Folder)
        {
            Vector3 sum = { 0, 0, 0 };
            int count = 0;
            function<void(Instance*)> walk = [&](Instance* n)
            {
                if (!n) return;
                if (n->getType() == InstanceType::Part)
                {
                    sum = Vector3Add(sum, static_cast<Part*>(n)->cframe.position);
                    count++;
                }
                for (Instance* c : n->children)
                    walk(c);
            };
            walk(inst);
            if (count > 0)
                return Vector3Scale(sum, 1.0f / static_cast<float>(count));
            return { 0, 0, 0 };
        }
        if (inst->getType() == InstanceType::Part)
            return getPartWorldPivot(*static_cast<Part*>(inst));
    }

    vector<Part*> parts = getSelectedParts();
    if (parts.empty())
        return { 0, 0, 0 };
    Vector3 sum = { 0, 0, 0 };
    for (Part* p : parts)
        sum = Vector3Add(sum, getPartWorldPivot(*p));
    return Vector3Scale(sum, 1.0f / static_cast<float>(parts.size()));
}


#endif // BT_CORE_H