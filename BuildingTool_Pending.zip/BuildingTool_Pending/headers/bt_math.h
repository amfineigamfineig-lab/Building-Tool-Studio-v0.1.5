// bt_math.h — Vector3 / Vector2 / CFrame math
// Auto-split from buildingTool_.cpp (keep include order).
#pragma once
#ifndef BT_MATH_H
#define BT_MATH_H

#pragma region "Vector3 Math"

Vector3 GetUpDirection(Vector3 rotation)
{
    float pitch = rotation.x * DEG2RAD;
    float yaw = rotation.y * DEG2RAD;

    Vector3 up;
    up.x = -sinf(yaw) * cosf(pitch);
    up.y = sinf(pitch);
    up.z = cosf(yaw) * cosf(pitch);

    return Vector3Normalize(up);
}

Vector3 rotateVector(Vector3 vector, Vector3 rotation)
{
    Matrix rotationMatrix = MatrixRotateXYZ({
        rotation.x * DEG2RAD,
        rotation.y * DEG2RAD,
        rotation.z * DEG2RAD
    });

    return Vector3Transform(vector, rotationMatrix);
}

Vector3 lerpRotation(Vector3 current, Vector3 target, float amount)
{
    amount = std::clamp(amount, 0.0f, 1.0f);
    auto shortestAngleDelta = [](float from, float to)
    {
        float delta = fmodf(to - from + 180.0f, 360.0f);
        if (delta < 0.0f)
            delta += 360.0f;
        return delta - 180.0f;
    };
    return {
        current.x + shortestAngleDelta(current.x, target.x) * amount,
        current.y + shortestAngleDelta(current.y, target.y) * amount,
        current.z + shortestAngleDelta(current.z, target.z) * amount
    };
}

// Capture Part1's pose relative to Part0 (call when Parts are assigned or Enabled)
inline void captureWeldRelative(WeldConstraint* w)
{
    if (!w || !w->part0 || !w->part1)
        return;
    Vector3 worldDelta = Vector3Subtract(w->part1->cframe.position, w->part0->cframe.position);
    w->relativePosition = rotateVector(worldDelta, {
        -w->part0->cframe.rotation.x,
        -w->part0->cframe.rotation.y,
        -w->part0->cframe.rotation.z
    });
    w->relativeRotation = {
        w->part1->cframe.rotation.x - w->part0->cframe.rotation.x,
        w->part1->cframe.rotation.y - w->part0->cframe.rotation.y,
        w->part1->cframe.rotation.z - w->part0->cframe.rotation.z
    };
    w->relativeCaptured = true;
}

Vector3 rotateCFrameEuler(Vector3 startRotation, Vector3 localAxis, float degrees)
{
    Matrix startMatrix =
        MatrixRotateXYZ({
            startRotation.x * DEG2RAD,
            startRotation.y * DEG2RAD,
            startRotation.z * DEG2RAD
        });

    Matrix deltaMatrix =
        MatrixRotate(
            localAxis,
            -degrees * DEG2RAD
        );

    Matrix resultMatrix =
        MatrixMultiply(
            startMatrix,
            deltaMatrix
        );

    Vector3 resultRadians =
        QuaternionToEuler(
            QuaternionFromMatrix(resultMatrix)
        );

    return Vector3Scale(
        resultRadians,
        -RAD2DEG
    );
}

Vector3 localToWorld(const CFrame& cframe, Vector3 localPosition)
{
    return Vector3Add(
        cframe.position,
        rotateVector(localPosition, cframe.rotation)
    );
}

Vector3 worldToLocal(const CFrame& cframe, Vector3 worldPosition)
{
    Vector3 delta = Vector3Subtract(worldPosition, cframe.position);
    // Inverse rotation via transpose of Euler rotation (approx by rotating with negated order)
    Matrix inv = MatrixInvert(MatrixRotateXYZ({
        cframe.rotation.x * DEG2RAD,
        cframe.rotation.y * DEG2RAD,
        cframe.rotation.z * DEG2RAD
    }));
    return Vector3Transform(delta, inv);
}

// Part pivot in world space = position + rotated PivotOffset
Vector3 getPartWorldPivot(const Part& part)
{
    return localToWorld(part.cframe, part.pivotOffset);
}

void setPartWorldPivot(Part& part, Vector3 worldPivot)
{
    // Keep PivotOffset; move position so pivot lands on worldPivot
    Vector3 worldOffset = rotateVector(part.pivotOffset, part.cframe.rotation);
    part.cframe.position = Vector3Subtract(worldPivot, worldOffset);
}

// Model WorldPivot: PrimaryPart path uses primary + model.pivotOffset;
// otherwise approximate with average of child part positions.
Vector3 getModelWorldPivot(const Model_Instance& model)
{
    if (model.primaryPart != nullptr)
        return localToWorld(model.primaryPart->cframe,
            Vector3Add(model.primaryPart->pivotOffset, model.pivotOffset));

    Vector3 sum = { 0, 0, 0 };
    int count = 0;
    function<void(const Instance*)> walk = [&](const Instance* inst)
    {
        if (!inst) return;
        if (inst->getType() == InstanceType::Part)
        {
            sum = Vector3Add(sum, static_cast<const Part*>(inst)->cframe.position);
            count++;
        }
        for (const Instance* child : inst->children)
            walk(child);
    };
    walk(&model);
    if (count == 0)
        return { 0, 0, 0 };
    return Vector3Scale(sum, 1.0f / static_cast<float>(count));
}

void scaleModelTo(Model_Instance& model, float targetScale, Vector3 pivot)
{
    if (!isfinite(targetScale) || targetScale <= 0.0f)
        return;
    float currentScale = static_cast<float>(model.scale);
    if (!isfinite(currentScale) || currentScale <= 0.0f)
        currentScale = 1.0f;
    float factor = targetScale / currentScale;
    if (!isfinite(factor) || factor <= 0.0f)
        return;

    function<void(Instance*)> scaleParts = [&](Instance* instance)
    {
        if (instance == nullptr)
            return;
        if (instance->getType() == InstanceType::Part)
        {
            Part* part = static_cast<Part*>(instance);
            part->cframe.position = Vector3Add(
                pivot,
                Vector3Scale(Vector3Subtract(part->cframe.position, pivot), factor));
            part->size = Vector3Scale(part->size, factor);
            part->pivotOffset = Vector3Scale(part->pivotOffset, factor);
        }
        else if (instance->getType() == InstanceType::Motor6D)
        {
            Motor6DConstraint* motor = static_cast<Motor6DConstraint*>(instance);
            motor->c0.position = Vector3Scale(motor->c0.position, factor);
            motor->c1.position = Vector3Scale(motor->c1.position, factor);
            motor->transform.position = Vector3Scale(motor->transform.position, factor);
        }
        else if (instance->getType() == InstanceType::WeldConstraint)
        {
            WeldConstraint* weld = static_cast<WeldConstraint*>(instance);
            weld->relativePosition = Vector3Scale(weld->relativePosition, factor);
        }
        for (Instance* child : instance->children)
            scaleParts(child);
    };
    scaleParts(&model);
    model.pivotOffset = Vector3Scale(model.pivotOffset, factor);
    model.scale = targetScale;
}

void scaleModelTo(Model_Instance& model, float targetScale)
{
    scaleModelTo(model, targetScale, getModelWorldPivot(model));
}

float Magnitude(const Vector3& v)
{
    return std::sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
}

#pragma endregion

#pragma region "Vector2 Math"

#pragma endregion
#pragma region "CFrame Math"

CFrame operator*(const CFrame& a, const CFrame& b)
{
    CFrame result;

    // Rotate b's position by a's rotation
    Vector3 rotatedPosition = rotateVector(b.position, a.rotation);

    // Add a's position to the rotated position
    result.position = Vector3Add(a.position, rotatedPosition);

    // Combine rotations (Euler angles)
    result.rotation.x = a.rotation.x + b.rotation.x;
    result.rotation.y = a.rotation.y + b.rotation.y;
    result.rotation.z = a.rotation.z + b.rotation.z;

    return result;
}

Matrix GetCFrameMatrix(const CFrame& cframe)
{
    Matrix rotation =
        MatrixRotateXYZ({
            cframe.rotation.x * DEG2RAD,
            cframe.rotation.y * DEG2RAD,
            cframe.rotation.z * DEG2RAD
        });

    Matrix translation =
        MatrixTranslate(
            cframe.position.x,
            cframe.position.y,
            cframe.position.z
        );

    // Original order used throughout the editor (do not flip — breaks character + gizmos)
    return MatrixMultiply(rotation, translation);
}

Matrix GetBlockTransform(const CFrame& cframe, Vector3 size)
{
    return MatrixMultiply(
        MatrixScale(size.x, size.y, size.z),
        GetCFrameMatrix(cframe)
    );
}

void BeginCFrame(const CFrame& cframe)
{
    Matrix transform = GetCFrameMatrix(cframe);

    rlPushMatrix();

    rlMultMatrixf(
        MatrixToFloat(transform)
    );
}

void EndCFrame()
{
    rlPopMatrix();
}

#pragma endregion

#endif // BT_MATH_H
