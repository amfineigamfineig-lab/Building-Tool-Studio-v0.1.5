// bt_assets.h — UI state, assets, icons, settings structs, early UI helpers
// Auto-split from buildingTool_.cpp (keep include order).
#pragma once
#ifndef BT_ASSETS_H
#define BT_ASSETS_H


#pragma region "2D Contents"

struct TopBarItem
{
    string label;
    string hoverText;

    bool isButton = false;

    vector<TopBarItem*> children;
};

TopBarItem* openMenu = nullptr;

enum class WindowType
{
    Viewport,
    Welcome,
    Script,
    Output,
    Library,
    ExplorerView,   // Explorer undocked into the window-bar / center area
    PropertiesView  // Properties undocked into the window-bar / center area
};

struct WindowTab
{
    WindowType type;
    Script* script = nullptr;
};

WindowType activeWindow = WindowType::Viewport;
Script* activeScript = nullptr;
vector<Script*> openScripts;
vector<WindowTab> windowTabs = {
    { WindowType::Viewport, nullptr },
    { WindowType::Output, nullptr }
};

// Insert Object menu (Ctrl+I)
bool insertMenuOpen = false;

// Right-click context menu (viewport / selection)
struct ContextMenuState
{
    bool open = false;
    float x = 0;
    float y = 0;
    int hover = -1;
    // 0 = empty world, 1 = selection
    int mode = 0;
};
ContextMenuState contextMenu;
bool showPartOrientationGuides = false;
// Distinguish right-click (menu) from right-hold (orbit / drag)
bool rightClickPending = false;
bool rightClickDragged = false;
Vector2 rightClickOrigin = { 0, 0 };
double rightClickPressTime = 0.0;
enum class RightClickZone { None, Viewport, Explorer };
RightClickZone rightClickZone = RightClickZone::None;
Instance* rightClickExplorerTarget = nullptr;

// Floating sub-windows (settings / insert) — positions inside the studio client area
Vector2 floatingStudioPos = { -1, -1 };
Vector2 floatingGamePos = { -1, -1 };
Vector2 floatingInsertPos = { -1, -1 };
Vector2 floatingPropertyColorPos = { -1, -1 };
bool floatingStudioDrag = false;
bool floatingGameDrag = false;
bool floatingInsertDrag = false;
bool floatingPropertyColorDrag = false;
Vector2 floatingDragOffset = { 0, 0 };

int insertMenuHover = -1;
float insertMenuScrollY = 0.0f;
float windowBarScrollX = 0.0f;
bool windowBarDraggingScroll = false;
int activeRibbonTab = 0;
bool scriptFindOpen = false;
bool scriptFindReplaceOpen = false;
int scriptFindFocusedField = 0;
string scriptFindQuery;
string scriptReplaceText;
int scriptFindMatchStart = -1;
int draggedWindowTab = -1;
bool windowBarTabDragMoved = false;
Vector2 windowBarTabDragStart = { 0, 0 };
Vector2 windowBarTabDragOffset = { 0, 0 };

// ============================================================
// Project embedded assets (images / sounds stored inside .hlx)
// ============================================================
enum class ProjectAssetType
{
    Image,
    Sound,
    Mesh
};

// Import progress overlay (shown while reading / compressing large assets)
struct ImportProgressState
{
    bool active = false;
    float progress = 0.0f; // 0..1
    string fileName;
    string status;
    ProjectAssetType type = ProjectAssetType::Image;
    Texture2D preview = { 0 };
    bool hasPreview = false;
};
ImportProgressState importProgress;

// Sound instance sample-preview playback (property panel)
Music soundPreviewMusic = { 0 };
bool soundPreviewMusicLoaded = false;
bool soundPreviewPlaying = false;
string soundPreviewAssetId;
float soundPreviewDuration = 0.0f;
float soundPreviewSeek = 0.0f; // 0..1
bool soundPreviewSeekDragging = false;

struct ProjectAsset
{
    string id;            // AssetID (stable within project)
    string name;          // Display name
    ProjectAssetType type = ProjectAssetType::Image;
    string fileType;      // e.g. "png", "wav", "ogg"
    vector<uint8_t> data; // File bytes (may be zstd-compressed payload)
    bool compressed = false; // true when `data` is ZSTD-compressed

    // Runtime caches (not serialized)
    Texture2D texture = { 0 };
    bool textureLoaded = false;
    Sound sound = { 0 };
    bool soundLoaded = false;
    Model meshModel = { 0 };
    bool meshModelLoaded = false;
    bool meshModelLoadAttempted = false;
    vector<Texture2D> meshDiffuseTextures;
    Vector3 meshBoundsMin = { 0, 0, 0 };
    Vector3 meshBoundsMax = { 0, 0, 0 };
};

vector<ProjectAsset> projectAssets;
int nextAssetIdCounter = 1;
int libraryScrollY = 0;
int libraryHoverIndex = -1;
bool audioDeviceReady = false;
bool projectDirty = false; // declared early — used by asset import helpers
extern Service workspace;
void addInstanceToParent(Instance* parent, Instance* child);

string generateAssetId();
string base64Encode(const vector<uint8_t>& data);
vector<uint8_t> base64Decode(const string& input);
void unloadProjectAssetRuntime(ProjectAsset& asset);
void clearProjectAssets();
bool ensureProjectAssetLoaded(ProjectAsset& asset);
string assetTypeName(ProjectAssetType type);
ProjectAssetType parseAssetType(const string& s);
ProjectAsset* findProjectAssetById(const string& id);
bool importAssetFromPath(const string& path);
bool importMeshPartFromPath(const string& path, Vector3 meshSize);
bool browseAndImportAsset();
void deleteProjectAssetAt(int index);
void focusActiveWindow();
void openLibraryWindow();
void renderLibraryWindow();
void handleLibraryInput();
vector<string> outputLogs;
enum class OutputSeverity
{
    Info,
    Warning,
    Error
};

struct OutputEntry
{
    string text;
    OutputSeverity severity;
    int line = -1;   // 1-based when known
    int column = -1; // 1-based when known
    Script* sourceScript = nullptr;
};

vector<OutputEntry> outputEntries;
int outputSelectStart = -1;
int outputSelectEnd = -1;
bool outputSelecting = false;

enum class DiagnosticSeverity { Error, Warning, Info };

struct ScriptDiagnostic
{
    int line = 1;      // 1-based
    int column = 1;    // 1-based
    int endColumn = -1;
    DiagnosticSeverity severity = DiagnosticSeverity::Error;
    string message;
};

// Diagnostics for the script currently open in the editor (refreshed on edit / open)
vector<ScriptDiagnostic> scriptDiagnostics;
unordered_map<Script*, vector<ScriptDiagnostic>> scriptRuntimeDiagnostics;
string scriptDiagnosticsSourceKey; // last analyzed source fingerprint
int scriptDiagHoverIndex = -1;
int sanitizeScriptSourceInPlace(std::string& source);
std::string sanitizeScriptClipboardText(const char* clipboard);

// Instance pointer properties (serialized as paths, resolved after load)
struct PendingInstanceRef
{
    Instance* owner = nullptr;
    string property;
    string path;
};
vector<PendingInstanceRef> pendingInstanceRefs;


float outputHeight = 280.0f;
bool outputResizing = false;
float scriptScrollX = 0.0f;
float scriptScrollY = 0.0f;
float outputScrollX = 0.0f;
float outputScrollY = 0.0f;
bool documentDraggingScrollX = false;
bool documentDraggingScrollY = false;
// When true, Output sticks to the latest message. Breaks if user scrolls up;
// resumes when they scroll back to the bottom.
bool outputFollowTail = true;
const size_t OUTPUT_MAX_MESSAGES = 300;
// Minimum scrollbar thumb size (px). Thumb still scales down with longer content;
// drag maps the remaining track range so small thumbs travel farther in content.
const float SCROLLBAR_MIN_THUMB = 18.0f;
float scrollbarThumbSize(float trackSize, float maxScroll);
float scrollbarScrollFromMouse(float mousePos, float trackStart, float trackSize,
    float thumbSize, float maxScroll);
int scriptCursor = 0;
int scriptFontSize = 16;
int scriptSelectionStart = -1;
int scriptSelectionEnd = -1;
bool scriptSelecting = false;
enum class ScriptCompletionKind
{
    Keyword, Variable, Function, Property, Event, Value, Type, Enum, Snippet, Folder, Text, Module
};

struct ScriptCompletionItem
{
    string label;
    ScriptCompletionKind kind = ScriptCompletionKind::Variable;
    string signature;
    string description;
};

bool scriptCompletionVisible = false;
int scriptCompletionIndex = 0;
int scriptCompletionScrollIndex = 0;
vector<ScriptCompletionItem> scriptCompletionMatches;
string scriptCompletionPrefix;
Rectangle scriptCompletionBounds = { 0, 0, 0, 0 };
Rectangle scriptCompletionDetailBounds = { 0, 0, 0, 0 };
double scriptLastInputTime = 0.0;
double scriptCaretResetTime = 0.0;
bool runtimePlaying = false;
bool runtimeClientMode = false;
PlayerInstance* runtimePlayer = nullptr;
Model_Instance* runtimeCharacter = nullptr;
HumanoidInstance* runtimeHumanoid = nullptr;
CameraInstance* runtimeCameraInstance = nullptr;
string runtimeStatus;
vector<pair<Script*, string>> runtimeSourceSnapshot;
struct ScriptEditSnapshot
{
    Script* script = nullptr;
    string source;
    int cursor = 0;
    int selectionStart = -1;
    int selectionEnd = -1;
};
vector<ScriptEditSnapshot> scriptUndoHistory;
vector<ScriptEditSnapshot> scriptRedoHistory;
struct RuntimeInstanceSnapshot
{
    Instance* instance = nullptr;
    string name;
    bool isPart = false;
    bool anchored = false;
    Vector3 size = { 0.0f, 0.0f, 0.0f };
    Color color = BLANK;
    CFrame cframe = { { 0.0f, 0.0f, 0.0f }, { 0.0f, 0.0f, 0.0f } };
    Vector3 velocity = { 0.0f, 0.0f, 0.0f };
};
vector<RuntimeInstanceSnapshot> runtimeInstanceSnapshot;
vector<Instance*> runtimeCreatedInstances; // Instance.new during Play — destroyed on Stop
unordered_map<string, Instance*> runtimePathToInstance; // stable Luau __Path → Instance*
struct RuntimeLuauCoroutine
{
    lua_State* thread = nullptr;
    string label;
    double resumeAt = 0.0;
    int resumeArguments = 0;
};
lua_State* runtimeLuauState = nullptr;
vector<RuntimeLuauCoroutine> runtimeLuauCoroutines;
const string RUNTIME_PROPERTY_UPDATE_PREFIX = "__BUILDING_TOOL_PROPERTY_UPDATE__";
const string RUNTIME_SOUND_CMD_PREFIX = "__BUILDING_TOOL_SOUND_CMD__";
const string RUNTIME_CREATE_PREFIX = "__BUILDING_TOOL_CREATE__";

// Runtime Sound instance playback streams (path → Music)
unordered_map<string, Music> runtimeSoundStreams;
unordered_map<string, bool> runtimeSoundPlaying;
// MusicStream keeps reading the file — do NOT delete until UnloadMusicStream.
unordered_map<string, string> runtimeSoundTempFiles;
string soundPreviewTempPath;
const string BUILDING_TOOL_VERSION = "0.1.5";
const string BUILDING_TOOL_VERSION_LABEL = "BUILDING TOOL 0.1.5";

void updateApplicationWindowTitle(); // defined after globals

bool forceExit = false;

struct LuauPropertyDefinition
{
    string name;
    string type;
};

struct LuauFunctionDefinition
{
    string name;
    string parameters;
    string returnType;
    string body;
};

struct LuauTypeDefinition
{
    string name;
    vector<LuauPropertyDefinition> properties;
    vector<LuauFunctionDefinition> functions;
};

struct LuauGlobalDefinition
{
    string name;
    string type;
    string expression;
    vector<LuauFunctionDefinition> functions;
};

// Add project-specific Luau types, properties, globals, or table functions here.
vector<LuauTypeDefinition> luauTypeDefinitions = {
    {
        "Instance",
        {
            { "Name", "string" },
            { "Parent", "Instance?" },
            { "ClassName", "string" },
            { "CFrame", "any" },
            { "Position", "any" },
            { "Orientation", "any" },
            { "Size", "any" },
            { "Color", "any" },
            { "Anchored", "boolean" },
            { "AdvancedPhysics", "boolean" },
            { "Density", "number" },
            { "Friction", "number" },
            { "Ambient", "any" },
            { "OutdoorAmbient", "any" },
            { "ColorShift_Top", "any" },
            { "ColorShift_Bottom", "any" },
            { "FogColor", "any" },
            { "FogStart", "number" },
            { "FogEnd", "number" },
            { "Brightness", "number" },
            { "ExposureCompensation", "number" },
            { "EnvironmentDiffuseScale", "number" },
            { "EnvironmentSpecularScale", "number" },
            { "GlobalShadows", "boolean" },
            { "ShadowSoftness", "string" }, // Hard | Soft | Sharp
            { "ClockTime", "number" },
            { "GeographicLatitude", "number" },
            { "Blur", "number" },
            { "Changed", "RBXScriptSignal" },
            { "Touched", "RBXScriptSignal" },
            { "AncestryChanged", "RBXScriptSignal" },
            { "Event", "RBXScriptSignal" },
            { "OnServerEvent", "RBXScriptSignal" },
            { "OnClientEvent", "RBXScriptSignal" },
            { "OnInvoke", "any" },
            { "OnServerInvoke", "any" },
            { "OnClientInvoke", "any" }
        },
        {
            { "GetChildren", "", "{Instance}", "return {}" },
            { "FindFirstChild", "name: string, recursive: boolean?", "Instance?", "return nil" },
            { "FindFirstChildOfClass", "className: string", "Instance?", "return nil" },
            { "FindFirstChildWhichIsA", "className: string, recursive: boolean", "Instance?", "return nil" },
            { "FindFirstAncestor", "name: string", "Instance?", "return nil" },
            { "FindFirstAncestorOfClass", "className: string", "Instance?", "return nil" },
            { "FindFirstAncestorWhichIsA", "className: string", "Instance?", "return nil" },
            { "FindFirstDescendant", "name: string", "Instance?", "return nil" },
            { "WaitForChild", "name: string, timeout: number?", "Instance?", "return nil" },
            { "GetService", "serviceName: string", "Instance?", "return nil" },
            { "GetFullName", "", "string", "return \"\"" },
            { "GetPropertyChangedSignal", "property: string", "RBXScriptSignal", "return {}" },
            { "GetAttributeChangedSignal", "attribute: string", "RBXScriptSignal", "return {}" },
            { "Fire", "...any", "()", "" },
            { "FireServer", "...any", "()", "" },
            { "FireClient", "player: Instance, ...any", "()", "" },
            { "FireAllClients", "...any", "()", "" },
            { "Invoke", "...any", "any", "return nil" },
            { "InvokeServer", "...any", "any", "return nil" },
            { "InvokeClient", "player: Instance, ...any", "any", "return nil" }
        }
    }
};

vector<LuauGlobalDefinition> luauGlobalDefinitions = {
    { "game", "Instance", "__buildingToolInstance(\"game\")", {} },
    { "workspace", "Instance", "__buildingToolInstance(\"workspace\")", {} },
    { "pointer", "Instance?", "nil", {} },
    { "__version", "string", "\"" + BUILDING_TOOL_VERSION + "\"", {} }
};

vector<LuauFunctionDefinition> luauGlobalFunctions;

// Roblox Studio–like Luau dark theme
Color SCRIPT_BACKGROUND = { 37, 37, 37, 255 };
Color SCRIPT_GUTTER = { 46, 46, 46, 255 };
Color SCRIPT_TEXT = { 220, 220, 220, 255 };
Color SCRIPT_COMMENT = { 102, 102, 102, 255 };
Color SCRIPT_STRING = { 173, 241, 149, 255 };
Color SCRIPT_KEYWORD = { 248, 109, 124, 255 };
Color SCRIPT_LITERAL = { 255, 198, 0, 255 };
Color SCRIPT_FUNCTION = { 253, 221, 140, 255 };
Color SCRIPT_NUMBER = { 255, 198, 0, 255 };
Color SCRIPT_BUILTIN = { 132, 214, 247, 255 };
Color SCRIPT_OPERATOR = { 180, 180, 180, 255 };
Color SCRIPT_TYPE = { 180, 160, 255, 255 };
Color SCRIPT_SELECTION = { 45, 105, 180, 255 };
Color SCRIPT_FIND_HIGHLIGHT = { 208, 155, 43, 170 };

void applyStudioScriptTheme()
{
    SCRIPT_SELECTION = studioSettings.theme == "Light"
        ? (Color){ 107, 166, 224, 150 } : (Color){ 45, 105, 180, 255 };
    SCRIPT_FIND_HIGHLIGHT = studioSettings.theme == "Light"
        ? (Color){ 238, 189, 75, 180 } : (Color){ 208, 155, 43, 170 };
    for (const CustomEditorTheme& theme : customEditorThemes)
    {
        if (studioSettings.theme != theme.name)
            continue;
        SCRIPT_BACKGROUND = theme.scriptBackground;
        SCRIPT_GUTTER = theme.scriptGutter;
        SCRIPT_TEXT = theme.scriptText;
        SCRIPT_COMMENT = theme.scriptComment;
        SCRIPT_STRING = theme.scriptString;
        SCRIPT_KEYWORD = theme.scriptKeyword;
        SCRIPT_LITERAL = theme.scriptLiteral;
        SCRIPT_FUNCTION = theme.scriptFunction;
        SCRIPT_NUMBER = theme.scriptNumber;
        SCRIPT_BUILTIN = theme.scriptBuiltin;
        SCRIPT_OPERATOR = theme.scriptOperator;
        SCRIPT_TYPE = theme.scriptType;
        SCRIPT_SELECTION = theme.scriptSelection;
        SCRIPT_FIND_HIGHLIGHT = theme.scriptFindHighlight;
        return;
    }

    if (studioSettings.theme == "Light")
    {
        SCRIPT_BACKGROUND = { 250, 251, 253, 255 }; SCRIPT_GUTTER = { 235, 239, 244, 255 };
        SCRIPT_TEXT = { 42, 48, 56, 255 }; SCRIPT_COMMENT = { 90, 130, 104, 255 };
        SCRIPT_STRING = { 166, 70, 34, 255 }; SCRIPT_KEYWORD = { 177, 39, 77, 255 };
        SCRIPT_LITERAL = { 155, 104, 0, 255 }; SCRIPT_FUNCTION = { 132, 83, 15, 255 };
        SCRIPT_NUMBER = { 28, 113, 129, 255 }; SCRIPT_BUILTIN = { 25, 104, 157, 255 };
        SCRIPT_OPERATOR = { 86, 94, 105, 255 }; SCRIPT_TYPE = { 106, 73, 156, 255 };
    }
    else if (studioSettings.theme == "Gray")
    {
        SCRIPT_BACKGROUND = { 38, 40, 43, 255 }; SCRIPT_GUTTER = { 48, 50, 53, 255 };
        SCRIPT_TEXT = { 224, 226, 229, 255 }; SCRIPT_COMMENT = { 138, 151, 139, 255 };
        SCRIPT_STRING = { 190, 210, 151, 255 }; SCRIPT_KEYWORD = { 226, 132, 149, 255 };
        SCRIPT_LITERAL = { 225, 190, 105, 255 }; SCRIPT_FUNCTION = { 229, 190, 129, 255 };
        SCRIPT_NUMBER = { 147, 192, 203, 255 }; SCRIPT_BUILTIN = { 135, 191, 213, 255 };
        SCRIPT_OPERATOR = { 180, 184, 190, 255 }; SCRIPT_TYPE = { 182, 164, 211, 255 };
    }
    else if (studioSettings.theme == "Orange")
    {
        SCRIPT_BACKGROUND = { 38, 31, 27, 255 }; SCRIPT_GUTTER = { 51, 40, 32, 255 };
        SCRIPT_TEXT = { 246, 229, 210, 255 }; SCRIPT_COMMENT = { 163, 142, 112, 255 };
        SCRIPT_STRING = { 180, 204, 133, 255 }; SCRIPT_KEYWORD = { 246, 132, 100, 255 };
        SCRIPT_LITERAL = { 244, 190, 91, 255 }; SCRIPT_FUNCTION = { 255, 198, 115, 255 };
        SCRIPT_NUMBER = { 113, 196, 205, 255 }; SCRIPT_BUILTIN = { 112, 183, 221, 255 };
        SCRIPT_OPERATOR = { 212, 189, 166, 255 }; SCRIPT_TYPE = { 206, 169, 212, 255 };
    }
    else
    {
        SCRIPT_BACKGROUND = { 37, 37, 37, 255 }; SCRIPT_GUTTER = { 46, 46, 46, 255 };
        SCRIPT_TEXT = { 220, 220, 220, 255 }; SCRIPT_COMMENT = { 102, 102, 102, 255 };
        SCRIPT_STRING = { 173, 241, 149, 255 }; SCRIPT_KEYWORD = { 248, 109, 124, 255 };
        SCRIPT_LITERAL = { 255, 198, 0, 255 }; SCRIPT_FUNCTION = { 253, 221, 140, 255 };
        SCRIPT_NUMBER = { 255, 198, 0, 255 }; SCRIPT_BUILTIN = { 132, 214, 247, 255 };
        SCRIPT_OPERATOR = { 180, 180, 180, 255 }; SCRIPT_TYPE = { 180, 160, 255, 255 };
    }
}
vector<string> SCRIPT_COMPLETION_WORDS = {
    // keywords (Luau)
    "and", "break", "continue", "do", "else", "elseif", "end", "export", "false", "for",
    "function", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true",
    "type", "typeof", "until", "while",
    // globals / services
    "print", "warn", "error", "assert", "require", "wait", "delay", "spawn", "tick", "time",
    "task", "game", "workspace", "script", "plugin", "shared", "_G", "pointer", "__version",
    "Players", "Lighting", "ReplicatedStorage", "ServerStorage", "ServerScriptService",
    "RunService", "TweenService", "UserInputService", "SoundService",
    // types / constructors
    "Instance", "Vector2", "Vector3", "CFrame", "Color3", "UDim", "UDim2", "BrickColor",
    "NumberRange", "NumberSequence", "ColorSequence", "Ray", "Region3", "Random", "TweenInfo",
    "Enum", "buffer", "vector",
    // libraries
    "math", "string", "table", "bit32", "coroutine", "debug", "os", "utf8",
    "pairs", "ipairs", "tonumber", "tostring", "select", "unpack", "rawget", "rawset", "rawequal",
    "setmetatable", "getmetatable", "pcall", "xpcall", "next",
    // Instance / API
    "new", "Clone", "Destroy", "GetChildren", "FindFirstChild", "FindFirstChildOfClass",
    "FindFirstChildWhichIsA", "FindFirstAncestor", "FindFirstAncestorOfClass",
    "FindFirstAncestorWhichIsA", "FindFirstDescendant", "WaitForChild", "GetService",
    "GetFullName", "IsA", "GetPropertyChangedSignal",
    // Vector / CFrame
    "fromRGB", "fromHSV", "fromAxisAngle", "fromEulerAnglesXYZ", "fromEulerAnglesYXZ",
    "fromMatrix", "lookAt", "lerp", "inverse", "components", "unit", "zero",
    "xAxis", "yAxis", "zAxis", "forward", "magnitude", "dot", "cross", "Angle",
    // task
    "defer", "cancel", "wait", "spawn", "delay",
    // properties common
    "Name", "Parent", "ClassName", "Anchored", "AdvancedPhysics", "Density", "Friction",
    "CanCollide", "Transparency", "Size", "Position",
    "Orientation", "CFrame", "Color", "WalkSpeed", "JumpPower", "HipHeight", "Health", "MaxHealth"
};

int getScriptTabWidth(const Script* script)
{
    if (script == nullptr)
        return 220;

    return max(220, MeasureText(script->name.c_str(), 16) + 52);
}

int getWindowTabWidth(const WindowTab& tab)
{
    if (tab.type == WindowType::Script)
        return getScriptTabWidth(tab.script);

    const char* label =
        tab.type == WindowType::Viewport ? "Viewport" :
        tab.type == WindowType::Welcome ? "Welcome" :
        tab.type == WindowType::Output ? "Output" :
        tab.type == WindowType::Library ? "Asset Manager" :
        tab.type == WindowType::ExplorerView ? "Explorer" :
        tab.type == WindowType::PropertiesView ? "Properties" :
        "Window";

    int textW = MeasureText(label, 16);
    // padding left/right + optional close button space for closable system tabs
    bool closable =
        tab.type == WindowType::Library ||
        tab.type == WindowType::ExplorerView ||
        tab.type == WindowType::PropertiesView;
    int pad = closable ? 52 : 28;
    return max(72, textW + pad);
}

int getWindowBarContentWidth()
{
    int width = 8;
    for (const WindowTab& tab : windowTabs)
        width += getWindowTabWidth(tab);
    return width;
}

void addOutputLog(const string& message, int line = -1, int column = -1, Script* script = nullptr)
{
    OutputSeverity severity = OutputSeverity::Info;
    if (message.find("[Error]") != string::npos ||
        message.find("error") != string::npos ||
        message.find("Error") != string::npos ||
        message.find("attempt to") != string::npos ||
        message.find("stack traceback") != string::npos ||
        message.find("[Analysis]") != string::npos)
        severity = OutputSeverity::Error;
    else if (message.find("[Warning]") != string::npos ||
             message.find("warning") != string::npos ||
             message.find("[Analysis Warning]") != string::npos)
        severity = OutputSeverity::Warning;

    // Prefer explicit location; else parse Luau-style ":line:" or ":line:col:"
    int ln = line, col = column;
    if (ln < 0)
    {
        // Patterns: [string "x"]:12: msg  |  file:12: msg  |  :12:33: msg
        size_t pos = 0;
        while (pos < message.size())
        {
            size_t colon = message.find(':', pos);
            if (colon == string::npos) break;
            // look for digits after colon
            size_t i = colon + 1;
            if (i >= message.size() || !isdigit((unsigned char)message[i]))
            {
                pos = colon + 1;
                continue;
            }
            int num = 0;
            while (i < message.size() && isdigit((unsigned char)message[i]))
            {
                num = num * 10 + (message[i] - '0');
                i++;
            }
            if (i < message.size() && message[i] == ':' && num > 0)
            {
                ln = num;
                // optional column
                size_t j = i + 1;
                if (j < message.size() && isdigit((unsigned char)message[j]))
                {
                    int cnum = 0;
                    while (j < message.size() && isdigit((unsigned char)message[j]))
                    {
                        cnum = cnum * 10 + (message[j] - '0');
                        j++;
                    }
                    if (j < message.size() && message[j] == ':')
                        col = cnum;
                }
                break;
            }
            pos = colon + 1;
        }
    }

    string text = message;
    if (ln > 0)
    {
        // Format: ::[Ln: n][Col: m]::
        if (col < 1) col = 1;
        string loc = "::[Ln: " + to_string(ln) + "][Col: " + to_string(col) + "]::";
        if (message.find("::[Ln:") == string::npos)
            text = loc + " " + message;
    }

    outputEntries.push_back({ text, severity, ln, col, script });

    // Attach diagnostics to the script so the editor can highlight the line
    if (script != nullptr && ln > 0 &&
        (severity == OutputSeverity::Error || severity == OutputSeverity::Warning))
    {
        ScriptDiagnostic d;
        d.line = ln;
        d.column = max(1, col);
        d.endColumn = -1;
        d.severity = (severity == OutputSeverity::Error)
            ? DiagnosticSeverity::Error : DiagnosticSeverity::Warning;
        d.message = message;
        scriptRuntimeDiagnostics[script].push_back(d);
        if (activeScript == script)
            scriptDiagnosticsSourceKey.clear(); // force refresh
    }
    // Cap message history — drop oldest until under limit
    while (outputEntries.size() > OUTPUT_MAX_MESSAGES)
        outputEntries.erase(outputEntries.begin());

    // Auto-scroll to latest when following the tail
    if (outputFollowTail)
    {
        // Actual max is applied next frame in render; push large so clamp lands at bottom
        outputScrollY = 1.0e9f;
    }
}

// Parse "line:col: message" or ":line: message" from Luau errors
bool parseLuauErrorLocation(const string& error, int& outLine, int& outCol, string& outMsg)
{
    outLine = -1;
    outCol = -1;
    outMsg = error;

    // Prefer Luau chunk form:  ...]:LINE: message  or  ...]:LINE:COL: message
    size_t br = error.find("]:");
    if (br != string::npos)
    {
        size_t i = br + 2;
        if (i < error.size() && isdigit(static_cast<unsigned char>(error[i])))
        {
            int num = 0;
            while (i < error.size() && isdigit(static_cast<unsigned char>(error[i])))
            {
                num = num * 10 + (error[i] - '0');
                i++;
            }
            if (i < error.size() && error[i] == ':' && num > 0)
            {
                outLine = num;
                size_t j = i + 1;
                if (j < error.size() && isdigit(static_cast<unsigned char>(error[j])))
                {
                    int cnum = 0;
                    while (j < error.size() && isdigit(static_cast<unsigned char>(error[j])))
                    {
                        cnum = cnum * 10 + (error[j] - '0');
                        j++;
                    }
                    if (j < error.size() && (error[j] == ':' || error[j] == ' '))
                    {
                        outCol = cnum;
                        outMsg = error.substr(j + (error[j] == ':' ? 1 : 0));
                        while (!outMsg.empty() && outMsg[0] == ' ') outMsg.erase(outMsg.begin());
                        return true;
                    }
                }
                outMsg = error.substr(i + 1);
                while (!outMsg.empty() && outMsg[0] == ' ') outMsg.erase(outMsg.begin());
                return true;
            }
        }
    }

    // Fallback: first :digits: pattern
    size_t pos = 0;
    while (pos < error.size())
    {
        size_t colon = error.find(':', pos);
        if (colon == string::npos) break;
        size_t i = colon + 1;
        if (i >= error.size() || !isdigit(static_cast<unsigned char>(error[i])))
        {
            pos = colon + 1;
            continue;
        }
        int num = 0;
        while (i < error.size() && isdigit(static_cast<unsigned char>(error[i])))
        {
            num = num * 10 + (error[i] - '0');
            i++;
        }
        if (i < error.size() && error[i] == ':' && num > 0)
        {
            outLine = num;
            outMsg = error.substr(i + 1);
            while (!outMsg.empty() && outMsg[0] == ' ') outMsg.erase(outMsg.begin());
            return true;
        }
        pos = colon + 1;
    }
    return false;
}

void analyzeScriptSource(const string& source, vector<ScriptDiagnostic>& out)
{
    out.clear();
    if (source.empty())
        return;

    string cleaned = source;
    int nClean = sanitizeScriptSourceInPlace(cleaned);
    if (nClean > 0)
    {
        out.push_back({ 1, 1, -1, DiagnosticSeverity::Warning,
            "Source had " + to_string(nClean) +
            " invisible/non-ASCII character(s) stripped (BOM, smart quotes, zero-width, etc.)" });
    }

    // Wrap as a function so we parse the full script WITHOUT executing side effects.
    // Line numbers from the compiler are +1 (the "local function ..." line).
    const string wrapped = string("local function __bt_analysis_chunk_()\n") + cleaned + "\nend\n";

    lua_CompileOptions options = {};
    options.debugLevel = 1;
    options.coverageLevel = 0;
    size_t bytecodeSize = 0;
    char* bytecode = luau_compile(wrapped.c_str(), wrapped.size(), &options, &bytecodeSize);
    if (bytecode == nullptr)
    {
        out.push_back({ 1, 1, -1, DiagnosticSeverity::Error, "compiler returned null bytecode" });
        return;
    }

    lua_State* temp = luaL_newstate();
    if (temp == nullptr)
    {
        free(bytecode);
        out.push_back({ 1, 1, -1, DiagnosticSeverity::Error, "could not create analysis VM" });
        return;
    }
    luaL_openlibs(temp);

    int loadResult = luau_load(temp, "=analysis", bytecode, bytecodeSize, 0);
    free(bytecode);
    if (loadResult != LUA_OK)
    {
        const char* err = lua_tostring(temp, -1);
        int ln = 1, col = 1;
        string msg = err ? err : "load failed";
        parseLuauErrorLocation(msg, ln, col, msg);
        if (ln > 1) ln -= 1; // wrapper line
        if (ln < 1) ln = 1;
        out.push_back({ ln, max(1, col), -1, DiagnosticSeverity::Error, msg });
        lua_close(temp);
        return;
    }

    // Running only *defines* the function — body does not run.
    if (lua_pcall(temp, 0, 0, 0) != LUA_OK)
    {
        const char* err = lua_tostring(temp, -1);
        int ln = 1, col = 1;
        string msg = err ? err : "compile error";
        parseLuauErrorLocation(msg, ln, col, msg);
        if (ln > 1) ln -= 1;
        if (ln < 1) ln = 1;
        out.push_back({ ln, max(1, col), -1, DiagnosticSeverity::Error, msg });
        lua_close(temp);
        return;
    }
    lua_close(temp);

    // Lightweight static warnings on cleaned source
    {
        int line = 1;
        size_t lineStart = 0;
        for (size_t i = 0; i <= cleaned.size(); ++i)
        {
            if (i == cleaned.size() || cleaned[i] == '\n')
            {
                string row = cleaned.substr(lineStart, i - lineStart);
                size_t w = row.find("wait(");
                if (w != string::npos)
                {
                    bool ok = true;
                    if (w >= 5 && row.compare(w - 5, 5, "task.") == 0) ok = false;
                    if (w > 0 && (isalnum((unsigned char)row[w - 1]) || row[w - 1] == '_')) ok = false;
                    if (ok)
                        out.push_back({ line, (int)w + 1, (int)w + 5, DiagnosticSeverity::Warning,
                            "wait() is legacy — prefer task.wait()" });
                }
                size_t s = row.find("spawn(");
                if (s != string::npos)
                {
                    if (!(s >= 5 && row.compare(s - 5, 5, "task.") == 0) &&
                        (s == 0 || (!isalnum((unsigned char)row[s - 1]) && row[s - 1] != '_')))
                        out.push_back({ line, (int)s + 1, (int)s + 6, DiagnosticSeverity::Warning,
                            "spawn() is legacy — prefer task.spawn()" });
                }
                line++;
                lineStart = i + 1;
            }
        }
    }
}


static int countSourceLines(const string& source)
{
    if (source.empty()) return 1;
    int lines = 1;
    for (char c : source)
        if (c == '\n') lines++;
    return lines;
}

void refreshScriptDiagnostics(const string& source)
{
    static string lastSourceText;
    const bool textChanged = (source != lastSourceText);
    const bool needRefresh = (source != scriptDiagnosticsSourceKey);

    if (!needRefresh)
        return;

    if (textChanged && activeScript != nullptr)
    {
        // User edited the script → drop stale Play highlights
        scriptRuntimeDiagnostics.erase(activeScript);
        lastSourceText = source;
    }
    else if (textChanged)
    {
        lastSourceText = source;
    }

    analyzeScriptSource(source, scriptDiagnostics);

    // Merge still-valid runtime diagnostics for the open script
    if (activeScript != nullptr)
    {
        auto it = scriptRuntimeDiagnostics.find(activeScript);
        if (it != scriptRuntimeDiagnostics.end())
        {
            for (const ScriptDiagnostic& d : it->second)
                scriptDiagnostics.push_back(d);
        }
    }

    const int maxLines = countSourceLines(source);
    for (size_t i = 0; i < scriptDiagnostics.size(); )
    {
        ScriptDiagnostic& d = scriptDiagnostics[i];
        if (d.line < 1) d.line = 1;
        if (d.line > maxLines)
        {
            scriptDiagnostics.erase(scriptDiagnostics.begin() + static_cast<ptrdiff_t>(i));
            continue;
        }
        if (d.column < 1) d.column = 1;
        ++i;
    }

    scriptDiagnosticsSourceKey = source;
    scriptDiagHoverIndex = -1;
}



string generateAssetId()
{
    // Roblox-style numeric content id form used inside the project: assetId://N
    return "assetId://" + to_string(nextAssetIdCounter++);
}

static const char* BASE64_CHARS =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

string base64Encode(const vector<uint8_t>& data)
{
    string out;
    out.reserve(((data.size() + 2) / 3) * 4);
    size_t i = 0;
    while (i + 2 < data.size())
    {
        uint32_t n = (uint32_t(data[i]) << 16) | (uint32_t(data[i + 1]) << 8) | uint32_t(data[i + 2]);
        out.push_back(BASE64_CHARS[(n >> 18) & 63]);
        out.push_back(BASE64_CHARS[(n >> 12) & 63]);
        out.push_back(BASE64_CHARS[(n >> 6) & 63]);
        out.push_back(BASE64_CHARS[n & 63]);
        i += 3;
    }
    if (i < data.size())
    {
        uint32_t n = uint32_t(data[i]) << 16;
        out.push_back(BASE64_CHARS[(n >> 18) & 63]);
        if (i + 1 < data.size())
        {
            n |= uint32_t(data[i + 1]) << 8;
            out.push_back(BASE64_CHARS[(n >> 12) & 63]);
            out.push_back(BASE64_CHARS[(n >> 6) & 63]);
            out.push_back('=');
        }
        else
        {
            out.push_back(BASE64_CHARS[(n >> 12) & 63]);
            out.push_back('=');
            out.push_back('=');
        }
    }
    return out;
}

vector<uint8_t> base64Decode(const string& input)
{
    auto valueOf = [](char c) -> int
    {
        if (c >= 'A' && c <= 'Z') return c - 'A';
        if (c >= 'a' && c <= 'z') return c - 'a' + 26;
        if (c >= '0' && c <= '9') return c - '0' + 52;
        if (c == '+') return 62;
        if (c == '/') return 63;
        return -1;
    };

    vector<uint8_t> out;
    out.reserve(input.size() * 3 / 4);
    int val = 0;
    int valBits = -8;
    for (char c : input)
    {
        if (c == '=' || c == '\n' || c == '\r' || c == ' ')
            continue;
        int d = valueOf(c);
        if (d < 0)
            continue;
        val = (val << 6) + d;
        valBits += 6;
        if (valBits >= 0)
        {
            out.push_back(static_cast<uint8_t>((val >> valBits) & 0xFF));
            valBits -= 8;
        }
    }
    return out;
}

void unloadProjectAssetRuntime(ProjectAsset& asset)
{
    if (asset.textureLoaded && asset.texture.id != 0)
    {
        UnloadTexture(asset.texture);
        asset.texture = { 0 };
        asset.textureLoaded = false;
    }
    if (asset.soundLoaded && asset.sound.frameCount > 0)
    {
        UnloadSound(asset.sound);
        asset.sound = { 0 };
        asset.soundLoaded = false;
    }
    if (asset.meshModelLoaded)
    {
        UnloadModel(asset.meshModel);
        asset.meshModel = { 0 };
        asset.meshModelLoaded = false;
        asset.meshDiffuseTextures.clear();
    }
}

void clearProjectAssets()
{
    for (ProjectAsset& asset : projectAssets)
        unloadProjectAssetRuntime(asset);
    projectAssets.clear();
}

string assetTypeName(ProjectAssetType type)
{
    if (type == ProjectAssetType::Sound) return "sound";
    if (type == ProjectAssetType::Mesh) return "mesh";
    return "image";
}

ProjectAssetType parseAssetType(const string& s)
{
    if (s == "sound") return ProjectAssetType::Sound;
    if (s == "mesh") return ProjectAssetType::Mesh;
    return ProjectAssetType::Image;
}

static string extensionLower(const string& path)
{
    filesystem::path p(path);
    string ext = p.extension().string();
    if (!ext.empty() && ext[0] == '.')
        ext.erase(ext.begin());
    for (char& c : ext)
        c = static_cast<char>(tolower(static_cast<unsigned char>(c)));
    return ext;
}

static bool isImageExtension(const string& ext)
{
    return ext == "png" || ext == "jpg" || ext == "jpeg" || ext == "bmp" ||
        ext == "gif" || ext == "tga" || ext == "psd" || ext == "hdr" ||
        ext == "pic" || ext == "ppm" || ext == "pgm" || ext == "pnm";
}

static Image loadProjectImageFromMemory(const string& extension,
    const uint8_t* bytes, size_t size)
{
    Image image = LoadImageFromMemory(
        ("." + extension).c_str(), bytes, static_cast<int>(size));
    if (image.data != nullptr)
        return image;

    int width = 0;
    int height = 0;
    int channels = 0;
    stbi_uc* decoded = stbi_load_from_memory(bytes, static_cast<int>(size),
        &width, &height, &channels, 4);
    if (decoded == nullptr)
        return { 0 };
    image.data = decoded;
    image.width = width;
    image.height = height;
    image.mipmaps = 1;
    image.format = PIXELFORMAT_UNCOMPRESSED_R8G8B8A8;
    return image;
}

static bool isSoundExtension(const string& ext)
{
    return ext == "wav" || ext == "ogg" || ext == "mp3" || ext == "flac";
}

static bool isMeshExtension(const string& ext)
{
    return ext == "obj" || ext == "glb" ||
        ext == "iqm" || ext == "vox" || ext == "m3d";
}

// Safe filename token from asset id (assetId://1 → assetId_1) — Windows rejects : and /
string sanitizeAssetFileToken(const string& id)
{
    string out;
    out.reserve(id.size());
    for (unsigned char c : id)
    {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
            (c >= '0' && c <= '9') || c == '-' || c == '_')
            out.push_back(static_cast<char>(c));
        else
            out.push_back('_');
    }
    if (out.empty())
        out = "asset";
    return out;
}

// Accept assetId://N, asset_N, or plain N
string normalizeAssetId(const string& raw)
{
    string s = raw;
    while (!s.empty() && (s.front() == ' ' || s.front() == '\t')) s.erase(s.begin());
    while (!s.empty() && (s.back() == ' ' || s.back() == '\t' || s.back() == '\r')) s.pop_back();
    if (s.rfind("assetId://", 0) == 0)
        return s;
    if (s.rfind("asset_", 0) == 0)
        return "assetId://" + s.substr(6);
    // Plain number → assetId://N
    bool allDigit = !s.empty();
    for (char c : s)
        if (c < '0' || c > '9') { allDigit = false; break; }
    if (allDigit)
        return "assetId://" + s;
    return s;
}

// Decompress asset payload if needed (ZSTD). Returns empty on failure.
vector<uint8_t> getProjectAssetRawBytes(const ProjectAsset& asset)
{
    if (asset.data.empty())
        return {};
    if (!asset.compressed)
        return asset.data;

    unsigned long long const bound = ZSTD_getFrameContentSize(asset.data.data(), asset.data.size());
    size_t capacity = 0;
    if (bound != ZSTD_CONTENTSIZE_ERROR && bound != ZSTD_CONTENTSIZE_UNKNOWN)
        capacity = static_cast<size_t>(bound);
    else
        // Unknown size: start with 8x compressed size (grows if needed)
        capacity = max(asset.data.size() * 8, size_t(1024 * 1024));

    if (capacity > 512ull * 1024ull * 1024ull) // 512 MB safety cap
        return {};

    vector<uint8_t> out(capacity);
    size_t result = ZSTD_decompress(out.data(), out.size(), asset.data.data(), asset.data.size());
    if (ZSTD_isError(result))
    {
        // Retry with larger buffer once
        if (capacity < 512ull * 1024ull * 1024ull)
        {
            capacity = min(capacity * 4, size_t(512ull * 1024ull * 1024ull));
            out.resize(capacity);
            result = ZSTD_decompress(out.data(), out.size(), asset.data.data(), asset.data.size());
        }
        if (ZSTD_isError(result))
            return {};
    }
    out.resize(result);
    return out;
}

static void pumpImportProgressFrame()
{
    BeginDrawing();
    ClearBackground((Color){ 22, 26, 34, 255 });

    int w = GetScreenWidth();
    int h = GetScreenHeight();
    int boxW = min(520, w - 40);
    int boxH = 120;
    int boxX = (w - boxW) / 2;
    int boxY = (h - boxH) / 2;

    DrawRectangle(boxX, boxY, boxW, boxH, (Color){ 36, 42, 54, 255 });
    DrawRectangleLinesEx(
        (Rectangle){ (float)boxX, (float)boxY, (float)boxW, (float)boxH },
        2.0f, (Color){ 0, 162, 255, 220 });

    // Thumbnail square
    Rectangle thumb = { (float)boxX + 14, (float)boxY + 20, 80, 80 };
    DrawRectangleRec(thumb, (Color){ 24, 28, 36, 255 });
    DrawRectangleLinesEx(thumb, 1.0f, (Color){ 90, 110, 140, 255 });
    if (importProgress.hasPreview && importProgress.preview.id != 0)
    {
        float scale = min(76.0f / max(1, importProgress.preview.width),
                          76.0f / max(1, importProgress.preview.height));
        float dw = importProgress.preview.width * scale;
        float dh = importProgress.preview.height * scale;
        DrawTexturePro(
            importProgress.preview,
            { 0, 0, (float)importProgress.preview.width, (float)importProgress.preview.height },
            { thumb.x + (80 - dw) * 0.5f, thumb.y + (80 - dh) * 0.5f, dw, dh },
            { 0, 0 }, 0.0f, WHITE);
    }
    else if (importProgress.type == ProjectAssetType::Sound)
    {
        DrawCircle(boxX + 54, boxY + 60, 18, (Color){ 0, 150, 90, 255 });
        DrawTriangle(
            { (float)boxX + 48, (float)boxY + 50 },
            { (float)boxX + 48, (float)boxY + 70 },
            { (float)boxX + 66, (float)boxY + 60 },
            RAYWHITE);
    }
    else
    {
        const char* previewLabel = importProgress.type == ProjectAssetType::Mesh ? "3D" : "IMG";
        DrawText(previewLabel, boxX + 36, boxY + 52, 16, (Color){ 140, 150, 170, 255 });
    }

    // Progress bar behind status text
    int barX = boxX + 110;
    int barY = boxY + 48;
    int barW = boxW - 124;
    int barH = 28;
    DrawRectangle(barX, barY, barW, barH, (Color){ 28, 34, 44, 255 });
    float p = std::clamp(importProgress.progress, 0.0f, 1.0f);
    DrawRectangle(barX, barY, static_cast<int>(barW * p), barH, (Color){ 0, 140, 220, 220 });
    DrawRectangleLines(barX, barY, barW, barH, (Color){ 80, 100, 130, 255 });

    int pct = static_cast<int>(p * 100.0f + 0.5f);
    string label = importProgress.status.empty()
        ? TextFormat("Importing (%d%%)", pct)
        : TextFormat("%s (%d%%)", importProgress.status.c_str(), pct);
    DrawText(label.c_str(), barX + 10, barY + 6, 16, RAYWHITE);

    DrawText(importProgress.fileName.c_str(), barX, boxY + 20, 14, (Color){ 170, 185, 205, 255 });
    DrawText("Embedding into project…", barX, boxY + 88, 13, (Color){ 130, 145, 165, 255 });

    EndDrawing();
}

bool ensureProjectAssetLoaded(ProjectAsset& asset)
{
    // Fast path: never re-decode / copy payload once the runtime object exists.
    // (Copying multi‑MB assets every frame was the main lag source.)
    if (asset.type == ProjectAssetType::Image)
    {
        if (asset.textureLoaded)
            return asset.texture.id != 0;
    }
    else if (asset.type == ProjectAssetType::Sound)
    {
        if (asset.soundLoaded)
            return asset.sound.frameCount > 0;
        if (!audioDeviceReady)
            return false;
    }
    else if (asset.type == ProjectAssetType::Mesh)
    {
        if (asset.meshModelLoaded)
            return asset.meshModel.meshCount > 0;
        if (asset.meshModelLoadAttempted)
            return false;
        asset.meshModelLoadAttempted = true;
    }
    else
        return false;

    vector<uint8_t> raw = getProjectAssetRawBytes(asset);
    if (raw.empty())
        return false;

    if (asset.type == ProjectAssetType::Image)
    {
        Image img = loadProjectImageFromMemory(asset.fileType, raw.data(), raw.size());
        if (img.data == nullptr)
        {
            addOutputLog("[Asset] Could not decode image " + asset.id +
                " (." + asset.fileType + ").");
            return false;
        }
        // Cap GPU texture size for huge source images
        if (img.width > 2048 || img.height > 2048)
        {
            float scale = min(2048.0f / img.width, 2048.0f / img.height);
            ImageResize(&img, max(1, (int)(img.width * scale)), max(1, (int)(img.height * scale)));
        }
        asset.texture = LoadTextureFromImage(img);
        UnloadImage(img);
        asset.textureLoaded = asset.texture.id != 0;
        return asset.textureLoaded;
    }

    if (asset.type == ProjectAssetType::Sound)
    {
        // Large sounds: skip full LoadSound (high RAM / lag). Runtime play already
        // uses MusicStream which loads in chunks. Mark stream-only when > ~1.5 MB.
        const size_t kStreamOnlyThreshold = 1500ull * 1024ull;
        if (raw.size() > kStreamOnlyThreshold)
        {
            asset.soundLoaded = false;
            asset.sound = { 0 };
            // Keep bytes so MusicStream can write a temp file on demand.
            addOutputLog("[Asset] Large sound (" + to_string(raw.size() / 1024) +
                " KB) — stream-only (no full decode).");
            return true;
        }
        // NEVER put assetId:// into a filesystem path — colon/slash break Windows
        string token = sanitizeAssetFileToken(asset.id);
        string tempPath = makeTempFilePath("bt_tmp_" + token + "." + asset.fileType);
        {
            ofstream tmp(tempPath, ios::binary);
            if (!tmp)
            {
                addOutputLog("[Asset] Failed to write temp sound file.");
                return false;
            }
            // Write in chunks to reduce peak memory pressure
            const size_t chunk = 256ull * 1024ull;
            size_t off = 0;
            while (off < raw.size())
            {
                size_t n = min(chunk, raw.size() - off);
                tmp.write(reinterpret_cast<const char*>(raw.data() + off),
                    static_cast<std::streamsize>(n));
                off += n;
            }
        }
        asset.sound = LoadSound(tempPath.c_str());
        filesystem::remove(tempPath);
        asset.soundLoaded = asset.sound.frameCount > 0;
        if (!asset.soundLoaded)
            addOutputLog("[Asset] LoadSound failed for " + asset.id + " (." + asset.fileType + ")");
        return asset.soundLoaded;
    }

    if (asset.type == ProjectAssetType::Mesh)
    {
        string token = sanitizeAssetFileToken(asset.id);
        string tempPath = makeTempFilePath("bt_tmp_" + token + "." + asset.fileType);
        {
            ofstream tmp(tempPath, ios::binary);
            if (!tmp)
            {
                addOutputLog("[Asset] Failed to write temporary mesh file.");
                return false;
            }
            tmp.write(reinterpret_cast<const char*>(raw.data()),
                static_cast<std::streamsize>(raw.size()));
            if (!tmp)
            {
                addOutputLog("[Asset] Failed to write temporary mesh file.");
                filesystem::remove(tempPath);
                return false;
            }
        }

        asset.meshModel = LoadModel(tempPath.c_str());
        filesystem::remove(tempPath);
        if (asset.meshModel.meshCount <= 0 || asset.meshModel.meshes == nullptr)
        {
            if (asset.meshModel.meshCount > 0)
                UnloadModel(asset.meshModel);
            asset.meshModel = { 0 };
            addOutputLog("[Asset] Could not load mesh asset " + asset.id +
                " (." + asset.fileType + ").");
            return false;
        }

        Vector3 boundsMin = { FLT_MAX, FLT_MAX, FLT_MAX };
        Vector3 boundsMax = { -FLT_MAX, -FLT_MAX, -FLT_MAX };
        bool hasVertex = false;
        for (int meshIndex = 0; meshIndex < asset.meshModel.meshCount; ++meshIndex)
        {
            const Mesh& mesh = asset.meshModel.meshes[meshIndex];
            if (mesh.vertices == nullptr)
                continue;
            for (int vertexIndex = 0; vertexIndex < mesh.vertexCount; ++vertexIndex)
            {
                const float* vertex = &mesh.vertices[vertexIndex * 3];
                boundsMin.x = min(boundsMin.x, vertex[0]);
                boundsMin.y = min(boundsMin.y, vertex[1]);
                boundsMin.z = min(boundsMin.z, vertex[2]);
                boundsMax.x = max(boundsMax.x, vertex[0]);
                boundsMax.y = max(boundsMax.y, vertex[1]);
                boundsMax.z = max(boundsMax.z, vertex[2]);
                hasVertex = true;
            }
        }
        if (!hasVertex)
        {
            UnloadModel(asset.meshModel);
            asset.meshModel = { 0 };
            addOutputLog("[Asset] Mesh asset contains no vertex data: " + asset.id);
            return false;
        }
        asset.meshBoundsMin = boundsMin;
        asset.meshBoundsMax = boundsMax;
        asset.meshDiffuseTextures.clear();
        asset.meshDiffuseTextures.reserve(static_cast<size_t>(asset.meshModel.materialCount));
        for (int materialIndex = 0; materialIndex < asset.meshModel.materialCount; ++materialIndex)
        {
            Material& material = asset.meshModel.materials[materialIndex];
            material.shader = blockShader;
            asset.meshDiffuseTextures.push_back(material.maps != nullptr
                ? material.maps[MATERIAL_MAP_DIFFUSE].texture : Texture2D{ 0 });
        }
        asset.meshModelLoaded = true;
        return true;
    }
    return false;
}

bool importAssetFromPath(const string& path)
{
    if (path.empty() || !filesystem::exists(path))
        return false;

    string ext = extensionLower(path);
    ProjectAssetType type;
    if (isImageExtension(ext))
        type = ProjectAssetType::Image;
    else if (isSoundExtension(ext))
        type = ProjectAssetType::Sound;
    else if (isMeshExtension(ext))
        type = ProjectAssetType::Mesh;
    else
    {
        addOutputLog("[Import] Unsupported file type: ." + ext);
        return false;
    }

    error_code ec;
    auto fileSize = filesystem::file_size(path, ec);
    if (ec || fileSize == 0)
    {
        addOutputLog("[Import] Could not read file size: " + path);
        return false;
    }
    if (fileSize > 512ull * 1024ull * 1024ull)
    {
        addOutputLog("[Import] File too large (max 512 MB): " + path);
        return false;
    }
    Vector3 importedMeshSize = { 1.0f, 1.0f, 1.0f };
    if (type == ProjectAssetType::Mesh)
    {
        Model validationModel = LoadModel(path.c_str());
        Vector3 boundsMin = { FLT_MAX, FLT_MAX, FLT_MAX };
        Vector3 boundsMax = { -FLT_MAX, -FLT_MAX, -FLT_MAX };
        bool hasVertex = false;
        for (int meshIndex = 0; meshIndex < validationModel.meshCount; ++meshIndex)
        {
            const Mesh& mesh = validationModel.meshes[meshIndex];
            if (mesh.vertices == nullptr)
                continue;
            for (int vertexIndex = 0; vertexIndex < mesh.vertexCount; ++vertexIndex)
            {
                const float* vertex = &mesh.vertices[vertexIndex * 3];
                boundsMin.x = min(boundsMin.x, vertex[0]);
                boundsMin.y = min(boundsMin.y, vertex[1]);
                boundsMin.z = min(boundsMin.z, vertex[2]);
                boundsMax.x = max(boundsMax.x, vertex[0]);
                boundsMax.y = max(boundsMax.y, vertex[1]);
                boundsMax.z = max(boundsMax.z, vertex[2]);
                hasVertex = true;
            }
        }
        bool validModel = validationModel.meshCount > 0 && hasVertex;
        if (validationModel.meshCount > 0)
            UnloadModel(validationModel);
        if (!validModel)
        {
            addOutputLog("[Import] Could not load mesh file: " + path);
            return false;
        }
        importedMeshSize = {
            max(0.1f, boundsMax.x - boundsMin.x),
            max(0.1f, boundsMax.y - boundsMin.y),
            max(0.1f, boundsMax.z - boundsMin.z)
        };
    }

    importProgress.active = true;
    importProgress.progress = 0.0f;
    importProgress.fileName = filesystem::path(path).filename().string();
    importProgress.status = "Reading";
    importProgress.type = type;
    importProgress.hasPreview = false;
    if (importProgress.preview.id != 0)
    {
        UnloadTexture(importProgress.preview);
        importProgress.preview = { 0 };
    }
    pumpImportProgressFrame();

    ifstream file(path, ios::binary);
    if (!file)
    {
        importProgress.active = false;
        addOutputLog("[Import] Could not read file: " + path);
        return false;
    }

    vector<uint8_t> bytes;
    bytes.resize(static_cast<size_t>(fileSize));
    const size_t chunkSize = 256 * 1024;
    size_t offset = 0;
    while (offset < bytes.size())
    {
        size_t toRead = min(chunkSize, bytes.size() - offset);
        file.read(reinterpret_cast<char*>(bytes.data() + offset), static_cast<std::streamsize>(toRead));
        std::streamsize got = file.gcount();
        if (got <= 0)
        {
            importProgress.active = false;
            addOutputLog("[Import] Read stalled at offset " + to_string(offset) + ": " + path);
            return false;
        }
        offset += static_cast<size_t>(got);
        importProgress.progress = 0.55f * (static_cast<float>(offset) / static_cast<float>(bytes.size()));
        if ((offset / chunkSize) % 2 == 0)
            pumpImportProgressFrame();
    }
    // Trim if file was shorter than reported size
    if (offset < bytes.size())
        bytes.resize(offset);

    if (bytes.empty())
    {
        importProgress.active = false;
        addOutputLog("[Import] File is empty: " + path);
        return false;
    }

    // Optional preview thumbnail for images
    if (type == ProjectAssetType::Image)
    {
        importProgress.status = "Preview";
        importProgress.progress = 0.58f;
        pumpImportProgressFrame();
        Image img = loadProjectImageFromMemory(ext, bytes.data(), bytes.size());
        if (img.data != nullptr)
        {
            Image thumb = ImageCopy(img);
            ImageResize(&thumb, min(80, thumb.width), min(80, thumb.height));
            importProgress.preview = LoadTextureFromImage(thumb);
            importProgress.hasPreview = importProgress.preview.id != 0;
            UnloadImage(thumb);
            UnloadImage(img);
        }
    }

    // Compress large payloads with ZSTD before embedding (better .hlx size)
    importProgress.status = "Compressing";
    importProgress.progress = 0.65f;
    pumpImportProgressFrame();

    ProjectAsset asset;
    asset.id = generateAssetId();
    asset.name = filesystem::path(path).stem().string();
    asset.type = type;
    asset.fileType = ext;
    asset.compressed = false;

    const size_t compressThreshold = 32 * 1024; // compress files > 32 KB
    if (bytes.size() >= compressThreshold)
    {
        size_t bound = ZSTD_compressBound(bytes.size());
        vector<uint8_t> compressed(bound);
        size_t z = ZSTD_compress(compressed.data(), bound, bytes.data(), bytes.size(), 3);
        if (!ZSTD_isError(z) && z < bytes.size())
        {
            compressed.resize(z);
            asset.data = std::move(compressed);
            asset.compressed = true;
        }
        else
        {
            asset.data = std::move(bytes);
        }
    }
    else
    {
        asset.data = std::move(bytes);
    }

    importProgress.status = "Importing";
    importProgress.progress = 0.92f;
    pumpImportProgressFrame();

    projectAssets.push_back(std::move(asset));
    projectDirty = true;

    importProgress.progress = 1.0f;
    importProgress.status = "Done";
    pumpImportProgressFrame();
    importProgress.active = false;
    if (importProgress.hasPreview && importProgress.preview.id != 0)
    {
        UnloadTexture(importProgress.preview);
        importProgress.preview = { 0 };
        importProgress.hasPreview = false;
    }

    const ProjectAsset& added = projectAssets.back();
    addOutputLog("[Import] Added " + assetTypeName(type) + " \"" + added.name +
        "\" (" + added.id + ", " + to_string(added.data.size()) + " bytes" +
        (added.compressed ? ", zstd" : "") + ")");
    if (type == ProjectAssetType::Mesh)
        return importMeshPartFromPath(path, importedMeshSize);
    return true;
}

bool importMeshPartFromPath(const string& path, Vector3 meshSize)
{
    if (projectAssets.empty() || projectAssets.back().type != ProjectAssetType::Mesh ||
        projectAssets.back().fileType != extensionLower(path))
        return false;

    auto* part = new Part();
    part->isMeshPart = true;
    part->name = filesystem::path(path).stem().string();
    part->meshId = projectAssets.back().id;
    part->textureId.clear();
    part->size = meshSize;
    size_t meshPartCount = 0;
    function<void(Instance*)> countMeshParts = [&](Instance* parent)
    {
        if (parent == nullptr)
            return;
        for (Instance* child : parent->children)
        {
            if (child != nullptr && child->getType() == InstanceType::Part &&
                static_cast<Part*>(child)->isMeshPart)
                ++meshPartCount;
            countMeshParts(child);
        }
    };
    countMeshParts(&workspace);
    part->cframe.position = { static_cast<float>(meshPartCount) * 2.5f, 2.0f, 0.0f };
    addInstanceToParent(&workspace, part);
    projectDirty = true;
    addOutputLog("[Import] Created MeshPart \"" + part->name +
        "\" (MeshId: " + part->meshId + ", TextureId: empty)");
    return true;
}

bool browseAndImportAsset()
{
    vector<char> buffer(32768, '\0');
    OPENFILENAMEA dialog = {};
    dialog.lStructSize = sizeof(dialog);
    dialog.hwndOwner = GetActiveWindow();
    dialog.lpstrFile = buffer.data();
    dialog.nMaxFile = static_cast<DWORD>(buffer.size());
    dialog.lpstrFilter =
        "Assets\0*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.tga;*.webp;*.qoi;*.psd;*.hdr;*.ico;*.ppm;*.pgm;*.wav;*.ogg;*.mp3;*.flac;*.obj;*.glb;*.iqm;*.vox;*.m3d\0"
        "Meshes\0*.obj;*.glb;*.iqm;*.vox;*.m3d\0"
        "Media Files\0*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.tga;*.webp;*.qoi;*.psd;*.hdr;*.ico;*.ppm;*.pgm;*.wav;*.ogg;*.mp3;*.flac\0"
        "Images\0*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.tga;*.webp;*.qoi;*.psd;*.hdr;*.pic;*.ppm;*.pgm;*.pnm;*.ico;*.dds\0"
        "Sounds\0*.wav;*.ogg;*.mp3;*.flac\0"
        "All Files\0*.*\0";
    dialog.nFilterIndex = 1;
    dialog.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR |
        OFN_ALLOWMULTISELECT | OFN_EXPLORER;
    if (!GetOpenFileNameA(&dialog))
        return false;

    vector<string> paths;
    const char* cursor = buffer.data();
    string first = cursor;
    cursor += first.size() + 1;
    if (*cursor == '\0')
        paths.push_back(first);
    else
    {
        filesystem::path directory(first);
        while (*cursor != '\0')
        {
            string filename = cursor;
            paths.push_back((directory / filename).string());
            cursor += filename.size() + 1;
        }
    }

    bool importedAny = false;
    for (const string& path : paths)
    {
        bool imported = importAssetFromPath(path);
        importedAny = imported || importedAny;
    }
    return importedAny;
}

void deleteProjectAssetAt(int index)
{
    if (index < 0 || index >= static_cast<int>(projectAssets.size()))
        return;
    string name = projectAssets[index].name;
    string id = projectAssets[index].id;
    unloadProjectAssetRuntime(projectAssets[index]);
    projectAssets.erase(projectAssets.begin() + index);
    projectDirty = true;
    if (libraryHoverIndex >= static_cast<int>(projectAssets.size()))
        libraryHoverIndex = static_cast<int>(projectAssets.size()) - 1;
    addOutputLog("[Library] Deleted asset \"" + name + "\" (" + id + ")");
}

ProjectAsset* findProjectAssetById(const string& id)
{
    if (id.empty())
        return nullptr;
    string want = normalizeAssetId(id);
    for (ProjectAsset& a : projectAssets)
    {
        if (a.id == want || a.id == id)
            return &a;
        // Also match legacy asset_N vs assetId://N
        if (normalizeAssetId(a.id) == want)
            return &a;
    }
    return nullptr;
}

void stopSoundPreview()
{
    if (soundPreviewMusicLoaded)
    {
        if (soundPreviewMusic.frameCount > 0)
        {
            StopMusicStream(soundPreviewMusic);
            UnloadMusicStream(soundPreviewMusic);
        }
        soundPreviewMusic = { 0 };
        soundPreviewMusicLoaded = false;
    }
    if (!soundPreviewTempPath.empty())
    {
        error_code ec;
        filesystem::remove(soundPreviewTempPath, ec);
        soundPreviewTempPath.clear();
    }
    soundPreviewPlaying = false;
    soundPreviewAssetId.clear();
    soundPreviewSeek = 0.0f;
    soundPreviewDuration = 0.0f;
    soundPreviewSeekDragging = false;
}

bool loadSoundPreviewForAssetId(const string& assetId)
{
    if (assetId.empty() || !audioDeviceReady)
        return false;

    string want = normalizeAssetId(assetId);
    if (soundPreviewMusicLoaded &&
        normalizeAssetId(soundPreviewAssetId) == want &&
        soundPreviewMusic.frameCount > 0)
        return true;

    stopSoundPreview();
    ProjectAsset* asset = findProjectAssetById(want);
    if (asset == nullptr || asset->type != ProjectAssetType::Sound)
        return false;

    vector<uint8_t> raw = getProjectAssetRawBytes(*asset);
    if (raw.empty())
        return false;

    string token = sanitizeAssetFileToken(asset->id);
    string tempPath = makeTempFilePath("bt_preview_" + token + "." + asset->fileType);
    {
        ofstream tmp(tempPath, ios::binary);
        if (!tmp)
            return false;
        const size_t chunk = 256ull * 1024ull;
        size_t off = 0;
        while (off < raw.size())
        {
            size_t n = min(chunk, raw.size() - off);
            tmp.write(reinterpret_cast<const char*>(raw.data() + off),
                static_cast<std::streamsize>(n));
            if (!tmp)
                return false;
            off += n;
        }
    }

    // Keep temp file alive for the stream lifetime (deleting early crashes UpdateMusicStream).
    Music music = LoadMusicStream(tempPath.c_str());
    if (music.frameCount == 0)
    {
        error_code ec;
        filesystem::remove(tempPath, ec);
        addOutputLog("[Sound] LoadMusicStream failed for " + want);
        return false;
    }

    soundPreviewTempPath = tempPath;
    soundPreviewMusic = music;
    soundPreviewMusicLoaded = true;
    soundPreviewAssetId = want;
    soundPreviewDuration = GetMusicTimeLength(soundPreviewMusic);
    if (!(soundPreviewDuration > 0.0f) || !isfinite(soundPreviewDuration))
        soundPreviewDuration = 1.0f;
    SetMusicVolume(soundPreviewMusic, 1.0f);
    return true;
}

void updateSoundPreview()
{
    if (!soundPreviewMusicLoaded || soundPreviewMusic.frameCount == 0)
        return;
    UpdateMusicStream(soundPreviewMusic);
    if (soundPreviewPlaying)
    {
        float t = GetMusicTimePlayed(soundPreviewMusic);
        if (!isfinite(t))
            t = 0.0f;
        soundPreviewSeek = std::clamp(t / max(0.001f, soundPreviewDuration), 0.0f, 1.0f);
        if (!IsMusicStreamPlaying(soundPreviewMusic) && soundPreviewSeek >= 0.99f)
        {
            soundPreviewPlaying = false;
            soundPreviewSeek = 0.0f;
            SeekMusicStream(soundPreviewMusic, 0.0f);
        }
    }
}

// Draws play/pause + seek bar for a Sound instance. Returns height used.
int renderSoundSampleBar(SoundInstance* sound, int x, int y, int width)
{
    if (sound == nullptr || width < 40)
        return 0;

    const int playSize = 28;
    Rectangle playBtn = { (float)x, (float)y + 4, (float)playSize, (float)playSize };
    Rectangle bar = {
        (float)(x + playSize + 10),
        (float)(y + 10),
        (float)max(20, width - playSize - 20),
        16.0f
    };

    Vector2 mouse = GetMousePosition();
    string idNorm = normalizeAssetId(sound->soundId);
    bool thisLoaded = soundPreviewMusicLoaded &&
        normalizeAssetId(soundPreviewAssetId) == idNorm &&
        soundPreviewMusic.frameCount > 0;
    bool thisPlaying = thisLoaded && soundPreviewPlaying;

    bool playHover = CheckCollisionPointRec(mouse, playBtn);
    DrawRectangleRec(playBtn, playHover ? (Color){ 0, 160, 100, 255 } : (Color){ 0, 120, 80, 255 });
    if (thisPlaying)
    {
        DrawRectangle(x + 8, y + 10, 5, 16, RAYWHITE);
        DrawRectangle(x + 16, y + 10, 5, 16, RAYWHITE);
    }
    else
    {
        DrawTriangle(
            { (float)x + 9, (float)y + 9 },
            { (float)x + 9, (float)y + 27 },
            { (float)x + 23, (float)y + 18 },
            RAYWHITE);
    }

    float fill = thisLoaded ? soundPreviewSeek : 0.0f;
    fill = std::clamp(fill, 0.0f, 1.0f);
    DrawRectangleRec(bar, (Color){ 40, 48, 60, 255 });
    DrawRectangle((int)bar.x, (int)bar.y, (int)(bar.width * fill), (int)bar.height, (Color){ 0, 160, 255, 220 });
    DrawRectangleLinesEx(bar, 1.0f, (Color){ 90, 110, 140, 255 });
    float hx = bar.x + bar.width * fill;
    DrawCircle((int)hx, (int)(bar.y + bar.height * 0.5f), 6, RAYWHITE);

    // Input — fully guarded so a failed load never touches Music APIs
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && playHover)
    {
        if (idNorm.empty())
        {
            addOutputLog("[Sound] Set SoundId to an assetId://N first.");
        }
        else if (thisPlaying)
        {
            PauseMusicStream(soundPreviewMusic);
            soundPreviewPlaying = false;
            sound->playing = false;
        }
        else
        {
            if (loadSoundPreviewForAssetId(idNorm) &&
                soundPreviewMusicLoaded &&
                soundPreviewMusic.frameCount > 0)
            {
                float speed = max(0.01f, sound->playbackSpeed);
                if (!isfinite(speed)) speed = 1.0f;
                SetMusicPitch(soundPreviewMusic, speed);
                SetMusicVolume(soundPreviewMusic, std::clamp(sound->volume, 0.0f, 1.0f));
                float seekT = 0.0f;
                if (soundPreviewSeek > 0.01f && soundPreviewSeek < 0.99f)
                    seekT = soundPreviewSeek * soundPreviewDuration;
                if (isfinite(seekT))
                    SeekMusicStream(soundPreviewMusic, max(0.0f, seekT));
                PlayMusicStream(soundPreviewMusic);
                soundPreviewPlaying = true;
                sound->playing = true;
            }
            else
            {
                addOutputLog("[Sound] Could not load sample for " + idNorm);
            }
        }
    }

    if (CheckCollisionPointRec(mouse, bar) &&
        (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) ||
         (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && soundPreviewSeekDragging)))
    {
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
            soundPreviewSeekDragging = true;
        if (!idNorm.empty())
        {
            if (!thisLoaded)
                loadSoundPreviewForAssetId(idNorm);
            if (soundPreviewMusicLoaded && soundPreviewMusic.frameCount > 0)
            {
                soundPreviewSeek = std::clamp((mouse.x - bar.x) / max(1.0f, bar.width), 0.0f, 1.0f);
                float seekT = soundPreviewSeek * soundPreviewDuration;
                if (isfinite(seekT))
                {
                    SeekMusicStream(soundPreviewMusic, max(0.0f, seekT));
                    sound->timePosition = max(0.0f, seekT);
                }
            }
        }
    }
    if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
        soundPreviewSeekDragging = false;

    float cur = thisLoaded ? soundPreviewSeek * soundPreviewDuration : 0.0f;
    float dur = thisLoaded ? soundPreviewDuration : 0.0f;
    if (!isfinite(cur)) cur = 0.0f;
    if (!isfinite(dur)) dur = 0.0f;
    DrawText(TextFormat("%.1fs / %.1fs  ·  speed %.2fx", cur, dur, sound->playbackSpeed),
        x + playSize + 10, y + 32, 12, (Color){ 150, 165, 185, 255 });

    return 48;
}

void openLibraryWindow()
{
    bool alreadyOpen = false;
    for (const WindowTab& tab : windowTabs)
    {
        if (tab.type == WindowType::Library)
        {
            alreadyOpen = true;
            break;
        }
    }
    if (!alreadyOpen)
        windowTabs.push_back({ WindowType::Library, nullptr });
    activeWindow = WindowType::Library;
    activeScript = nullptr;
    focusActiveWindow();
}

void focusActiveWindow();

string buildLuauDefinitions();
string getInstancePath(const Instance* instance);
Instance* findInstanceByPath(const string& path);
void resolvePendingInstanceRefs();
void loadStudioSettings();
void loadLuauConfig();

void applyRuntimePropertyUpdate(const string& command);
void applyRuntimeCreateCommand(const string& command);
void stopRuntime();
void startRuntime(bool clientMode = false);
void collapseAllExplorerChildren(Instance* root = nullptr);

int EXPLORER_WIDTH = 300;
const int MENU_BAR_HEIGHT = 28;
int RIBBON_BAR_HEIGHT = 108;
int ACTION_BAR_HEIGHT = 32;
int WINDOW_BAR_HEIGHT = 32;
int EXPLORER_TOP = 174;
int EDITOR_CONTENT_TOP = 174;
static inline int editorActionBarY() { return MENU_BAR_HEIGHT; }
static inline int editorRibbonBarY() { return MENU_BAR_HEIGHT + ACTION_BAR_HEIGHT; }
static inline int editorWindowBarY() { return editorRibbonBarY() + RIBBON_BAR_HEIGHT; }
static inline int editorContentTopY() { return editorWindowBarY() + WINDOW_BAR_HEIGHT; }
void updateEditorChromeLayout()
{
    ACTION_BAR_HEIGHT = studioSettings.showActionBar ? 32 : 0;
    RIBBON_BAR_HEIGHT = studioSettings.showRibbonBar ? 108 : 0;
    WINDOW_BAR_HEIGHT = studioSettings.showWindowBar ? 32 : 0;
    EXPLORER_TOP = editorContentTopY();
    EDITOR_CONTENT_TOP = editorContentTopY();
}

const int EXPLORER_ROW_HEIGHT = 28;
const int EXPLORER_FONT_SIZE = 18;
const int EXPLORER_INDENT = 24;
const int EXPLORER_BRANCH_WIDTH = 22;
const int EXPLORER_SCROLLBAR_SIZE = 12;
int PROPERTY_WIDTH = 280;

// ============================================================
// Dock panels: moveable / stackable side panels + "active zone" focus
// ============================================================
//
// Explorer and Properties each live in one of two screen-edge "slots" (Left
// or Right). A slot can hold one panel, or two stacked as tabs (only the
// active tab of a slot actually renders/handles input). Dragging a panel's
// header to the opposite edge moves it there; dragging it onto the slot that
// already holds the other panel stacks them together.
enum class DockPanelKind { Properties, Explorer };

struct DockSlotState
{
    vector<DockPanelKind> stack;
    int activeTab = 0;
};

DockSlotState leftDockSlot = { { DockPanelKind::Properties }, 0 };
DockSlotState rightDockSlot = { { DockPanelKind::Explorer }, 0 };

DockSlotState* dockSlotContaining(DockPanelKind panel)
{
    for (DockPanelKind k : leftDockSlot.stack)
        if (k == panel) return &leftDockSlot;
    for (DockPanelKind k : rightDockSlot.stack)
        if (k == panel) return &rightDockSlot;
    return nullptr;
}

bool isDockPanelOnLeft(DockPanelKind panel)
{
    for (DockPanelKind k : leftDockSlot.stack)
        if (k == panel) return true;
    return false;
}

// True when the panel lives as a center window-bar tab (not a side dock).
bool isDockPanelInWindowBar(DockPanelKind panel)
{
    WindowType want = panel == DockPanelKind::Explorer
        ? WindowType::ExplorerView
        : WindowType::PropertiesView;
    for (const WindowTab& tab : windowTabs)
        if (tab.type == want)
            return true;
    return false;
}

// Only the active tab of a slot is actually drawn/handled; the other panel
// stacked behind it stays fully idle that frame. Center window-bar views
// count as active only while their window tab is focused.
bool isDockPanelActiveTab(DockPanelKind panel)
{
    if (panel == DockPanelKind::Explorer && activeWindow == WindowType::ExplorerView)
        return true;
    if (panel == DockPanelKind::Properties && activeWindow == WindowType::PropertiesView)
        return true;

    // Panel promoted to the window bar is hidden from side slots until redocked
    if (isDockPanelInWindowBar(panel))
        return false;

    DockSlotState* slot = dockSlotContaining(panel);
    if (slot == nullptr || slot->stack.empty())
        return false;
    return slot->stack[slot->activeTab] == panel;
}

const char* dockPanelTitle(DockPanelKind panel)
{
    return panel == DockPanelKind::Properties ? "Properties" : "Explorer";
}

// Each panel keeps its own width preference even after being moved/stacked.
int dockPanelWidth(DockPanelKind panel)
{
    return panel == DockPanelKind::Properties ? PROPERTY_WIDTH : EXPLORER_WIDTH;
}

int leftSlotWidth()
{
    if (leftDockSlot.stack.empty()) return 0;
    return dockPanelWidth(leftDockSlot.stack[leftDockSlot.activeTab]);
}

int rightSlotWidth()
{
    if (rightDockSlot.stack.empty()) return 0;
    return dockPanelWidth(rightDockSlot.stack[rightDockSlot.activeTab]);
}

// Moves `panel` out of whichever slot it's currently in and into `target`,
// either replacing an empty slot or stacking onto whatever's already there.
void dockPanelInto(DockPanelKind panel, DockSlotState& target)
{
    DockSlotState* current = dockSlotContaining(panel);
    if (current == &target)
        return;

    if (current != nullptr)
        current->stack.erase(remove(current->stack.begin(), current->stack.end(), panel), current->stack.end());

    if (find(target.stack.begin(), target.stack.end(), panel) == target.stack.end())
        target.stack.push_back(panel);

    target.activeTab = static_cast<int>(target.stack.size()) - 1;
    if (current != nullptr && current->activeTab >= static_cast<int>(current->stack.size()))
        current->activeTab = max(0, static_cast<int>(current->stack.size()) - 1);
}

// Drag-to-redock gesture state, shared by Explorer's and Properties' header
// click handling so there's one place that decides where a drop lands.
bool dockDragActive = false;
DockPanelKind dockDragPanel = DockPanelKind::Explorer;
Vector2 dockDragStartMouse = { 0, 0 };
Vector2 dockDragOffset = { 0, 0 }; // mouse offset inside the floating card
bool dockDragMoved = false;
enum class DockDropSide { None, Left, Right, WindowBar };
DockDropSide dockDropHover = DockDropSide::None;

void beginDockDrag(DockPanelKind panel, Vector2 mouse)
{
    dockDragActive = true;
    dockDragPanel = panel;
    dockDragStartMouse = mouse;
    dockDragMoved = false;
    dockDropHover = DockDropSide::None;
    // Offset so the floating header sits under the cursor near where the grab started
    dockDragOffset = { 40.0f, 16.0f };
}

static Rectangle dockDropZoneLeft()
{
    float w = std::max(120.0f, static_cast<float>(GetScreenWidth()) * 0.22f);
    return { 0.0f, 60.0f, w, static_cast<float>(GetScreenHeight() - 60) };
}

static Rectangle dockDropZoneRight()
{
    float w = std::max(120.0f, static_cast<float>(GetScreenWidth()) * 0.22f);
    return { static_cast<float>(GetScreenWidth()) - w, 60.0f, w, static_cast<float>(GetScreenHeight() - 60) };
}

// Window-bar strip (document tabs row under the top menu)
static Rectangle dockDropZoneWindowBar()
{
    return { 0.0f, 60.0f, static_cast<float>(GetScreenWidth()), 32.0f };
}

static DockDropSide dockDropSideAt(Vector2 mouse)
{
    // Window bar has priority when the cursor is over the tab strip
    if (CheckCollisionPointRec(mouse, dockDropZoneWindowBar()))
        return DockDropSide::WindowBar;
    if (CheckCollisionPointRec(mouse, dockDropZoneLeft()))
        return DockDropSide::Left;
    if (CheckCollisionPointRec(mouse, dockDropZoneRight()))
        return DockDropSide::Right;
    // Fallback: which half of the screen (not the window bar)
    return (mouse.x < GetScreenWidth() * 0.5f) ? DockDropSide::Left : DockDropSide::Right;
}

// Remove a side panel from left/right slots (used when promoting it to the window bar).
static void undockPanelFromSides(DockPanelKind panel)
{
    auto strip = [&](DockSlotState& slot)
    {
        slot.stack.erase(remove(slot.stack.begin(), slot.stack.end(), panel), slot.stack.end());
        if (slot.activeTab >= static_cast<int>(slot.stack.size()))
            slot.activeTab = max(0, static_cast<int>(slot.stack.size()) - 1);
    };
    strip(leftDockSlot);
    strip(rightDockSlot);
}

static void ensureWindowTab(WindowType type)
{
    for (const WindowTab& tab : windowTabs)
        if (tab.type == type)
        {
            activeWindow = type;
            activeScript = nullptr;
            focusActiveWindow();
            return;
        }
    windowTabs.push_back({ type, nullptr });
    activeWindow = type;
    activeScript = nullptr;
    focusActiveWindow();
}

static void closeWindowTabType(WindowType type)
{
    windowTabs.erase(
        remove_if(windowTabs.begin(), windowTabs.end(),
            [type](const WindowTab& tab) { return tab.type == type; }),
        windowTabs.end()
    );
    if (activeWindow == type)
    {
        activeWindow = WindowType::Viewport;
        activeScript = nullptr;
    }
}

// Promote a side panel into a center window-bar tab (and remove it from side docks).
static void dockPanelToWindowBar(DockPanelKind panel)
{
    undockPanelFromSides(panel);
    if (panel == DockPanelKind::Explorer)
        ensureWindowTab(WindowType::ExplorerView);
    else
        ensureWindowTab(WindowType::PropertiesView);
}

// Called once per frame; tracks hover zone and commits drop on release.
void updateDockDrag()
{
    if (!dockDragActive)
        return;

    Vector2 mouse = GetMousePosition();
    if (fabsf(mouse.x - dockDragStartMouse.x) > 6.0f || fabsf(mouse.y - dockDragStartMouse.y) > 6.0f)
        dockDragMoved = true;

    if (dockDragMoved)
        dockDropHover = dockDropSideAt(mouse);
    else
        dockDropHover = DockDropSide::None;

    if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
    {
        if (dockDragMoved)
        {
            if (dockDropHover == DockDropSide::WindowBar)
            {
                dockPanelToWindowBar(dockDragPanel);
            }
            else
            {
                // Returning a center-tab panel to a side dock closes its window tab
                if (dockDragPanel == DockPanelKind::Explorer)
                    closeWindowTabType(WindowType::ExplorerView);
                else
                    closeWindowTabType(WindowType::PropertiesView);

                DockSlotState& target = (dockDropHover == DockDropSide::Left) ? leftDockSlot : rightDockSlot;
                dockPanelInto(dockDragPanel, target);
            }
        }
        dockDragActive = false;
        dockDragMoved = false;
        dockDropHover = DockDropSide::None;
    }
}

// Floating ghost panel + dock drop-zone highlights while dragging.
void renderDockDragOverlay()
{
    if (!dockDragActive || !dockDragMoved)
        return;

    Vector2 mouse = GetMousePosition();
    int screenH = GetScreenHeight();
    int screenW = GetScreenWidth();

    // --- Drop zones: Left / Right / Window Bar ---
    Rectangle leftZone = dockDropZoneLeft();
    Rectangle rightZone = dockDropZoneRight();
    Rectangle barZone = dockDropZoneWindowBar();

    bool leftHot = dockDropHover == DockDropSide::Left;
    bool rightHot = dockDropHover == DockDropSide::Right;
    bool barHot = dockDropHover == DockDropSide::WindowBar;

    // Dim editor slightly
    DrawRectangle(0, 40, screenW, screenH - 40, (Color){ 0, 0, 0, 40 });

    // Window bar zone (top document strip)
    DrawRectangleRec(barZone, barHot ? (Color){ 0, 160, 255, 90 } : (Color){ 90, 120, 160, 50 });
    DrawRectangleLinesEx(barZone, barHot ? 3.0f : 1.5f,
        barHot ? (Color){ 0, 200, 255, 240 } : (Color){ 140, 170, 210, 140 });
    AppDrawText("Drop on Window Bar", screenW / 2 - 90, 48, 16,
        barHot ? (Color){ 230, 245, 255, 255 } : (Color){ 180, 200, 220, 220 });

    DrawRectangleRec(leftZone, leftHot ? (Color){ 0, 140, 220, 70 } : (Color){ 80, 100, 140, 35 });
    DrawRectangleLinesEx(leftZone, leftHot ? 3.0f : 1.5f,
        leftHot ? (Color){ 0, 180, 255, 230 } : (Color){ 120, 150, 200, 120 });
    AppDrawText("Drop Left", static_cast<int>(leftZone.x + 16),
        static_cast<int>(leftZone.y + leftZone.height * 0.5f - 10), 18,
        leftHot ? (Color){ 220, 240, 255, 255 } : (Color){ 160, 180, 210, 200 });

    DrawRectangleRec(rightZone, rightHot ? (Color){ 0, 140, 220, 70 } : (Color){ 80, 100, 140, 35 });
    DrawRectangleLinesEx(rightZone, rightHot ? 3.0f : 1.5f,
        rightHot ? (Color){ 0, 180, 255, 230 } : (Color){ 120, 150, 200, 120 });
    const char* rightLabel = "Drop Right";
    int rightLabelW = MeasureText(rightLabel, 18);
    AppDrawText(rightLabel, static_cast<int>(rightZone.x + rightZone.width - rightLabelW - 16),
        static_cast<int>(rightZone.y + rightZone.height * 0.5f - 10), 18,
        rightHot ? (Color){ 220, 240, 255, 255 } : (Color){ 160, 180, 210, 200 });

    // --- Floating panel following the mouse ---
    int floatW = dockPanelWidth(dockDragPanel);
    int floatH = std::min(220, screenH - 100);
    float fx = mouse.x - dockDragOffset.x;
    float fy = mouse.y - dockDragOffset.y;
    fx = std::clamp(fx, 0.0f, static_cast<float>(screenW - floatW));
    fy = std::clamp(fy, 60.0f, static_cast<float>(screenH - floatH));

    DrawRectangle(static_cast<int>(fx), static_cast<int>(fy), floatW, floatH, (Color){ 36, 42, 54, 230 });
    DrawRectangleLinesEx(
        (Rectangle){ fx, fy, static_cast<float>(floatW), static_cast<float>(floatH) },
        2.0f, (Color){ 0, 162, 255, 220 });
    DrawRectangle(static_cast<int>(fx), static_cast<int>(fy), floatW, 32, (Color){ 50, 58, 72, 255 });
    AppDrawText(dockPanelTitle(dockDragPanel), static_cast<int>(fx) + 12, static_cast<int>(fy) + 8, 16, RAYWHITE);
    AppDrawText("Dragging…", static_cast<int>(fx) + 12, static_cast<int>(fy) + 44, 14, (Color){ 160, 180, 210, 255 });
}

// Draws either a plain title (single panel in the slot) or a small tab row
// (two panels stacked) inside an existing header rectangle. Returns the
// index of a clicked tab, or -1 if the click (if any) wasn't on a tab.
//
// Stacked tabs behave like a single-panel header: press selects the tab and
// begins a dock-drag for THAT panel. A click without movement just switches
// tabs; moving the mouse pulls the panel out of the stack (same overlay /
// drop zones as a solo panel drag).
int renderDockHeaderTabs(DockSlotState& slot, int x, int y, int height, Color activeColor, Color inactiveColor)
{
    if (slot.stack.size() < 2)
        return -1;

    int tabWidth = 96;
    Vector2 mouse = GetMousePosition();

    for (size_t i = 0; i < slot.stack.size(); i++)
    {
        int tabX = x + static_cast<int>(i) * (tabWidth + 4);
        bool active = static_cast<int>(i) == slot.activeTab;
        Rectangle tabRect = {
            static_cast<float>(tabX), static_cast<float>(y),
            static_cast<float>(tabWidth), static_cast<float>(height)
        };

        // Hover highlight on individual tabs
        bool hovered = CheckCollisionPointRec(mouse, tabRect);
        Color fill = active ? activeColor : inactiveColor;
        if (hovered && !active)
            fill = (Color){ 55, 64, 78, 255 };
        DrawRectangle(tabX, y, tabWidth, height, fill);
        if (hovered)
            DrawRectangleLinesEx(tabRect, 1.0f, (Color){ 0, 162, 255, 180 });
        AppDrawText(dockPanelTitle(slot.stack[i]), tabX + 10, y + (height - 14) / 2, 14, RAYWHITE);
    }

    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && !dockDragActive)
    {
        for (size_t i = 0; i < slot.stack.size(); i++)
        {
            int tabX = x + static_cast<int>(i) * (tabWidth + 4);
            Rectangle tabRect = {
                static_cast<float>(tabX), static_cast<float>(y),
                static_cast<float>(tabWidth), static_cast<float>(height)
            };
            if (CheckCollisionPointRec(mouse, tabRect))
            {
                slot.activeTab = static_cast<int>(i);
                // Drag this specific stacked panel (Explorer or Properties)
                beginDockDrag(slot.stack[i], mouse);
                return static_cast<int>(i);
            }
        }
    }
    return -1;
}

// -- "Active zone" focus tracking -----------------------------------------
// Only one dock panel is "focused" at a time. Keyboard-driven shortcuts that
// aren't already scoped by mouse position (Explorer's Delete/Ctrl+C/V/D,
// the script editor's typing, etc.) are gated on this so two panels can't
// both react to the same keypress.
enum class FocusZone { Viewport, Properties, Explorer, Output, ScriptEditor, Library, Chrome };
FocusZone focusedZone = FocusZone::Viewport;

bool isZoneFocused(FocusZone zone)
{
    return focusedZone == zone;
}

void focusActiveWindow()
{
    switch (activeWindow)
    {
        case WindowType::Script: focusedZone = FocusZone::ScriptEditor; break;
        case WindowType::Output: focusedZone = FocusZone::Output; break;
        case WindowType::Library: focusedZone = FocusZone::Library; break;
        case WindowType::ExplorerView: focusedZone = FocusZone::Explorer; break;
        case WindowType::PropertiesView: focusedZone = FocusZone::Properties; break;
        case WindowType::Viewport: focusedZone = FocusZone::Viewport; break;
        default: focusedZone = FocusZone::Chrome; break;
    }
}

int getPropertyX()
{
    if (activeWindow == WindowType::PropertiesView)
        return leftSlotWidth();
    return isDockPanelOnLeft(DockPanelKind::Properties) ? 0 : GetScreenWidth() - PROPERTY_WIDTH;
}

int getExplorerX();

void updateFocusFromMouseWheel()
{
    if (GetMouseWheelMove() == 0.0f)
        return;
    if (studioSettingsOpen || gameSettingsOpen || insertMenuOpen)
    {
        focusedZone = FocusZone::Chrome;
        return;
    }
    Vector2 mouse = GetMousePosition();
    if (isDockPanelActiveTab(DockPanelKind::Explorer))
    {
        int explorerX = getExplorerX();
        if (mouse.x >= explorerX && mouse.x < explorerX + EXPLORER_WIDTH && mouse.y >= EXPLORER_TOP)
        {
            focusedZone = FocusZone::Explorer;
            return;
        }
    }
    if (isDockPanelActiveTab(DockPanelKind::Properties))
    {
        int propertyX = getPropertyX();
        if (mouse.x >= propertyX && mouse.x < propertyX + PROPERTY_WIDTH && mouse.y >= EDITOR_CONTENT_TOP)
        {
            focusedZone = FocusZone::Properties;
            return;
        }
    }
    if (mouse.y < EDITOR_CONTENT_TOP && mouse.y >= MENU_BAR_HEIGHT)
    {
        focusedZone = FocusZone::Chrome;
        return;
    }
    if (activeWindow == WindowType::PropertiesView)
    {
        focusedZone = FocusZone::Properties;
        return;
    }
    if (activeWindow == WindowType::ExplorerView)
    {
        focusedZone = FocusZone::Explorer;
        return;
    }
    if (activeWindow == WindowType::Library)
    {
        focusedZone = FocusZone::Library;
        return;
    }
    if (activeWindow == WindowType::Script)
    {
        focusedZone = FocusZone::ScriptEditor;
    }
    else if (activeWindow == WindowType::Output)
    {
        focusedZone = FocusZone::Output;
    }

    if (activeWindow == WindowType::Viewport)
        focusedZone = FocusZone::Viewport;
}
const int PROPERTY_SCROLLBAR_SIZE = 12;

float propertyScrollX = 0.0f;
float propertyScrollY = 0.0f;
bool propertyDraggingScrollX = false;
bool propertyDraggingScrollY = false;
bool propertyResizing = false;
bool explorerResizing = false;
int activePropertyRow = -1;
string propertyEditText;
int propertyEditCursor = 0;
double propertyCaretResetTime = 0.0; // blink reset like script editor
// Enum dropdown in Properties panel
bool propertyEnumDropdownOpen = false;
int propertyEnumDropdownRow = -1;
vector<string> propertyEnumDropdownOptions;
int propertyEnumDropdownHover = -1;
// Preferred POV for Play / switch button (false = Server, true = Client)
bool editorClientPOV = false;
Instance* pointerPickOwner = nullptr;
string pointerPickProperty;

vector<string> luauConfigKeywords = {
    "and", "break", "continue", "do", "else", "elseif", "end", "export", "false", "for",
    "function", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true",
    "type", "typeof", "until", "while"
};
vector<string> luauConfigBuiltins;
vector<string> luauConfigTypes;
vector<string> luauConfigPointerProperties = {
    "Parent", "PrimaryPart", "Part0", "Part1", "RootPart", "Target"
};
bool luauConfigLoaded = false;

bool isPointerProperty(const string& property)
{
    return find(luauConfigPointerProperties.begin(), luauConfigPointerProperties.end(), property)
        != luauConfigPointerProperties.end();
}
bool propertyColorPickerOpen = false;
Color propertyPickerColor = WHITE;
Color* propertyPickerExternalTarget = nullptr;
string propertyPickerHex;
string propertyColorRgbText;
int propertyColorRgbCursor = 0;
bool propertyColorRgbEditing = false;
bool propertyColorRgbSelectAll = false;
float propertyPickerHue = 0.0f;
float propertyPickerSaturation = 0.0f;
float propertyPickerValue = 1.0f;
Rectangle propertyColorPickerBounds = { 0, 0, 0, 0 };
int propertyColorSavedSlotSelection = 0;
bool screenGuiPointerHovered = false;

string default_Image_Path = "assets/icons";

// Resolve icon path from several common locations (cwd / app dir / relative)
string resolveIconPath(const string& item)
{
    string name = item + ".png";
    vector<filesystem::path> candidates;
    error_code ec;
    filesystem::path cwd = filesystem::path(GetWorkingDirectory());
    auto addIconCandidates = [&candidates, &name](const filesystem::path& root)
    {
        candidates.push_back(root / name);
        candidates.push_back(root / "Instance" / name);
        candidates.push_back(root / "Misc" / name);
    };
    addIconCandidates(cwd / "assets" / "icons");
    addIconCandidates(cwd / "icons");
    addIconCandidates(cwd / "BuildingTool_Pending" / "assets" / "icons");
#ifdef _WIN32
    {
        char modulePath[MAX_PATH] = {};
        if (GetModuleFileNameA(nullptr, modulePath, MAX_PATH) > 0)
        {
            filesystem::path exeDir = filesystem::path(modulePath).parent_path();
            addIconCandidates(exeDir / "assets" / "icons");
            addIconCandidates(exeDir / "icons");
            addIconCandidates(exeDir / "BuildingTool_Pending" / "assets" / "icons");
        }
    }
#endif
    // Raylib application directory when available
    {
        const char* appDir = GetApplicationDirectory();
        if (appDir && appDir[0])
        {
            filesystem::path ad(appDir);
            addIconCandidates(ad / "assets" / "icons");
            addIconCandidates(ad / "icons");
        }
    }
    addIconCandidates(filesystem::path(default_Image_Path));

    for (const auto& c : candidates)
    {
        if (filesystem::exists(c, ec) && !ec)
            return c.string();
    }
    return (filesystem::path(default_Image_Path) / name).string();
}

Texture2D loadImage(const string& item)
{
    string path = resolveIconPath(item);
    Texture2D result = LoadTexture(path.c_str());
    if (result.id != 0)
    {
        GenTextureMipmaps(&result);
        SetTextureFilter(result, TEXTURE_FILTER_TRILINEAR);
        SetTextureWrap(result, TEXTURE_WRAP_CLAMP);
    }
    return result;
}

// Shared explorer / insert icon draw (fit-in-box + studio icon tint)
void drawEditorIcon(Texture2D icon, float x, float y, float boxW, float boxH, Color tint)
{
    if (icon.id == 0) return;
    float scale = fminf(boxW / (float)max(icon.width, 1), boxH / (float)max(icon.height, 1));
    float drawW = icon.width * scale;
    float drawH = icon.height * scale;
    float ox = (boxW - drawW) * 0.5f;
    float oy = (boxH - drawH) * 0.5f;
    DrawTexturePro(
        icon,
        { 0, 0, (float)icon.width, (float)icon.height },
        { x + ox, y + oy, drawW, drawH },
        { 0, 0 },
        0.0f,
        tint
    );
}

class iconLib {
public:
    Texture2D folderIcon;
    Texture2D partIcon;
    Texture2D scriptIcon;
    Texture2D modelIcon;
    Texture2D workspaceIcon;
    Texture2D serverstorageIcon;
    Texture2D localScriptIcon;
    Texture2D moduleScriptIcon;
    Texture2D replicatedStorageIcon;
    Texture2D lightingIcon;
    Texture2D playerIcon;
    Texture2D playersIcon;
    Texture2D textureIcon;
    Texture2D soundIcon;
    Texture2D serverScriptService;
    Texture2D weldConstraintIcon;
    Texture2D motor6DConstraintIcon;
    Texture2D playIcon;
    Texture2D playPlayerIcon;
    Texture2D stopIcon;
    Texture2D ribbonSelectIcon;
    Texture2D ribbonMoveIcon;
    Texture2D ribbonRotateIcon;
    Texture2D ribbonScaleIcon;
    Texture2D ribbonGroupIcon;
    Texture2D ribbonUngroupIcon;
    Texture2D ribbonAnchorIcon;
    Texture2D mouseDefaultIcon;
    Texture2D mouseClickIcon;
    Texture2D mouseLeftRightIcon;
    Texture2D mouseMoveGizmoIcon;
    Texture2D mouseObjectSelectionIcon;
    Texture2D mouseRotateGizmoIcon;
    Texture2D mouseScaleGizmoIcon;
    Texture2D bindableEventIcon;
    Texture2D remoteEventIcon;
    Texture2D bindableFunctionIcon;
    Texture2D remoteFunctionIcon;
    Texture2D humanoidIcon;
    Texture2D cameraIcon;
    Texture2D guiIcon;
    // New typed icons (assets/icons/*.png)
    Texture2D pointLightIcon;
    Texture2D spotLightIcon;
    Texture2D surfaceLightIcon;
    Texture2D sunLightIcon;
    Texture2D blurIcon;
    Texture2D bloomIcon;
    Texture2D billboardGuiIcon;
    Texture2D surfaceGuiIcon;
    Texture2D screenGuiIcon;
    Texture2D frameIcon;
    Texture2D scrollingFrameIcon;
    Texture2D textLabelIcon;
    Texture2D textButtonIcon;
    Texture2D textBoxIcon;
    Texture2D imageLabelIcon;
    Texture2D imageButtonIcon;
    Texture2D uiCornerIcon;
    Texture2D uiListIcon;
    Texture2D uiStrokeIcon;
    Texture2D uiGridIcon;
    Texture2D uiGradientIcon;
    Texture2D uiAspectIcon;
    Texture2D starterGuiIcon;
    Texture2D decalIcon;
    Texture2D meshPartIcon;
    Texture2D toolIcon;
    Texture2D attachmentIcon;
    // Autocomplete / IntelliSense icons (assets/icons/AC*.png)
    Texture2D acVariableIcon;
    Texture2D acFunctionIcon;
    Texture2D acPropertyIcon;
    Texture2D acEventIcon;
    Texture2D acValueIcon;
    Texture2D acEnumIcon;
    Texture2D acSnippetIcon;
    Texture2D acFolderIcon;
    Texture2D acTextIcon;

    iconLib() {
        partIcon = loadImage("Part");
        workspaceIcon = loadImage("Workspace");
        scriptIcon = loadImage("Script");
        serverstorageIcon = loadImage("ServerStorage");
        localScriptIcon = loadImage("LocalScript");
        moduleScriptIcon = loadImage("ModuleScript");
        modelIcon = loadImage("Model");
        folderIcon = loadImage("Folder");
        replicatedStorageIcon = loadImage("ReplicatedStorage");
        lightingIcon = loadImage("Lighting");
        playerIcon = loadImage("Player");
        playersIcon = loadImage("Players");
        textureIcon = loadImage("Texture");
        soundIcon = loadImage("Sound");
        serverScriptService = loadImage("ServerScript");
        weldConstraintIcon = loadImage("Weld");
        motor6DConstraintIcon = loadImage("Motor6d");
        playIcon = loadImage("Test_Run");
        playPlayerIcon = loadImage("Server_And_Clients_Run");
        stopIcon = loadImage("Stop_Run");
        ribbonSelectIcon = loadImage("Ribbon_Select");
        ribbonMoveIcon = loadImage("Ribbon_Move_Gizmo");
        ribbonRotateIcon = loadImage("Ribbon_Rotate_Gizmo");
        ribbonScaleIcon = loadImage("Ribbon_Scale_Gizmo");
        ribbonGroupIcon = loadImage("Ribbon_Group_Selected");
        ribbonUngroupIcon = loadImage("Ribbon_Ungroup_Selected");
        ribbonAnchorIcon = loadImage("Ribbon_Anchor_Selected");
        mouseDefaultIcon = loadImage("Mouse_Default");
        mouseClickIcon = loadImage("Mouse_Click");
        mouseLeftRightIcon = loadImage("Mouse_LeftRight");
        mouseMoveGizmoIcon = loadImage("Mouse_Move_Gizmo");
        mouseObjectSelectionIcon = loadImage("Mouse_Object_Selection");
        mouseRotateGizmoIcon = loadImage("Mouse_Rotate_Gizmo");
        mouseScaleGizmoIcon = loadImage("Mouse_Scale_Gizmo");
        bindableEventIcon = loadImage("BindableEvent");
        remoteEventIcon = loadImage("RemoteEvent");
        bindableFunctionIcon = loadImage("BindaleFunction");
        remoteFunctionIcon = loadImage("RemoteFunction");
        humanoidIcon = loadImage("Humanoid");
        cameraIcon = loadImage("Camera"); // optional; falls back if missing
        if (cameraIcon.id == 0) cameraIcon = loadImage("Players");
        guiIcon = loadImage("GameGui");
        if (guiIcon.id == 0) guiIcon = loadImage("Frame");
        // Typed icons
        spotLightIcon = loadImage("SpotLight");
        surfaceLightIcon = loadImage("SurfaceLight");
        pointLightIcon = loadImage("PointLight");
        sunLightIcon = loadImage("SunLight");
        blurIcon = loadImage("Blur");
        bloomIcon = loadImage("Bloom");
        billboardGuiIcon = loadImage("BillBoardGui");
        surfaceGuiIcon = loadImage("SurfaceGui");
        screenGuiIcon = loadImage("GameGui");
        if (screenGuiIcon.id == 0) screenGuiIcon = loadImage("StarterGui");
        frameIcon = loadImage("Frame");
        scrollingFrameIcon = loadImage("ScrollFrame");
        textLabelIcon = loadImage("TextLabel");
        textButtonIcon = loadImage("TextButton");
        textBoxIcon = loadImage("TextBox");
        imageLabelIcon = loadImage("ImageLabel");
        imageButtonIcon = loadImage("ImageButton");
        uiCornerIcon = loadImage("UICorner");
        uiListIcon = loadImage("UIList");
        uiStrokeIcon = loadImage("UIStroke");
        uiGridIcon = loadImage("UIGrid");
        uiGradientIcon = loadImage("UIGradient");
        uiAspectIcon = loadImage("UISizeConstant");
        starterGuiIcon = loadImage("StarterGui");
        decalIcon = loadImage("Decal");
        meshPartIcon = loadImage("MeshPart");
        toolIcon = loadImage("Tool");
        attachmentIcon = loadImage("Attachment");
        // Note: filenames match assets/icons (ACVarible.png has the project spelling)
        acVariableIcon = loadImage("ACVarible");
        acFunctionIcon = loadImage("ACFunction");
        acPropertyIcon = loadImage("ACProperty");
        acEventIcon = loadImage("ACEvent");
        acValueIcon = loadImage("ACValue");
        acEnumIcon = loadImage("ACEnum");
        acSnippetIcon = loadImage("ACCodeSnippet");
        acFolderIcon = loadImage("ACFolder");
        acTextIcon = loadImage("ACText");
    }

    ~iconLib() {
        UnloadTexture(partIcon);
        UnloadTexture(workspaceIcon);
        UnloadTexture(serverstorageIcon);
        UnloadTexture(localScriptIcon);
        UnloadTexture(moduleScriptIcon);
        UnloadTexture(scriptIcon);
        UnloadTexture(modelIcon);
        UnloadTexture(folderIcon);
        UnloadTexture(replicatedStorageIcon);
        UnloadTexture(lightingIcon);
        UnloadTexture(playerIcon);
        UnloadTexture(playersIcon);
        UnloadTexture(playIcon);
        UnloadTexture(playPlayerIcon);
        UnloadTexture(stopIcon);
        UnloadTexture(ribbonSelectIcon);
        UnloadTexture(ribbonMoveIcon);
        UnloadTexture(ribbonRotateIcon);
        UnloadTexture(ribbonScaleIcon);
        UnloadTexture(ribbonGroupIcon);
        UnloadTexture(ribbonUngroupIcon);
        UnloadTexture(ribbonAnchorIcon);
        UnloadTexture(mouseDefaultIcon);
        UnloadTexture(mouseClickIcon);
        UnloadTexture(mouseLeftRightIcon);
        UnloadTexture(mouseMoveGizmoIcon);
        UnloadTexture(mouseObjectSelectionIcon);
        UnloadTexture(mouseRotateGizmoIcon);
        UnloadTexture(mouseScaleGizmoIcon);
        UnloadTexture(textureIcon);
        UnloadTexture(soundIcon);
        UnloadTexture(serverScriptService);
        UnloadTexture(weldConstraintIcon);
        UnloadTexture(motor6DConstraintIcon);
        UnloadTexture(bindableEventIcon);
        UnloadTexture(remoteEventIcon);
        UnloadTexture(bindableFunctionIcon);
        UnloadTexture(remoteFunctionIcon);
        UnloadTexture(humanoidIcon);
        UnloadTexture(cameraIcon);
        UnloadTexture(sunLightIcon);
        UnloadTexture(blurIcon);
        UnloadTexture(bloomIcon);
        UnloadTexture(acVariableIcon);
        UnloadTexture(acFunctionIcon);
        UnloadTexture(acPropertyIcon);
        UnloadTexture(acEventIcon);
        UnloadTexture(acValueIcon);
        UnloadTexture(acEnumIcon);
        UnloadTexture(acSnippetIcon);
        UnloadTexture(acFolderIcon);
        UnloadTexture(acTextIcon);
    }
};

iconLib* explorerIcons = nullptr;

Texture2D getStudioMouseIcon()
{
    if (explorerIcons == nullptr)
        return { 0 };
    if (propertyResizing || explorerResizing)
        return explorerIcons->mouseLeftRightIcon;
    if (pointerPickOwner != nullptr)
        return explorerIcons->mouseObjectSelectionIcon;
    if (selectToolActive)
        return explorerIcons->mouseDefaultIcon;
    if (hoveredGizmoAxis != GizmoAxis::None || draggingGizmo)
        return explorerIcons->mouseLeftRightIcon;
    Vector2 mouse = GetMousePosition();
    int explorerX = getExplorerX();
    bool explorerOnLeft = isDockPanelOnLeft(DockPanelKind::Explorer);
    bool explorerResizeHotspot = EXPLORER_WIDTH > 40 &&
        (explorerOnLeft
            ? fabsf(mouse.x - (explorerX + EXPLORER_WIDTH)) <= 5.0f
            : fabsf(mouse.x - explorerX) <= 5.0f);
    int propertyX = getPropertyX();
    bool propertyOnLeft = isDockPanelOnLeft(DockPanelKind::Properties);
    bool propertyResizeHotspot = PROPERTY_WIDTH > 40 &&
        (propertyOnLeft
            ? fabsf(mouse.x - (propertyX + PROPERTY_WIDTH)) <= 5.0f
            : fabsf(mouse.x - propertyX) <= 5.0f);
    if (explorerResizeHotspot || propertyResizeHotspot)
        return explorerIcons->mouseLeftRightIcon;
    if (isZoneFocused(FocusZone::Viewport))
    {
        if (currentGizmo == GizmoType::Rotate)
            return explorerIcons->mouseRotateGizmoIcon;
        if (currentGizmo == GizmoType::Scale)
            return explorerIcons->mouseScaleGizmoIcon;
        return explorerIcons->mouseMoveGizmoIcon;
    }
    if (IsMouseButtonDown(MOUSE_BUTTON_LEFT))
        return explorerIcons->mouseClickIcon;
    return explorerIcons->mouseDefaultIcon;
}

void renderStudioMouseCursor()
{
    Texture2D icon = getStudioMouseIcon();
    if (icon.id == 0)
        return;
    Vector2 mouse = GetMousePosition();
    drawEditorIcon(icon, mouse.x - 1.5f, mouse.y - 1.5f, 27.0f, 27.0f, WHITE);
}


#pragma endregion

#endif // BT_ASSETS_H