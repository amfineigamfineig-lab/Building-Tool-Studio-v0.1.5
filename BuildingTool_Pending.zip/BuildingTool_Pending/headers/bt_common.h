// bt_common.h — Includes, fonts, mesh helpers, materials, enums, gizmo state
// Auto-split from buildingTool_.cpp (keep include order).
#pragma once
#ifndef BT_COMMON_H
#define BT_COMMON_H

#pragma region "Includes"

#include <iostream>
#include <cstdio>
#include <string>
#include <vector>
#include <cmath>
#include <cfloat>
#include <algorithm>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <functional>
#include <cstring>
#include <cctype>
#include <fstream>
#include <iterator>
#include <sstream>
#include <iomanip>
#include <cstdlib>
#include <limits>
#include <cstdint>
#include <filesystem>
#define Rectangle Win32Rectangle
#define CloseWindow Win32CloseWindow
#define ShowCursor Win32ShowCursor
#define LoadImage Win32LoadImage
#define DrawTextEx Win32DrawTextEx
#define PlaySound Win32PlaySound
#include <windows.h>
#include <commdlg.h>
#include <objbase.h>
#undef Rectangle
#undef CloseWindow
#undef ShowCursor
#undef LoadImage
#undef DrawTextEx
#undef PlaySound
#ifdef DrawText
#undef DrawText
#endif

#include <chrono>

#include "raylib.h"
#include "C:/raylib/raylib/src/external/stb_image.h"
#include "../assets/Headers/Compress.h"
#include "../assets/Headers/luau_api.h"
#include "rlgl.h"
#include "C:/raylib/raylib/src/raymath.h"
#include "F:/luau/VM/include/lua.h"
#include "F:/luau/VM/include/lualib.h"
#include "F:/luau/Compiler/include/luacode.h"

#pragma endregion

using namespace std;

Font applicationFont = { 0 };
bool applicationFontLoaded = false;

// Bold/italic variants for syntax highlighting (and any other text that wants
// emphasis). Loaded from the Consolas family alongside the regular font. If a
// variant isn't available on disk we fall back to faux styling (double-strike
// bold, sheared italic) so callers never have to special-case missing fonts.
Font applicationFontBold = { 0 };
Font applicationFontItalic = { 0 };
Font applicationFontBoldItalic = { 0 };
bool applicationFontBoldLoaded = false;
bool applicationFontItalicLoaded = false;
bool applicationFontBoldItalicLoaded = false;

enum class TextStyle
{
    Regular,
    Bold,
    Italic,
    BoldItalic
};

// Faux-italic shear amount: horizontal pixels shifted per pixel of glyph height.
const float FAUX_ITALIC_SHEAR = 0.22f;
// Faux-bold double-strike offset in pixels.
const float FAUX_BOLD_OFFSET = 0.65f;

void AppDrawTextStyled(const char* text, int x, int y, int fontSize, Color color, TextStyle style)
{
    bool wantBold = (style == TextStyle::Bold || style == TextStyle::BoldItalic);
    bool wantItalic = (style == TextStyle::Italic || style == TextStyle::BoldItalic);

    Font font = applicationFontLoaded ? applicationFont : GetFontDefault();
    bool usingTrueBold = false;
    bool usingTrueItalic = false;

    if (wantBold && wantItalic && applicationFontBoldItalicLoaded)
    {
        font = applicationFontBoldItalic;
        usingTrueBold = true;
        usingTrueItalic = true;
    }
    else if (wantBold && applicationFontBoldLoaded)
    {
        font = applicationFontBold;
        usingTrueBold = true;
    }
    else if (wantItalic && applicationFontItalicLoaded)
    {
        font = applicationFontItalic;
        usingTrueItalic = true;
    }

    bool needFauxItalic = wantItalic && !usingTrueItalic;
    bool needFauxBold = wantBold && !usingTrueBold;

    Vector2 position = { static_cast<float>(x), static_cast<float>(y) };

    if (needFauxItalic)
    {
        // Shear glyphs about the (x, y) draw origin so slanting doesn't shift
        // the text's on-screen anchor point.
        Matrix shear = MatrixIdentity();
        shear.m4 = -FAUX_ITALIC_SHEAR;

        rlPushMatrix();
        rlTranslatef(position.x, position.y, 0.0f);
        rlMultMatrixf(MatrixToFloat(shear));
        rlTranslatef(-position.x, -position.y, 0.0f);

        DrawTextEx(font, text, position, static_cast<float>(fontSize), 0.0f, color);
        if (needFauxBold)
            DrawTextEx(font, text, { position.x + FAUX_BOLD_OFFSET, position.y }, static_cast<float>(fontSize), 0.0f, color);

        rlPopMatrix();
        return;
    }

    DrawTextEx(font, text, position, static_cast<float>(fontSize), 0.0f, color);
    if (needFauxBold)
        DrawTextEx(font, text, { position.x + FAUX_BOLD_OFFSET, position.y }, static_cast<float>(fontSize), 0.0f, color);
}

int AppMeasureTextStyled(const char* text, int fontSize, TextStyle style)
{
    bool wantBold = (style == TextStyle::Bold || style == TextStyle::BoldItalic);
    bool wantItalic = (style == TextStyle::Italic || style == TextStyle::BoldItalic);

    Font font = applicationFontLoaded ? applicationFont : GetFontDefault();

    if (wantBold && wantItalic && applicationFontBoldItalicLoaded)
        font = applicationFontBoldItalic;
    else if (wantBold && applicationFontBoldLoaded)
        font = applicationFontBold;
    else if (wantItalic && applicationFontItalicLoaded)
        font = applicationFontItalic;

    Vector2 size = MeasureTextEx(font, text, static_cast<float>(fontSize), 0.0f);
    // Faux-bold's double-strike offset widens the visible glyph slightly;
    // account for it so cursor/selection math in the script editor stays lined up.
    bool usingTrueBold = (wantBold && wantItalic && applicationFontBoldItalicLoaded) ||
                          (wantBold && !wantItalic && applicationFontBoldLoaded);
    if (wantBold && !usingTrueBold)
        size.x += FAUX_BOLD_OFFSET;

    return static_cast<int>(size.x);
}

// UI scale relative to a 1920×1080 reference so text/panels stay readable when
// the window is not maximized. Clamped so tiny windows don't collapse UI.
float getUiScale()
{
    float sx = static_cast<float>(GetScreenWidth()) / 1920.0f;
    float sy = static_cast<float>(GetScreenHeight()) / 1080.0f;
    float s = min(sx, sy);
    return std::clamp(s, 0.75f, 1.35f);
}

int ui(int value)
{
    return max(1, static_cast<int>(value * getUiScale() + 0.5f));
}

int uiFont(int base)
{
    return max(11, static_cast<int>(base * getUiScale() + 0.5f));
}

string cleanNumber(float value)
{
    return TextFormat("%.7g", static_cast<double>(value));
}

string cleanNumber(double value)
{
    return TextFormat("%.15g", value);
}

// System storage for settings, fonts, previews — ./temp under the working directory
string getTempDir()
{
    static string cached;
    if (!cached.empty())
        return cached;
    // Prefer ./temp next to the executable cwd (user-facing system storage)
    filesystem::path p = filesystem::path(GetWorkingDirectory()) / "temp";
    error_code ec;
    filesystem::create_directories(p, ec);
    if (ec)
    {
        // Fallback if cwd is locked
        p = filesystem::path(GetWorkingDirectory()) / "BuildingTool_Pending" / "temp";
        filesystem::create_directories(p, ec);
    }
    cached = p.string();
    return cached;
}

string makeTempFilePath(const string& name)
{
    return (filesystem::path(getTempDir()) / name).string();
}

void AppDrawText(const char* text, int x, int y, int fontSize, Color color)
{
    DrawTextEx(
        applicationFontLoaded ? applicationFont : GetFontDefault(),
        text,
        { static_cast<float>(x), static_cast<float>(y) },
        static_cast<float>(fontSize),
        0.0f,
        color
    );
}

int AppMeasureText(const char* text, int fontSize)
{
    Vector2 size = MeasureTextEx(
        applicationFontLoaded ? applicationFont : GetFontDefault(),
        text,
        static_cast<float>(fontSize),
        0.0f
    );
    return static_cast<int>(size.x);
}

#define DrawText AppDrawText
#define MeasureText AppMeasureText

#pragma endregion

#pragma region "Mesh"

#pragma region "Torus Mesh"
Mesh torusMesh;
Material torusMaterial;
Material gizmoMaterial;
Mesh gizmoConeMesh;
// Measured (not assumed) local-space Y of the cone's base ring and its apex tip.
// GenMeshCone's exact pivot/orientation can differ between raylib versions, so we
// scan the generated mesh once at load time instead of hard-coding "base at y=0,
// tip at y=+1" — that mismatch was the root cause of the gizmo cone appearing
// offset toward the shaft's center instead of sitting at the arrow tip.
float gizmoConeLocalBaseY = 0.0f;
float gizmoConeLocalTipY = 1.0f;
const float TORUS_BASE_RADIUS = 2.0f;


Mesh CreateTorusMesh(float majorRadius, float minorRadius,int majorSegments, int minorSegments)
{
    Mesh mesh = { 0 };

    int vertexCount = majorSegments * minorSegments;
    int triangleCount = majorSegments * minorSegments * 2;

    mesh.vertexCount = vertexCount;
    mesh.triangleCount = triangleCount;

    mesh.vertices  = (float *)MemAlloc(vertexCount * 3 * sizeof(float));
    mesh.normals   = (float *)MemAlloc(vertexCount * 3 * sizeof(float));
    mesh.texcoords = (float *)MemAlloc(vertexCount * 2 * sizeof(float));
    mesh.indices   = (unsigned short *)MemAlloc(triangleCount * 3 * sizeof(unsigned short));

    for (int i = 0; i < majorSegments; i++)
    {
        float u = 2.0f * PI * i / majorSegments;

        for (int j = 0; j < minorSegments; j++)
        {
            float v = 2.0f * PI * j / minorSegments;

            int vertex = i * minorSegments + j;

            float cu = cosf(u);
            float su = sinf(u);
            float cv = cosf(v);
            float sv = sinf(v);

            // Position
            float x = (majorRadius + minorRadius * cv) * cu;
            float y = minorRadius * sv;
            float z = (majorRadius + minorRadius * cv) * su;

            mesh.vertices[vertex * 3 + 0] = x;
            mesh.vertices[vertex * 3 + 1] = y;
            mesh.vertices[vertex * 3 + 2] = z;

            // Normal
            mesh.normals[vertex * 3 + 0] = cv * cu;
            mesh.normals[vertex * 3 + 1] = sv;
            mesh.normals[vertex * 3 + 2] = cv * su;

            // UV
            mesh.texcoords[vertex * 2 + 0] =
                (float)i / majorSegments;

            mesh.texcoords[vertex * 2 + 1] =
                (float)j / minorSegments;
        }
    }

    // Indices
    int index = 0;

    for (int i = 0; i < majorSegments; i++)
    {
        int nextI = (i + 1) % majorSegments;

        for (int j = 0; j < minorSegments; j++)
        {
            int nextJ = (j + 1) % minorSegments;

            int a = i * minorSegments + j;
            int b = nextI * minorSegments + j;
            int c = nextI * minorSegments + nextJ;
            int d = i * minorSegments + nextJ;

            mesh.indices[index++] = a;
            mesh.indices[index++] = b;
            mesh.indices[index++] = c;

            mesh.indices[index++] = a;
            mesh.indices[index++] = c;
            mesh.indices[index++] = d;
        }
    }

    UploadMesh(&mesh, false);

    return mesh;
}

#pragma endregion

#pragma region "Gizmo Cone Mesh"

// Scans a cone mesh's raw vertex data to find which local Y extreme is the
// single apex point (near-zero radius from the Y axis) and which is the base
// ring (full radius). This replaces guessing about GenMeshCone's internal
// pivot convention with a direct measurement of the mesh raylib actually gave us.
void ComputeConeMeshLocalBounds(const Mesh& mesh, float& outBaseY, float& outTipY)
{
    if (mesh.vertexCount <= 0 || mesh.vertices == nullptr)
    {
        outBaseY = 0.0f;
        outTipY = 1.0f;
        return;
    }

    float minY = FLT_MAX;
    float maxY = -FLT_MAX;

    // Track the largest radius (distance from the Y axis) seen near each Y extreme.
    float radiusAtMinY = 0.0f;
    float radiusAtMaxY = 0.0f;

    for (int i = 0; i < mesh.vertexCount; i++)
    {
        float x = mesh.vertices[i * 3 + 0];
        float y = mesh.vertices[i * 3 + 1];
        float z = mesh.vertices[i * 3 + 2];

        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
    }

    const float epsilon = (maxY - minY) * 0.01f + 0.0001f;

    for (int i = 0; i < mesh.vertexCount; i++)
    {
        float x = mesh.vertices[i * 3 + 0];
        float y = mesh.vertices[i * 3 + 1];
        float z = mesh.vertices[i * 3 + 2];

        float radius = sqrtf(x * x + z * z);

        if (fabsf(y - minY) <= epsilon && radius > radiusAtMinY)
            radiusAtMinY = radius;

        if (fabsf(y - maxY) <= epsilon && radius > radiusAtMaxY)
            radiusAtMaxY = radius;
    }

    // The apex is whichever extreme has (close to) zero radius; the base ring
    // is the extreme with the full radius.
    if (radiusAtMinY <= radiusAtMaxY)
    {
        outBaseY = maxY;
        outTipY = minY;
    }
    else
    {
        outBaseY = minY;
        outTipY = maxY;
    }
}

#pragma endregion

#pragma endregion

#pragma region "Materials"

Material partMaterial;

Mesh blockMesh;
Mesh sphereMesh;
Mesh cylinderMesh;
Mesh sphereMeshMedium;
Mesh sphereMeshLow;
Mesh cylinderMeshMedium;
Mesh cylinderMeshLow;

Material blockMaterial;
Shader blockShader;

Shader shadowShader;
RenderTexture2D shadowMap;
Material shadowMaterial;
Camera3D shadowCamera;
// Copy of the editor/runtime 3D camera used by BillboardGui / SurfaceGui projection.
Camera3D viewportCamera = { 0 };
bool viewportCameraValid = false;

// Final scene render target + post-processing blur.
RenderTexture2D lightingSceneTarget;
Shader postProcessShader;
int postProcessTexelSizeLoc;
int postProcessBlurLoc;

int shadowMapLoc;
int shadowMapTexelSizeLoc;
int lightSpaceMatrixLoc;
int shadowLightSpaceLoc;

Matrix lightSpaceMatrix;

int sunDirectionLoc;
int sunColorLoc;
int sunIntensityLoc;
int ambientLoc;

int ambientColorLoc;
int outdoorAmbientLoc;
int brightnessLoc;
int exposureCompensationLoc;
int colorShiftTopLoc;
int colorShiftBottomLoc;
int fogColorLoc;
int fogStartLoc;
int fogEndLoc;
int cameraPositionLoc;
int globalShadowsLoc;
int shadowSoftnessLoc;
int shadowFilterSizeLoc;
int reflectanceLoc;
int environmentSpecularScaleLoc;
int lightCountLoc;
int lightPosLoc;
int lightColorLoc;
int lightDirLoc;
int lightBrightnessLoc;
int lightRangeLoc;
int lightAngleLoc;
int lightKindLoc;

#pragma endregion

// ============================================================
// Enums
// ============================================================
#pragma region "Instance Enums"

enum class InstanceType
{
    Part,
    Script,
    Model,
    Folder,
    Service,
    Sound,
    Texture,
    WeldConstraint,
    Motor6D,
    Blur,
    ColorCorrection,
    SunLight,
    PointLight,
    SpotLight,
    SurfaceLight,
    Bloom,
    Player,
    BindableEvent,
    BindableFunction,
    RemoteEvent,
    RemoteFunction,
    Humanoid,
    Camera,
    // 2D GUI (Roblox-like)
    ScreenGui,
    SurfaceGui,
    BillboardGui,
    Frame,
    ScrollingFrame,
    TextLabel,
    ImageLabel,
    TextButton,
    ImageButton,
    TextBox,
    UICorner,
    UIListLayout,
    UIStroke,
    UIPadding,
    UIGridLayout,
    UIAspectRatioConstraint
};

// UDim / UDim2 for GuiObject layout
struct UDimValue
{
    float scale = 0.0f;
    float offset = 0.0f;
};

struct UDim2Value
{
    UDimValue x;
    UDimValue y;
};

enum class PartType
{
    Block,
    Wedge,
    CornerWedge,
    Cylinder,
    Sphere,
    Cone
};

enum class CollisionFidelity
{
    Default = 0,
    Hull = 1,
    Box = 2,
    PreciseConvexDecomposition = 3,
    Tunable = 4
};

enum class ScriptType
{
    LocalScript,
    ModuleScript,
    Script
};

#pragma endregion

#pragma region "Gizmo"

enum class GizmoType
{
    Move,
    Rotate,
    Scale
};

enum class GizmoAxis
{
    None,
    X,
    Y,
    Z,
    Center
};

struct GizmoHandle
{
    GizmoAxis axis;
    int sign;
    Vector3 position;
};

struct Part;

GizmoType currentGizmo = GizmoType::Move;
bool selectToolActive = false;

GizmoAxis hoveredGizmoAxis = GizmoAxis::None;
GizmoAxis activeGizmoAxis = GizmoAxis::None;

int hoveredGizmoSign = 1;
int activeGizmoSign = 1;

bool draggingGizmo = false;

Vector2 gizmoStartMouse = { 0, 0 };

Vector3 gizmoStartPosition = { 0, 0, 0 };
Vector3 gizmoStartSize = { 1, 1, 1 };
Vector3 gizmoStartRotation = { 0, 0, 0 };
float gizmoStartModelScale = 1.0f;

vector<Part*> gizmoParts;
vector<Vector3> gizmoStartPositions;
vector<Vector3> gizmoStartSizes;
vector<Vector3> gizmoStartRotations;
bool gizmoCenterScale = false;
bool gizmoResize = false;

float gizmoStartAngle = 0.0f;
float gizmoDragValue = 0.0f;
bool helpOpen = false;
bool studioSettingsOpen = false;
float studioSettingsScrollY = 0.0f;
float studioSettingsMaxScrollY = 0.0f;
bool studioSettingsScrollbarDragging = false;
struct StudioSettings
{
    bool showGrid = true;
    bool showActionBar = true;
    bool showRibbonBar = true;
    bool showWindowBar = true;
    string theme = "Dark";
    bool vsync = true;
    int targetFps = 144;
    float cameraSpeed = 1.0f;
    bool autoSave = true;
    int autoSaveMinutes = 5;   // cooldown between autosaves
    int autoSaveCap = 5;       // max rotating autosave versions per project
    Color iconTint = { 255, 255, 255, 255 }; // explorer / insert icon tint
    string iconColorMode = "Mono";
    unordered_map<string, Color> iconGroupColors = {
        { "Geometry", { 238, 190, 91, 255 } },
        { "Scripts", { 100, 188, 235, 255 } },
        { "Containers", { 143, 190, 131, 255 } },
        { "UI", { 192, 148, 225, 255 } },
        { "Assets", { 232, 135, 115, 255 } },
        { "Services", { 116, 176, 180, 255 } }
    };
    array<Color, 12> colorSlots = {
        WHITE, BLACK, RED, ORANGE, YELLOW, GREEN, BLUE, PURPLE, PINK,
        Color{ 0, 220, 220, 255 }, Color{ 155, 115, 85, 255 }, Color{ 145, 155, 170, 255 }
    };
    array<bool, 12> colorSlotUsed = {};
};
StudioSettings studioSettings;
string selectedIconColorGroup = "Geometry";
bool iconGroupColorPickerOpen = false;
float iconGroupPickerHue = 0.0f;
float iconGroupPickerSaturation = 0.0f;
float iconGroupPickerValue = 1.0f;
unordered_map<string, Color> iconIndividualColors;
string iconIndividualColorKey;
float advancedIconScrollY = 0.0f;
bool advancedIconScrollbarDragging = false;
string advancedIconSearch;
bool showAdvancedIconColors = false;
bool advancedIconSearchFocused = false;
bool projectStorageMultiFile = false;
bool serializeProjectForRuntime = false;
bool projectSerializationFailed = false;
int projectSerializationScriptIndex = 0;
int projectSerializationAssetIndex = 0;
filesystem::path projectSourceRoot;
bool runtimeOnlyBuild = false;

struct ThemeGradientStop
{
    float time = 0.0f;
    Color color = { 0, 0, 0, 255 };
};

struct EditorThemeColors
{
    Color canvas;
    Color panel;
    Color header;
    Color surface;
    Color border;
    Color text;
    Color muted;
    Color accent;
    Color accentHover;
    Color selected;
    bool hasGradient = false;
    Color gradientStart = { 0, 0, 0, 255 };
    Color gradientEnd = { 0, 0, 0, 255 };
    vector<ThemeGradientStop> gradientStops;
};

void drawThemeBackground(Rectangle bounds, const EditorThemeColors& theme, Color fallback)
{
    if (!theme.hasGradient || bounds.height <= 1.0f)
    {
        DrawRectangleRec(bounds, fallback);
        return;
    }
    int top = static_cast<int>(bounds.y);
    int height = max(1, static_cast<int>(bounds.height));
    auto colorAt = [&](float time)
    {
        if (theme.gradientStops.size() < 2)
        {
            return Color{
                static_cast<unsigned char>(theme.gradientStart.r + (theme.gradientEnd.r - theme.gradientStart.r) * time),
                static_cast<unsigned char>(theme.gradientStart.g + (theme.gradientEnd.g - theme.gradientStart.g) * time),
                static_cast<unsigned char>(theme.gradientStart.b + (theme.gradientEnd.b - theme.gradientStart.b) * time),
                static_cast<unsigned char>(theme.gradientStart.a + (theme.gradientEnd.a - theme.gradientStart.a) * time)
            };
        }
        if (time <= theme.gradientStops.front().time)
            return theme.gradientStops.front().color;
        if (time >= theme.gradientStops.back().time)
            return theme.gradientStops.back().color;
        for (size_t index = 1; index < theme.gradientStops.size(); ++index)
        {
            const ThemeGradientStop& right = theme.gradientStops[index];
            const ThemeGradientStop& left = theme.gradientStops[index - 1];
            if (time <= right.time)
            {
                float span = max(0.0001f, right.time - left.time);
                float t = (time - left.time) / span;
                return Color{
                    static_cast<unsigned char>(left.color.r + (right.color.r - left.color.r) * t),
                    static_cast<unsigned char>(left.color.g + (right.color.g - left.color.g) * t),
                    static_cast<unsigned char>(left.color.b + (right.color.b - left.color.b) * t),
                    static_cast<unsigned char>(left.color.a + (right.color.a - left.color.a) * t)
                };
            }
        }
        return theme.gradientStops.back().color;
    };
    for (int row = 0; row < height; ++row)
    {
        float t = static_cast<float>(row) / max(1, height - 1);
        Color color = colorAt(t);
        DrawRectangle(static_cast<int>(bounds.x), top + row, static_cast<int>(bounds.width), 1, color);
    }
}

struct CustomEditorTheme
{
    string name;
    EditorThemeColors ui = {
        { 24, 28, 34, 255 }, { 31, 36, 43, 255 }, { 42, 49, 59, 255 },
        { 50, 58, 69, 255 }, { 69, 79, 93, 255 }, { 226, 232, 240, 255 },
        { 145, 157, 173, 255 }, { 54, 124, 192, 255 }, { 73, 148, 218, 255 }, { 48, 74, 101, 255 }
    };
    Color scriptBackground = { 37, 37, 37, 255 };
    Color scriptGutter = { 46, 46, 46, 255 };
    Color scriptText = { 220, 220, 220, 255 };
    Color scriptComment = { 102, 102, 102, 255 };
    Color scriptString = { 173, 241, 149, 255 };
    Color scriptKeyword = { 248, 109, 124, 255 };
    Color scriptLiteral = { 255, 198, 0, 255 };
    Color scriptFunction = { 253, 221, 140, 255 };
    Color scriptNumber = { 255, 198, 0, 255 };
    Color scriptBuiltin = { 132, 214, 247, 255 };
    Color scriptOperator = { 180, 180, 180, 255 };
    Color scriptType = { 180, 160, 255, 255 };
    Color scriptSelection = { 45, 105, 180, 255 };
    Color scriptFindHighlight = { 208, 155, 43, 170 };
    string iconColorMode;
    unordered_map<string, Color> iconSetColors;
    unordered_map<string, Color> iconInstanceColors;
    unordered_map<string, Color> iconMiscColors;
    unordered_map<string, Color> ribbonColors;
};

vector<CustomEditorTheme> customEditorThemes;

EditorThemeColors getEditorThemeColors()
{
    for (const CustomEditorTheme& theme : customEditorThemes)
        if (studioSettings.theme == theme.name)
            return theme.ui;
    if (studioSettings.theme == "Light")
        return { { 229, 233, 238, 255 }, { 246, 247, 249, 255 }, { 219, 225, 232, 255 },
            { 234, 238, 243, 255 }, { 184, 193, 204, 255 }, { 38, 46, 56, 255 },
            { 93, 105, 120, 255 }, { 45, 112, 180, 255 }, { 65, 133, 203, 255 }, { 210, 225, 241, 255 } };
    if (studioSettings.theme == "Gray")
        return { { 42, 44, 47, 255 }, { 53, 55, 58, 255 }, { 62, 64, 67, 255 },
            { 72, 74, 77, 255 }, { 91, 94, 98, 255 }, { 229, 231, 234, 255 },
            { 159, 164, 170, 255 }, { 100, 145, 174, 255 }, { 119, 163, 191, 255 }, { 73, 91, 103, 255 } };
    if (studioSettings.theme == "Orange")
        return { { 37, 31, 27, 255 }, { 49, 40, 33, 255 }, { 63, 48, 37, 255 },
            { 76, 55, 38, 255 }, { 112, 77, 46, 255 }, { 247, 232, 214, 255 },
            { 190, 164, 137, 255 }, { 222, 119, 42, 255 }, { 241, 145, 60, 255 }, { 103, 65, 37, 255 } };
    return { { 24, 28, 34, 255 }, { 31, 36, 43, 255 }, { 42, 49, 59, 255 },
        { 50, 58, 69, 255 }, { 69, 79, 93, 255 }, { 226, 232, 240, 255 },
        { 145, 157, 173, 255 }, { 54, 124, 192, 255 }, { 73, 148, 218, 255 }, { 48, 74, 101, 255 } };
}

Color getStudioIconTint(const string& group)
{
    if (studioSettings.iconColorMode == "Theme")
    {
        for (const CustomEditorTheme& theme : customEditorThemes)
        {
            if (studioSettings.theme != theme.name)
                continue;
            auto iconColor = theme.iconSetColors.find(group);
            if (iconColor != theme.iconSetColors.end())
                return iconColor->second;
            return theme.ui.accent;
        }
        return getEditorThemeColors().accent;
    }
    if (studioSettings.iconColorMode == "Mono")
        return studioSettings.iconTint;
    if (studioSettings.iconColorMode == "Advanced")
        return WHITE;
    auto color = studioSettings.iconGroupColors.find(group);
    return color != studioSettings.iconGroupColors.end() ? color->second : studioSettings.iconTint;
}

string getAdvancedInstanceIconKey(const string& key)
{
    if (key == "BillBoardGui") return "BillboardGui";
    if (key == "BindaleFunction") return "BindableFunction";
    return key;
}

Color getStudioInstanceIconTint(const string& key, const string& group)
{
    auto overrideColor = iconIndividualColors.find("Instance/" + getAdvancedInstanceIconKey(key));
    if (overrideColor != iconIndividualColors.end())
        return overrideColor->second;
    if (studioSettings.iconColorMode == "Theme")
    {
        for (const CustomEditorTheme& theme : customEditorThemes)
        {
            if (studioSettings.theme != theme.name)
                continue;
            auto iconColor = theme.iconInstanceColors.find(key);
            if (iconColor != theme.iconInstanceColors.end())
                return iconColor->second;
            return getStudioIconTint(group);
        }
    }
    return getStudioIconTint(group);
}

string getAdvancedMiscIconKey(const string& key)
{
    if (key == "Move") return "Ribbon_Move_Gizmo";
    if (key == "Scale") return "Ribbon_Scale_Gizmo";
    if (key == "Rotate") return "Ribbon_Rotate_Gizmo";
    if (key == "Select") return "Ribbon_Select";
    if (key == "Group") return "Ribbon_Group_Selected";
    if (key == "Ungroup") return "Ribbon_Ungroup_Selected";
    if (key == "Anchor") return "Ribbon_Anchor_Selected";
    if (key == "Play") return "Test_Run";
    if (key == "PlayClient") return "Server_And_Clients_Run";
    if (key == "Stop") return "Stop_Run";
    return key;
}

Color getStudioRibbonIconTint(const string& key)
{
    auto overrideColor = iconIndividualColors.find("Misc/" + getAdvancedMiscIconKey(key));
    if (overrideColor != iconIndividualColors.end())
        return overrideColor->second;
    if (studioSettings.iconColorMode == "Theme")
    {
        for (const CustomEditorTheme& theme : customEditorThemes)
        {
            if (studioSettings.theme != theme.name)
                continue;
            auto ribbonColor = theme.ribbonColors.find(key);
            if (ribbonColor != theme.ribbonColors.end())
                return ribbonColor->second;
            auto miscColor = theme.iconMiscColors.find(key);
            if (miscColor != theme.iconMiscColors.end())
                return miscColor->second;
            return getStudioIconTint("Services");
        }
    }
    return getStudioIconTint("Services");
}

Color getStudioMiscIconTint(const string& key)
{
    auto overrideColor = iconIndividualColors.find("Misc/" + getAdvancedMiscIconKey(key));
    if (overrideColor != iconIndividualColors.end())
        return overrideColor->second;
    if (studioSettings.iconColorMode == "Theme")
    {
        for (const CustomEditorTheme& theme : customEditorThemes)
        {
            if (studioSettings.theme != theme.name)
                continue;
            auto iconColor = theme.iconMiscColors.find(key);
            if (iconColor != theme.iconMiscColors.end())
                return iconColor->second;
            return getStudioIconTint("Services");
        }
    }
    return getStudioIconTint("Services");
}

// Project / game settings (saved inside the .hlx project, not system temp)
struct GameSettings
{
    // 1 = lowest (fast), 6 = highest (most realistic shader work)
    int graphicsQuality = 4;
};
GameSettings gameSettings;
bool gameSettingsOpen = false;

// Effective caps driven by graphicsQuality (used by shader / light collection)
struct GraphicsQualityCaps
{
    int maxLights = 4;
    bool shadowsEnabled = true;
    int shadowFilterSize = 1; // 0..7 denser sample grid; kernel width stays fixed
    float specularScale = 1.0f;
    float reflectanceScale = 1.0f;
    bool postProcess = true;
};

GraphicsQualityCaps getGraphicsQualityCaps(int q)
{
    q = max(1, min(6, q));
    GraphicsQualityCaps c;
    switch (q)
    {
    case 1: // Fastest — no shadows, no local lights
        c.maxLights = 0;
        c.shadowsEnabled = false;
        c.shadowFilterSize = 0;
        c.specularScale = 0.0f;
        c.reflectanceScale = 0.0f;
        c.postProcess = false;
        break;
    case 2: // 1 shadow sample
        c.maxLights = 2;
        c.shadowsEnabled = true;
        c.shadowFilterSize = 0; // 1 point
        c.specularScale = 0.3f;
        c.reflectanceScale = 0.25f;
        c.postProcess = false;
        break;
    case 3: // up to 5x5 shadow taps
        c.maxLights = 4;
        c.shadowsEnabled = true;
        c.shadowFilterSize = 1;
        c.specularScale = 0.55f;
        c.reflectanceScale = 0.5f;
        c.postProcess = false;
        break;
    case 4: // up to 7x7 shadow taps
        c.maxLights = 6;
        c.shadowsEnabled = true;
        c.shadowFilterSize = 2;
        c.specularScale = 0.85f;
        c.reflectanceScale = 0.85f;
        c.postProcess = true;
        break;
    case 5: // up to 9x9 shadow taps
        c.maxLights = 8;
        c.shadowsEnabled = true;
        c.shadowFilterSize = 3;
        c.specularScale = 1.0f;
        c.reflectanceScale = 1.0f;
        c.postProcess = true;
        break;
    default: // 6 Ultra — up to 11x11 shadow taps
        c.maxLights = 8;
        c.shadowsEnabled = true;
        c.shadowFilterSize = 4;
        c.specularScale = 1.25f;
        c.reflectanceScale = 1.3f;
        c.postProcess = true;
        break;
    }
    return c;
}

// Importable / system fonts for Gui text (enum in property panel)
struct ProjectFontEntry
{
    string name;
    string path;      // empty = built-in default; "system:Name" or file path
    Font font = { 0 };
    bool loaded = false;
    bool isSystem = false;
};
vector<ProjectFontEntry> projectFonts;
string fontBrowserSearch;
float fontBrowserScrollY = 0.0f;
int fontBrowserSelected = 0;
bool fontBrowserOpen = false; // sub-panel of Studio Settings (Advanced)
int studioSettingsTab = 0; // 0=General, 1=Advanced
string studioSelectedFont = "SourceSans"; // font chosen in Advanced for app/GUI default

static void ensureDefaultProjectFonts()
{
    if (!projectFonts.empty()) return;
    projectFonts.push_back({ "SourceSans", "", {0}, false, false });
    projectFonts.push_back({ "Legacy", "", {0}, false, false });
    projectFonts.push_back({ "Code", "", {0}, false, false });
    // Common system fonts (loaded on demand)
    const char* sys[] = { "Arial", "Segoe UI", "Consolas", "Times New Roman", "Calibri", "Verdana", "Tahoma", "Courier New" };
    for (const char* n : sys)
        projectFonts.push_back({ n, string("system:") + n, {0}, false, true });
}

static Font* resolveProjectFont(const string& name)
{
    ensureDefaultProjectFonts();
    for (ProjectFontEntry& e : projectFonts)
    {
        if (e.name != name) continue;
        if (e.path.empty())
            return applicationFontLoaded ? &applicationFont : nullptr;
        if (!e.loaded)
        {
            // Try Windows fonts folder
            string tryPath = e.path;
            if (e.path.rfind("system:", 0) == 0)
            {
                string base = e.path.substr(7);
#ifdef _WIN32
                tryPath = string("C:/Windows/Fonts/") + base + ".ttf";
                e.font = LoadFontEx(tryPath.c_str(), 32, 0, 250);
                if (e.font.glyphCount == 0)
                {
                    tryPath = string("C:/Windows/Fonts/") + base + ".ttc";
                    e.font = LoadFontEx(tryPath.c_str(), 32, 0, 250);
                }
                if (e.font.glyphCount == 0)
                {
                    // lowercase file names
                    string lower;
                    for (char c : base) lower += (char)tolower((unsigned char)c);
                    tryPath = "C:/Windows/Fonts/" + lower + ".ttf";
                    e.font = LoadFontEx(tryPath.c_str(), 32, 0, 250);
                }
#else
                tryPath = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf";
                e.font = LoadFontEx(tryPath.c_str(), 32, 0, 250);
#endif
            }
            else
            {
                e.font = LoadFontEx(e.path.c_str(), 32, 0, 250);
            }
            e.loaded = e.font.glyphCount > 0;
        }
        return e.loaded ? &e.font : (applicationFontLoaded ? &applicationFont : nullptr);
    }
    return applicationFontLoaded ? &applicationFont : nullptr;
}

static vector<string> getAvailableFontNames()
{
    ensureDefaultProjectFonts();
    vector<string> names;
    for (const auto& e : projectFonts)
        names.push_back(e.name);
    return names;
}

static bool importFontFromPath(const string& path)
{
    if (path.empty() || !filesystem::exists(path)) return false;
    string name = filesystem::path(path).stem().string();
    if (name.empty()) name = "ImportedFont";
    // Unique name
    string base = name;
    int n = 1;
    ensureDefaultProjectFonts();
    while (true)
    {
        bool clash = false;
        for (const auto& e : projectFonts)
            if (e.name == name) { clash = true; break; }
        if (!clash) break;
        name = base + to_string(n++);
    }
    // Embed: copy into temp/fonts so the font travels with settings
    filesystem::path embedDir = filesystem::path(getTempDir()) / "fonts";
    error_code ec;
    filesystem::create_directories(embedDir, ec);
    string ext = filesystem::path(path).extension().string();
    string embedPath = (embedDir / (name + ext)).string();
    filesystem::copy_file(path, embedPath, filesystem::copy_options::overwrite_existing, ec);
    string loadPath = ec ? path : embedPath;

    ProjectFontEntry e;
    e.name = name;
    e.path = loadPath; // embedded path preferred
    e.isSystem = false; // imported → can be used for game Gui text
    e.font = LoadFontEx(loadPath.c_str(), 32, 0, 250);
    e.loaded = e.font.glyphCount > 0;
    if (!e.loaded)
        return false;
    projectFonts.push_back(e);
    return true;
}

#pragma endregion

#endif // BT_COMMON_H
