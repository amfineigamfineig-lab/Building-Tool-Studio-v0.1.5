// bt_panels.h — Properties, explorer, rename, selection
#pragma once
#ifndef BT_PANELS_H
#define BT_PANELS_H

Texture2D getInstanceIcon(const Instance* instance);
string getInstanceIconColorKey(const Instance* instance);
string getInstanceIconGroup(const Instance* instance);

void cancelPropertyEdit()
{
    activePropertyRow = -1;
    propertyEditText.clear();
    propertyEditCursor = 0;
    propertyEnumDropdownOpen = false;
    propertyEnumDropdownRow = -1;
    propertyEnumDropdownOptions.clear();
    propertyColorPickerOpen = false;
    propertyColorRgbEditing = false;
    propertyColorRgbSelectAll = false;
    propertyPickerExternalTarget = nullptr;
    floatingPropertyColorDrag = false;
}

int getPropertyValueX(const PropertyRow& row, float scrollX)
{
    int indent = row.kind == PropertyKind::Packed ? 14 :
        (row.kind == PropertyKind::PackedField ? 18 : 0);
    int labelRight = 10 + indent + MeasureText(row.name.c_str(), uiFont(15));
    return max(125, labelRight + 12) - static_cast<int>(scrollX);
}

Rectangle getPointerClearButtonRect(int valueX, int y)
{
    return { static_cast<float>(valueX + 209), static_cast<float>(y + 8), 20.0f, 20.0f };
}

Color* getPropertyColorTarget(Instance* instance, const string& property)
{
    if (instance == nullptr)
        return nullptr;
    if (instance == &Lighting)
    {
        if (property == "Ambient") return &lightingSettings.ambient;
        if (property == "OutdoorAmbient") return &lightingSettings.outdoorAmbient;
        if (property == "ColorShift_Top") return &lightingSettings.colorShiftTop;
        if (property == "ColorShift_Bottom") return &lightingSettings.colorShiftBottom;
        if (property == "FogColor") return &lightingSettings.fogColor;
        return nullptr;
    }
    switch (instance->getType())
    {
        case InstanceType::Part: return &static_cast<Part*>(instance)->color;
        case InstanceType::ColorCorrection: return &static_cast<ColorCorrectionInstance*>(instance)->tintColor;
        case InstanceType::SunLight: return &static_cast<SunLightInstance*>(instance)->color;
        case InstanceType::PointLight: return &static_cast<PointLightInstance*>(instance)->color;
        case InstanceType::SpotLight: return &static_cast<SpotLightInstance*>(instance)->color;
        case InstanceType::SurfaceLight: return &static_cast<SurfaceLightInstance*>(instance)->color;
        case InstanceType::Texture:
            if (property == "Color3") return &static_cast<TextureInstance*>(instance)->color3;
            return nullptr;
        case InstanceType::UIStroke:
            if (property == "Color") return &static_cast<UIModifierInstance*>(instance)->strokeColor;
            return nullptr;
        case InstanceType::Frame:
        case InstanceType::ScrollingFrame:
        case InstanceType::TextLabel:
        case InstanceType::ImageLabel:
        case InstanceType::TextButton:
        case InstanceType::ImageButton:
        case InstanceType::TextBox:
        {
            auto* gui = static_cast<GuiObjectInstance*>(instance);
            if (property == "BackgroundColor3") return &gui->backgroundColor;
            if (property == "BorderColor3") return &gui->borderColor;
            if (property == "TextColor3") return &gui->textColor;
            if (property == "TextStrokeColor3") return &gui->textStrokeColor;
            if (property == "PlaceholderColor3") return &gui->placeholderColor;
            if (property == "ImageColor3") return &gui->imageColor;
            if (property == "ScrollBarImageColor3") return &gui->scrollBarImageColor;
            return nullptr;
        }
        default: return nullptr;
    }
}

void renderPropertyPanel()
{
    bool propertiesVisible = isDockPanelActiveTab(DockPanelKind::Properties);
    if (!propertiesVisible && !propertyColorPickerOpen)
        return;
    if (!propertiesVisible)
    {
        drawPropertyColorPickerOverlay();
        return;
    }

    struct ScopedPropertyWidth
    {
        int previous;
        ScopedPropertyWidth() : previous(PROPERTY_WIDTH)
        {
            if (activeWindow == WindowType::PropertiesView)
                PROPERTY_WIDTH = max(280, GetScreenWidth() - leftSlotWidth() - rightSlotWidth());
        }
        ~ScopedPropertyWidth() { PROPERTY_WIDTH = previous; }
    } scopedPropertyWidth;

    int propertyX = getPropertyX();
    EditorThemeColors theme = getEditorThemeColors();

    // Panel starts flush under the window bar (no gap under chrome).
    const int panelTop = EDITOR_CONTENT_TOP;
    const int headerH = 34;
    DrawRectangle(propertyX, panelTop, PROPERTY_WIDTH, GetScreenHeight() - panelTop, theme.panel);
    DrawRectangle(propertyX, panelTop, PROPERTY_WIDTH, headerH, theme.header);

    DockSlotState* propertySlot = dockSlotContaining(DockPanelKind::Properties);
    if (propertySlot != nullptr)
    {
        int clickedTab = renderDockHeaderTabs(*propertySlot, propertyX + 6, panelTop + 5, 24,
            theme.surface, theme.header);
        if (clickedTab != -1)
            propertySlot->activeTab = clickedTab;
    }
    if (isZoneFocused(FocusZone::Properties))
        DrawRectangle(propertyX, panelTop + headerH - 2, PROPERTY_WIDTH, 2, theme.accent);

    // Title stays inside the header (was y=79 — overlaid the window bar)
    if (propertySlot == nullptr || propertySlot->stack.size() < 2)
        DrawText(PROPERTY_WIDTH > 40 ? "Properties" : "+", propertyX + (PROPERTY_WIDTH > 40 ? 12 : 7), panelTop + 8, 18, theme.text);
    if (PROPERTY_WIDTH > 40)
    {
        DrawRectangle(propertyX + PROPERTY_WIDTH - 28, panelTop + 7, 22, 20, theme.surface);
        DrawText("-", propertyX + PROPERTY_WIDTH - 21, panelTop + 7, 16, theme.text);
    }
    else
        return;

    // Everything below was originally written assuming the panel is pinned
    // at screen x=0. Rather than touch every literal offset in this large
    // block, we shift the whole thing with a transform so it lands at
    // `propertyX` regardless of which edge the panel is currently docked to.
    // (Scissor rects ignore the transform stack, so that one call below is
    // given the real x explicitly.)
    rlPushMatrix();
    rlTranslatef(static_cast<float>(propertyX), 0.0f, 0.0f);

    Instance* instance = selectedInstances.empty() ? nullptr : selectedInstances.front();
    vector<PropertyRow> rows = getMergedPropertyRows(selectedInstances);
    const int rowHeight = ui(42);
    // Content starts under the 34px header (EDITOR_CONTENT_TOP + 34)
    const int contentTop = EDITOR_CONTENT_TOP + 46;
    const int contentHeight = GetScreenHeight() - contentTop - PROPERTY_SCROLLBAR_SIZE;
    int contentWidth = ui(390);
    for (const PropertyRow& row : rows)
        contentWidth = max(contentWidth, getPropertyValueX(row, 0.0f) + 255);
    int totalHeight = 0;
    for (const auto& r : rows)
        totalHeight += (r.kind == PropertyKind::SoundPreview) ? 56 : rowHeight;
    float maxScrollY = max(0, totalHeight - contentHeight);
    float maxScrollX = max(0, contentWidth - (PROPERTY_WIDTH - PROPERTY_SCROLLBAR_SIZE));
    propertyScrollY = std::clamp(propertyScrollY, 0.0f, static_cast<float>(maxScrollY));
    propertyScrollX = std::clamp(propertyScrollX, 0.0f, static_cast<float>(maxScrollX));

    BeginScissorMode(propertyX, contentTop, PROPERTY_WIDTH - PROPERTY_SCROLLBAR_SIZE,
        contentHeight);
    if (selectedInstances.empty())
    {
        DrawText("Select an instance", 12, contentTop + 14, 16, theme.muted);
    }
    else
    {
        if (selectedInstances.size() > 1)
            DrawText(TextFormat("%d instances selected", (int)selectedInstances.size()),
                12, contentTop - 18, 13, theme.muted);

        // Variable row heights so SoundPreview can sit inline with other properties
        int yCursor = contentTop - static_cast<int>(propertyScrollY);
        for (int index = 0; index < static_cast<int>(rows.size()); ++index)
        {
            int thisH = (rows[index].kind == PropertyKind::SoundPreview) ? 56 : rowHeight;
            int y = yCursor;
            DrawLine(0, y + thisH - 1, contentWidth, y + thisH - 1, theme.border);

            int nameX = 10 - static_cast<int>(propertyScrollX);
            // Expand/collapse triangle for Packed headers
            if (rows[index].kind == PropertyKind::Packed)
            {
                bool open = propertyPackedExpanded.count(rows[index].packId) > 0;
                int triX = nameX;
                int triY = y + thisH / 2;
                if (open)
                {
                    // down-pointing
                    DrawTriangle(
                        (Vector2){ (float)triX, (float)(triY - 4) },
                        (Vector2){ (float)(triX + 10), (float)(triY - 4) },
                        (Vector2){ (float)(triX + 5), (float)(triY + 5) },
                        (Color){ 180, 190, 205, 255 });
                }
                else
                {
                    // right-pointing
                    DrawTriangle(
                        (Vector2){ (float)triX, (float)(triY - 5) },
                        (Vector2){ (float)triX, (float)(triY + 5) },
                        (Vector2){ (float)(triX + 9), (float)triY },
                        (Color){ 180, 190, 205, 255 });
                }
                nameX += 14;
            }
            else if (rows[index].kind == PropertyKind::PackedField)
            {
                nameX += 18; // indent components
            }
            DrawText(rows[index].name.c_str(), nameX, y + 5, uiFont(15), theme.text);

            int valueX = getPropertyValueX(rows[index], propertyScrollX);
            if (rows[index].kind == PropertyKind::Packed)
            {
                // Compact packed display (not editable as free text — expand to edit fields)
                DrawRectangleRounded({ (float)valueX, (float)y + 4, 235, 28 }, 0.16f, 6, theme.canvas);
                DrawRectangleRoundedLines({ (float)valueX, (float)y + 4, 235, 28 }, 0.16f, 6, theme.border);
                DrawText(rows[index].packCompact.c_str(), valueX + 7, y + 9, uiFont(14), theme.text);
            }
            else if (rows[index].kind == PropertyKind::SoundPreview)
            {
                if (instance->getType() == InstanceType::Sound)
                {
                    // Absolute coords: panel is translated by propertyX
                    // Under rlTranslatef(propertyX) — use local X
                    renderSoundSampleBar(static_cast<SoundInstance*>(instance),
                        valueX, y, PROPERTY_WIDTH - valueX - 20);
                }
            }
            else if (rows[index].kind == PropertyKind::Boolean)
            {
                bool checked = rows[index].value == "true";
                DrawRectangleRounded({ (float)valueX, (float)y + 7, 22, 22 }, 0.2f, 6,
                    checked ? (Color){ 225, 230, 238, 255 } : (Color){ 65, 72, 82, 255 });
                DrawRectangleRoundedLines({ (float)valueX, (float)y + 7, 22, 22 }, 0.2f, 6,
                    (Color){ 140, 150, 165, 255 });
                if (checked)
                {
                    DrawLine(valueX + 5, y + 18, valueX + 10, y + 23, DARKGRAY);
                    DrawLine(valueX + 10, y + 23, valueX + 18, y + 12, DARKGRAY);
                }
            }
            else if (rows[index].kind == PropertyKind::Enum)
            {
                // Enum shows current value + dropdown chevron (list opens on click)
                Color boxColor = (propertyEnumDropdownOpen && propertyEnumDropdownRow == index)
                    ? theme.selected : theme.surface;
                DrawRectangleRounded({ (float)valueX, (float)y + 4, 235, 28 }, 0.16f, 6, boxColor);
                DrawRectangleRoundedLines({ (float)valueX, (float)y + 4, 235, 28 }, 0.16f, 6, theme.border);
                DrawText(rows[index].value.c_str(), valueX + 7, y + 9, uiFont(14), theme.text);
                DrawText("▼", valueX + 210, y + 9, uiFont(12), theme.muted);
            }
            else if (rows[index].kind == PropertyKind::InstanceRef)
            {
                DrawRectangleRounded({ (float)valueX, (float)y + 4, 235, 28 }, 0.16f, 6, theme.surface);
                DrawRectangleRoundedLines({ (float)valueX, (float)y + 4, 235, 28 }, 0.16f, 6, theme.border);
                Instance* target = getPointerPropertyTarget(instance, rows[index].name);
                if (selectedInstances.size() > 1 && rows[index].value.empty())
                    target = nullptr;
                int textX = valueX + 7;
                if (target != nullptr)
                {
                    Texture2D icon = getInstanceIcon(target);
                    drawEditorIcon(icon, (float)textX, (float)y + 8, 20.0f, 20.0f,
                        getStudioInstanceIconTint(getInstanceIconColorKey(target), getInstanceIconGroup(target)));
                    textX += 24;
                }
                string value = rows[index].value.empty() ? "None" : rows[index].value;
                if (pointerPickOwner == instance && pointerPickProperty == rows[index].name)
                    value = "Click a target...";
                DrawText(value.c_str(), textX, y + 9, uiFont(14), target != nullptr ? theme.text : theme.muted);
                if (rows[index].name != "Parent")
                {
                    Rectangle clearButton = getPointerClearButtonRect(valueX, y);
                    DrawRectangleRec(clearButton, (Color){ 75, 34, 39, 255 });
                    DrawRectangleLinesEx(clearButton, 1.0f, (Color){ 150, 55, 62, 255 });
                    DrawLine((int)clearButton.x + 6, (int)clearButton.y + 6,
                        (int)clearButton.x + 14, (int)clearButton.y + 14, (Color){ 255, 90, 95, 255 });
                    DrawLine((int)clearButton.x + 14, (int)clearButton.y + 6,
                        (int)clearButton.x + 6, (int)clearButton.y + 14, (Color){ 255, 90, 95, 255 });
                }
            }
            else if (rows[index].kind == PropertyKind::Color)
            {
                Color* color = getPropertyColorTarget(instance, rows[index].name);
                Color displayColor = color != nullptr ? *color : WHITE;
                Rectangle colorSwatch = { (float)valueX, (float)y + 7, 38, 24 };
                Rectangle rgbValue = { (float)valueX + 44, (float)y + 5, 138, 28 };
                Rectangle copyValue = { (float)valueX + 186, (float)y + 5, 45, 28 };
                DrawRectangleRounded(colorSwatch, 0.24f, 6, displayColor);
                DrawRectangleRoundedLines(colorSwatch, 0.24f, 6, theme.border);
                DrawRectangleRounded(rgbValue, 0.18f, 6, theme.surface);
                DrawText(TextFormat("%d, %d, %d", displayColor.r, displayColor.g, displayColor.b),
                    (int)rgbValue.x + 7, (int)rgbValue.y + 7, uiFont(13), theme.text);
                DrawRectangleRounded(copyValue, 0.18f, 6, theme.surface);
                DrawText("Copy", (int)copyValue.x + 7, (int)copyValue.y + 7, uiFont(13), theme.muted);
            }
            else
            {
                Color boxColor = activePropertyRow == index ? theme.selected : theme.surface;
                DrawRectangleRounded({ (float)valueX, (float)y + 4, 235, 28 }, 0.16f, 6, boxColor);
                DrawRectangleRoundedLines({ (float)valueX, (float)y + 4, 235, 28 }, 0.16f, 6, theme.border);
                string value = activePropertyRow == index ? propertyEditText : rows[index].value;
                if (pointerPickOwner == instance && pointerPickProperty == rows[index].name)
                    value = "Click a target...";
                DrawText(value.c_str(), valueX + 7, y + 9, uiFont(14), theme.text);
                // Smooth blinking caret (same cadence as script editor)
                if (activePropertyRow == index && isZoneFocused(FocusZone::Properties) &&
                    fmod(GetTime() - propertyCaretResetTime, 1.0) < 0.5)
                {
                    int cursor = std::clamp(propertyEditCursor, 0, (int)propertyEditText.size());
                    string before = propertyEditText.substr(0, (size_t)cursor);
                    int caretX = valueX + 7 + MeasureText(before.c_str(), uiFont(14));
                    DrawRectangle(caretX, y + 6, 2, 24, SKYBLUE);
                }
            }
            yCursor += thisH;
        }
    }
    EndScissorMode();

    Rectangle verticalTrack = { static_cast<float>(PROPERTY_WIDTH - PROPERTY_SCROLLBAR_SIZE), static_cast<float>(contentTop),
        static_cast<float>(PROPERTY_SCROLLBAR_SIZE), static_cast<float>(contentHeight) };
    DrawRectangleRec(verticalTrack, theme.canvas);
    float thumbHeight = maxScrollY > 0.0f
        ? scrollbarThumbSize(static_cast<float>(contentHeight), maxScrollY)
        : static_cast<float>(contentHeight);
    DrawRectangle(static_cast<int>(verticalTrack.x), static_cast<int>(verticalTrack.y + (maxScrollY > 0.0f ? propertyScrollY / maxScrollY * (contentHeight - thumbHeight) : 0)), PROPERTY_SCROLLBAR_SIZE, static_cast<int>(thumbHeight), (Color){ 112, 123, 140, 255 });

    Rectangle horizontalTrack = { 0, static_cast<float>(GetScreenHeight() - PROPERTY_SCROLLBAR_SIZE),
        static_cast<float>(PROPERTY_WIDTH - PROPERTY_SCROLLBAR_SIZE), static_cast<float>(PROPERTY_SCROLLBAR_SIZE) };
    DrawRectangleRec(horizontalTrack, (Color){ 22, 25, 30, 255 });
    if (maxScrollX > 0.0f)
    {
        float thumbWidth = scrollbarThumbSize(horizontalTrack.width, maxScrollX);
        DrawRectangle(static_cast<int>(propertyScrollX / maxScrollX * (horizontalTrack.width - thumbWidth)),
            static_cast<int>(horizontalTrack.y), static_cast<int>(thumbWidth), PROPERTY_SCROLLBAR_SIZE, (Color){ 112, 123, 140, 255 });
    }

    if (propertyColorPickerOpen)
    {
        rlPopMatrix();
        drawPropertyColorPickerOverlay();
        rlPushMatrix();
        rlTranslatef(static_cast<float>(propertyX), 0.0f, 0.0f);
    }

    // Enum options dropdown (drawn above rows, clipped to panel)
    if (propertyEnumDropdownOpen && instance != nullptr &&
        propertyEnumDropdownRow >= 0 && !propertyEnumDropdownOptions.empty())
    {
        vector<PropertyRow> rows = getPropertyRows(instance);
        if (propertyEnumDropdownRow < static_cast<int>(rows.size()))
        {
            // Approximate Y of the active enum row
            int yCursor = contentTop - static_cast<int>(propertyScrollY);
            for (int i = 0; i < propertyEnumDropdownRow && i < static_cast<int>(rows.size()); ++i)
                yCursor += (rows[i].kind == PropertyKind::SoundPreview) ? 56 : rowHeight;
            int valueX = getPropertyValueX(rows[propertyEnumDropdownRow], propertyScrollX);
            int listH = static_cast<int>(propertyEnumDropdownOptions.size()) * 26 + 4;
            int listY = yCursor + rowHeight;
            DrawRectangle(valueX, listY, 235, listH, theme.panel);
            DrawRectangleLines(valueX, listY, 235, listH, theme.border);
            Vector2 mouseLocal = GetMousePosition();
            mouseLocal.x -= propertyX;
            for (int i = 0; i < static_cast<int>(propertyEnumDropdownOptions.size()); ++i)
            {
                int oy = listY + 2 + i * 26;
                Rectangle opt = { (float)valueX, (float)oy, 235, 26 };
                bool hover = CheckCollisionPointRec(mouseLocal, opt);
                if (hover) propertyEnumDropdownHover = i;
                if (hover || propertyEnumDropdownOptions[i] == rows[propertyEnumDropdownRow].value)
                    DrawRectangleRec(opt, hover ? theme.accent : theme.surface);
                DrawText(propertyEnumDropdownOptions[i].c_str(), valueX + 8, oy + 5, uiFont(14), theme.text);
            }
        }
    }

    rlPopMatrix();
}

void handlePropertyPanelInput()
{
    static vector<Instance*> previousSelection;
    if (previousSelection != selectedInstances)
    {
        cancelPropertyEdit();
        previousSelection = selectedInstances;
    }

    if (!isDockPanelActiveTab(DockPanelKind::Properties) && !propertyColorPickerOpen)
        return;

    struct ScopedPropertyWidth
    {
        int previous;
        ScopedPropertyWidth() : previous(PROPERTY_WIDTH)
        {
            if (activeWindow == WindowType::PropertiesView)
                PROPERTY_WIDTH = max(280, GetScreenWidth() - leftSlotWidth() - rightSlotWidth());
        }
        ~ScopedPropertyWidth() { PROPERTY_WIDTH = previous; }
    } scopedPropertyWidth;

    Vector2 mouse = GetMousePosition();
    if (mouse.y < EDITOR_CONTENT_TOP && !propertyColorPickerOpen)
        return;

    int propertyX = getPropertyX();
    if (mouse.x >= propertyX && mouse.x < propertyX + PROPERTY_WIDTH &&
        (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) || IsMouseButtonPressed(MOUSE_BUTTON_RIGHT) ||
         IsMouseButtonPressed(MOUSE_BUTTON_MIDDLE)))
        focusedZone = FocusZone::Properties;

    bool onLeft = isDockPanelOnLeft(DockPanelKind::Properties);

    if (onLeft)
    {
        if (mouse.x >= propertyX + PROPERTY_WIDTH - 5 && mouse.x <= propertyX + PROPERTY_WIDTH + 5 && PROPERTY_WIDTH > 40)
        {
            if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
                propertyResizing = true;
            if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && propertyResizing)
                PROPERTY_WIDTH = std::clamp(static_cast<int>(mouse.x) - propertyX, 24, max(24, GetScreenWidth() - 24));
        }
    }
    else if (mouse.x >= propertyX - 5 && mouse.x <= propertyX + 5 && PROPERTY_WIDTH > 40)
    {
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
            propertyResizing = true;
        if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && propertyResizing)
            PROPERTY_WIDTH = std::clamp(GetScreenWidth() - static_cast<int>(mouse.x), 24, max(24, GetScreenWidth() - 24));
    }
    if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
        propertyResizing = false;

    if (mouse.x >= propertyX && mouse.x < propertyX + PROPERTY_WIDTH && mouse.y >= EDITOR_CONTENT_TOP && mouse.y < EDITOR_CONTENT_TOP + 34 &&
        IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
    {
        if (PROPERTY_WIDTH > 40 && mouse.x >= propertyX + PROPERTY_WIDTH - 34)
        {
            PROPERTY_WIDTH = 24;
            return;
        }
        if (PROPERTY_WIDTH <= 40)
        {
            PROPERTY_WIDTH = 280;
            return;
        }

        DockSlotState* slot = dockSlotContaining(DockPanelKind::Properties);
        if (slot != nullptr && slot->stack.size() > 1)
        {
            // Stacked tab strip: hit-test each tab and drag THAT panel
            const int tabWidth = 96;
            const int tabY = 108;
            const int tabH = 24;
            int baseX = propertyX + 6;
            bool hitTab = false;
            for (size_t i = 0; i < slot->stack.size(); ++i)
            {
                int tabX = baseX + static_cast<int>(i) * (tabWidth + 4);
                Rectangle tabRect = {
                    static_cast<float>(tabX), static_cast<float>(tabY),
                    static_cast<float>(tabWidth), static_cast<float>(tabH)
                };
                if (CheckCollisionPointRec(mouse, tabRect))
                {
                    slot->activeTab = static_cast<int>(i);
                    beginDockDrag(slot->stack[i], mouse);
                    hitTab = true;
                    break;
                }
            }
            if (!hitTab)
                beginDockDrag(DockPanelKind::Properties, mouse); // empty header chrome
        }
        else
            beginDockDrag(DockPanelKind::Properties, mouse);
        return;
    }

    if (dockDragActive && dockDragPanel == DockPanelKind::Properties)
        return;

    if ((mouse.x < propertyX || mouse.x >= propertyX + PROPERTY_WIDTH) && !propertyColorPickerOpen)
        return;

    Instance* instance = selectedInstances.empty() ? nullptr : selectedInstances.front();
    vector<PropertyRow> rows = getMergedPropertyRows(selectedInstances);
    int contentTop = EDITOR_CONTENT_TOP + ui(48);
    int contentHeight = GetScreenHeight() - contentTop - PROPERTY_SCROLLBAR_SIZE;
    int totalHeight = 0;
    for (const auto& r : rows)
        totalHeight += (r.kind == PropertyKind::SoundPreview) ? 56 : ui(42);
    int contentWidth = ui(390);
    float maxScrollY = max(0, totalHeight - contentHeight);
    float maxScrollX = max(0, contentWidth - (PROPERTY_WIDTH - PROPERTY_SCROLLBAR_SIZE));

    Rectangle verticalTrack = { static_cast<float>(PROPERTY_WIDTH - PROPERTY_SCROLLBAR_SIZE), static_cast<float>(contentTop),
        static_cast<float>(PROPERTY_SCROLLBAR_SIZE), static_cast<float>(contentHeight) };
    Rectangle horizontalTrack = { 0, static_cast<float>(GetScreenHeight() - PROPERTY_SCROLLBAR_SIZE),
        static_cast<float>(PROPERTY_WIDTH - PROPERTY_SCROLLBAR_SIZE), static_cast<float>(PROPERTY_SCROLLBAR_SIZE) };
    Vector2 localMouse = mouse;
    localMouse.x -= propertyX;
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(localMouse, verticalTrack) && maxScrollY > 0.0f)
        propertyDraggingScrollY = true;
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(localMouse, horizontalTrack) && maxScrollX > 0.0f)
        propertyDraggingScrollX = true;
    if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && propertyDraggingScrollY)
    {
        float thumbH = scrollbarThumbSize(static_cast<float>(contentHeight), maxScrollY);
        propertyScrollY = scrollbarScrollFromMouse(localMouse.y, static_cast<float>(contentTop),
            static_cast<float>(contentHeight), thumbH, maxScrollY);
    }
    if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && propertyDraggingScrollX)
    {
        float trackW = static_cast<float>(PROPERTY_WIDTH - PROPERTY_SCROLLBAR_SIZE);
        float thumbW = scrollbarThumbSize(trackW, maxScrollX);
        propertyScrollX = scrollbarScrollFromMouse(localMouse.x, 0.0f, trackW, thumbW, maxScrollX);
    }
    if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
    {
        propertyDraggingScrollX = false;
        propertyDraggingScrollY = false;
    }
    if (activePropertyRow >= 0 && instance != nullptr && isZoneFocused(FocusZone::Properties) &&
        !propertyColorPickerOpen)
    {
        auto resetCaretBlink = [&]() { propertyCaretResetTime = GetTime(); };
        if (IsKeyPressed(KEY_ENTER))
        {
            // Only commit if the user typed something; empty keeps the old value.
            if (!propertyEditText.empty())
                applyPropertyTextToSelection(activePropertyRow, propertyEditText);
            activePropertyRow = -1;
            propertyEditText.clear();
            propertyEditCursor = 0;
        }
        else if (IsKeyPressed(KEY_ESCAPE))
            cancelPropertyEdit();
        else if (IsKeyPressed(KEY_BACKSPACE) && propertyEditCursor > 0)
        {
            propertyEditText.erase(propertyEditCursor - 1, 1);
            propertyEditCursor--;
            resetCaretBlink();
        }
        else if (IsKeyPressed(KEY_DELETE) && propertyEditCursor < (int)propertyEditText.size())
        {
            propertyEditText.erase(propertyEditCursor, 1);
            resetCaretBlink();
        }
        else if (IsKeyPressed(KEY_LEFT))
        {
            propertyEditCursor = max(0, propertyEditCursor - 1);
            resetCaretBlink();
        }
        else if (IsKeyPressed(KEY_RIGHT))
        {
            propertyEditCursor = min(static_cast<int>(propertyEditText.size()), propertyEditCursor + 1);
            resetCaretBlink();
        }
        else if (IsKeyPressed(KEY_HOME))
        {
            propertyEditCursor = 0;
            resetCaretBlink();
        }
        else if (IsKeyPressed(KEY_END))
        {
            propertyEditCursor = (int)propertyEditText.size();
            resetCaretBlink();
        }

        bool ctrl = IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL);
        int codepoint = GetCharPressed();
        while (codepoint > 0)
        {
            if (!ctrl && codepoint >= 32 && codepoint <= 126)
            {
                propertyEditText.insert(propertyEditCursor, 1, static_cast<char>(codepoint));
                propertyEditCursor++;
                resetCaretBlink();
            }
            codepoint = GetCharPressed();
        }
    }
    if (propertyColorPickerOpen)
    {
        const int pickerWidth = 340;
        const int pickerHeight = 470;
        Rectangle titleBar = { propertyColorPickerBounds.x, propertyColorPickerBounds.y,
            propertyColorPickerBounds.width, 38.0f };
        Rectangle closeButton = { titleBar.x + titleBar.width - 34.0f, titleBar.y + 6.0f, 24.0f, 24.0f };
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, closeButton))
        {
            propertyColorPickerOpen = false;
            propertyColorRgbEditing = false;
            propertyColorRgbSelectAll = false;
            if (propertyPickerExternalTarget != nullptr)
                saveStudioSettings();
            propertyPickerExternalTarget = nullptr;
            if (activePropertyRow >= 0)
                activePropertyRow = -1;
            return;
        }
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, titleBar) &&
            !CheckCollisionPointRec(mouse, closeButton))
        {
            floatingPropertyColorDrag = true;
            floatingDragOffset = { mouse.x - floatingPropertyColorPos.x, mouse.y - floatingPropertyColorPos.y };
        }
        if (floatingPropertyColorDrag)
        {
            if (IsMouseButtonDown(MOUSE_BUTTON_LEFT))
            {
                floatingPropertyColorPos.x = Clamp(mouse.x - floatingDragOffset.x, 0.0f,
                    max(0.0f, static_cast<float>(GetScreenWidth() - pickerWidth)));
                floatingPropertyColorPos.y = Clamp(mouse.y - floatingDragOffset.y, 0.0f,
                    max(0.0f, static_cast<float>(GetScreenHeight() - pickerHeight)));
            }
            else
                floatingPropertyColorDrag = false;
            return;
        }
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && !CheckCollisionPointRec(mouse, propertyColorPickerBounds))
        {
            propertyColorPickerOpen = false;
            propertyColorRgbEditing = false;
            propertyColorRgbSelectAll = false;
            if (propertyPickerExternalTarget != nullptr)
                saveStudioSettings();
            propertyPickerExternalTarget = nullptr;
            if (activePropertyRow >= 0)
            {
                activePropertyRow = -1;
                propertyEditText.clear();
                propertyEditCursor = 0;
            }
            return;
        }
        Color* selectedColor = propertyPickerExternalTarget;
        if (instance != nullptr && activePropertyRow >= 0 && activePropertyRow < static_cast<int>(rows.size()))
            selectedColor = getPropertyColorTarget(instance, rows[activePropertyRow].name);
        if (propertyColorRgbEditing && selectedColor != nullptr)
        {
            if (IsKeyPressed(KEY_ENTER))
                propertyColorRgbEditing = false;
            bool ctrl = IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL);
            if (ctrl && IsKeyPressed(KEY_A))
            {
                propertyColorRgbSelectAll = true;
                propertyColorRgbCursor = static_cast<int>(propertyColorRgbText.size());
            }
            if (ctrl && IsKeyPressed(KEY_C))
                SetClipboardText(propertyColorRgbText.c_str());
            if (ctrl && IsKeyPressed(KEY_V))
            {
                const char* clipboard = GetClipboardText();
                if (clipboard != nullptr)
                {
                    if (propertyColorRgbSelectAll)
                    {
                        propertyColorRgbText.clear();
                        propertyColorRgbCursor = 0;
                    }
                    for (const char* ch = clipboard; *ch != '\0' && propertyColorRgbText.size() < 24; ++ch)
                        if ((*ch >= '0' && *ch <= '9') || *ch == ',' || *ch == ' ' || *ch == '(' || *ch == ')')
                            propertyColorRgbText.insert(propertyColorRgbCursor++, 1, *ch);
                    propertyColorRgbSelectAll = false;
                }
            }
            if (IsKeyPressed(KEY_BACKSPACE))
            {
                if (propertyColorRgbSelectAll)
                {
                    propertyColorRgbText.clear();
                    propertyColorRgbCursor = 0;
                }
                else if (propertyColorRgbCursor > 0)
                {
                    propertyColorRgbText.erase(--propertyColorRgbCursor, 1);
                }
                propertyColorRgbSelectAll = false;
            }
            if (IsKeyPressed(KEY_DELETE))
            {
                if (propertyColorRgbSelectAll)
                {
                    propertyColorRgbText.clear();
                    propertyColorRgbCursor = 0;
                }
                else if (propertyColorRgbCursor < static_cast<int>(propertyColorRgbText.size()))
                    propertyColorRgbText.erase(propertyColorRgbCursor, 1);
                propertyColorRgbSelectAll = false;
            }
            if (IsKeyPressed(KEY_LEFT))
            {
                propertyColorRgbCursor = max(0, propertyColorRgbCursor - 1);
                propertyColorRgbSelectAll = false;
            }
            if (IsKeyPressed(KEY_RIGHT))
            {
                propertyColorRgbCursor = min(static_cast<int>(propertyColorRgbText.size()), propertyColorRgbCursor + 1);
                propertyColorRgbSelectAll = false;
            }
            if (IsKeyPressed(KEY_HOME))
            {
                propertyColorRgbCursor = 0;
                propertyColorRgbSelectAll = false;
            }
            if (IsKeyPressed(KEY_END))
            {
                propertyColorRgbCursor = static_cast<int>(propertyColorRgbText.size());
                propertyColorRgbSelectAll = false;
            }
            int codepoint = GetCharPressed();
            while (codepoint > 0)
            {
                if (!ctrl && propertyColorRgbText.size() < 24 &&
                    ((codepoint >= '0' && codepoint <= '9') || codepoint == ',' ||
                     codepoint == ' ' || codepoint == '(' || codepoint == ')'))
                {
                    if (propertyColorRgbSelectAll)
                    {
                        propertyColorRgbText.clear();
                        propertyColorRgbCursor = 0;
                        propertyColorRgbSelectAll = false;
                    }
                    propertyColorRgbText.insert(propertyColorRgbCursor++, 1, static_cast<char>(codepoint));
                }
                codepoint = GetCharPressed();
            }
            propertyColorRgbCursor = std::clamp(propertyColorRgbCursor, 0, static_cast<int>(propertyColorRgbText.size()));
            int red = 0, green = 0, blue = 0;
            char trailing = '\0';
            if (std::sscanf(propertyColorRgbText.c_str(), " ( %d , %d , %d ) %c", &red, &green, &blue, &trailing) == 3 ||
                std::sscanf(propertyColorRgbText.c_str(), " %d , %d , %d %c", &red, &green, &blue, &trailing) == 3)
            {
                if (red >= 0 && red <= 255 && green >= 0 && green <= 255 && blue >= 0 && blue <= 255)
                {
                    *selectedColor = { (unsigned char)red, (unsigned char)green, (unsigned char)blue, 255 };
                    propertyPickerColor = *selectedColor;
                    Vector3 hsv = ColorToHSV(*selectedColor);
                    propertyPickerHue = hsv.x;
                    propertyPickerSaturation = hsv.y;
                    propertyPickerValue = hsv.z;
                    projectDirty = propertyPickerExternalTarget == nullptr;
                }
            }
        }
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, propertyColorPickerBounds))
        {
            Rectangle rgbField = { propertyColorPickerBounds.x + 52, propertyColorPickerBounds.y + 394, 188, 30 };
            Rectangle copyButton = { propertyColorPickerBounds.x + 250, propertyColorPickerBounds.y + 394, 76, 30 };
            if (CheckCollisionPointRec(mouse, rgbField))
            {
                propertyColorRgbEditing = true;
                propertyColorRgbCursor = static_cast<int>(propertyColorRgbText.size());
                propertyColorRgbSelectAll = false;
                propertyCaretResetTime = GetTime();
            }
            else if (CheckCollisionPointRec(mouse, copyButton))
            {
                if (selectedColor != nullptr)
                    SetClipboardText(TextFormat("%d, %d, %d", selectedColor->r, selectedColor->g, selectedColor->b));
                propertyColorRgbEditing = false;
            }
        }
        if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && CheckCollisionPointRec(mouse, propertyColorPickerBounds) &&
            (instance != nullptr || propertyPickerExternalTarget != nullptr))
        {
            if (selectedColor == nullptr)
                return;
            int pickerX = static_cast<int>(propertyColorPickerBounds.x);
            int pickerY = static_cast<int>(propertyColorPickerBounds.y);
            if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
            {
                const Color basicColors[] = {
                    WHITE, BLACK, RED, ORANGE, YELLOW, GREEN, BLUE, PURPLE,
                    PINK, MAGENTA, (Color){ 0, 220, 220, 255 }, (Color){ 145, 155, 170, 255 }
                };
                for (int index = 0; index < 12; ++index)
                {
                    Rectangle swatch = { (float)pickerX + 14 + (index % 6) * 46,
                        (float)pickerY + 70 + (index / 6) * 28, 36, 22 };
                    if (CheckCollisionPointRec(mouse, swatch))
                    {
                        *selectedColor = basicColors[index];
                        propertyPickerColor = *selectedColor;
                        Vector3 hsv = ColorToHSV(*selectedColor);
                        propertyPickerHue = hsv.x;
                        propertyPickerSaturation = hsv.y;
                        propertyPickerValue = hsv.z;
                        projectDirty = propertyPickerExternalTarget == nullptr;
                    }
                }
                Rectangle saveSlot = { (float)pickerX + 170, (float)pickerY + 124, 156, 24 };
                if (CheckCollisionPointRec(mouse, saveSlot))
                {
                    studioSettings.colorSlots[propertyColorSavedSlotSelection] = *selectedColor;
                    studioSettings.colorSlotUsed[propertyColorSavedSlotSelection] = true;
                    saveStudioSettings();
                }
                for (int index = 0; index < 12; ++index)
                {
                    Rectangle slot = { (float)pickerX + 14 + (index % 6) * 46,
                        (float)pickerY + 150 + (index / 6) * 26, 36, 20 };
                    if (!CheckCollisionPointRec(mouse, slot))
                        continue;
                    propertyColorSavedSlotSelection = index;
                    if (!studioSettings.colorSlotUsed[index])
                        continue;
                    *selectedColor = studioSettings.colorSlots[index];
                    propertyPickerColor = *selectedColor;
                    Vector3 hsv = ColorToHSV(*selectedColor);
                    propertyPickerHue = hsv.x;
                    propertyPickerSaturation = hsv.y;
                    propertyPickerValue = hsv.z;
                    projectDirty = propertyPickerExternalTarget == nullptr;
                }
            }
            if (mouse.x >= pickerX + 14 && mouse.x <= pickerX + 274 &&
                mouse.y >= pickerY + 222 && mouse.y <= pickerY + 322)
            {
                propertyPickerSaturation = std::clamp((mouse.x - pickerX - 14) / 259.0f, 0.0f, 1.0f);
                propertyPickerValue = 1.0f - std::clamp((mouse.y - pickerY - 222) / 99.0f, 0.0f, 1.0f);
                propertyPickerColor = ColorFromHSV(propertyPickerHue, propertyPickerSaturation, propertyPickerValue);
                *selectedColor = propertyPickerColor;
                projectDirty = propertyPickerExternalTarget == nullptr;
            }
            if (mouse.x >= pickerX + 286 && mouse.x <= pickerX + 308 &&
                mouse.y >= pickerY + 222 && mouse.y <= pickerY + 322)
            {
                propertyPickerHue = std::clamp((mouse.y - pickerY - 222) / 100.0f, 0.0f, 1.0f) * 360.0f;
                propertyPickerColor = ColorFromHSV(propertyPickerHue, propertyPickerSaturation, propertyPickerValue);
                *selectedColor = propertyPickerColor;
                projectDirty = propertyPickerExternalTarget == nullptr;
            }
            if (selectedColor != nullptr && !propertyColorRgbEditing)
                propertyColorRgbText = TextFormat("%d, %d, %d", selectedColor->r, selectedColor->g, selectedColor->b);
            if (propertyColorRgbEditing == false &&
                mouse.x >= pickerX + 14 && mouse.x <= pickerX + 274 &&
                mouse.y >= pickerY + 222 && mouse.y <= pickerY + 322)
                projectDirty = propertyPickerExternalTarget == nullptr;
            if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && mouse.x >= pickerX + 250 && mouse.y >= pickerY + 394)
            {
                if (mouse.x <= pickerX + 326 && mouse.y <= pickerY + 424)
                    SetClipboardText(TextFormat("%d, %d, %d", selectedColor->r, selectedColor->g, selectedColor->b));
            }
        }
        if (CheckCollisionPointRec(mouse, propertyColorPickerBounds))
            return;
    }

    float wheel = isZoneFocused(FocusZone::Properties) ? GetMouseWheelMove() : 0.0f;
    if (wheel != 0.0f)
    {
        bool shift = IsKeyDown(KEY_LEFT_SHIFT) || IsKeyDown(KEY_RIGHT_SHIFT);
        float& scroll = shift ? propertyScrollX : propertyScrollY;
        scroll = max(0.0f, scroll - wheel * 45.0f);
    }

    if (!IsMouseButtonPressed(MOUSE_BUTTON_LEFT) || instance == nullptr)
        return;

    // Handle open Enum dropdown selection first
    if (propertyEnumDropdownOpen && propertyEnumDropdownRow >= 0 &&
        !propertyEnumDropdownOptions.empty())
    {
        vector<PropertyRow> erows = getMergedPropertyRows(selectedInstances);
        if (propertyEnumDropdownRow < static_cast<int>(erows.size()))
        {
            int yCursor = contentTop - static_cast<int>(propertyScrollY);
            for (int i = 0; i < propertyEnumDropdownRow && i < static_cast<int>(erows.size()); ++i)
                yCursor += (erows[i].kind == PropertyKind::SoundPreview) ? 56 : ui(42);
            int valueX = propertyX + getPropertyValueX(erows[propertyEnumDropdownRow], propertyScrollX);
            int listY = yCursor + ui(42);
            for (int i = 0; i < static_cast<int>(propertyEnumDropdownOptions.size()); ++i)
            {
                Rectangle opt = { (float)valueX, (float)(listY + 2 + i * 26), 235, 26 };
                if (CheckCollisionPointRec(mouse, opt))
                {
                    applyPropertyTextToSelection(propertyEnumDropdownRow, propertyEnumDropdownOptions[i]);
                    propertyEnumDropdownOpen = false;
                    propertyEnumDropdownRow = -1;
                    propertyEnumDropdownOptions.clear();
                    activePropertyRow = -1;
                    return;
                }
            }
        }
        // Click outside closes dropdown without applying
        propertyEnumDropdownOpen = false;
        propertyEnumDropdownRow = -1;
        propertyEnumDropdownOptions.clear();
        return;
    }

    if (mouse.y < contentTop || mouse.y >= contentTop + contentHeight)
        return;
    // Variable-height rows (SoundPreview is taller)
    float localY = mouse.y - contentTop + propertyScrollY;
    int rowIndex = -1;
    float acc = 0.0f;
    for (int i = 0; i < static_cast<int>(rows.size()); ++i)
    {
        float h = (rows[i].kind == PropertyKind::SoundPreview) ? 56.0f : static_cast<float>(ui(42));
        if (localY >= acc && localY < acc + h)
        {
            rowIndex = i;
            break;
        }
        acc += h;
    }
    if (rowIndex < 0 || rowIndex >= static_cast<int>(rows.size()))
        return;
    if (rows[rowIndex].kind == PropertyKind::SoundPreview ||
        rows[rowIndex].kind == PropertyKind::ReadOnly)
        return;
    if (rows[rowIndex].kind == PropertyKind::InstanceRef && rows[rowIndex].name != "Parent")
    {
        int rowY = contentTop + static_cast<int>(acc) - static_cast<int>(propertyScrollY);
        Rectangle clearButton = getPointerClearButtonRect(
            getPropertyValueX(rows[rowIndex], propertyScrollX), rowY);
        clearButton.x += static_cast<float>(propertyX);
        if (CheckCollisionPointRec(mouse, clearButton))
        {
            bool cleared = false;
            for (Instance* selected : selectedInstances)
                cleared = clearPointerProperty(selected, rows[rowIndex].name) || cleared;
            if (cleared)
                projectDirty = true;
            if (pointerPickProperty == rows[rowIndex].name &&
                find(selectedInstances.begin(), selectedInstances.end(), pointerPickOwner) != selectedInstances.end())
            {
                pointerPickOwner = nullptr;
                pointerPickProperty.clear();
            }
            activePropertyRow = -1;
            return;
        }
    }
    if (rows[rowIndex].kind == PropertyKind::Boolean)
    {
        // Toggle for all selected instances that share this property.
        // Mixed (empty) values default to turning ON.
        const string& cur = rows[rowIndex].value;
        bool nextOn = cur.empty() ? true : !(cur == "true" || cur == "True");
        applyPropertyTextToSelection(rowIndex, nextOn ? "true" : "false");
        projectDirty = true;
        return;
    }
    else if (rows[rowIndex].kind == PropertyKind::Enum)
    {
        // Open dropdown list of predefined Enum options (not free text)
        propertyEnumDropdownOpen = true;
        propertyEnumDropdownRow = rowIndex;
        propertyEnumDropdownOptions = rows[rowIndex].enumOptions;
        propertyEnumDropdownHover = -1;
        activePropertyRow = rowIndex;
        propertyEditText = rows[rowIndex].value;
    }
    else if (rows[rowIndex].kind == PropertyKind::Color)
    {
        Color* color = getPropertyColorTarget(instance, rows[rowIndex].name);

        if (color != nullptr)
        {
            int valueX = propertyX + getPropertyValueX(rows[rowIndex], propertyScrollX);
            Rectangle copyValue = { (float)valueX + 186, (float)(contentTop + static_cast<int>(acc) -
                static_cast<int>(propertyScrollY)) + 5, 45, 28 };
            if (CheckCollisionPointRec(mouse, copyValue))
            {
                SetClipboardText(TextFormat("%d, %d, %d", color->r, color->g, color->b));
                activePropertyRow = -1;
                return;
            }
            propertyPickerColor = *color;
            Vector3 hsv = ColorToHSV(propertyPickerColor);
            propertyPickerHue = hsv.x;
            propertyPickerSaturation = hsv.y;
            propertyPickerValue = hsv.z;
            propertyColorRgbText = TextFormat("%d, %d, %d", color->r, color->g, color->b);
            propertyColorRgbCursor = static_cast<int>(propertyColorRgbText.size());
            propertyColorRgbEditing = false;
            propertyColorRgbSelectAll = false;
            propertyCaretResetTime = GetTime();
            propertyPickerExternalTarget = nullptr;
            propertyColorPickerOpen = true;
            floatingPropertyColorDrag = false;
            floatingPropertyColorPos = {
                max(0.0f, (GetScreenWidth() - 340.0f) * 0.5f),
                max(0.0f, (GetScreenHeight() - 470.0f) * 0.5f)
            };
            activePropertyRow = rowIndex;
            propertyEditText.clear();
            propertyEditCursor = 0;
        }
    }
    else if (rows[rowIndex].kind == PropertyKind::InstanceRef ||
             (rows[rowIndex].kind == PropertyKind::String && isPointerProperty(rows[rowIndex].name)))
    {
        // Start pointer-pick mode: next Explorer/viewport click assigns the reference.
        if (canPickPointerProperty(instance, rows[rowIndex].name))
        {
            pointerPickOwner = instance;
            pointerPickProperty = rows[rowIndex].name;
            activePropertyRow = -1;
            propertyEditText.clear();
            return;
        }
    }
    else if (rows[rowIndex].kind == PropertyKind::Packed)
    {
        // Toggle expand/collapse for packed Vector3 / UDim2 / etc.
        const string& id = rows[rowIndex].packId;
        if (propertyPackedExpanded.count(id))
            propertyPackedExpanded.erase(id);
        else
            propertyPackedExpanded.insert(id);
        activePropertyRow = -1;
        propertyEditText.clear();
        propertyEditCursor = 0;
    }
    else if (rows[rowIndex].kind == PropertyKind::String || rows[rowIndex].kind == PropertyKind::Number ||
             rows[rowIndex].kind == PropertyKind::PackedField)
    {
        if (isPointerProperty(rows[rowIndex].name) &&
            canPickPointerProperty(instance, rows[rowIndex].name))
        {
            pointerPickOwner = instance;
            pointerPickProperty = rows[rowIndex].name;
            activePropertyRow = -1;
            return;
        }
        // Clear field on focus so the user types a fresh value (no trailing "0.000|" caret).
        // Enter or click-away applies; Escape cancels without writing.
        activePropertyRow = rowIndex;
        propertyEditText.clear();
        propertyEditCursor = 0;
        propertyCaretResetTime = GetTime();
    }
}

bool isInstanceSelected(Instance* instance)
{
    return find(
        selectedInstances.begin(),
        selectedInstances.end(),
        instance
    ) != selectedInstances.end();
}


// ------------------------------------------------------------
// Flatten Explorer tree
// ------------------------------------------------------------

bool isExplorerExpanded(const Instance* instance);

void flattenInstances(const vector<Instance*>& instances,vector<Instance*>& result)
{
    for (Instance* instance : instances)
    {
        if (instance == nullptr)
            continue;

        if (instance->hidden && !showHiddenAssets)
            continue;

        result.push_back(instance);

        bool expanded = isExplorerExpanded(instance);

        if (expanded && !instance->children.empty())
        {
            flattenInstances(
                instance->children,
                result
            );
        }
    }
}

void collectScripts(const vector<Instance*>& instances, vector<Script*>& scripts)
{
    for (Instance* instance : instances)
    {
        if (instance == nullptr)
            continue;
        if (instance->getType() == InstanceType::Script)
            scripts.push_back(static_cast<Script*>(instance));
        collectScripts(instance->children, scripts);
    }
}


Instance* findInstanceByPath(const string& path)
{
    if (path.empty() || path == "game")
        return &game;
    string p = path;
    if (p.rfind("game.", 0) == 0)
        p = p.substr(5);
    else if (p.rfind("game/", 0) == 0)
        p = p.substr(5);

    vector<string> segments;
    size_t start = 0;
    while (start <= p.size())
    {
        size_t sep = p.find_first_of("./", start);
        if (sep == string::npos) sep = p.size();
        if (sep > start)
            segments.push_back(p.substr(start, sep - start));
        if (sep == p.size()) break;
        start = sep + 1;
    }
    if (segments.empty())
        return &game;

    Instance* current = &game;
    for (const string& seg : segments)
    {
        Instance* next = nullptr;
        for (Instance* child : current->children)
        {
            if (child && child->name == seg)
            {
                next = child;
                break;
            }
        }
        if (next == nullptr)
            return nullptr;
        current = next;
    }
    return current;
}


void resolvePendingInstanceRefs()
{
    for (const PendingInstanceRef& ref : pendingInstanceRefs)
    {
        if (ref.owner == nullptr || ref.path.empty()) continue;
        Instance* target = findInstanceByPath(ref.path);
        if (target == nullptr) continue;
        if (ref.property == "RootPart" && ref.owner->getType() == InstanceType::Humanoid && target->getType() == InstanceType::Part)
            static_cast<HumanoidInstance*>(ref.owner)->rootPart = static_cast<Part*>(target);
        else if (ref.property == "PrimaryPart" && ref.owner->getType() == InstanceType::Model && target->getType() == InstanceType::Part)
            static_cast<Model_Instance*>(ref.owner)->primaryPart = static_cast<Part*>(target);
        else if (ref.property == "Target" && ref.owner->getType() == InstanceType::Camera)
            static_cast<CameraInstance*>(ref.owner)->target = target;
        else if (ref.property == "Adornee" &&
                 (ref.owner->getType() == InstanceType::ScreenGui ||
                  ref.owner->getType() == InstanceType::SurfaceGui ||
                  ref.owner->getType() == InstanceType::BillboardGui))
            static_cast<LayerCollectorInstance*>(ref.owner)->adornee = target;
        else if ((ref.property == "Part0" || ref.property == "Part1") && target->getType() == InstanceType::Part)
        {
            Part* part = static_cast<Part*>(target);
            if (ref.owner->getType() == InstanceType::WeldConstraint)
            {
                auto* w = static_cast<WeldConstraint*>(ref.owner);
                if (ref.property == "Part0") w->part0 = part; else w->part1 = part;
            }
            else if (ref.owner->getType() == InstanceType::Motor6D)
            {
                auto* m = static_cast<Motor6DConstraint*>(ref.owner);
                if (ref.property == "Part0") m->part0 = part;
                else
                {
                    m->part1 = part;
                    // Motor6D lives under Part1 children after load.
                    if (m->part1 != nullptr && m->parent != m->part1)
                    {
                        removeInstanceFromParent(m);
                        addInstanceToParent(m->part1, m);
                    }
                }
            }
        }
    }
    pendingInstanceRefs.clear();
}

string getInstancePath(const Instance* instance)
{
    vector<string> names;
    for (const Instance* current = instance; current != nullptr && current->parent != nullptr; current = current->parent)
        names.push_back(current->name);

    string path = "game";
    for (auto it = names.rbegin(); it != names.rend(); ++it)
        path += "." + *it;
    return path;
}

// Slash path used by runtime Luau proxies (__Path / __buildingToolScriptByPath)
string getInstanceRuntimePath(const Instance* instance)
{
    vector<string> names;
    for (const Instance* current = instance; current != nullptr && current->parent != nullptr; current = current->parent)
        names.push_back(current->name);

    string path = "game";
    for (auto it = names.rbegin(); it != names.rend(); ++it)
        path += "/" + *it;
    return path;
}

bool isExplorerExpanded(const Instance* instance)
{
    return find(
        collapsedExplorerInstances.begin(),
        collapsedExplorerInstances.end(),
        instance
    ) == collapsedExplorerInstances.end();
}

void setExplorerExpanded(Instance* instance,bool expanded)
{
    if (instance == nullptr || instance->children.empty())
        return;

    auto it = find(
        collapsedExplorerInstances.begin(),
        collapsedExplorerInstances.end(),
        instance
    );

    if (expanded && it != collapsedExplorerInstances.end())
        collapsedExplorerInstances.erase(it);
    else if (!expanded && it == collapsedExplorerInstances.end())
        collapsedExplorerInstances.push_back(instance);
}

void revealExplorerAncestors(Instance* instance)
{
    for (Instance* ancestor = instance != nullptr ? instance->parent : nullptr;
         ancestor != nullptr;
         ancestor = ancestor->parent)
        setExplorerExpanded(ancestor, true);
}

// Collapse every node that has children so the Explorer starts closed after load/new.
void collapseAllExplorerChildren(Instance* root)
{
    if (root == nullptr)
        root = &game;
    function<void(Instance*)> walk = [&](Instance* inst)
    {
        if (inst == nullptr)
            return;
        if (!inst->children.empty())
            setExplorerExpanded(inst, false);
        for (Instance* child : inst->children)
            walk(child);
    };
    walk(root);
}

// ------------------------------------------------------------
// Select from Explorer
// ------------------------------------------------------------

void selectExplorerInstance(Instance* clicked)
{
    // Locked only blocks viewport pick — explorer can always select
    if (clicked == nullptr)
        return;

    if (pointerPickOwner != nullptr && assignPointerProperty(clicked))
        return;

    revealExplorerAncestors(clicked);

    bool ctrl =
        IsKeyDown(KEY_LEFT_CONTROL) ||
        IsKeyDown(KEY_RIGHT_CONTROL);

    bool shift =
        IsKeyDown(KEY_LEFT_SHIFT) ||
        IsKeyDown(KEY_RIGHT_SHIFT);

    vector<Instance*> flattened;

    flattenInstances(
        game.children,
        flattened
    );

    auto clickedIt =
        find(
            flattened.begin(),
            flattened.end(),
            clicked
        );

    if (clickedIt == flattened.end())
        return;

    int clickedIndex =
        static_cast<int>(
            clickedIt - flattened.begin()
        );


    // ========================================================
    // SHIFT CLICK
    // ========================================================

    if (shift && selectionAnchor != nullptr)
    {
        auto anchorIt =
            find(
                flattened.begin(),
                flattened.end(),
                selectionAnchor
            );

        if (anchorIt != flattened.end())
        {
            int anchorIndex =
                static_cast<int>(
                    anchorIt - flattened.begin()
                );

            int first =
                min(anchorIndex, clickedIndex);

            int last =
                max(anchorIndex, clickedIndex);

            // Without Ctrl, replace selection.
            if (!ctrl)
                selectedInstances.clear();

            // Add everything in the range.
            for (int i = first; i <= last; i++)
            {
                if (!isInstanceSelected(flattened[i]))
                {
                    selectedInstances.push_back(
                        flattened[i]
                    );
                }
            }

            return;
        }
    }


    // ========================================================
    // CTRL CLICK
    // ========================================================

    if (ctrl)
    {
        auto it =
            find(
                selectedInstances.begin(),
                selectedInstances.end(),
                clicked
            );

        if (it != selectedInstances.end())
        {
            // Already selected -> remove it.
            selectedInstances.erase(it);
        }
        else
        {
            // Not selected -> add it.
            selectedInstances.push_back(clicked);
        }

        selectionAnchor = clicked;

        return;
    }


    // ========================================================
    // NORMAL CLICK
    // ========================================================

    selectedInstances.clear();

    selectedInstances.push_back(clicked);

    selectionAnchor = clicked;
}

// ------------------------------------------------------------
// Draw Explorer Tree
// ------------------------------------------------------------

Texture2D getInstanceIcon(const Instance* instance)
{
    if (explorerIcons == nullptr || instance == nullptr)
        return { 0 };

    if (instance == &workspace)
        return explorerIcons->workspaceIcon;
    if (instance == &ServerStorage)
        return explorerIcons->serverstorageIcon;
    if (instance == &ReplicatedStorage)
        return explorerIcons->replicatedStorageIcon;
    if (instance == &Lighting)
        return explorerIcons->lightingIcon;
    if (instance == &Players)
        return explorerIcons->playersIcon;
    if (instance == &ServerScriptService)
        return explorerIcons->serverScriptService;
    switch(instance->getType())
    {
        case InstanceType::Part:
        {
            const Part* part = static_cast<const Part*>(instance);
            if (part->isMeshPart && explorerIcons->meshPartIcon.id != 0)
                return explorerIcons->meshPartIcon;
            return explorerIcons->partIcon;
        }
        case InstanceType::Model:
            return explorerIcons->modelIcon;
        case InstanceType::Script:
        {
            const Script* script =
                static_cast<const Script*>(instance);

            switch (script->type)
            {
                case ScriptType::Script:
                    return explorerIcons->scriptIcon;

                case ScriptType::LocalScript:
                    return explorerIcons->localScriptIcon;

                case ScriptType::ModuleScript:
                    return explorerIcons->moduleScriptIcon;

                default:
                    return explorerIcons->scriptIcon;
            }
        }
        case InstanceType::Folder:
            return explorerIcons->folderIcon;
        case InstanceType::Sound:
            return explorerIcons->soundIcon;
        case InstanceType::Texture:
            return explorerIcons->textureIcon;
        case InstanceType::WeldConstraint:
            return explorerIcons->weldConstraintIcon;
        case InstanceType::Motor6D:
            return explorerIcons->motor6DConstraintIcon;
        case InstanceType::Player:
            return explorerIcons->playerIcon;
        case InstanceType::Humanoid:
            return explorerIcons->humanoidIcon;
        case InstanceType::Camera:
            return explorerIcons->cameraIcon;
        case InstanceType::BindableEvent:
            return explorerIcons->bindableEventIcon;
        case InstanceType::BindableFunction:
            return explorerIcons->bindableFunctionIcon;
        case InstanceType::RemoteEvent:
            return explorerIcons->remoteEventIcon;
        case InstanceType::RemoteFunction:
            return explorerIcons->remoteFunctionIcon;
        case InstanceType::ScreenGui:
            return explorerIcons->screenGuiIcon.id ? explorerIcons->screenGuiIcon :
                (explorerIcons->guiIcon.id ? explorerIcons->guiIcon : explorerIcons->folderIcon);
        case InstanceType::SurfaceGui:
            return explorerIcons->surfaceGuiIcon.id ? explorerIcons->surfaceGuiIcon :
                (explorerIcons->guiIcon.id ? explorerIcons->guiIcon : explorerIcons->folderIcon);
        case InstanceType::BillboardGui:
            return explorerIcons->billboardGuiIcon.id ? explorerIcons->billboardGuiIcon :
                (explorerIcons->guiIcon.id ? explorerIcons->guiIcon : explorerIcons->folderIcon);
        case InstanceType::Frame:
            return explorerIcons->frameIcon.id ? explorerIcons->frameIcon : explorerIcons->guiIcon;
        case InstanceType::ScrollingFrame:
            return explorerIcons->scrollingFrameIcon.id ? explorerIcons->scrollingFrameIcon : explorerIcons->guiIcon;
        case InstanceType::TextLabel:
            return explorerIcons->textLabelIcon.id ? explorerIcons->textLabelIcon : explorerIcons->guiIcon;
        case InstanceType::ImageLabel:
            return explorerIcons->imageLabelIcon.id ? explorerIcons->imageLabelIcon : explorerIcons->guiIcon;
        case InstanceType::TextButton:
            return explorerIcons->textButtonIcon.id ? explorerIcons->textButtonIcon : explorerIcons->guiIcon;
        case InstanceType::ImageButton:
            return explorerIcons->imageButtonIcon.id ? explorerIcons->imageButtonIcon : explorerIcons->guiIcon;
        case InstanceType::TextBox:
            return explorerIcons->textBoxIcon.id ? explorerIcons->textBoxIcon : explorerIcons->guiIcon;
        case InstanceType::UICorner:
            return explorerIcons->uiCornerIcon.id ? explorerIcons->uiCornerIcon : explorerIcons->guiIcon;
        case InstanceType::UIListLayout:
            return explorerIcons->uiListIcon.id ? explorerIcons->uiListIcon : explorerIcons->guiIcon;
        case InstanceType::UIStroke:
            return explorerIcons->uiStrokeIcon.id ? explorerIcons->uiStrokeIcon : explorerIcons->guiIcon;
        case InstanceType::UIPadding:
            return explorerIcons->uiAspectIcon.id ? explorerIcons->uiAspectIcon : explorerIcons->guiIcon;
        case InstanceType::UIGridLayout:
            return explorerIcons->uiGridIcon.id ? explorerIcons->uiGridIcon : explorerIcons->guiIcon;
        case InstanceType::UIAspectRatioConstraint:
            return explorerIcons->uiAspectIcon.id ? explorerIcons->uiAspectIcon : explorerIcons->guiIcon;
        case InstanceType::PointLight:
            return explorerIcons->pointLightIcon.id ? explorerIcons->pointLightIcon : explorerIcons->lightingIcon;
        case InstanceType::SpotLight:
            return explorerIcons->spotLightIcon.id ? explorerIcons->spotLightIcon : explorerIcons->lightingIcon;
        case InstanceType::SurfaceLight:
            return explorerIcons->surfaceLightIcon.id ? explorerIcons->surfaceLightIcon : explorerIcons->lightingIcon;
        case InstanceType::SunLight:
            return explorerIcons->sunLightIcon.id ? explorerIcons->sunLightIcon : explorerIcons->lightingIcon;
        case InstanceType::Blur:
            return explorerIcons->blurIcon.id ? explorerIcons->blurIcon : explorerIcons->lightingIcon;
        case InstanceType::Bloom:
            return explorerIcons->bloomIcon.id ? explorerIcons->bloomIcon : explorerIcons->lightingIcon;
        case InstanceType::ColorCorrection:
            return explorerIcons->lightingIcon;
        default:
            break;
    }
    return explorerIcons->partIcon;
}

string getInstanceIconColorKey(const Instance* instance)
{
    if (instance == &workspace) return "Workspace";
    if (instance == &ServerStorage) return "ServerStorage";
    if (instance == &ReplicatedStorage) return "ReplicatedStorage";
    if (instance == &Lighting) return "Lighting";
    if (instance == &Players) return "Players";
    if (instance == &ServerScriptService) return "ServerScriptService";
    if (instance == nullptr) return "Folder";
    switch (instance->getType())
    {
        case InstanceType::Part:
            return static_cast<const Part*>(instance)->isMeshPart ? "MeshPart" : "Part";
        case InstanceType::Model: return "Model";
        case InstanceType::Script:
        {
            const Script* script = static_cast<const Script*>(instance);
            if (script->type == ScriptType::LocalScript) return "LocalScript";
            if (script->type == ScriptType::ModuleScript) return "ModuleScript";
            return "Script";
        }
        case InstanceType::Folder: return "Folder";
        case InstanceType::Sound: return "Sound";
        case InstanceType::Texture: return "Texture";
        case InstanceType::WeldConstraint: return "WeldConstraint";
        case InstanceType::Motor6D: return "Motor6D";
        case InstanceType::Player: return "Player";
        case InstanceType::Humanoid: return "Humanoid";
        case InstanceType::Camera: return "Camera";
        case InstanceType::ScreenGui: return "ScreenGui";
        case InstanceType::SurfaceGui: return "SurfaceGui";
        case InstanceType::BillboardGui: return "BillboardGui";
        case InstanceType::Frame: return "Frame";
        case InstanceType::ScrollingFrame: return "ScrollingFrame";
        case InstanceType::TextLabel: return "TextLabel";
        case InstanceType::ImageLabel: return "ImageLabel";
        case InstanceType::TextButton: return "TextButton";
        case InstanceType::ImageButton: return "ImageButton";
        case InstanceType::TextBox: return "TextBox";
        case InstanceType::UICorner: return "UICorner";
        case InstanceType::UIListLayout: return "UIListLayout";
        case InstanceType::UIStroke: return "UIStroke";
        case InstanceType::UIPadding: return "UIPadding";
        case InstanceType::UIGridLayout: return "UIGridLayout";
        case InstanceType::UIAspectRatioConstraint: return "UIAspectRatioConstraint";
        case InstanceType::PointLight: return "PointLight";
        case InstanceType::SpotLight: return "SpotLight";
        case InstanceType::SurfaceLight: return "SurfaceLight";
        default: return instance->name;
    }
}

string getInstanceIconGroup(const Instance* instance)
{
    if (instance == nullptr)
        return "Containers";
    if (instance == &workspace || instance == &ServerStorage || instance == &ReplicatedStorage ||
        instance == &Lighting || instance == &Players || instance == &ServerScriptService)
        return "Services";
    switch (instance->getType())
    {
        case InstanceType::Part:
        case InstanceType::Model:
        case InstanceType::WeldConstraint:
        case InstanceType::Motor6D:
            return "Geometry";
        case InstanceType::Script:
            return "Scripts";
        case InstanceType::Folder:
            return "Containers";
        case InstanceType::Sound:
        case InstanceType::Texture:
            return "Assets";
        case InstanceType::ScreenGui:
        case InstanceType::SurfaceGui:
        case InstanceType::BillboardGui:
        case InstanceType::Frame:
        case InstanceType::ScrollingFrame:
        case InstanceType::TextLabel:
        case InstanceType::ImageLabel:
        case InstanceType::TextButton:
        case InstanceType::ImageButton:
        case InstanceType::TextBox:
        case InstanceType::UICorner:
        case InstanceType::UIListLayout:
        case InstanceType::UIStroke:
        case InstanceType::UIPadding:
        case InstanceType::UIGridLayout:
        case InstanceType::UIAspectRatioConstraint:
            return "UI";
        default:
            return "Services";
    }
}

int render_children(vector<Instance*>& instances,int x,int y,vector<bool>& branches)
{
    EditorThemeColors theme = getEditorThemeColors();
    for (int i = 0;
         i < static_cast<int>(instances.size());
         i++)
    {
        Instance* child = instances[i];

        if (child == nullptr)
            continue;

        bool isLast =
            (i == static_cast<int>(instances.size()) - 1);


        // ====================================================
        // Row
        // ====================================================

        int explorerX = getExplorerX();

        Rectangle rowRect = {
            static_cast<float>(explorerX),
            static_cast<float>(y - 2),
            static_cast<float>(EXPLORER_WIDTH - EXPLORER_SCROLLBAR_SIZE),
            static_cast<float>(EXPLORER_ROW_HEIGHT)
        };

        bool hovered =
            CheckCollisionPointRec(
                GetMousePosition(),
                rowRect
            );

        bool selected =
            isInstanceSelected(child);


        // Selection background
        if (selected)
        {
            DrawRectangleRec(
                rowRect,
                theme.selected
            );
        }
        else if (hovered)
        {
            DrawRectangleRec(
                rowRect,
                theme.surface
            );
        }
        if (child == explorerDropTarget)
            DrawRectangleLinesEx(rowRect, 2.0f, theme.accentHover);


        // ====================================================
        // Branch lines
        // ====================================================

        for (int j = 0;
             j < static_cast<int>(branches.size());
             j++)
        {
            if (branches[j])
            {
                int lineX =
                    x -
                    (static_cast<int>(branches.size()) - j)
                    * EXPLORER_INDENT;

                DrawLine(
                    lineX,
                    y - EXPLORER_ROW_HEIGHT / 2,
                    lineX,
                    y + EXPLORER_ROW_HEIGHT / 2,
                    theme.border
                );
            }
        }


        // ====================================================
        // Text
        // ====================================================

        int textX = x;

        if (!branches.empty())
        {
            int branchX = x;

            // Vertical branch
            DrawLine(
                branchX,
                y - EXPLORER_ROW_HEIGHT / 2,
                branchX,
                isLast
                    ? y + EXPLORER_FONT_SIZE / 2
                    : y + EXPLORER_ROW_HEIGHT / 2,
                theme.border
            );

            // Horizontal branch
            DrawLine(
                branchX,
                y + EXPLORER_FONT_SIZE / 2,
                branchX + EXPLORER_BRANCH_WIDTH,
                y + EXPLORER_FONT_SIZE / 2,
                theme.border
            );

            textX =
                branchX +
                EXPLORER_BRANCH_WIDTH +
                4;
        }

        if (!child->children.empty())
        {
            // Expand/collapse control — record exact screen rect for click hit-test
            Rectangle expandBox = {
                (float)textX,
                (float)(y + 1),
                16.0f,
                16.0f
            };
            DrawRectangleRec(expandBox, theme.surface);
            DrawRectangleLinesEx(expandBox, 1.0f, theme.border);
            DrawText(
                isExplorerExpanded(child) ? "v" : ">",
                (int)expandBox.x + 3,
                (int)expandBox.y + 1,
                EXPLORER_FONT_SIZE - 1,
                theme.text
            );
            // Slightly larger hit pad so the button is easy to click
            Rectangle hit = {
                expandBox.x - 2.0f,
                expandBox.y - 2.0f,
                expandBox.width + 4.0f,
                expandBox.height + 4.0f
            };
            explorerExpandHits.push_back({ child, hit });
            textX += 18;
        }


        Texture2D icon = getInstanceIcon(child);
        if (icon.id > 0)
            drawEditorIcon(icon, (float)textX, (float)y, 16.0f, 16.0f,
                getStudioInstanceIconTint(getInstanceIconColorKey(child), getInstanceIconGroup(child)));

        int nameX = textX + 20;

        if (renamingInstance == child)
        {
            int textWidth =
                MeasureText(renameText.c_str(), EXPLORER_FONT_SIZE);

            if (renameSelectAll)
            {
                DrawRectangle(
                    nameX,
                    y,
                    max(2, textWidth),
                    EXPLORER_FONT_SIZE,
                    theme.accent
                );
            }

            DrawText(
                renameText.c_str(),
                nameX,
                y,
                EXPLORER_FONT_SIZE,
                theme.text
            );

            int caretX =
                nameX +
                MeasureText(
                    renameText.substr(0, renameCursor).c_str(),
                    EXPLORER_FONT_SIZE
                );

            DrawRectangle(
                caretX,
                y - 1,
                2,
                EXPLORER_FONT_SIZE + 2,
                theme.text
            );
        }
        else
        {
            DrawText(
                child->name.c_str(),
                nameX,
                y,
                EXPLORER_FONT_SIZE,
                theme.text
            );
        }


        y += EXPLORER_ROW_HEIGHT;


        // ====================================================
        // Children
        // ====================================================

        if (!child->children.empty() && isExplorerExpanded(child))
        {
            branches.push_back(!isLast);

            y =
                render_children(
                    child->children,
                    x + EXPLORER_INDENT,
                    y,
                    branches
                );

            branches.pop_back();
        }
    }

    return y;
}


// ------------------------------------------------------------
// Explorer
// ------------------------------------------------------------

void renderExplorer(vector<Instance*>& instances)
{
    if (!isDockPanelActiveTab(DockPanelKind::Explorer))
        return;

    struct ScopedExplorerWidth
    {
        int previous;
        ScopedExplorerWidth() : previous(EXPLORER_WIDTH)
        {
            if (activeWindow == WindowType::ExplorerView)
                EXPLORER_WIDTH = max(300, GetScreenWidth() - leftSlotWidth() - rightSlotWidth());
        }
        ~ScopedExplorerWidth() { EXPLORER_WIDTH = previous; }
    } scopedExplorerWidth;

    EditorThemeColors theme = getEditorThemeColors();
    int explorerX = getExplorerX();
    int explorerBottom = GetScreenHeight();
    int contentTop = EXPLORER_TOP + 32;
    int contentHeight = explorerBottom - contentTop - EXPLORER_SCROLLBAR_SIZE;

    vector<Instance*> flattened;
    flattenInstances(instances, flattened);

    int contentWidth = EXPLORER_WIDTH - EXPLORER_SCROLLBAR_SIZE;
    for (Instance* instance : flattened)
    {
        int depth = 0;
        for (Instance* parent = instance->parent; parent != nullptr; parent = parent->parent)
            depth++;

        contentWidth = max(
            contentWidth,
            10 + depth * EXPLORER_INDENT + 20 +
            MeasureText(instance->name.c_str(), EXPLORER_FONT_SIZE)
        );
    }

    int contentPixelHeight = static_cast<int>(flattened.size()) * EXPLORER_ROW_HEIGHT;
    float maxScrollX = max(0, contentWidth - (EXPLORER_WIDTH - EXPLORER_SCROLLBAR_SIZE));
    float maxScrollY = max(0, contentPixelHeight - contentHeight);
    explorerScrollX = std::clamp(explorerScrollX, 0.0f, maxScrollX);
    explorerScrollY = std::clamp(explorerScrollY, 0.0f, maxScrollY);


    DrawRectangle(
        explorerX,
        EXPLORER_TOP,
        EXPLORER_WIDTH,
        GetScreenHeight() - EXPLORER_TOP,
        theme.panel
    );

    DrawRectangle(explorerX, EXPLORER_TOP, EXPLORER_WIDTH, 32, theme.header);
    DrawLine(explorerX, contentTop - 1, explorerX + EXPLORER_WIDTH, contentTop - 1, theme.border);

    DockSlotState* explorerSlot = dockSlotContaining(DockPanelKind::Explorer);
    if (explorerSlot != nullptr)
    {
        int clickedTab = renderDockHeaderTabs(*explorerSlot, explorerX + 6, EXPLORER_TOP + 4, 24,
            theme.surface, theme.header);
        if (clickedTab != -1)
            explorerSlot->activeTab = clickedTab;
    }
    // Focused-panel highlight: a thin accent line under the header when this
    // is the active input zone, so it's visually clear which panel has focus.
    if (isZoneFocused(FocusZone::Explorer))
        DrawRectangle(explorerX, EXPLORER_TOP + 30, EXPLORER_WIDTH, 2, theme.accent);

    if (explorerSlot == nullptr || explorerSlot->stack.size() < 2)
    {
        DrawText(
            EXPLORER_WIDTH > 40 ? "Explorer" : "+",
            EXPLORER_WIDTH > 40 ? explorerX + 14 : explorerX + 6,
            EXPLORER_TOP + 7,
            20,
            theme.text
        );
    }
    if (EXPLORER_WIDTH > 40)
    {
        DrawRectangle(explorerX + EXPLORER_WIDTH - 28, EXPLORER_TOP + 6, 22, 20, theme.surface);
        DrawText("-", explorerX + EXPLORER_WIDTH - 21, EXPLORER_TOP + 6, 16, theme.text);
    }
    else
        return;


    vector<bool> branches;


    explorerExpandHits.clear();
    bool explorerOnLeft = isDockPanelOnLeft(DockPanelKind::Explorer);
    int explorerContentX = explorerX + (explorerOnLeft ? EXPLORER_SCROLLBAR_SIZE : 0);
    int explorerContentWidth = EXPLORER_WIDTH - EXPLORER_SCROLLBAR_SIZE;
    BeginScissorMode(explorerContentX, contentTop, explorerContentWidth, contentHeight);
    render_children(instances, explorerContentX + 10 - static_cast<int>(explorerScrollX),
                    contentTop + 1 - static_cast<int>(explorerScrollY), branches);
    EndScissorMode();

    Rectangle verticalTrack = {
        static_cast<float>(explorerOnLeft ? explorerX : explorerX + EXPLORER_WIDTH - EXPLORER_SCROLLBAR_SIZE),
        static_cast<float>(contentTop),
        static_cast<float>(EXPLORER_SCROLLBAR_SIZE),
        static_cast<float>(contentHeight)
    };
    Rectangle horizontalTrack = {
        static_cast<float>(explorerContentX),
        static_cast<float>(explorerBottom - EXPLORER_SCROLLBAR_SIZE),
        static_cast<float>(explorerContentWidth),
        static_cast<float>(EXPLORER_SCROLLBAR_SIZE)
    };
    DrawRectangleRec(verticalTrack, theme.canvas);
    DrawRectangleRec(horizontalTrack, theme.canvas);

    float verticalThumbHeight = maxScrollY > 0.0f
        ? scrollbarThumbSize(static_cast<float>(contentHeight), maxScrollY)
        : static_cast<float>(contentHeight);
    float horizontalThumbWidth = maxScrollX > 0.0f
        ? scrollbarThumbSize(horizontalTrack.width, maxScrollX)
        : horizontalTrack.width;
    Rectangle verticalThumb = {
        verticalTrack.x,
        verticalTrack.y + (maxScrollY > 0.0f ? explorerScrollY / maxScrollY * (contentHeight - verticalThumbHeight) : 0.0f),
        static_cast<float>(EXPLORER_SCROLLBAR_SIZE), verticalThumbHeight
    };
    Rectangle horizontalThumb = {
        horizontalTrack.x + (maxScrollX > 0.0f ? explorerScrollX / maxScrollX * (horizontalTrack.width - horizontalThumbWidth) : 0.0f),
        horizontalTrack.y, horizontalThumbWidth, static_cast<float>(EXPLORER_SCROLLBAR_SIZE)
    };
    DrawRectangleRec(verticalThumb, (Color){ 112, 123, 140, 255 });
    DrawRectangleRec(horizontalThumb, (Color){ 112, 123, 140, 255 });

    if (explorerDragging && explorerDraggedInstance != nullptr)
    {
        Vector2 mouse = GetMousePosition();
        const int previewRows = min(6, static_cast<int>(explorerDraggedInstance->children.size()));
        int previewWidth = MeasureText(explorerDraggedInstance->name.c_str(), EXPLORER_FONT_SIZE) + 28;
        for (int index = 0; index < previewRows; ++index)
        {
            Instance* child = explorerDraggedInstance->children[index];
            if (child != nullptr)
                previewWidth = max(previewWidth, MeasureText(child->name.c_str(), EXPLORER_FONT_SIZE) + 42);
        }
        if (explorerDraggedInstance->children.size() > static_cast<size_t>(previewRows))
            previewWidth = max(previewWidth, MeasureText("...", EXPLORER_FONT_SIZE) + 42);
        previewWidth = min(280, max(140, previewWidth));
        int previewHeight = 28 + previewRows * 19 +
            (explorerDraggedInstance->children.size() > static_cast<size_t>(previewRows) ? 19 : 0);
        float previewX = mouse.x + 18.0f;
        float previewY = mouse.y + 18.0f;
        if (previewX + previewWidth > GetScreenWidth())
            previewX = mouse.x - previewWidth - 18.0f;
        if (previewY + previewHeight > GetScreenHeight())
            previewY = mouse.y - previewHeight - 18.0f;
        previewX = Clamp(previewX, 0.0f, static_cast<float>(GetScreenWidth() - previewWidth));
        previewY = Clamp(previewY, static_cast<float>(MENU_BAR_HEIGHT),
            static_cast<float>(GetScreenHeight() - previewHeight));

        Rectangle preview = { previewX, previewY, static_cast<float>(previewWidth), static_cast<float>(previewHeight) };
        DrawRectangleRec(preview, theme.panel);
        DrawRectangleLinesEx(preview, 2.0f, theme.accent);
        DrawRectangle(static_cast<int>(previewX), static_cast<int>(previewY), previewWidth, 26, theme.header);
        DrawText(explorerDraggedInstance->name.c_str(), static_cast<int>(previewX) + 8,
            static_cast<int>(previewY) + 5, EXPLORER_FONT_SIZE, theme.text);
        for (int index = 0; index < previewRows; ++index)
        {
            Instance* child = explorerDraggedInstance->children[index];
            if (child == nullptr)
                continue;
            DrawText(child->name.c_str(), static_cast<int>(previewX) + 24,
                static_cast<int>(previewY) + 29 + index * 19, EXPLORER_FONT_SIZE, theme.muted);
        }
        if (explorerDraggedInstance->children.size() > static_cast<size_t>(previewRows))
            DrawText("...", static_cast<int>(previewX) + 24,
                static_cast<int>(previewY) + 29 + previewRows * 19, EXPLORER_FONT_SIZE, theme.muted);
    }
}


// ------------------------------------------------------------
// Explorer Mouse Click
// ------------------------------------------------------------

void beginRename(Instance* instance)
{
    if (instance == nullptr)
        return;

    renamingInstance = instance;
    renameText = instance->name;
    renameCursor = static_cast<int>(renameText.size());
    renameSelectAll = true;
}

void finishRename(bool accept)
{
    if (renamingInstance != nullptr && accept && !renameText.empty())
        renamingInstance->name = renameText;

    renamingInstance = nullptr;
    renameText.clear();
    renameCursor = 0;
    renameSelectAll = false;
}

void handleExplorerRename()
{
    // Not currently renaming
    if (renamingInstance == nullptr)
    {
        // Active-panel isolation: Enter only renames when Explorer is focused
        // and no property field is being edited.
        if (activePropertyRow >= 0)
            return;
        if (!isZoneFocused(FocusZone::Explorer))
            return;
        if (selectedInstances.size() == 1 && IsKeyPressed(KEY_ENTER))
        {
            beginRename(selectedInstances.front());
        }

        return;
    }

    // Finish rename
    if (IsKeyPressed(KEY_ENTER))
    {
        finishRename(true);
        return;
    }

    // Cancel rename
    if (IsKeyPressed(KEY_ESCAPE))
    {
        finishRename(false);
        return;
    }

    bool ctrl = IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL);
    if (ctrl && IsKeyPressed(KEY_A))
    {
        renameSelectAll = true;
        renameCursor = static_cast<int>(renameText.size());
    }
    if (ctrl && IsKeyPressed(KEY_C) && renameSelectAll)
        SetClipboardText(renameText.c_str());
    if (ctrl && IsKeyPressed(KEY_X) && renameSelectAll)
    {
        SetClipboardText(renameText.c_str());
        renameText.clear();
        renameCursor = 0;
        renameSelectAll = false;
    }
    if (ctrl && IsKeyPressed(KEY_V))
    {
        const char* clipboard = GetClipboardText();
        if (clipboard != nullptr)
        {
            if (renameSelectAll)
            {
                renameText.clear();
                renameCursor = 0;
            }
            renameText.insert(renameCursor, clipboard);
            renameCursor += static_cast<int>(strlen(clipboard));
            renameSelectAll = false;
        }
    }

    // ============================================================
    // LEFT / RIGHT
    // ============================================================

    if (IsKeyPressed(KEY_LEFT))
    {
        renameSelectAll = false;

        renameCursor =
            max(0, renameCursor - 1);
    }

    if (IsKeyPressed(KEY_RIGHT))
    {
        renameSelectAll = false;

        renameCursor =
            min(
                static_cast<int>(renameText.size()),
                renameCursor + 1
            );
    }

    // ============================================================
    // BACKSPACE
    // ============================================================

    if (IsKeyPressed(KEY_BACKSPACE))
    {
        if (renameSelectAll)
        {
            renameText.clear();
            renameCursor = 0;
        }
        else if (
            renameCursor > 0 &&
            renameCursor <= static_cast<int>(renameText.size())
        )
        {
            renameText.erase(
                renameCursor - 1,
                1
            );

            renameCursor--;
        }

        renameSelectAll = false;
    }

    // ============================================================
    // TYPING
    // ============================================================

    int codepoint = GetCharPressed();

    while (codepoint > 0)
    {
        if (!ctrl && codepoint >= 32 && codepoint <= 126)
        {
            if (renameSelectAll)
            {
                renameText.clear();
                renameCursor = 0;
                renameSelectAll = false;
            }

            // Keep cursor inside the string
            renameCursor =
                std::clamp(
                    renameCursor,
                    0,
                    static_cast<int>(renameText.size())
                );

            renameText.insert(
                renameCursor,
                1,
                static_cast<char>(codepoint)
            );

            renameCursor++;
        }

        codepoint = GetCharPressed();
    }

    // Final safety check
    renameCursor =
        std::clamp(
            renameCursor,
            0,
            static_cast<int>(renameText.size())
        );
}

void handleExplorerClick()
{
    if (renamingInstance != nullptr)
        return;
    if (!isDockPanelActiveTab(DockPanelKind::Explorer))
        return;

    Vector2 mouse =
        GetMousePosition();

    int explorerX =
        getExplorerX();
    if (mouse.x >= explorerX && mouse.x < explorerX + EXPLORER_WIDTH && mouse.y >= EXPLORER_TOP &&
        (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) || IsMouseButtonPressed(MOUSE_BUTTON_RIGHT) ||
         IsMouseButtonPressed(MOUSE_BUTTON_MIDDLE)))
        focusedZone = FocusZone::Explorer;

    bool onLeft = isDockPanelOnLeft(DockPanelKind::Explorer);

    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) &&
        mouse.x >= explorerX && mouse.x <= explorerX + EXPLORER_WIDTH &&
        mouse.y >= EXPLORER_TOP && mouse.y < EXPLORER_TOP + 32)
    {
        if (EXPLORER_WIDTH > 40 && mouse.x >= explorerX + EXPLORER_WIDTH - 34)
        {
            EXPLORER_WIDTH = 24;
            return;
        }
        if (EXPLORER_WIDTH <= 40)
        {
            EXPLORER_WIDTH = 300;
            return;
        }

        // Header / stacked tab strip: drag the specific panel under the cursor
        // (same gesture as a solo panel — floating card + drop zones).
        DockSlotState* slot = dockSlotContaining(DockPanelKind::Explorer);
        if (slot != nullptr && slot->stack.size() > 1)
        {
            const int tabWidth = 96;
            const int tabY = EXPLORER_TOP + 4;
            const int tabH = 24;
            int baseX = explorerX + 6;
            bool hitTab = false;
            for (size_t i = 0; i < slot->stack.size(); ++i)
            {
                int tabX = baseX + static_cast<int>(i) * (tabWidth + 4);
                Rectangle tabRect = {
                    static_cast<float>(tabX), static_cast<float>(tabY),
                    static_cast<float>(tabWidth), static_cast<float>(tabH)
                };
                if (CheckCollisionPointRec(mouse, tabRect))
                {
                    slot->activeTab = static_cast<int>(i);
                    beginDockDrag(slot->stack[i], mouse);
                    hitTab = true;
                    break;
                }
            }
            if (!hitTab)
                beginDockDrag(DockPanelKind::Explorer, mouse);
        }
        else
            beginDockDrag(DockPanelKind::Explorer, mouse);
    }

    if (dockDragActive && dockDragPanel == DockPanelKind::Explorer)
        return;

    if (onLeft)
    {
        if (mouse.x >= explorerX + EXPLORER_WIDTH - 5 && mouse.x <= explorerX + EXPLORER_WIDTH + 5 && EXPLORER_WIDTH > 40)
        {
            if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
                explorerResizing = true;
            if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && explorerResizing)
                EXPLORER_WIDTH = std::clamp(static_cast<int>(mouse.x) - explorerX, 24, max(24, GetScreenWidth() - 24));
        }
    }
    else if (mouse.x >= explorerX - 5 && mouse.x <= explorerX + 5 && EXPLORER_WIDTH > 40)
    {
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
            explorerResizing = true;
        if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && explorerResizing)
            EXPLORER_WIDTH = std::clamp(GetScreenWidth() - static_cast<int>(mouse.x), 24, max(24, GetScreenWidth() - 24));
    }
    if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
        explorerResizing = false;
    if (EXPLORER_WIDTH <= 40)
        return;


    int contentTop = EXPLORER_TOP + 32;
    int contentBottom = GetScreenHeight() - EXPLORER_SCROLLBAR_SIZE;
    int contentLeft = explorerX + (onLeft ? EXPLORER_SCROLLBAR_SIZE : 0);
    int contentRight = explorerX + EXPLORER_WIDTH - (onLeft ? 0 : EXPLORER_SCROLLBAR_SIZE);
    int explorerScrollbarX = onLeft ? explorerX : explorerX + EXPLORER_WIDTH - EXPLORER_SCROLLBAR_SIZE;
    bool clickedExplorerArrow = false;
    auto updateExplorerDropTarget = [&]()
    {
        explorerDropTarget = nullptr;
        if (!explorerDragging || explorerDraggedInstances.empty() ||
            mouse.x < explorerX || mouse.x >= contentRight ||
            mouse.y < contentTop || mouse.y >= contentBottom)
            return;
        vector<Instance*> visible;
        flattenInstances(game.children, visible);
        int targetIndex = static_cast<int>((mouse.y - contentTop + explorerScrollY) / EXPLORER_ROW_HEIGHT);
        if (targetIndex < 0 || targetIndex >= static_cast<int>(visible.size()))
            return;
        Instance* candidate = visible[targetIndex];
        bool invalidTarget = false;
        for (Instance* dragged : explorerDraggedInstances)
        {
            if (candidate == dragged || isInstanceInBranch(dragged, candidate))
            {
                invalidTarget = true;
                break;
            }
        }
        if (!invalidTarget)
            explorerDropTarget = candidate;
    };

    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) &&
        mouse.x >= contentLeft && mouse.x < contentRight &&
        mouse.y >= contentTop && mouse.y < contentBottom)
    {
        vector<Instance*> flattened;
        flattenInstances(game.children, flattened);

        int index = static_cast<int>((mouse.y - contentTop + explorerScrollY) / EXPLORER_ROW_HEIGHT);
        if (index >= 0 && index < static_cast<int>(flattened.size()))
        {
            explorerDraggedInstance = flattened[index];
            explorerDragStartMouse = mouse;
            explorerDragging = false;
            bool preserveMultiSelection = isInstanceSelected(explorerDraggedInstance);

            // Match expand/collapse against the exact rects drawn this frame
            clickedExplorerArrow = false;
            for (const ExplorerExpandHit& hit : explorerExpandHits)
            {
                if (hit.instance == explorerDraggedInstance &&
                    CheckCollisionPointRec(mouse, hit.rect))
                {
                    clickedExplorerArrow = true;
                    break;
                }
            }
            // Fallback: any expand box under the cursor (row index can lag scroll)
            if (!clickedExplorerArrow)
            {
                for (const ExplorerExpandHit& hit : explorerExpandHits)
                {
                    if (CheckCollisionPointRec(mouse, hit.rect))
                    {
                        explorerDraggedInstance = hit.instance;
                        clickedExplorerArrow = true;
                        break;
                    }
                }
            }

            double now = GetTime();
            if (explorerDraggedInstance == lastExplorerClicked &&
                now - lastExplorerClickTime < 0.45)
                explorerClickCount++;
            else
                explorerClickCount = 1;

            lastExplorerClicked = explorerDraggedInstance;
            lastExplorerClickTime = now;
            if (!preserveMultiSelection)
                selectExplorerInstance(explorerDraggedInstance);
            explorerDraggedInstances = preserveMultiSelection
                ? getSelectedRoots()
                : vector<Instance*>{ explorerDraggedInstance };

            if (!clickedExplorerArrow && explorerClickCount == 2 &&
                explorerDraggedInstance->getType() == InstanceType::Script)
            {
                openScriptWindow(static_cast<Script*>(explorerDraggedInstance));
            }

            if (clickedExplorerArrow)
            {
                setExplorerExpanded(
                    explorerDraggedInstance,
                    !isExplorerExpanded(explorerDraggedInstance)
                );
                explorerDraggedInstance = nullptr;
            }
            if (!clickedExplorerArrow && explorerClickCount >= 3)
            {
                beginRename(explorerDraggedInstance);
                explorerClickCount = 0;
            }
        }
    }

    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) &&
        mouse.x >= explorerScrollbarX && mouse.x < explorerScrollbarX + EXPLORER_SCROLLBAR_SIZE &&
        mouse.y >= contentTop && mouse.y < contentBottom)
        explorerDraggingScrollY = true;

    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) &&
        mouse.x >= contentLeft && mouse.x < contentRight &&
        mouse.y >= contentBottom)
        explorerDraggingScrollX = true;

    if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && explorerDraggedInstance != nullptr &&
        Vector2Distance(explorerDragStartMouse, mouse) > 4.0f)
        explorerDragging = true;
    updateExplorerDropTarget();

    if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT))
    {
        if (explorerDragging && explorerDropTarget != nullptr)
            for (Instance* dragged : explorerDraggedInstances)
                reparentInstance(dragged, explorerDropTarget);

        explorerDraggedInstance = nullptr;
        explorerDraggedInstances.clear();
        explorerDropTarget = nullptr;
        explorerDragging = false;
        explorerDraggingScrollX = false;
        explorerDraggingScrollY = false;
    }

    if (mouse.x < explorerX || mouse.y < contentTop)
        return;

    if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && explorerDraggingScrollY)
    {
        vector<Instance*> flattened;
        flattenInstances(game.children, flattened);
        int contentHeight = GetScreenHeight() - contentTop - EXPLORER_SCROLLBAR_SIZE;
        float maxScrollY = max(0.0f, static_cast<float>(static_cast<int>(flattened.size()) * EXPLORER_ROW_HEIGHT - contentHeight));
        float thumbH = scrollbarThumbSize(static_cast<float>(contentHeight), maxScrollY);
        explorerScrollY = scrollbarScrollFromMouse(mouse.y, static_cast<float>(contentTop),
            static_cast<float>(contentHeight), thumbH, maxScrollY);
        return;
    }

    if (IsMouseButtonDown(MOUSE_BUTTON_LEFT) && explorerDraggingScrollX)
    {
        float trackW = static_cast<float>(EXPLORER_WIDTH - EXPLORER_SCROLLBAR_SIZE);
        // Approximate max horizontal scroll from current clamp range
        float maxScrollX = max(0.0f, explorerScrollX + 200.0f); // will clamp next frame in render
        // Prefer using a generous range; explorer render clamps each frame
        maxScrollX = max(maxScrollX, 400.0f);
        float thumbW = scrollbarThumbSize(trackW, maxScrollX);
        explorerScrollX = scrollbarScrollFromMouse(mouse.x, static_cast<float>(contentLeft), trackW, thumbW, maxScrollX);
        return;
    }

    if (mouse.x >= contentLeft && mouse.x < contentRight &&
        mouse.y >= contentTop && mouse.y < contentBottom)
    {
        float wheel = isZoneFocused(FocusZone::Explorer) ? GetMouseWheelMove() : 0.0f;
        if (wheel != 0.0f)
        {
            explorerScrollY -= wheel * EXPLORER_ROW_HEIGHT * 2.0f;
            return;
        }
    }

    if (!IsMouseButtonPressed(MOUSE_BUTTON_LEFT) || explorerDraggedInstance != nullptr)
        return;


    vector<Instance*> flattened;

    flattenInstances(
        game.children,
        flattened
    );


    // Explorer rows start below the Explorer header.
    int index =
        static_cast<int>(
            (mouse.y - contentTop + explorerScrollY) /
            EXPLORER_ROW_HEIGHT
        );


    if (index < 0 ||
        index >= static_cast<int>(flattened.size()))
    {
        return;
    }


    Instance* clicked =
        flattened[index];


    selectExplorerInstance(clicked);
}

void handleExplorerKeyboard()
{
    if (renamingInstance != nullptr || !isZoneFocused(FocusZone::Explorer) || selectedInstances.size() != 1)
        return;

    Instance* selected = selectedInstances.front();
    if (selected == nullptr)
        return;

    if (IsKeyPressed(KEY_LEFT))
    {
        setExplorerExpanded(selected, true);
        return;
    }

    if (IsKeyPressed(KEY_RIGHT))
    {
        setExplorerExpanded(selected, false);
        return;
    }

    if (!IsKeyPressed(KEY_UP) && !IsKeyPressed(KEY_DOWN))
        return;

    vector<Instance*> flattened;
    flattenInstances(game.children, flattened);

    auto selectedIt = find(flattened.begin(), flattened.end(), selected);
    if (selectedIt == flattened.end() || flattened.empty())
        return;

    int selectedIndex = static_cast<int>(selectedIt - flattened.begin());
    int nextIndex = IsKeyPressed(KEY_UP)
        ? max(0, selectedIndex - 1)
        : min(static_cast<int>(flattened.size()) - 1, selectedIndex + 1);

    selectExplorerInstance(flattened[nextIndex]);
}

bool isScriptWordCharacter(char character)
{
    return isalnum(static_cast<unsigned char>(character)) || character == '_';
}


// Load keywords / completions / pointer property names from luau_config.json
// Search order: assets/luau_config.json, temp/luau_config.json, ./luau_config.json

#endif // BT_PANELS_H