#pragma once
// physic.h — Stable rigid-body step for Building Tool.
// Path: assets/Headers/physic.h
// Include AFTER Part / Instance / workspace / runtimePlaying / localToWorld /
// rotateVector / WeldConstraint / Motor6DConstraint / captureWeldRelative exist.

#ifndef BUILDING_TOOL_PHYSIC_H
#define BUILDING_TOOL_PHYSIC_H

#include <vector>
#include <functional>
#include <algorithm>
#include <cmath>
#include <unordered_set>

// Tunables (Roblox-inspired, tuned for stability)
struct PhysicsSettings
{
    float gravity = -196.2f;        // Workspace.Gravity
    float maxFallSpeed = 500.0f;
    float elasticity = 0.15f;        // low bounce — was 0.5 and felt chaotic
    float friction = 0.55f;          // 0..1 tangent kill on contact
    float angularDamping = 0.90f;   // per substep (stronger than before)
    float linearDamping = 0.0f;     // air drag on horizontal (0 = none)
    float groundSettleSpeed = 3.0f; // kill small vertical bounce on floors
    float skin = 0.002f;            // depenetration bias
    int substeps = 6;               // 4 is enough; 8 amplified jitter
};

inline PhysicsSettings gPhysicsSettings;

// ---------------------------------------------------------------------------
// Bounds (AABB from oriented corners / shape samples)
// ---------------------------------------------------------------------------
inline void getPartMeshSamplePoints(const Part& part, std::vector<Vector3>& out)
{
    out.clear();
    Vector3 h = { part.size.x * 0.5f, part.size.y * 0.5f, part.size.z * 0.5f };

    auto addLocal = [&](float x, float y, float z)
    {
        out.push_back(localToWorld(part.cframe, { x, y, z }));
    };

    if (part.isMeshPart && part.collisionFidelity != CollisionFidelity::Box)
    {
        ProjectAsset* asset = findProjectAssetById(part.meshId);
        if (asset != nullptr && asset->type == ProjectAssetType::Mesh &&
            ensureProjectAssetLoaded(*asset))
        {
            // The current solver resolves contacts from world-space bounds;
            // use the imported mesh's cached hull bounds rather than rescanning
            // every vertex on each physics substep.
            for (int sx = -1; sx <= 1; sx += 2)
                for (int sy = -1; sy <= 1; sy += 2)
                    for (int sz = -1; sz <= 1; sz += 2)
                        addLocal(h.x * static_cast<float>(sx),
                            h.y * static_cast<float>(sy), h.z * static_cast<float>(sz));
            return;
        }
    }

    if (part.type == PartType::Sphere)
    {
        float r = std::min({ h.x, h.y, h.z });
        addLocal(0,  r, 0); addLocal(0, -r, 0);
        addLocal(r,  0, 0); addLocal(-r, 0, 0);
        addLocal(0,  0, r); addLocal(0,  0, -r);
        const float inv = 0.70710678f * r;
        addLocal( inv, 0,  inv); addLocal(-inv, 0,  inv);
        addLocal( inv, 0, -inv); addLocal(-inv, 0, -inv);
        addLocal( inv, inv, 0);  addLocal(-inv, inv, 0);
        addLocal(0, inv,  inv);  addLocal(0, inv, -inv);
        addLocal( inv, -inv, 0); addLocal(-inv, -inv, 0);
        addLocal(0, -inv, inv);  addLocal(0, -inv, -inv);
        return;
    }

    if (part.type == PartType::Cylinder || part.type == PartType::Cone)
    {
        float radius = h.x;
        float yTop = h.y;
        float yBot = -h.y;
        const int segs = 12;
        for (int i = 0; i < segs; ++i)
        {
            float a = (float)i / (float)segs * 6.2831853f;
            float cx = cosf(a) * radius;
            float cz = sinf(a) * radius;
            if (part.type == PartType::Cone)
            {
                addLocal(0, yTop, 0);
                addLocal(cx, yBot, cz);
            }
            else
            {
                addLocal(cx, yTop, cz);
                addLocal(cx, yBot, cz);
            }
        }
        addLocal(0, 0, 0);
        return;
    }

    for (int sx = -1; sx <= 1; sx += 2)
        for (int sy = -1; sy <= 1; sy += 2)
            for (int sz = -1; sz <= 1; sz += 2)
                addLocal(h.x * (float)sx, h.y * (float)sy, h.z * (float)sz);
}

inline void getPartAABB(const Part& part, Vector3& outMin, Vector3& outMax)
{
    const Matrix rotation = MatrixRotateXYZ({
        part.cframe.rotation.x * DEG2RAD,
        part.cframe.rotation.y * DEG2RAD,
        part.cframe.rotation.z * DEG2RAD
    });
    const float hx = part.size.x * 0.5f;
    const float hy = part.size.y * 0.5f;
    const float hz = part.size.z * 0.5f;
    Vector3 extents = { 0, 0, 0 };
    if (!part.isMeshPart && part.type == PartType::Sphere)
    {
        extents = { hx, hx, hx };
    }
    else if (!part.isMeshPart && part.type == PartType::Cylinder)
    {
        extents = {
            hx * std::sqrt(rotation.m0 * rotation.m0 + rotation.m8 * rotation.m8) +
                hy * std::fabs(rotation.m4),
            hx * std::sqrt(rotation.m1 * rotation.m1 + rotation.m9 * rotation.m9) +
                hy * std::fabs(rotation.m5),
            hx * std::sqrt(rotation.m2 * rotation.m2 + rotation.m10 * rotation.m10) +
                hy * std::fabs(rotation.m6)
        };
    }
    else
    {
        extents = {
            std::fabs(rotation.m0) * hx + std::fabs(rotation.m4) * hy + std::fabs(rotation.m8) * hz,
            std::fabs(rotation.m1) * hx + std::fabs(rotation.m5) * hy + std::fabs(rotation.m9) * hz,
            std::fabs(rotation.m2) * hx + std::fabs(rotation.m6) * hy + std::fabs(rotation.m10) * hz
        };
    }
    outMin = Vector3Subtract(part.cframe.position, extents);
    outMax = Vector3Add(part.cframe.position, extents);

    extern HumanoidInstance* runtimeHumanoid;
    if (runtimeClientMode && runtimeHumanoid != nullptr &&
        runtimeHumanoid->rootPart == &part)
    {
        // The torso is the avatar's only physical part; extend its collision
        // envelope to cover the attached head and legs so the visible rig
        // cannot pass through thin, unanchored mesh parts.
        outMin.y = std::min(outMin.y,
            part.cframe.position.y - std::max(part.size.y * 0.5f, runtimeHumanoid->hipHeight));
        outMax.y = std::max(outMax.y, part.cframe.position.y + part.size.y * 0.5f + 1.0f);
    }
}

inline bool sphereOverlapsAABB(Vector3 center, float radius,
    Vector3 bMin, Vector3 bMax, Vector3& outNormal, float& outPenetration)
{
    Vector3 closest = {
        std::clamp(center.x, bMin.x, bMax.x),
        std::clamp(center.y, bMin.y, bMax.y),
        std::clamp(center.z, bMin.z, bMax.z)
    };
    Vector3 delta = Vector3Subtract(center, closest);
    float distSq = Vector3LengthSqr(delta);
    if (distSq > radius * radius)
        return false;

    if (distSq > 1e-8f)
    {
        float dist = sqrtf(distSq);
        outNormal = Vector3Scale(delta, 1.0f / dist);
        outPenetration = radius - dist;
    }
    else
    {
        float dx1 = center.x - bMin.x, dx2 = bMax.x - center.x;
        float dy1 = center.y - bMin.y, dy2 = bMax.y - center.y;
        float dz1 = center.z - bMin.z, dz2 = bMax.z - center.z;
        float ax = std::min(dx1, dx2);
        float ay = std::min(dy1, dy2);
        float az = std::min(dz1, dz2);
        if (ax <= ay && ax <= az)
        {
            outNormal = { (dx1 < dx2) ? -1.0f : 1.0f, 0, 0 };
            outPenetration = radius + ax;
        }
        else if (ay <= az)
        {
            outNormal = { 0, (dy1 < dy2) ? -1.0f : 1.0f, 0 };
            outPenetration = radius + ay;
        }
        else
        {
            outNormal = { 0, 0, (dz1 < dz2) ? -1.0f : 1.0f };
            outPenetration = radius + az;
        }
    }
    return true;
}

inline bool cylinderOverlapsAABB(Vector3 center, float radius, float halfHeight,
    Vector3 bMin, Vector3 bMax, Vector3& outNormal, float& outPenetration)
{
    float lowY = center.y - halfHeight;
    float highY = center.y + halfHeight;
    if (lowY >= bMax.y || highY <= bMin.y)
        return false;

    float closestX = std::clamp(center.x, bMin.x, bMax.x);
    float closestZ = std::clamp(center.z, bMin.z, bMax.z);
    float dx = center.x - closestX;
    float dz = center.z - closestZ;
    float radialDistance = std::sqrt(dx * dx + dz * dz);
    if (radialDistance >= radius)
        return false;

    float verticalPenetration = std::min(highY - bMin.y, bMax.y - lowY);
    float radialPenetration = radius - radialDistance;
    if (radialDistance > 1e-6f)
        outNormal = { dx / radialDistance, 0.0f, dz / radialDistance };
    else
    {
        float left = center.x - bMin.x;
        float right = bMax.x - center.x;
        float back = center.z - bMin.z;
        float front = bMax.z - center.z;
        float nearest = std::min({ left, right, back, front });
        if (nearest == left) outNormal = { -1, 0, 0 };
        else if (nearest == right) outNormal = { 1, 0, 0 };
        else if (nearest == back) outNormal = { 0, 0, -1 };
        else outNormal = { 0, 0, 1 };
        radialPenetration = radius + nearest;
    }

    if (verticalPenetration * 1.05f <= radialPenetration)
    {
        outNormal = { 0.0f, lowY < bMin.y ? -1.0f : 1.0f, 0.0f };
        outPenetration = verticalPenetration;
    }
    else
        outPenetration = radialPenetration;
    return true;
}

inline bool sphereOverlapsSphere(Vector3 centerA, float radiusA,
    Vector3 centerB, float radiusB, Vector3& outNormal, float& outPenetration)
{
    Vector3 delta = Vector3Subtract(centerA, centerB);
    float distanceSquared = Vector3LengthSqr(delta);
    float combinedRadius = radiusA + radiusB;
    if (distanceSquared >= combinedRadius * combinedRadius)
        return false;
    if (distanceSquared < 1e-8f)
    {
        outNormal = { 0, 1, 0 };
        outPenetration = combinedRadius;
        return true;
    }
    float distance = std::sqrt(distanceSquared);
    outNormal = Vector3Scale(delta, 1.0f / distance);
    outPenetration = combinedRadius - distance;
    return true;
}

inline bool sphereOverlapsCylinder(Vector3 sphereCenter, float sphereRadius,
    Vector3 cylinderCenter, float cylinderRadius, float cylinderHalfHeight,
    Vector3& outNormal, float& outPenetration)
{
    float dx = sphereCenter.x - cylinderCenter.x;
    float dz = sphereCenter.z - cylinderCenter.z;
    float radialDistance = std::sqrt(dx * dx + dz * dz);
    float closestX = cylinderCenter.x;
    float closestZ = cylinderCenter.z;
    if (radialDistance > cylinderRadius && radialDistance > 1e-6f)
    {
        float scale = cylinderRadius / radialDistance;
        closestX += dx * scale;
        closestZ += dz * scale;
    }
    float closestY = std::clamp(sphereCenter.y,
        cylinderCenter.y - cylinderHalfHeight,
        cylinderCenter.y + cylinderHalfHeight);
    Vector3 delta = {
        sphereCenter.x - closestX,
        sphereCenter.y - closestY,
        sphereCenter.z - closestZ
    };
    float distanceSquared = Vector3LengthSqr(delta);
    if (distanceSquared >= sphereRadius * sphereRadius)
        return false;
    if (distanceSquared > 1e-8f)
    {
        float distance = std::sqrt(distanceSquared);
        outNormal = Vector3Scale(delta, 1.0f / distance);
        outPenetration = sphereRadius - distance;
        return true;
    }

    float radialClearance = cylinderRadius - radialDistance;
    float verticalClearance = cylinderHalfHeight -
        std::fabs(sphereCenter.y - cylinderCenter.y);
    if (radialClearance <= verticalClearance)
    {
        outNormal = radialDistance > 1e-6f
            ? Vector3{ dx / radialDistance, 0.0f, dz / radialDistance }
            : Vector3{ 1.0f, 0.0f, 0.0f };
        outPenetration = sphereRadius + radialClearance;
    }
    else
    {
        outNormal = { 0.0f,
            sphereCenter.y >= cylinderCenter.y ? 1.0f : -1.0f, 0.0f };
        outPenetration = sphereRadius + verticalClearance;
    }
    return true;
}

inline bool cylinderOverlapsCylinder(Vector3 centerA, float radiusA, float halfHeightA,
    Vector3 centerB, float radiusB, float halfHeightB,
    Vector3& outNormal, float& outPenetration)
{
    float verticalPenetration = halfHeightA + halfHeightB -
        std::fabs(centerA.y - centerB.y);
    if (verticalPenetration <= 0.0f)
        return false;

    float dx = centerA.x - centerB.x;
    float dz = centerA.z - centerB.z;
    float radialDistance = std::sqrt(dx * dx + dz * dz);
    float radialPenetration = radiusA + radiusB - radialDistance;
    if (radialPenetration <= 0.0f)
        return false;

    if (verticalPenetration <= radialPenetration)
    {
        outNormal = { 0.0f, centerA.y >= centerB.y ? 1.0f : -1.0f, 0.0f };
        outPenetration = verticalPenetration;
    }
    else
    {
        outNormal = radialDistance > 1e-6f
            ? Vector3{ dx / radialDistance, 0.0f, dz / radialDistance }
            : Vector3{ 1.0f, 0.0f, 0.0f };
        outPenetration = radialPenetration;
    }
    return true;
}

inline void collectPhysicsParts(Instance* root, std::vector<Part*>& solid, std::vector<Part*>& dynamicParts)
{
    std::function<void(Instance*)> walk = [&](Instance* inst)
    {
        if (!inst) return;
        if (inst->getType() == InstanceType::Part)
        {
            Part* p = static_cast<Part*>(inst);
            if (p->anchored && p->canCollide)
                solid.push_back(p);
            else if (!p->anchored)
                dynamicParts.push_back(p);
        }
        for (Instance* child : inst->children)
            walk(child);
    };
    walk(root);
}

// Part1 of Weld / Motor6D follows Part0 — skip free integration.
inline void collectWeldKinematicSlaves(Instance* root, std::unordered_set<Part*>& slaves)
{
    std::function<void(Instance*)> walk = [&](Instance* inst)
    {
        if (!inst) return;
        if (inst->getType() == InstanceType::WeldConstraint)
        {
            auto* w = static_cast<WeldConstraint*>(inst);
            if (w->enabled && w->part0 && w->part1 && !w->part1->anchored)
                slaves.insert(w->part1);
        }
        else if (inst->getType() == InstanceType::Motor6D)
        {
            auto* m = static_cast<Motor6DConstraint*>(inst);
            if (m->enabled && m->part0 && m->part1 && !m->part1->anchored)
                slaves.insert(m->part1);
        }
        for (Instance* c : inst->children)
            walk(c);
    };
    walk(root);
}

// Deterministic contact: no random kicks (those made the sim look "broken").
inline float getPartPhysicsFriction(const Part* part, const PhysicsSettings& cfg)
{
    if (part == nullptr || !part->advancedPhysics)
        return cfg.friction;
    return std::clamp(part->friction, 0.0f, 1.0f);
}

inline float getPartMass(const Part* part)
{
    if (part == nullptr)
        return 1.0f;
    float volume = std::max(0.001f, part->size.x * part->size.y * part->size.z);
    if (!part->isMeshPart && part->type == PartType::Sphere)
    {
        float radius = std::max(0.05f, part->size.x * 0.5f);
        volume = (4.0f / 3.0f) * PI * radius * radius * radius;
    }
    else if (!part->isMeshPart && part->type == PartType::Cylinder)
    {
        float radius = std::max(0.05f, part->size.x * 0.5f);
        volume = PI * radius * radius * std::max(0.1f, part->size.y);
    }
    float density = part->advancedPhysics
        ? std::clamp(part->density, 0.01f, 100.0f) : 1.0f;
    return std::max(0.001f, volume * density);
}

inline void applyContactResponse(Part* p, Vector3 normal, float penetration, const PhysicsSettings& cfg)
{
    if (penetration <= 0.0001f || p == nullptr)
        return;

    // Separate along normal (clamp huge corrections from bad AABBs)
    float sep = std::min(penetration + cfg.skin, 1.5f);
    p->cframe.position = Vector3Add(p->cframe.position,
        Vector3Scale(normal, sep));

    const bool humanoidRoot = runtimeHumanoid != nullptr &&
        p == runtimeHumanoid->rootPart;
    const float controlledVelocityX = p->velocity.x;
    const float controlledVelocityZ = p->velocity.z;
    float vn = Vector3DotProduct(p->velocity, normal);
    const bool isFloor = fabsf(normal.y) > 0.65f;
    const bool isWall = fabsf(normal.y) < 0.35f;
    const float friction = humanoidRoot ? 0.0f : getPartPhysicsFriction(p, cfg);
    bool wasMovingIntoSurface = vn < 0.0f;

    if (vn < 0.0f)
    {
        float impact = -vn;
        if (impact < cfg.groundSettleSpeed || isFloor)
        {
            p->velocity = Vector3Subtract(p->velocity, Vector3Scale(normal, vn));
            if (isFloor && wasMovingIntoSurface)
                p->velocity.y = 0.0f;
        }
        else
        {
            p->velocity = Vector3Add(p->velocity,
                Vector3Scale(normal, impact * (1.0f + cfg.elasticity)));
        }
    }

    Vector3 tangent = Vector3Subtract(p->velocity,
        Vector3Scale(normal, Vector3DotProduct(p->velocity, normal)));
    if (isWall)
    {
        float keepY = p->velocity.y;
        p->velocity = Vector3Subtract(p->velocity, Vector3Scale(tangent, friction * 0.25f));
        p->velocity.y = keepY;
    }
    else
    {
        p->velocity = Vector3Subtract(p->velocity, Vector3Scale(tangent, friction));
    }

    if (isFloor)
    {
        if (friction > 0.0f && Vector3Length(tangent) > 0.05f)
        {
            float radius = 0.5f * std::min({ p->size.x, p->size.y, p->size.z });
            radius = std::max(radius, 0.05f);
            Vector3 targetSpin = Vector3Scale(Vector3CrossProduct(normal, tangent),
                RAD2DEG / radius);
            targetSpin.x = std::clamp(targetSpin.x, -360.0f, 360.0f);
            targetSpin.y = std::clamp(targetSpin.y, -360.0f, 360.0f);
            targetSpin.z = std::clamp(targetSpin.z, -360.0f, 360.0f);
            float blend = std::clamp(friction * 0.5f, 0.0f, 1.0f);
            p->angularVelocity = Vector3Add(p->angularVelocity,
                Vector3Scale(Vector3Subtract(targetSpin, p->angularVelocity), blend));
        }
        else if (friction <= 0.0f)
            p->angularVelocity = Vector3Scale(p->angularVelocity, 0.98f);
    }
    if (humanoidRoot)
    {
        p->velocity.x = controlledVelocityX;
        p->velocity.z = controlledVelocityZ;
    }
}

inline void resolvePartAgainstSolids(Part* p, const std::vector<Part*>& solid, const PhysicsSettings& cfg)
{
    if (!p || !p->canCollide)
        return;

    Vector3 aMin, aMax;
    getPartAABB(*p, aMin, aMax);

    const bool isSphere = !p->isMeshPart && p->type == PartType::Sphere;
    const float sphereR = isSphere
        ? p->size.x * 0.5f
        : 0.0f;

    for (Part* other : solid)
    {
        if (!other) continue;
        Vector3 bMin, bMax;
        getPartAABB(*other, bMin, bMax);

        const bool otherSphere = !other->isMeshPart && other->type == PartType::Sphere;
        const bool otherCylinder = !other->isMeshPart && other->type == PartType::Cylinder;

        if (isSphere && otherSphere)
        {
            Vector3 n;
            float pen = 0.0f;
            if (sphereOverlapsSphere(p->cframe.position, sphereR,
                other->cframe.position, other->size.x * 0.5f, n, pen))
                applyContactResponse(p, n, pen, cfg);
            continue;
        }

        if (isSphere && otherCylinder)
        {
            Vector3 n;
            float pen = 0.0f;
            if (sphereOverlapsCylinder(p->cframe.position, sphereR,
                other->cframe.position, other->size.x * 0.5f,
                other->size.y * 0.5f, n, pen))
                applyContactResponse(p, n, pen, cfg);
            continue;
        }

        if (!p->isMeshPart && p->type == PartType::Cylinder && otherCylinder)
        {
            Vector3 n;
            float pen = 0.0f;
            if (cylinderOverlapsCylinder(p->cframe.position, p->size.x * 0.5f,
                p->size.y * 0.5f, other->cframe.position, other->size.x * 0.5f,
                other->size.y * 0.5f, n, pen))
                applyContactResponse(p, n, pen, cfg);
            getPartAABB(*p, aMin, aMax);
            continue;
        }

        if (isSphere)
        {
            Vector3 n;
            float pen = 0.0f;
            if (sphereOverlapsAABB(p->cframe.position, sphereR, bMin, bMax, n, pen))
                applyContactResponse(p, n, pen, cfg);
            continue;
        }

        if (otherSphere)
        {
            Vector3 n;
            float pen = 0.0f;
            if (sphereOverlapsAABB(other->cframe.position, other->size.x * 0.5f,
                aMin, aMax, n, pen))
                applyContactResponse(p, Vector3Negate(n), pen, cfg);
            getPartAABB(*p, aMin, aMax);
            continue;
        }

        if (otherCylinder)
        {
            Vector3 n;
            float pen = 0.0f;
            if (cylinderOverlapsAABB(other->cframe.position, other->size.x * 0.5f,
                other->size.y * 0.5f, aMin, aMax, n, pen))
                applyContactResponse(p, Vector3Negate(n), pen, cfg);
            getPartAABB(*p, aMin, aMax);
            continue;
        }

        if (!p->isMeshPart && p->type == PartType::Cylinder)
        {
            Vector3 n;
            float pen = 0.0f;
            if (cylinderOverlapsAABB(p->cframe.position, p->size.x * 0.5f,
                p->size.y * 0.5f, bMin, bMax, n, pen))
                applyContactResponse(p, n, pen, cfg);
            getPartAABB(*p, aMin, aMax);
            continue;
        }

        bool overlap =
            aMin.x < bMax.x && aMax.x > bMin.x &&
            aMin.y < bMax.y && aMax.y > bMin.y &&
            aMin.z < bMax.z && aMax.z > bMin.z;
        if (!overlap)
            continue;

        float penX1 = bMax.x - aMin.x;
        float penX2 = aMax.x - bMin.x;
        float penY1 = bMax.y - aMin.y;
        float penY2 = aMax.y - bMin.y;
        float penZ1 = bMax.z - aMin.z;
        float penZ2 = aMax.z - bMin.z;

        float absX = std::min(penX1, penX2);
        float absY = std::min(penY1, penY2);
        float absZ = std::min(penZ1, penZ2);

        // Prefer the axis of least penetration; bias toward Y when close
        // so resting on floors doesn't get solved as a side push.
        Vector3 n = { 0, 1, 0 };
        float pen = absY;
        const float yBias = 1.05f;
        if (absY * yBias <= absX && absY * yBias <= absZ)
        {
            n = { 0, (penY1 < penY2) ? 1.0f : -1.0f, 0 };
            pen = absY;
        }
        else if (absX <= absZ)
        {
            n = { (penX1 < penX2) ? 1.0f : -1.0f, 0, 0 };
            pen = absX;
        }
        else
        {
            n = { 0, 0, (penZ1 < penZ2) ? 1.0f : -1.0f };
            pen = absZ;
        }

        applyContactResponse(p, n, pen, cfg);
        getPartAABB(*p, aMin, aMax);
    }
}

inline void resolveDynamicContact(Part* a, Part* b, Vector3 normal,
    float penetration, const PhysicsSettings& cfg)
{
    Vector3 delta = Vector3Subtract(a->cframe.position, b->cframe.position);
    if (Vector3DotProduct(delta, normal) < 0.0f)
        normal = Vector3Negate(normal);
    if (penetration <= 0.0001f)
        return;

    float inverseMassA = 1.0f / getPartMass(a);
    float inverseMassB = 1.0f / getPartMass(b);
    float inverseMassSum = inverseMassA + inverseMassB;
    float correction = penetration + cfg.skin;
    a->cframe.position = Vector3Add(a->cframe.position,
        Vector3Scale(normal, correction * inverseMassA / inverseMassSum));
    b->cframe.position = Vector3Subtract(b->cframe.position,
        Vector3Scale(normal, correction * inverseMassB / inverseMassSum));

    float va = Vector3DotProduct(a->velocity, normal);
    float vb = Vector3DotProduct(b->velocity, normal);
    const bool humanoidRootA = runtimeHumanoid != nullptr &&
        a == runtimeHumanoid->rootPart;
    const bool humanoidRootB = runtimeHumanoid != nullptr &&
        b == runtimeHumanoid->rootPart;
    const float controlledVelocityAX = a->velocity.x;
    const float controlledVelocityAZ = a->velocity.z;
    const float controlledVelocityBX = b->velocity.x;
    const float controlledVelocityBZ = b->velocity.z;
    float relativeVelocity = va - vb;
    if (relativeVelocity < -0.001f)
    {
        float impulse = -(1.0f + cfg.elasticity) * relativeVelocity / inverseMassSum;
        a->velocity = Vector3Add(a->velocity,
            Vector3Scale(normal, impulse * inverseMassA));
        b->velocity = Vector3Add(b->velocity,
            Vector3Scale(normal, -impulse * inverseMassB));
    }

    Vector3 tangentA = Vector3Subtract(a->velocity,
        Vector3Scale(normal, Vector3DotProduct(a->velocity, normal)));
    Vector3 tangentB = Vector3Subtract(b->velocity,
        Vector3Scale(normal, Vector3DotProduct(b->velocity, normal)));
    float frictionA = runtimeHumanoid != nullptr && a == runtimeHumanoid->rootPart
        ? 0.0f : getPartPhysicsFriction(a, cfg);
    float frictionB = runtimeHumanoid != nullptr && b == runtimeHumanoid->rootPart
        ? 0.0f : getPartPhysicsFriction(b, cfg);
    a->velocity = Vector3Subtract(a->velocity,
        Vector3Scale(tangentA, frictionA * 0.5f));
    b->velocity = Vector3Subtract(b->velocity,
        Vector3Scale(tangentB, frictionB * 0.5f));
    if (humanoidRootA)
    {
        a->velocity.x = controlledVelocityAX;
        a->velocity.z = controlledVelocityAZ;
    }
    if (humanoidRootB)
    {
        b->velocity.x = controlledVelocityBX;
        b->velocity.z = controlledVelocityBZ;
    }
}

inline void resolveDynamicPair(Part* a, Part* b, const PhysicsSettings& cfg)
{
    if (!a || !b || !a->canCollide || !b->canCollide)
        return;

    const bool sphereA = !a->isMeshPart && a->type == PartType::Sphere;
    const bool sphereB = !b->isMeshPart && b->type == PartType::Sphere;
    const bool cylinderA = !a->isMeshPart && a->type == PartType::Cylinder;
    const bool cylinderB = !b->isMeshPart && b->type == PartType::Cylinder;
    Vector3 aMin, aMax, bMin, bMax;
    Vector3 contactNormal;
    float contactPenetration = 0.0f;

    if (sphereA && sphereB)
    {
        if (sphereOverlapsSphere(a->cframe.position, a->size.x * 0.5f,
            b->cframe.position, b->size.x * 0.5f,
            contactNormal, contactPenetration))
            resolveDynamicContact(a, b, contactNormal, contactPenetration, cfg);
        return;
    }

    if (sphereA && cylinderB)
    {
        if (sphereOverlapsCylinder(a->cframe.position, a->size.x * 0.5f,
            b->cframe.position, b->size.x * 0.5f, b->size.y * 0.5f,
            contactNormal, contactPenetration))
            resolveDynamicContact(a, b, contactNormal, contactPenetration, cfg);
        return;
    }
    if (cylinderA && sphereB)
    {
        if (sphereOverlapsCylinder(b->cframe.position, b->size.x * 0.5f,
            a->cframe.position, a->size.x * 0.5f, a->size.y * 0.5f,
            contactNormal, contactPenetration))
            resolveDynamicContact(a, b, Vector3Negate(contactNormal),
                contactPenetration, cfg);
        return;
    }
    if (cylinderA && cylinderB)
    {
        if (cylinderOverlapsCylinder(a->cframe.position, a->size.x * 0.5f,
            a->size.y * 0.5f, b->cframe.position, b->size.x * 0.5f,
            b->size.y * 0.5f, contactNormal, contactPenetration))
            resolveDynamicContact(a, b, contactNormal, contactPenetration, cfg);
        return;
    }
    if (sphereA)
    {
        getPartAABB(*b, aMin, aMax);
        if (sphereOverlapsAABB(a->cframe.position, a->size.x * 0.5f,
            aMin, aMax, contactNormal, contactPenetration))
            resolveDynamicContact(a, b, contactNormal, contactPenetration, cfg);
        return;
    }
    if (sphereB)
    {
        getPartAABB(*a, aMin, aMax);
        if (sphereOverlapsAABB(b->cframe.position, b->size.x * 0.5f,
            aMin, aMax, contactNormal, contactPenetration))
            resolveDynamicContact(a, b, Vector3Negate(contactNormal),
                contactPenetration, cfg);
        return;
    }
    if (cylinderA)
    {
        getPartAABB(*b, aMin, aMax);
        if (cylinderOverlapsAABB(a->cframe.position, a->size.x * 0.5f,
            a->size.y * 0.5f, aMin, aMax, contactNormal, contactPenetration))
            resolveDynamicContact(a, b, contactNormal, contactPenetration, cfg);
        return;
    }
    if (cylinderB)
    {
        getPartAABB(*a, aMin, aMax);
        if (cylinderOverlapsAABB(b->cframe.position, b->size.x * 0.5f,
            b->size.y * 0.5f, aMin, aMax, contactNormal, contactPenetration))
            resolveDynamicContact(a, b, Vector3Negate(contactNormal),
                contactPenetration, cfg);
        return;
    }

    getPartAABB(*a, aMin, aMax);
    getPartAABB(*b, bMin, bMax);

    bool overlap =
        aMin.x < bMax.x && aMax.x > bMin.x &&
        aMin.y < bMax.y && aMax.y > bMin.y &&
        aMin.z < bMax.z && aMax.z > bMin.z;
    if (!overlap)
        return;

    float penX = std::min(bMax.x - aMin.x, aMax.x - bMin.x);
    float penY = std::min(bMax.y - aMin.y, aMax.y - bMin.y);
    float penZ = std::min(bMax.z - aMin.z, aMax.z - bMin.z);

    Vector3 n = { 0, 1, 0 };
    float pen = penY;
    if (penX < penY && penX < penZ) { n = { 1, 0, 0 }; pen = penX; }
    else if (penZ < penY) { n = { 0, 0, 1 }; pen = penZ; }

    Vector3 delta = Vector3Subtract(a->cframe.position, b->cframe.position);
    if (Vector3DotProduct(delta, n) < 0.0f)
        n = Vector3Scale(n, -1.0f);

    if (pen <= 0.0001f)
        return;

    resolveDynamicContact(a, b, n, pen, cfg);
}


inline void applyWeldPose(WeldConstraint* w)
{
    if (!w || !w->enabled || !w->part0 || !w->part1)
        return;
    if (w->part1->anchored)
        return;

    if (!w->relativeCaptured)
        captureWeldRelative(w);

    Vector3 worldOff = rotateVector(w->relativePosition, w->part0->cframe.rotation);
    w->part1->cframe.position = Vector3Add(w->part0->cframe.position, worldOff);
    w->part1->cframe.rotation = {
        w->part0->cframe.rotation.x + w->relativeRotation.x,
        w->part0->cframe.rotation.y + w->relativeRotation.y,
        w->part0->cframe.rotation.z + w->relativeRotation.z
    };
    w->part1->velocity = w->part0->velocity;
    w->part1->angularVelocity = w->part0->angularVelocity;
}

inline Matrix cframeRotationMatrix(const CFrame& c)
{
    return MatrixRotateXYZ({
        c.rotation.x * DEG2RAD,
        c.rotation.y * DEG2RAD,
        c.rotation.z * DEG2RAD
    });
}

// Extract Euler degrees matching MatrixRotateXYZ (same as cframeRotationMatrix).
// Avoids QuaternionToEuler sign/order mismatches that break intermediate angles
// (0/90/180 worked, but values like 30/45 did not).
inline Vector3 matrixToEulerXYZDeg(const Matrix& m)
{
    // Match raylib MatrixRotateXYZ layout:
    //   m0=cz*cy  m4=sz*cy  m8=-sy
    //   m1=...    m5=...    m9=cy*sx
    //   m2=...    m6=...    m10=cy*cx
    float sy = -m.m8;
    sy = std::clamp(sy, -1.0f, 1.0f);
    float x, y, z;
    if (sy > 0.9999f)
    {
        x = atan2f(-m.m4, m.m5);
        y = PI / 2.0f;
        z = 0.0f;
    }
    else if (sy < -0.9999f)
    {
        x = atan2f(m.m4, m.m5);
        y = -PI / 2.0f;
        z = 0.0f;
    }
    else
    {
        y = asinf(sy);
        x = atan2f(m.m9, m.m10);  // cy*sx, cy*cx
        z = atan2f(m.m4, m.m0);   // sz*cy, cz*cy
    }
    return { x * RAD2DEG, y * RAD2DEG, z * RAD2DEG };
}

// CFrame composition matching Roblox: A * B applies B in A's local space.
inline CFrame multiplyCFrame(const CFrame& a, const CFrame& b)
{
    Matrix ar = cframeRotationMatrix(a);
    Matrix br = cframeRotationMatrix(b);
    Matrix r = MatrixMultiply(ar, br);

    Vector3 p = Vector3Add(a.position, Vector3Transform(b.position, ar));
    Vector3 euler = matrixToEulerXYZDeg(r);

    return { p, euler };
}

inline CFrame inverseCFrame(const CFrame& c)
{
    Matrix r = cframeRotationMatrix(c);
    Matrix inv = MatrixInvert(r);

    Vector3 p = Vector3Transform(Vector3Scale(c.position, -1.0f), inv);
    Vector3 euler = matrixToEulerXYZDeg(inv);

    return { p, euler };
}

inline void applyMotor6DPose(Motor6DConstraint* m, float step)
{
    if (!m || !m->enabled || !m->part0 || !m->part1)
        return;

    if (std::isfinite(m->desiredAngle) && std::isfinite(m->currentAngle))
    {
        if (m->maxVelocity <= 0.0f || !std::isfinite(m->maxVelocity))
            m->currentAngle = m->desiredAngle;
        else
        {
            float maxStep = m->maxVelocity * std::max(0.0f, step);
            m->currentAngle += std::clamp(m->desiredAngle - m->currentAngle,
                -maxStep, maxStep);
        }
    }

    // Rebuild both Part1 position and rotation from the live Part0 pose and
    // the two attachment offsets every step. Transform is the animation offset.
    CFrame world = multiplyCFrame(m->part0->cframe, m->c0);
    CFrame motorTransform = m->transform;
    motorTransform.rotation.z += m->currentAngle * RAD2DEG;
    world = multiplyCFrame(world, motorTransform);
    world = multiplyCFrame(world, inverseCFrame(m->c1));

    m->part1->cframe = world;
    m->part1->velocity = m->part0->velocity;
    m->part1->angularVelocity = m->part0->angularVelocity;
}

inline void applyPhysicsJoints(float step)
{
    std::function<void(Instance*)> walk = [&](Instance* inst)
    {
        if (!inst) return;
        if (inst->getType() == InstanceType::WeldConstraint)
            applyWeldPose(static_cast<WeldConstraint*>(inst));
        else if (inst->getType() == InstanceType::Motor6D)
            applyMotor6DPose(static_cast<Motor6DConstraint*>(inst), step);
        for (Instance* c : inst->children)
            walk(c);
    };
    walk(&workspace);
}

inline bool partIsGrounded(const Part* p, const std::vector<Part*>& solid, float probe = 0.25f)
{
    if (!p) return false;
    Vector3 pMin, pMax;
    getPartAABB(*p, pMin, pMax);
    float feetY = pMin.y;
    Vector3 probeMin = { pMin.x + 0.02f, feetY - probe, pMin.z + 0.02f };
    Vector3 probeMax = { pMax.x - 0.02f, feetY + 0.08f, pMax.z - 0.02f };
    for (Part* s : solid)
    {
        if (!s || s == p) continue;
        Vector3 sMin, sMax;
        getPartAABB(*s, sMin, sMax);
        bool overlap =
            probeMin.x < sMax.x && probeMax.x > sMin.x &&
            probeMin.y < sMax.y && probeMax.y > sMin.y &&
            probeMin.z < sMax.z && probeMax.z > sMin.z;
        if (overlap)
            return true;
    }
    return false;
}

// Looks for a climbable surface next to the humanoid root: either a Part with
// Truss = true overlapping a short probe out from the root, or any solid,
// non-truss part whose horizontal gap to the root is a tight squeeze
// (>0 and <=0.5 studs — close enough to grip like a ladder rung or a crack
// between two walls). Returns true and fills outNormal with the outward
// direction (away from the surface, world space) on success.
inline bool findHumanoidClimbSurface(const Part* root, const std::vector<Part*>& solid,
    float climbGap, Vector3& outNormal)
{
    if (root == nullptr)
        return false;

    Vector3 rMin, rMax;
    getPartAABB(*root, rMin, rMax);

    const float gapLimit = std::max(0.0f, climbGap);

    for (Part* p : solid)
    {
        if (!p || p == root || !p->truss)
            continue;

        Vector3 pMin, pMax;
        getPartAABB(*p, pMin, pMax);

        // The truss must actually span the humanoid vertically. This prevents
        // a tiny truss fragment above/below the character from maintaining a
        // climb state.
        if (pMax.y < rMin.y + 0.2f || pMin.y > rMax.y - 0.2f)
            continue;

        // Horizontal separation from the humanoid AABB to the truss AABB.
        // Negative values mean collision/penetration; those still count as
        // attached to the climb surface. The magnitude/clearance must remain
        // within climbGap or the humanoid immediately leaves climb state.
        float dx = 0.0f;
        if (rMax.x < pMin.x) dx = pMin.x - rMax.x;
        else if (pMax.x < rMin.x) dx = rMin.x - pMax.x;

        float dz = 0.0f;
        if (rMax.z < pMin.z) dz = pMin.z - rMax.z;
        else if (pMax.z < rMin.z) dz = rMin.z - pMax.z;

        float horizontalGap = sqrtf(dx * dx + dz * dz);
        if (horizontalGap > gapLimit)
            continue;

        // Pick the nearest truss face so jump-off pushes away from the actual
        // surface rather than from the arbitrary probe direction.
        if (dx > 0.0f)
            outNormal = { -1.0f, 0.0f, 0.0f };
        else if (rMin.x > pMax.x)
            outNormal = { 1.0f, 0.0f, 0.0f };
        else if (dz > 0.0f)
            outNormal = { 0.0f, 0.0f, -1.0f };
        else if (rMin.z > pMax.z)
            outNormal = { 0.0f, 0.0f, 1.0f };
        else
        {
            // A collision/overlap with the truss: choose the closest face.
            float left = fabsf(rMin.x - pMax.x);
            float right = fabsf(pMin.x - rMax.x);
            float back = fabsf(rMin.z - pMax.z);
            float front = fabsf(pMin.z - rMax.z);
            float best = std::min(std::min(left, right), std::min(back, front));

            if (best == left) outNormal = { 1.0f, 0.0f, 0.0f };
            else if (best == right) outNormal = { -1.0f, 0.0f, 0.0f };
            else if (best == back) outNormal = { 0.0f, 0.0f, 1.0f };
            else outNormal = { 0.0f, 0.0f, -1.0f };
        }

        return true;
    }

    return false;
}

inline void updateBasicPhysics(float dt)
{
    if (!runtimePlaying || dt <= 0.0f)
        return;

    const PhysicsSettings& cfg = gPhysicsSettings;
    dt = std::min(dt, 1.0f / 30.0f);
    const int substeps = std::max(1, cfg.substeps);
    const float step = dt / static_cast<float>(substeps);

    std::vector<Part*> solid;
    std::vector<Part*> dynamicParts;
    collectPhysicsParts(&workspace, solid, dynamicParts);

    std::unordered_set<Part*> weldSlaves;
    collectWeldKinematicSlaves(&workspace, weldSlaves);

    for (int s = 0; s < substeps; ++s)
    {
        for (Part* p : dynamicParts)
        {
            if (!p || weldSlaves.count(p))
                continue;

            // Gravity — skip for humanoid root while climbing (input owns vertical)
            extern HumanoidInstance* runtimeHumanoid;
            const bool climbRoot = (runtimeHumanoid != nullptr &&
                runtimeHumanoid->climbing &&
                runtimeHumanoid->rootPart == p);
            if (!climbRoot)
            {
                p->velocity.y += cfg.gravity * step;
                if (p->velocity.y < -cfg.maxFallSpeed)
                    p->velocity.y = -cfg.maxFallSpeed;
            }

            // Optional light air drag on horizontal only
            if (cfg.linearDamping > 0.0f)
            {
                float d = 1.0f - cfg.linearDamping * step;
                if (d < 0.0f) d = 0.0f;
                p->velocity.x *= d;
                p->velocity.z *= d;
            }

            // Integrate translation
            p->cframe.position.x += p->velocity.x * step;
            p->cframe.position.y += p->velocity.y * step;
            p->cframe.position.z += p->velocity.z * step;

            // Integrate rotation ONLY if spinning meaningfully — and damp hard.
            // Pure euler integration of angularVelocity is unstable; we keep it
            // for light visual tumble but clamp rates so parts don't explode.
            const float maxSpin = 360.0f; // deg/s
            p->angularVelocity.x = std::clamp(p->angularVelocity.x, -maxSpin, maxSpin);
            p->angularVelocity.y = std::clamp(p->angularVelocity.y, -maxSpin, maxSpin);
            p->angularVelocity.z = std::clamp(p->angularVelocity.z, -maxSpin, maxSpin);

            p->cframe.rotation.x += p->angularVelocity.x * step;
            p->cframe.rotation.y += p->angularVelocity.y * step;
            p->cframe.rotation.z += p->angularVelocity.z * step;

            resolvePartAgainstSolids(p, solid, cfg);
            p->angularVelocity = Vector3Scale(p->angularVelocity, cfg.angularDamping);
        }

        for (size_t i = 0; i < dynamicParts.size(); ++i)
        {
            if (weldSlaves.count(dynamicParts[i])) continue;
            for (size_t j = i + 1; j < dynamicParts.size(); ++j)
            {
                if (weldSlaves.count(dynamicParts[j])) continue;
                resolveDynamicPair(dynamicParts[i], dynamicParts[j], cfg);
            }
        }

        applyPhysicsJoints(step);
    }

    // Humanoid: HipHeight = distance from ground plane to root center.
    // Legs are visual-only (Motor6D); root is the sole collider. After normal
    // solid resolution we snap the root so feet land at ground + 0 and the
    // torso floats at groundY + HipHeight.
    extern HumanoidInstance* runtimeHumanoid;
    if (runtimeHumanoid != nullptr && runtimeHumanoid->rootPart != nullptr)
    {
        Part* root = runtimeHumanoid->rootPart;
        float hip = runtimeHumanoid->hipHeight;
        if (hip < 0.05f) hip = 0.05f;

        // Climbing: only Parts with Truss = true override the normal ground
        // logic entirely — gravity is left
        // to updateRuntimePlayerCamera() to suspend via direct velocity
        // control (climb up/down on input), and jumping off pushes the
        // character away from the surface using climbNormal.
        Vector3 climbNormal;
        bool nearClimbSurface = findHumanoidClimbSurface(root, solid, runtimeHumanoid->climbGap, climbNormal);
        runtimeHumanoid->climbing = nearClimbSurface;
        if (nearClimbSurface)
            runtimeHumanoid->climbNormal = climbNormal;

        if (runtimeHumanoid->climbing)
        {
            // While climbing, don't run the ground snap/grounded logic below —
            // vertical movement is driven by player input instead.
            runtimeHumanoid->grounded = false;
        }
        else
        {
        Vector3 rMin, rMax;
        getPartAABB(*root, rMin, rMax);
        // Foot probe: a thin volume at (rootCenter.y - hip)
        float footY = root->cframe.position.y - hip;
        Vector3 probeMin = { rMin.x + 0.05f, footY - 0.4f, rMin.z + 0.05f };
        Vector3 probeMax = { rMax.x - 0.05f, footY + 0.25f, rMax.z - 0.05f };

        float bestTop = -1e9f;
        Part* groundPart = nullptr;
        for (Part* s : solid)
        {
            if (!s) continue;
            Vector3 sMin, sMax;
            getPartAABB(*s, sMin, sMax);
            bool overlap =
                probeMin.x < sMax.x && probeMax.x > sMin.x &&
                probeMin.y < sMax.y && probeMax.y > sMin.y &&
                probeMin.z < sMax.z && probeMax.z > sMin.z;
            if (overlap && sMax.y > bestTop)
            {
                bestTop = sMax.y;
                groundPart = s;
            }
        }

        bool onGround = (bestTop > -1e8f) && (root->velocity.y <= 2.0f);
        // Also accept near-rest contact on the root AABB itself
        if (!onGround && root->velocity.y <= 1.0f)
            onGround = partIsGrounded(root, solid, 0.4f);

        // Slope gate: approximate the ground surface's normal from the part's
        // own orientation (its local "up" axis rotated by cframe.rotation) —
        // this lets a rotated block act like a ramp even though the collision
        // itself is AABB-based. If the slope is steeper than the humanoid's
        // SlopeAngle, treat it as not walkable so the character isn't glued
        // to a surface it should be sliding/falling off of.
        if (onGround && groundPart != nullptr)
        {
            Vector3 surfaceUp = rotateVector({ 0, 1, 0 }, groundPart->cframe.rotation);
            float ny = std::clamp(surfaceUp.y, -1.0f, 1.0f);
            float slopeDeg = acosf(ny) * RAD2DEG;
            if (slopeDeg > runtimeHumanoid->slopeAngle)
                onGround = false;
        }

        runtimeHumanoid->grounded = onGround;
        if (onGround)
        {
            if (bestTop <= -1e8f)
            {
                // fallback: use root AABB bottom contact height
                for (Part* s : solid)
                {
                    if (!s) continue;
                    Vector3 sMin, sMax;
                    getPartAABB(*s, sMin, sMax);
                    if (rMin.x < sMax.x && rMax.x > sMin.x &&
                        rMin.z < sMax.z && rMax.z > sMin.z &&
                        rMin.y <= sMax.y + 0.5f && rMin.y >= sMax.y - 1.0f)
                        bestTop = std::max(bestTop, sMax.y);
                }
            }
            if (bestTop > -1e8f)
            {
                // Snap root center to groundTop + HipHeight
                float targetY = bestTop + hip;
                root->cframe.position.y = targetY;
            }
            if (root->velocity.y < 0.0f)
                root->velocity.y = 0.0f;
            root->angularVelocity = { 0, 0, 0 };
        }
        } // else (!climbing)
    }
}

#endif // BUILDING_TOOL_PHYSIC_H