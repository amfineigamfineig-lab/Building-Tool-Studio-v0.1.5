#ifndef HLXSAVE_H
#define HLXSAVE_H

#include <cstdint>
#include <cstring>
#include <fstream>
#include <vector>
#include <string>
#include <limits>
#include <filesystem>

#include <zstd.h>

#define HLX_MAGIC "HLX2"
#define HLX_VERSION 2

enum HLXCompression : uint8_t
{
    HLX_NONE = 0,
    HLX_ZSTD = 1
};

enum HLXResult
{
    HLX_OK = 0,
    HLX_FILE_NOT_FOUND,
    HLX_INVALID_HEADER,
    HLX_UNSUPPORTED_VERSION,
    HLX_UNSUPPORTED_COMPRESSION,
    HLX_READ_ERROR,
    HLX_WRITE_ERROR,
    HLX_COMPRESSION_ERROR,
    HLX_DECOMPRESSION_ERROR,
    HLX_FILE_TOO_LARGE
};

#pragma pack(push, 1)

struct HLXHeader
{
    char magic[4];              // "HLX2"
    uint8_t version;            // 2
    uint8_t compression;        // HLX_NONE or HLX_ZSTD
    uint32_t originalSize;      // Uncompressed size
    uint32_t compressedSize;    // Stored payload size
};

#pragma pack(pop)

namespace HLX
{
    inline bool Compress(
        const std::vector<uint8_t>& input,
        std::vector<uint8_t>& output,
        HLXCompression compression)
    {
        if (compression == HLX_NONE)
        {
            output = input;
            return true;
        }

        if (compression != HLX_ZSTD)
            return false;

        if (input.size() >
            static_cast<size_t>(ZSTD_compressBound(input.size())))
        {
            return false;
        }

        size_t destinationSize =
            ZSTD_compressBound(input.size());

        output.resize(destinationSize);

        size_t result = ZSTD_compress(
            output.data(),
            destinationSize,
            input.data(),
            input.size(),
            22
        );

        if (ZSTD_isError(result))
        {
            output.clear();
            return false;
        }

        output.resize(result);

        return true;
    }


    inline bool Decompress(
        const std::vector<uint8_t>& input,
        std::vector<uint8_t>& output,
        size_t originalSize,
        HLXCompression compression)
    {
        if (compression == HLX_NONE)
        {
            output = input;

            return output.size() == originalSize;
        }

        if (compression != HLX_ZSTD)
            return false;

        output.resize(originalSize);

        size_t result = ZSTD_decompress(
            output.data(),
            originalSize,
            input.data(),
            input.size()
        );

        if (ZSTD_isError(result) ||
            result != originalSize)
        {
            output.clear();
            return false;
        }

        return true;
    }




    inline HLXResult Save(
        const std::filesystem::path& filename,
        const std::vector<uint8_t>& data,
        HLXCompression compression = HLX_ZSTD
    )
    {
        TraceLog(
            LOG_INFO,
            "HLX::Save() started"
        );

        TraceLog(
            LOG_INFO,
            "Save path: %s",
            filename.u8string().c_str()
        );

        if (filename.empty())
        {
            TraceLog(
                LOG_ERROR,
                "HLX::Save() failed: filename is empty"
            );

            return HLX_FILE_NOT_FOUND;
        }

        if (
            data.size() >
            std::numeric_limits<uint32_t>::max()
        )
        {
            return HLX_FILE_TOO_LARGE;
        }

        std::vector<uint8_t> storedData;

        if (!Compress(
            data,
            storedData,
            compression
        ))
        {
            TraceLog(
                LOG_ERROR,
                "HLX compression failed"
            );

            return HLX_COMPRESSION_ERROR;
        }

        if (
            storedData.size() >
            std::numeric_limits<uint32_t>::max()
        )
        {
            return HLX_FILE_TOO_LARGE;
        }

        HLXHeader header{};

        std::memcpy(
            header.magic,
            HLX_MAGIC,
            4
        );

        header.version =
            HLX_VERSION;

        header.compression =
            static_cast<uint8_t>(
                compression
            );

        header.originalSize =
            static_cast<uint32_t>(
                data.size()
            );

        header.compressedSize =
            static_cast<uint32_t>(
                storedData.size()
            );

        TraceLog(
            LOG_INFO,
            "Opening file..."
        );

        std::ofstream file(
            filename,
            std::ios::binary |
            std::ios::out |
            std::ios::trunc
        );

        if (!file.is_open())
        {
            TraceLog(
                LOG_ERROR,
                "Could not open file: %s",
                filename.u8string().c_str()
            );

            return HLX_FILE_NOT_FOUND;
        }

        TraceLog(
            LOG_INFO,
            "File opened successfully"
        );

        // Write header

        file.write(
            reinterpret_cast<const char*>(
                &header
            ),
            static_cast<std::streamsize>(
                sizeof(HLXHeader)
            )
        );

        if (!file.good())
        {
            TraceLog(
                LOG_ERROR,
                "Failed to write HLX header"
            );

            return HLX_WRITE_ERROR;
        }

        // Write compressed data

        if (!storedData.empty())
        {
            file.write(
                reinterpret_cast<const char*>(
                    storedData.data()
                ),
                static_cast<std::streamsize>(
                    storedData.size()
                )
            );

            if (!file.good())
            {
                TraceLog(
                    LOG_ERROR,
                    "Failed to write compressed data"
                );

                return HLX_WRITE_ERROR;
            }
        }

        file.flush();

        if (!file.good())
        {
            TraceLog(
                LOG_ERROR,
                "Failed to flush file"
            );

            return HLX_WRITE_ERROR;
        }

        file.close();

        TraceLog(
            LOG_INFO,
            "HLX file saved successfully: %s",
            filename.u8string().c_str()
        );

        return HLX_OK;
    }


    inline HLXResult Load(
        const std::filesystem::path& file_path,
        std::vector<uint8_t>& output
    )
    {
        output.clear();

        std::ifstream file(
            file_path,
            std::ios::binary
        );

        if (!file.is_open())
        {
            return HLX_FILE_NOT_FOUND;
        }

        HLXHeader header{};

        file.read(
            reinterpret_cast<char*>(
                &header
            ),
            sizeof(HLXHeader)
        );

        if (
            file.gcount() !=
            static_cast<std::streamsize>(
                sizeof(HLXHeader)
            )
        )
        {
            return HLX_READ_ERROR;
        }

        if (
            std::memcmp(
                header.magic,
                HLX_MAGIC,
                4
            ) != 0
        )
        {
            return HLX_INVALID_HEADER;
        }

        if (
            header.version !=
            HLX_VERSION
        )
        {
            return HLX_UNSUPPORTED_VERSION;
        }

        if (
            header.compression >
            HLX_ZSTD
        )
        {
            return HLX_UNSUPPORTED_COMPRESSION;
        }

        std::vector<uint8_t> storedData(
            header.compressedSize
        );

        if (header.compressedSize > 0)
        {
            file.read(
                reinterpret_cast<char*>(
                    storedData.data()
                ),
                static_cast<std::streamsize>(
                    storedData.size()
                )
            );

            if (
                file.gcount() !=
                static_cast<std::streamsize>(
                    storedData.size()
                )
            )
            {
                return HLX_READ_ERROR;
            }
        }

        if (
            !Decompress(
                storedData,
                output,
                header.originalSize,
                static_cast<HLXCompression>(
                    header.compression
                )
            )
        )
        {
            return HLX_DECOMPRESSION_ERROR;
        }

        return HLX_OK;
    }


    inline HLXResult SaveJSON(
        const std::string& filename,
        const std::string& json,
        HLXCompression compression = HLX_ZSTD)
    {
        std::vector<uint8_t> data(
            json.begin(),
            json.end()
        );

        return Save(
            filename,
            data,
            compression
        );
    }


    inline HLXResult LoadJSON(
        const std::string& filename,
        std::string& json)
    {
        std::vector<uint8_t> data;

        HLXResult result =
            Load(filename, data);

        if (result != HLX_OK)
            return result;

        json.assign(
            data.begin(),
            data.end()
        );

        return HLX_OK;
    }
}

#endif

