#pragma once
// luau_api.h — Luau prelude source snippets for Building Tool runtime.
// Path: assets/Headers/luau_api.h
//
// Holds the *code* behind builtins that luau_config.json lists as keywords /
// completion words (print, warn, task, Vector3, UDim2, RunService helpers, …).
// Included from buildingTool_.cpp and injected by buildLuauDefinitions().
//
// Not a replacement for luau_config.json (that file is editor theme + completion
// word lists only). This header is the executable Luau surface.

#ifndef BUILDING_TOOL_LUAU_API_H
#define BUILDING_TOOL_LUAU_API_H

#include <string>

// ---------------------------------------------------------------------------
// Core globals: print / warn / assert / require scaffolding / tick
// ---------------------------------------------------------------------------
inline std::string buildingToolLuauCorePrelude()
{
    return R"LUAU(
-- Building Tool Luau core (from assets/Headers/luau_api.h)
local __buildingToolPrint = print
local __buildingToolWarn = warn
local function __buildingToolTrace()
    local source, line = debug.info(2, "sl")
    return tostring(source) .. ":" .. tostring(line)
end
function print(...)
    __buildingToolPrint(__buildingToolTrace() .. ":", ...)
end
function warn(...)
    __buildingToolWarn(__buildingToolTrace() .. ":", ...)
end
local __buildingToolAssert = assert
function assert(condition, ...)
    if not condition then
        __buildingToolWarn(__buildingToolTrace() .. ": assertion failed")
    end
    return __buildingToolAssert(condition, ...)
end

function tick()
    return __buildingToolClock and __buildingToolClock() or os.clock()
end
function time()
    return tick()
end

shared = shared or {}
_G = _G or {}
)LUAU";
}

// ---------------------------------------------------------------------------
// task library (wait / spawn / defer / delay)
// ---------------------------------------------------------------------------
inline std::string buildingToolLuauTaskLibrary()
{
    return R"LUAU(
task = task or {}
function task.wait(seconds)
    seconds = seconds or 0
    return coroutine.yield(seconds)
end
function task.spawn(callback, ...)
    return __buildingToolTaskSpawn(callback, ...)
end
function task.defer(callback, ...)
    return __buildingToolTaskDefer(callback, ...)
end
function task.delay(seconds, callback, ...)
    return __buildingToolTaskDelay(seconds, callback, ...)
end
-- Legacy aliases
function wait(seconds) return task.wait(seconds) end
function spawn(callback, ...) return task.spawn(callback, ...) end
function delay(seconds, callback, ...) return task.delay(seconds, callback, ...) end
)LUAU";
}

// ---------------------------------------------------------------------------
// Datatypes: Vector2, Vector3, Color3, CFrame, UDim, UDim2
// ---------------------------------------------------------------------------
inline std::string buildingToolLuauDatatypes()
{
    return R"LUAU(
-- Vector2
Vector2 = Vector2 or {}
local function __btV2(x, y)
    return setmetatable({ X = x or 0, Y = y or 0 }, {
        __add = function(a, b) return __btV2(a.X + b.X, a.Y + b.Y) end,
        __sub = function(a, b) return __btV2(a.X - b.X, a.Y - b.Y) end,
        __unm = function(a) return __btV2(-a.X, -a.Y) end,
        __mul = function(a, b)
            if type(a) == "number" then return __btV2(a * b.X, a * b.Y) end
            return __btV2(a.X * b, a.Y * b)
        end,
        __div = function(a, b) return __btV2(a.X / b, a.Y / b) end,
        __tostring = function(a) return string.format("Vector2(%.3f, %.3f)", a.X, a.Y) end,
    })
end
function Vector2.new(x, y) return __btV2(x, y) end
Vector2.zero = __btV2(0, 0)
Vector2.xAxis = __btV2(1, 0)
Vector2.yAxis = __btV2(0, 1)

-- Vector3
Vector3 = Vector3 or {}
local function __btV3(x, y, z)
    return setmetatable({ X = x or 0, Y = y or 0, Z = z or 0 }, {
        __add = function(a, b) return __btV3(a.X + b.X, a.Y + b.Y, a.Z + b.Z) end,
        __sub = function(a, b) return __btV3(a.X - b.X, a.Y - b.Y, a.Z - b.Z) end,
        __unm = function(a) return __btV3(-a.X, -a.Y, -a.Z) end,
        __mul = function(a, b)
            if type(a) == "number" then return __btV3(a * b.X, a * b.Y, a * b.Z) end
            return __btV3(a.X * b, a.Y * b, a.Z * b)
        end,
        __div = function(a, b) return __btV3(a.X / b, a.Y / b, a.Z / b) end,
        __tostring = function(a) return string.format("Vector3(%.3f, %.3f, %.3f)", a.X, a.Y, a.Z) end,
    })
end
function Vector3.new(x, y, z) return __btV3(x, y, z) end
Vector3.zero = __btV3(0, 0, 0)
Vector3.xAxis = __btV3(1, 0, 0)
Vector3.yAxis = __btV3(0, 1, 0)
Vector3.zAxis = __btV3(0, 0, 1)
Vector3.forward = __btV3(0, 0, -1)
Vector3.back = __btV3(0, 0, 1)

-- Color3
Color3 = Color3 or {}
function Color3.new(r, g, b)
    return { R = r or 0, G = g or 0, B = b or 0 }
end
function Color3.fromRGB(r, g, b)
    return Color3.new((r or 0) / 255, (g or 0) / 255, (b or 0) / 255)
end
function Color3.fromHSV(h, s, v)
    -- simplified RGB from HSV (v as value)
    h = (h or 0) % 1
    s = s or 0
    v = v or 0
    local i = math.floor(h * 6)
    local f = h * 6 - i
    local p, q, t = v * (1 - s), v * (1 - f * s), v * (1 - (1 - f) * s)
    i = i % 6
    if i == 0 then return Color3.new(v, t, p)
    elseif i == 1 then return Color3.new(q, v, p)
    elseif i == 2 then return Color3.new(p, v, t)
    elseif i == 3 then return Color3.new(p, q, v)
    elseif i == 4 then return Color3.new(t, p, v)
    else return Color3.new(v, p, q) end
end

-- CFrame (position + euler rotation proxy)
CFrame = CFrame or {}
local function __btCF(pos, rot)
    pos = pos or Vector3.zero
    rot = rot or Vector3.zero
    return setmetatable({
        Position = pos,
        Rotation = rot,
        LookVector = Vector3.forward,
        RightVector = Vector3.xAxis,
        UpVector = Vector3.yAxis,
    }, {
        __tostring = function(c)
            return string.format("CFrame(%.2f, %.2f, %.2f)", c.Position.X, c.Position.Y, c.Position.Z)
        end,
        __index = {
            Lerp = function(self, goal, alpha)
                alpha = math.clamp(alpha or 0, 0, 1)
                local p = Vector3.new(
                    self.Position.X + (goal.Position.X - self.Position.X) * alpha,
                    self.Position.Y + (goal.Position.Y - self.Position.Y) * alpha,
                    self.Position.Z + (goal.Position.Z - self.Position.Z) * alpha)
                return __btCF(p, self.Rotation)
            end,
        },
    })
end
function CFrame.new(x, y, z)
    if type(x) == "table" and x.X ~= nil then
        return __btCF(Vector3.new(x.X, x.Y, x.Z or 0))
    end
    return __btCF(Vector3.new(x or 0, y or 0, z or 0))
end
function CFrame.Angles(rx, ry, rz)
    return __btCF(Vector3.zero, Vector3.new(rx or 0, ry or 0, rz or 0))
end

-- UDim / UDim2 (Gui layout)
UDim = UDim or {}
function UDim.new(scale, offset)
    return { Scale = scale or 0, Offset = offset or 0 }
end

UDim2 = UDim2 or {}
function UDim2.new(xScale, xOffset, yScale, yOffset)
    return {
        X = UDim.new(xScale, xOffset),
        Y = UDim.new(yScale, yOffset),
        Width = UDim.new(xScale, xOffset),
        Height = UDim.new(yScale, yOffset),
    }
end
function UDim2.fromScale(x, y)
    return UDim2.new(x or 0, 0, y or 0, 0)
end
function UDim2.fromOffset(x, y)
    return UDim2.new(0, x or 0, 0, y or 0)
end

)LUAU";
}

// ---------------------------------------------------------------------------
// Enum library (subset used by UI + tween + input)
// ---------------------------------------------------------------------------
inline std::string buildingToolLuauEnums()
{
    return R"LUAU(
Enum = Enum or {}
Enum.Material = { Plastic = 0, SmoothPlastic = 1, Neon = 2, Wood = 3, Metal = 4, Concrete = 5, Glass = 6, Grass = 7, Sand = 8 }
Enum.PartType = { Block = 0, Ball = 1, Cylinder = 2, Sphere = 3, Wedge = 4, CornerWedge = 5, Cone = 6 }
Enum.KeyCode = { W = "W", A = "A", S = "S", D = "D", Space = "Space", E = "E", Q = "Q", LeftShift = "LeftShift" }
Enum.UserInputType = { MouseButton1 = 0, MouseButton2 = 1, MouseButton3 = 2, MouseMovement = 3, Keyboard = 4, Touch = 5 }
Enum.EasingStyle = { Linear = 0, Sine = 1, Quad = 2, Cubic = 3, Quart = 4, Quint = 5, Bounce = 6, Elastic = 7 }
Enum.EasingDirection = { In = 0, Out = 1, InOut = 2 }
Enum.NormalId = { Top = "Top", Bottom = "Bottom", Front = "Front", Back = "Back", Left = "Left", Right = "Right" }
Enum.Font = { SourceSans = "SourceSans", SourceSansBold = "SourceSansBold", Code = "Code", Legacy = "Legacy", Gotham = "Gotham", GothamBold = "GothamBold", GothamMedium = "GothamMedium", Roboto = "Roboto", RobotoMono = "RobotoMono" }
Enum.TextXAlignment = { Left = "Left", Center = "Center", Right = "Right" }
Enum.TextYAlignment = { Top = "Top", Center = "Center", Bottom = "Bottom" }
Enum.TextTruncate = { None = "None", AtEnd = "AtEnd" }
Enum.ScaleType = { Stretch = "Stretch", Slice = "Slice", Tile = "Tile", Fit = "Fit", Crop = "Crop" }
Enum.FillDirection = { Horizontal = "Horizontal", Vertical = "Vertical" }
Enum.HorizontalAlignment = { Left = "Left", Center = "Center", Right = "Right" }
Enum.VerticalAlignment = { Top = "Top", Center = "Center", Bottom = "Bottom" }
Enum.SortOrder = { LayoutOrder = "LayoutOrder", Name = "Name" }
Enum.ApplyStrokeMode = { Contextual = "Contextual", Border = "Border" }
Enum.LineJoinMode = { Round = "Round", Bevel = "Bevel", Miter = "Miter" }
Enum.BorderMode = { Outline = "Outline", Middle = "Middle", Inset = "Inset" }
Enum.AutomaticSize = { None = "None", X = "X", Y = "Y", XY = "XY" }
Enum.SizeConstraint = { RelativeXY = "RelativeXY", RelativeXX = "RelativeXX", RelativeYY = "RelativeYY" }
Enum.ScrollingDirection = { X = "X", Y = "Y", XY = "XY" }
Enum.ElasticBehavior = { WhenNeeded = "WhenNeeded", Always = "Always", Never = "Never" }
Enum.ScrollBarInset = { None = "None", ScrollBar = "ScrollBar", Always = "Always" }
Enum.SurfaceGuiSizingMode = { PixelsPerStud = "PixelsPerStud", FixedSize = "FixedSize" }
Enum.AspectType = { FitWithinMaxSize = "FitWithinMaxSize", ScaleWithParentSize = "ScaleWithParentSize" }
Enum.DominantAxis = { Width = "Width", Height = "Height" }
Enum.CameraType = { Fixed = "Fixed", Watch = "Watch", Attach = "Attach", Track = "Track", Follow = "Follow", Custom = "Custom", Scriptable = "Scriptable" }
Enum.HumanoidStateType = { Running = "Running", Jumping = "Jumping", Freefall = "Freefall", Landed = "Landed", Seated = "Seated", Dead = "Dead", Physics = "Physics" }
Enum.Shape = Enum.PartType
)LUAU";
}

// ---------------------------------------------------------------------------
// RunService method stubs (IsClient / IsServer / IsStudio / signals filled by host)
// ---------------------------------------------------------------------------
inline std::string buildingToolLuauRunServiceApi()
{
    return R"LUAU(
-- RunService API surface (host may replace the table; methods are always functions)
RunService = RunService or {}
function RunService:IsClient()
    return __buildingToolIsClient == true
end
function RunService:IsServer()
    return __buildingToolIsClient ~= true
end
function RunService:IsStudio()
    return true
end
function RunService:IsRunning()
    return true
end
)LUAU";
}

// ---------------------------------------------------------------------------
// GuiObject property name list (documentation + completion alignment)
// ---------------------------------------------------------------------------
inline std::string buildingToolLuauGuiPropertyNotes()
{
    return R"LUAU(
-- GuiObject common properties (Properties panel + instance proxy):
-- Active, AnchorPoint, AutomaticSize, BackgroundColor3, BackgroundTransparency,
-- BorderColor3, BorderMode, BorderSizePixel, ClipsDescendants, GroupTransparency,
-- Interactable, LayoutOrder, Position, Rotation, Size, SizeConstraint, Visible, ZIndex,
-- Selectable, SelectionOrder
--
-- TextLabel / TextButton / TextBox:
-- Text, TextColor3, TextSize, TextTransparency, TextScaled, TextWrapped, Font,
-- TextXAlignment, TextYAlignment, TextTruncate, RichText, TextStrokeColor3,
-- TextStrokeTransparency, LineHeight, MaxVisibleGraphemes
-- TextBox: PlaceholderText, PlaceholderColor3, ClearTextOnFocus, MultiLine, TextEditable
--
-- ImageLabel / ImageButton:
-- Image, ImageColor3, ImageTransparency, ScaleType, ImageRectOffset, ImageRectSize, SliceScale
-- ImageButton: HoverImage, PressedImage
-- GuiButton: AutoButtonColor, Modal
--
-- ScrollingFrame:
-- ScrollingEnabled, CanvasSize (UDim2), CanvasPosition, ScrollBarThickness,
-- ScrollBarImageColor3, ScrollBarImageTransparency, ScrollingDirection,
-- ElasticBehavior, AutomaticCanvasSize, HorizontalScrollBarInset, VerticalScrollBarInset
--
-- LayerCollector (ScreenGui / SurfaceGui / BillboardGui):
-- Enabled, DisplayOrder, ResetOnSpawn, IgnoreGuiInset, ClipToDeviceSafeArea,
-- Active, AlwaysOnTop, Adornee, MaxDistance, Brightness, LightInfluence
-- SurfaceGui: Face, PixelsPerStud, CanvasSize, SizingMode, ZOffset, ClipsDescendants
-- BillboardGui: Size, StudsOffset, DistanceLowerLimit, DistanceUpperLimit
--
-- UICorner.CornerRadius | UIStroke.Thickness/Color/Transparency/ApplyStrokeMode/LineJoinMode
-- UIListLayout.FillDirection/HorizontalAlignment/VerticalAlignment/SortOrder/Padding/Wraps
-- UIPadding.PaddingLeft/Right/Top/Bottom | UIGridLayout.CellSize/CellPadding/FillDirectionMaxCells
-- UIAspectRatioConstraint.AspectRatio/AspectType/DominantAxis
)LUAU";
}

// ---------------------------------------------------------------------------
// Gui class name table + Instance.new helper surface for completion / scripts
// ---------------------------------------------------------------------------
inline std::string buildingToolLuauGuiDefinitions()
{
    return R"LUAU(
-- Supported 2D GUI class names (Instance.new / insert menu)
local __btGuiClasses = {
    ScreenGui = true, SurfaceGui = true, BillboardGui = true,
    Frame = true, ScrollingFrame = true,
    TextLabel = true, ImageLabel = true,
    TextButton = true, ImageButton = true, TextBox = true,
    UICorner = true, UIListLayout = true, UIStroke = true,
    UIPadding = true, UIGridLayout = true, UIAspectRatioConstraint = true,
}

-- Default property templates (documentation; host proxy applies real defaults)
local __btGuiDefaults = {
    ScreenGui = { Enabled = true, DisplayOrder = 0, ResetOnSpawn = true, IgnoreGuiInset = false },
    BillboardGui = { Enabled = true, AlwaysOnTop = false, MaxDistance = 0, Size = UDim2.new(0, 200, 0, 50), StudsOffset = Vector3.new(0, 0, 0) },
    SurfaceGui = { Enabled = true, Face = "Front", PixelsPerStud = 50, AlwaysOnTop = false, LightInfluence = 0 },
    Frame = { Size = UDim2.new(0, 200, 0, 50), BackgroundColor3 = Color3.fromRGB(255, 255, 255), BackgroundTransparency = 0, Visible = true },
    TextLabel = { Text = "Label", TextSize = 14, TextColor3 = Color3.fromRGB(0, 0, 0), BackgroundTransparency = 1 },
    TextButton = { Text = "Button", TextSize = 14, AutoButtonColor = true },
    TextBox = { Text = "", PlaceholderText = "", ClearTextOnFocus = true, MultiLine = false },
    ImageLabel = { Image = "", ImageColor3 = Color3.fromRGB(255, 255, 255), ScaleType = "Stretch" },
    ImageButton = { Image = "", HoverImage = "", PressedImage = "", AutoButtonColor = true },
    ScrollingFrame = { CanvasSize = UDim2.new(0, 0, 0, 0), ScrollingEnabled = true, ScrollBarThickness = 12 },
    UICorner = { CornerRadius = UDim.new(0, 8) },
    UIStroke = { Thickness = 1, Color = Color3.fromRGB(0, 0, 0), Transparency = 0 },
    UIListLayout = { FillDirection = "Vertical", SortOrder = "LayoutOrder", Padding = UDim.new(0, 0) },
    UIPadding = {},
    UIGridLayout = { CellSize = UDim2.new(0, 100, 0, 100), CellPadding = UDim2.new(0, 4, 0, 4) },
    UIAspectRatioConstraint = { AspectRatio = 1 },
}

-- Color3 helpers already provided by datatypes; ensure fromRGB / fromHSV aliases
if Color3 and not Color3.fromHSV then
    function Color3.fromHSV(h, s, v)
        -- host may replace; simple fallback
        return Color3.new(v, v, v)
    end
end

-- UDim constructor alias used by UICorner defaults
UDim = UDim or {}
function UDim.new(scale, offset)
    return { Scale = scale or 0, Offset = offset or 0 }
end
)LUAU";
}

inline std::string buildingToolLuauHmath()
{
    return R"LUAU(
hmath = hmath or {}

----------------------------------------------------------------
-- Math helpers
----------------------------------------------------------------

local function clamp(x, minValue, maxValue)
	if minValue > maxValue then
		minValue, maxValue = maxValue, minValue
	end

	return math.max(minValue, math.min(maxValue, x))
end

local function lerp(a, b, t)
	return a + (b - a) * t
end

local function inverseLerp(a, b, value)
	if a == b then
		return 0
	end

	return (value - a) / (b - a)
end

local function remap(value, inMin, inMax, outMin, outMax)
	if inMin == inMax then
		return outMin
	end

	return outMin + (value - inMin) / (inMax - inMin) * (outMax - outMin)
end

local function sign(x)
	if x > 0 then
		return 1
	elseif x < 0 then
		return -1
	end

	return 0
end

local function step(edge, x)
	return x < edge and 0 or 1
end

local function smoothstep(edge0, edge1, x)
	if edge0 == edge1 then
		return x < edge0 and 0 or 1
	end

	local t = clamp((x - edge0) / (edge1 - edge0), 0, 1)
	return t * t * (3 - 2 * t)
end

local function smootherstep(edge0, edge1, x)
	if edge0 == edge1 then
		return x < edge0 and 0 or 1
	end

	local t = clamp((x - edge0) / (edge1 - edge0), 0, 1)

	return t * t * t * (t * (t * 6 - 15) + 10)
end

local function fract(x)
	return x - math.floor(x)
end

local function trunc(x)
	if x >= 0 then
		return math.floor(x)
	end

	return math.ceil(x)
end

local function deg(x)
	return x * 180 / math.pi
end

local function rad(x)
	return x * math.pi / 180
end

local function hypot(a, b)
	return math.sqrt(a * a + b * b)
end

local function square(x)
	return x * x
end

local function cube(x)
	return x * x * x
end

local function average(a, b)
	return (a + b) / 2
end

local function cbrt(x)
	if math.cbrt then
		return math.cbrt(x)
	end

	if x < 0 then
		return -((-x) ^ (1 / 3))
	end

	return x ^ (1 / 3)
end


----------------------------------------------------------------
-- atan2 fallback
----------------------------------------------------------------

local function atan2(y, x)
	if math.atan2 then
		return math.atan2(y, x)
	end

	if x > 0 then
		return math.atan(y / x)
	elseif x < 0 and y >= 0 then
		return math.atan(y / x) + math.pi
	elseif x < 0 and y < 0 then
		return math.atan(y / x) - math.pi
	elseif x == 0 and y > 0 then
		return math.pi / 2
	elseif x == 0 and y < 0 then
		return -math.pi / 2
	end

	return 0
end


----------------------------------------------------------------
-- Hyperbolic functions
----------------------------------------------------------------

local function sinh(x)
	if math.sinh then
		return math.sinh(x)
	end

	return (math.exp(x) - math.exp(-x)) / 2
end

local function cosh(x)
	if math.cosh then
		return math.cosh(x)
	end

	return (math.exp(x) + math.exp(-x)) / 2
end

local function tanh(x)
	if math.tanh then
		return math.tanh(x)
	end

	local e2x = math.exp(2 * x)

	return (e2x - 1) / (e2x + 1)
end

local function asinh(x)
	if math.asinh then
		return math.asinh(x)
	end

	return math.log(x + math.sqrt(x * x + 1))
end

local function acosh(x)
	if math.acosh then
		return math.acosh(x)
	end

	return math.log(x + math.sqrt(x * x - 1))
end

local function atanh(x)
	if math.atanh then
		return math.atanh(x)
	end

	return 0.5 * math.log((1 + x) / (1 - x))
end


----------------------------------------------------------------
-- Functions exposed to formulas
----------------------------------------------------------------

local functions = {
	-- Basic
	abs = math.abs,
	sign = sign,
	min = math.min,
	max = math.max,

	floor = math.floor,
	ceil = math.ceil,
	trunc = trunc,

	sqrt = math.sqrt,
	cbrt = cbrt,

	-- Powers / logarithms
	pow = function(a, b)
		return a ^ b
	end,

	exp = math.exp,
	log = math.log,
	ln = math.log,

	log10 = function(x)
		return math.log(x, 10)
	end,

	-- Trigonometry
	sin = math.sin,
	cos = math.cos,
	tan = math.tan,

	asin = math.asin,
	acos = math.acos,
	atan = math.atan,
	atan2 = atan2,

	-- Hyperbolic
	sinh = sinh,
	cosh = cosh,
	tanh = tanh,
	asinh = asinh,
	acosh = acosh,
	atanh = atanh,

	-- Angles
	deg = deg,
	rad = rad,

	-- Interpolation
	clamp = clamp,
	lerp = lerp,
	inverseLerp = inverseLerp,
	remap = remap,

	-- Curves
	step = step,
	smoothstep = smoothstep,
	smootherstep = smootherstep,

	-- Miscellaneous
	fract = fract,
	hypot = hypot,
	distance = hypot,

	square = square,
	cube = cube,
	average = average,

	neg = function(x)
		return -x
	end,

	recip = function(x)
		return 1 / x
	end,

	mod = function(a, b)
		return a % b
	end,

	fmod = math.fmod,

	-- Random
	random = function(a, b)
		if a == nil then
			return math.random()
		elseif b == nil then
			return math.random(a)
		end

		return math.random(a, b)
	end,

	randomf = function(a, b)
		a = a or 0
		b = b or 1

		return a + math.random() * (b - a)
	end,
}


----------------------------------------------------------------
-- Constants
----------------------------------------------------------------

local constants = {
	pi = math.pi,
	tau = math.pi * 2,
	e = math.exp(1),

	inf = math.huge,

	phi = (1 + math.sqrt(5)) / 2,

	sqrt2 = math.sqrt(2),
	sqrt3 = math.sqrt(3),

	ln2 = math.log(2),
	ln10 = math.log(10),

	zero = 0,
	one = 1,
}


----------------------------------------------------------------
-- Parser
----------------------------------------------------------------

function hmath.formula(formulaString, ...)
	local args = { ... }

	local pos = 1
	local length = #formulaString

	local function errorAt(message)
		error(string.format(
			"hmath.formula: %s at position %d\n%s\n%s^",
			message,
			pos,
			formulaString,
			string.rep(" ", pos - 1)
		), 0)
	end

	local function peek(offset)
		offset = offset or 0

		local p = pos + offset

		if p > length then
			return nil
		end

		return formulaString:sub(p, p)
	end

	local function consume()
		local c = peek()

		pos += 1

		return c
	end

	local function match(text)
		if formulaString:sub(pos, pos + #text - 1) == text then
			pos += #text
			return true
		end

		return false
	end

	local function skipWhitespace()
		while pos <= length do
			local c = peek()

			if c == " "
				or c == "\t"
				or c == "\n"
				or c == "\r"
			then
				pos += 1
			else
				break
			end
		end
	end

	local function isDigit(c)
		return c ~= nil and c:match("%d") ~= nil
	end

	local function isAlpha(c)
		return c ~= nil and c:match("[%a_]") ~= nil
	end

	local function isAlphaNumeric(c)
		return c ~= nil and c:match("[%w_]") ~= nil
	end


	----------------------------------------------------------------
	-- Forward declarations
	----------------------------------------------------------------

	local parseExpression
	local parseComparison
	local parseBitOr
	local parseBitXor
	local parseBitAnd
	local parseShift
	local parseAdditive
	local parseMultiplicative
	local parseUnary
	local parsePower
	local parsePrimary


	----------------------------------------------------------------
	-- Argument: \[n]
	----------------------------------------------------------------

	local function parseArgument()
		if consume() ~= "\\" then
			errorAt("Expected argument")
		end

		if consume() ~= "[" then
			errorAt("Expected '[' after '\\'")
		end

		skipWhitespace()

		local start = pos

		while isDigit(peek()) do
			consume()
		end

		if start == pos then
			errorAt("Expected argument index")
		end

		local index = tonumber(formulaString:sub(start, pos - 1))

		skipWhitespace()

		if consume() ~= "]" then
			errorAt("Expected ']'")
		end

		local value = args[index]

		if value == nil then
			errorAt("Missing argument \\[" .. index .. "]")
		end

		if type(value) ~= "number" then
			errorAt(string.format(
				"Argument \\[%d] must be a number, got %s",
				index,
				type(value)
			))
		end

		return value
	end


	----------------------------------------------------------------
	-- Number
	----------------------------------------------------------------

	local function parseNumber()
		local start = pos

		while isDigit(peek()) do
			consume()
		end

		if peek() == "." then
			consume()

			while isDigit(peek()) do
				consume()
			end
		end

		if peek() == "e" or peek() == "E" then
			consume()

			if peek() == "+" or peek() == "-" then
				consume()
			end

			local exponentStart = pos

			while isDigit(peek()) do
				consume()
			end

			if exponentStart == pos then
				errorAt("Invalid scientific notation")
			end
		end

		local text = formulaString:sub(start, pos - 1)
		local value = tonumber(text)

		if value == nil then
			errorAt("Invalid number '" .. text .. "'")
		end

		return value
	end


	----------------------------------------------------------------
	-- Identifier
	----------------------------------------------------------------

	local function parseIdentifier()
		local start = pos

		consume()

		while isAlphaNumeric(peek()) do
			consume()
		end

		return formulaString:sub(start, pos - 1)
	end


	----------------------------------------------------------------
	-- Function call
	----------------------------------------------------------------

	local function parseFunction(name)
		local fn = functions[name]

		if not fn then
			errorAt("Unknown function '" .. name .. "'")
		end

		if consume() ~= "(" then
			errorAt("Expected '('")
		end

		skipWhitespace()

		local values = {}

		if peek() ~= ")" then
			while true do
				values[#values + 1] = parseExpression()

				skipWhitespace()

				if peek() == "," then
					consume()
					skipWhitespace()
				else
					break
				end
			end
		end

		if consume() ~= ")" then
			errorAt("Expected ')' after function arguments")
		end

		local success, result = pcall(fn, table.unpack(values))

		if not success then
			errorAt(string.format(
				"Error calling function '%s': %s",
				name,
				tostring(result)
			))
		end

		if type(result) ~= "number" then
			errorAt(string.format(
				"Function '%s' returned %s instead of a number",
				name,
				type(result)
			))
		end

		return result
	end


	----------------------------------------------------------------
	-- Primary
	--
	-- number
	-- argument
	-- constant
	-- function(...)
	-- (expression)
	----------------------------------------------------------------

	function parsePrimary()
		skipWhitespace()

		local c = peek()

		if c == "\\" then
			return parseArgument()
		end

		if isDigit(c)
			or (c == "." and isDigit(peek(1)))
		then
			return parseNumber()
		end

		if c == "(" then
			consume()

			local value = parseExpression()

			skipWhitespace()

			if consume() ~= ")" then
				errorAt("Expected ')'")
			end

			return value
		end

		if isAlpha(c) then
			local name = parseIdentifier()

			skipWhitespace()

			if peek() == "(" then
				return parseFunction(name)
			end

			local value = constants[name]

			if value ~= nil then
				return value
			end

			errorAt("Unknown identifier '" .. name .. "'")
		end

		errorAt("Expected number, argument, constant, function, or '('")
	end


	----------------------------------------------------------------
	-- Power
	--
	-- ** is exponentiation.
	--
	-- Right associative:
	--   2 ** 3 ** 2
	--   = 2 ** (3 ** 2)
	----------------------------------------------------------------

	function parsePower()
		local left = parsePrimary()

		skipWhitespace()

		if match("**") then
			local right = parseUnary()

			return left ^ right
		end

		return left
	end


	----------------------------------------------------------------
	-- Unary
	--
	-- +x
	-- -x
	-- ~x    bitwise NOT
	----------------------------------------------------------------

	function parseUnary()
		skipWhitespace()

		local c = peek()

		if c == "-" then
			consume()
			return -parseUnary()
		end

		if c == "+" then
			consume()
			return parseUnary()
		end

		if c == "~" then
			consume()

			local value = parseUnary()

			return bit32.bnot(value)
		end

		return parsePower()
	end


	----------------------------------------------------------------
	-- Multiplication / Division / Modulo
	----------------------------------------------------------------

	function parseMultiplicative()
		local value = parseUnary()

		while true do
			skipWhitespace()

			local c = peek()

			if c == "*" and peek(1) ~= "*" then
				consume()

				value *= parseUnary()

			elseif c == "/" then
				consume()

				value /= parseUnary()

			elseif c == "%" then
				consume()

				value %= parseUnary()

			-- Implicit multiplication:
			--
			-- 2pi
			-- 2(3 + 4)
			-- 2sqrt(9)
			--
			elseif c == "("
				or c == "\\"
				or isAlpha(c)
				or isDigit(c)
			then
				value *= parseUnary()

			else
				break
			end
		end

		return value
	end


	----------------------------------------------------------------
	-- Addition / Subtraction
	----------------------------------------------------------------

	function parseAdditive()
		local value = parseMultiplicative()

		while true do
			skipWhitespace()

			local c = peek()

			if c == "+" then
				consume()

				value += parseMultiplicative()

			elseif c == "-" then
				consume()

				value -= parseMultiplicative()

			else
				break
			end
		end

		return value
	end


	----------------------------------------------------------------
	-- Shift
	--
	-- x << n
	-- x >> n
	----------------------------------------------------------------

	function parseShift()
		local value = parseAdditive()

		while true do
			skipWhitespace()

			if match("<<") then
				value = bit32.lshift(
					value,
					parseAdditive()
				)

			elseif match(">>") then
				value = bit32.rshift(
					value,
					parseAdditive()
				)

			else
				break
			end
		end

		return value
	end


	----------------------------------------------------------------
	-- Bitwise AND
	--
	-- x & y
	----------------------------------------------------------------

	function parseBitAnd()
		local value = parseShift()

		while true do
			skipWhitespace()

			if peek() == "&" then
				consume()

				value = bit32.band(
					value,
					parseShift()
				)
			else
				break
			end
		end

		return value
	end


	----------------------------------------------------------------
	-- Bitwise XOR
	--
	-- x ^ y
	----------------------------------------------------------------

	function parseBitXor()
		local value = parseBitAnd()

		while true do
			skipWhitespace()

			if peek() == "^" then
				consume()

				value = bit32.bxor(
					value,
					parseBitAnd()
				)
			else
				break
			end
		end

		return value
	end


	----------------------------------------------------------------
	-- Bitwise OR
	--
	-- x | y
	----------------------------------------------------------------

	function parseBitOr()
		local value = parseBitXor()

		while true do
			skipWhitespace()

			if peek() == "|" then
				consume()

				value = bit32.bor(
					value,
					parseBitXor()
				)
			else
				break
			end
		end

		return value
	end


	----------------------------------------------------------------
	-- Comparisons
	--
	-- < <= > >= == ~=
	--
	-- Results are numeric:
	--   true  -> 1
	--   false -> 0
	----------------------------------------------------------------

	local function boolNumber(value)
		return value and 1 or 0
	end

	function parseComparison()
		local value = parseBitOr()

		while true do
			skipWhitespace()

			if match("<=") then
				value = boolNumber(value <= parseBitOr())

			elseif match(">=") then
				value = boolNumber(value >= parseBitOr())

			elseif match("==") then
				value = boolNumber(value == parseBitOr())

			elseif match("~=") then
				value = boolNumber(value ~= parseBitOr())

			elseif peek() == "<" then
				consume()

				value = boolNumber(value < parseBitOr())

			elseif peek() == ">" then
				consume()

				value = boolNumber(value > parseBitOr())

			else
				break
			end
		end

		return value
	end


	----------------------------------------------------------------
	-- Expression
	----------------------------------------------------------------

	function parseExpression()
		return parseComparison()
	end


	----------------------------------------------------------------
	-- Start parsing
	----------------------------------------------------------------

	skipWhitespace()

	if pos > length then
		errorAt("Empty expression")
	end

	local result = parseExpression()

	skipWhitespace()

	if pos <= length then
		errorAt("Unexpected character '" .. tostring(peek()) .. "'")
	end

	return result
end

)LUAU";
}

// Concatenate all static prelude chunks (host still appends instance tree + signals).
inline std::string buildingToolLuauStaticPrelude()
{
    return buildingToolLuauCorePrelude()
        + buildingToolLuauTaskLibrary()
        + buildingToolLuauDatatypes()
        + buildingToolLuauEnums()
        + buildingToolLuauRunServiceApi()
        + buildingToolLuauGuiPropertyNotes()
        + buildingToolLuauGuiDefinitions()
        + buildingToolLuauHmath();
}

#endif // BUILDING_TOOL_LUAU_API_H